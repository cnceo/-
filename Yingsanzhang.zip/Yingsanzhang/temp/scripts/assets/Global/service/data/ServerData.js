"use strict";
cc._RFpush(module, '2f5c5TC37tGWaY7hIDx2KBL', 'ServerData');
// Global/service/data/ServerData.js

cc.Class({
    "extends": cc.Component,

    properties: {
        servers: []
    },

    // use this for initialization
    onLoad: function onLoad() {}

});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();