"use strict";
cc._RFpush(module, '9074bEc4iJJ0oTsI756F/cE', 'main');
// Global/service/controller/main.js

var GlobalManager = require("GlobalManager");
var constDef = require("ConstDef");

cc.Class({
    "extends": cc.Component,

    properties: {},

    onLoad: function onLoad() {
        GlobalManager.instance.confData.loadConfJson();
        cc.director.loadScene("logon");
    }

});

cc._RFpop();