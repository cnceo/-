"use strict";
cc._RFpush(module, 'c73deC76fFDiqHtRr4Ojdz0', 'ccShader_Default_Vert_noMVP');
// Global/qisuLib/Show/Shaders/ccShader_Default_Vert_noMVP.js

module.exports = "\nattribute vec4 a_position;\n attribute vec2 a_texCoord;\n attribute vec4 a_color;\n varying vec2 v_texCoord;\n varying vec4 v_fragmentColor;\n void main()\n {\n     gl_Position = CC_PMatrix  * a_position;\n     v_fragmentColor = a_color;\n     v_texCoord = a_texCoord;\n }\n";

cc._RFpop();