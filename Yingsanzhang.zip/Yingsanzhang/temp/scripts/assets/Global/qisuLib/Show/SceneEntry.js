"use strict";
cc._RFpush(module, 'f31844jA4dM842dZR9v2gMX', 'SceneEntry');
// Global/qisuLib/Show/SceneEntry.js

cc.Class({
    'extends': cc.Component,

    properties: {
        menuAnim: {
            'default': null,
            type: cc.Animation
        }
    },
    onLoad: function onLoad() {
        this.menuAnim.play('menu_reset');

        this.scheduleOnce((function () {
            this.menuAnim.play('menu_intro');
        }).bind(this), 0.5);
    },

    start: function start() {}
});

cc._RFpop();