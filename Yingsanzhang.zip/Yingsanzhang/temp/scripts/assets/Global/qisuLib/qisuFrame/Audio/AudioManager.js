"use strict";
cc._RFpush(module, 'cbad3omgGJKpKsR8Tf8+ykv', 'AudioManager');
// Global/qisuLib/qisuFrame/Audio/AudioManager.js

cc.Class({
    "extends": cc.Component,

    properties: {
        strSoundFilePath: "resources/common/audio/"
    },

    onLoad: function onLoad() {},

    setSoundFilePath: function setSoundFilePath(val) {
        this.strSoundFilePath = val;
    },

    play: function play(clip, isLoop) {
        var url = clip;
        if (typeof clip == "string") {
            url = cc.url.raw(this.strSoundFilePath + clip);
        }

        cc.audioEngine.playMusic(url, isLoop);
    },

    playEffect: function playEffect(clip, isLoop) {
        var url = clip;
        if (typeof clip == "string") {
            url = cc.url.raw(this.strSoundFilePath + clip);
        }

        cc.audioEngine.playEffect(url, isLoop);
    },

    pause: function pause() {
        cc.audioEngine.pauseMusic();
    },

    stop: function stop() {
        cc.audioEngine.stopMusic();
    },

    resume: function resume() {
        cc.audioEngine.resumeMusic();
    }

});

cc._RFpop();