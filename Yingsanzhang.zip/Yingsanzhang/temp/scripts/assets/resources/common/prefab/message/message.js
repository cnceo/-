"use strict";
cc._RFpush(module, 'bb486skCDFA85GWsdJCBBjw', 'message');
// resources/common/prefab/message/message.js

cc.Class({
    "extends": cc.Component,

    properties: {},

    onLoad: function onLoad() {
        var ctx = this.node.getComponent(cc.Graphics);
        ctx.moveTo(0, 0);
        ctx.lineTo(1080, 0);

        ctx.stroke();
    },
    initInfo: function initInfo(data) {}
});

cc._RFpop();