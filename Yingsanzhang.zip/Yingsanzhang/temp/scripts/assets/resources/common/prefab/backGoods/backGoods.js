"use strict";
cc._RFpush(module, 'e159bGHAD9Dp6vkYwr15QB7', 'backGoods');
// resources/common/prefab/backGoods/backGoods.js

cc.Class({
    "extends": cc.Component,

    properties: {
        LabelName: cc.Label
    },
    onLoad: function onLoad() {},
    initInfo: function initInfo(data) {
        this.LabelName.string = data.name;
    }
});

cc._RFpop();