cc.Class({
    "extends": cc.Component,

    properties: {
        LabelName: cc.Label
    },
    onLoad: function onLoad() {},
    initInfo: function initInfo(data) {
        this.LabelName.string = data.name;
    }
});