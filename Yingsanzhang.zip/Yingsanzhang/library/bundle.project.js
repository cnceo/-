require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"AudioManager":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'cbad3omgGJKpKsR8Tf8+ykv', 'AudioManager');
// Global/qisuLib/qisuFrame/Audio/AudioManager.js

cc.Class({
    "extends": cc.Component,

    properties: {
        strSoundFilePath: "resources/common/audio/"
    },

    onLoad: function onLoad() {},

    setSoundFilePath: function setSoundFilePath(val) {
        this.strSoundFilePath = val;
    },

    play: function play(clip, isLoop) {
        var url = clip;
        if (typeof clip == "string") {
            url = cc.url.raw(this.strSoundFilePath + clip);
        }

        cc.audioEngine.playMusic(url, isLoop);
    },

    playEffect: function playEffect(clip, isLoop) {
        var url = clip;
        if (typeof clip == "string") {
            url = cc.url.raw(this.strSoundFilePath + clip);
        }

        cc.audioEngine.playEffect(url, isLoop);
    },

    pause: function pause() {
        cc.audioEngine.pauseMusic();
    },

    stop: function stop() {
        cc.audioEngine.stopMusic();
    },

    resume: function resume() {
        cc.audioEngine.resumeMusic();
    }

});

cc._RFpop();
},{}],"Avg_Black_White":[function(require,module,exports){
"use strict";
cc._RFpush(module, '8d8b2ipKEFPVaL3QrYyyDQc', 'Avg_Black_White');
// Global/qisuLib/Show/Avg_Black_White.js

var _default_vert = require("ccShader_Default_Vert");
var _default_vert_no_mvp = require("ccShader_Default_Vert_noMVP");
var _black_white_frag = require("ccShader_Avg_Black_White_Frag");

var EffectBlackWhite = cc.Class({
    "extends": cc.Component,

    properties: {
        isAllChildrenUser: false
    },

    onLoad: function onLoad() {
        this._use();
    },

    _use: function _use() {
        this._program = new cc.GLProgram();
        if (cc.sys.isNative) {
            cc.log("use native GLProgram");
            this._program.initWithString(_default_vert_no_mvp, _black_white_frag);
            this._program.link();
            this._program.updateUniforms();
        } else {
            this._program.initWithVertexShaderByteArray(_default_vert, _black_white_frag);
            this._program.addAttribute(cc.macro.ATTRIBUTE_NAME_POSITION, cc.macro.VERTEX_ATTRIB_POSITION);
            this._program.addAttribute(cc.macro.ATTRIBUTE_NAME_COLOR, cc.macro.VERTEX_ATTRIB_COLOR);
            this._program.addAttribute(cc.macro.ATTRIBUTE_NAME_TEX_COORD, cc.macro.VERTEX_ATTRIB_TEX_COORDS);
            this._program.link();
            this._program.updateUniforms();
        }
        this.setProgram(this.node._sgNode, this._program);
    },
    setProgram: function setProgram(node, program) {

        if (cc.sys.isNative) {
            var glProgram_state = cc.GLProgramState.getOrCreateWithGLProgram(program);
            node.setGLProgramState(glProgram_state);
        } else {
            node.setShaderProgram(program);
        }

        var children = node.children;
        if (!children) return;

        for (var i = 0; i < children.length; i++) {
            this.setProgram(children[i], program);
        }
    }

});

cc.BlackWhite = module.exports = EffectBlackWhite;

cc._RFpop();
},{"ccShader_Avg_Black_White_Frag":"ccShader_Avg_Black_White_Frag","ccShader_Default_Vert":"ccShader_Default_Vert","ccShader_Default_Vert_noMVP":"ccShader_Default_Vert_noMVP"}],"ButtonScaler":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'ee347sqTNxDPLqpsYRivhQU', 'ButtonScaler');
// Global/qisuLib/Show/ButtonScaler.js

var GlobalManager = require("GlobalManager");

cc.Class({
    "extends": cc.Component,

    properties: {
        pressedScale: 0.8,
        transDuration: 0.1,

        strSound: "button.mp3"
    },
    onLoad: function onLoad() {
        var self = this;
        self.initScale = this.node.scale;
        self.scaleDownAction = cc.scaleTo(self.transDuration, self.pressedScale);
        self.scaleUpAction = cc.scaleTo(self.transDuration, self.initScale);
        function onTouchDown(event) {
            this.stopAllActions();
            this.runAction(self.scaleDownAction);
        }
        function onTouchEnd(event) {

            GlobalManager.instance.audio.playEffect(self.strSound, false);

            this.stopAllActions();
            this.runAction(self.scaleUpAction);
        }
        function onTouchUp(event) {
            this.stopAllActions();
            this.runAction(self.scaleUpAction);
        }
        this.node.on('touchstart', onTouchDown, this.node);
        this.node.on('touchend', onTouchEnd, this.node);
        this.node.on('touchmove', onTouchUp, this.node);
        this.node.on('touchcancel', onTouchUp, this.node);
    }
});

cc._RFpop();
},{"GlobalManager":"GlobalManager"}],"ConfData":[function(require,module,exports){
"use strict";
cc._RFpush(module, '0e575nGOnJBupo5xLDm3FiP', 'ConfData');
// Global/service/data/ConfData.js

var ConfData = cc.Class({
    "extends": cc.Component,

    properties: {
        // ---------------------------------
        bHoldPlayersInfo: false,

        arrConfPash: [] },
    // {path / content}
    statics: {
        JsonIndex: null
    },

    loadCallBack: function loadCallBack(index, callback) {

        var self = this;
        if (index >= self.arrConfPash.length) {
            callback();
            return;
        }
        cc.loader.loadRes(self.arrConfPash[index].path, function (error, resObj) {
            self.arrConfPash[index].content = resObj;
            self.loadCallBack(index + 1, callback);
        });
    },

    onLoad: function onLoad() {
        ConfData.JsonIndex = cc.Enum({
            OTHER: 0,
            T_GAME_KIND: 1,
            T_GAME_NODE: 2,
            T_GAME_ROOM: 3,
            T_GAME_TYPE: 4,
            T_ROOM_AREA: 5,
            T_SERVER_INFO: 6,
            T_GOODS: 7
        });
    },
    callback: function callback() {},
    loadConfJson: function loadConfJson(callback) {
        this.arrConfPash.push({ "path": "common/jsonConf/Platform/other", "content": null });
        this.arrConfPash.push({ "path": "common/jsonConf/Platform/t_game_kind", "content": null });
        this.arrConfPash.push({ "path": "common/jsonConf/Platform/t_game_node", "content": null });
        this.arrConfPash.push({ "path": "common/jsonConf/Platform/t_game_room", "content": null });
        this.arrConfPash.push({ "path": "common/jsonConf/Platform/t_game_type", "content": null });
        this.arrConfPash.push({ "path": "common/jsonConf/Platform/t_room_area", "content": null });
        this.arrConfPash.push({ "path": "common/jsonConf/Platform/t_server_info", "content": null });
        this.arrConfPash.push({ "path": "common/jsonConf/Platform/t_goods", "content": null });
        this.loadCallBack(0, this.callback);
    },

    getConfJson: function getConfJson(index) {
        return this.arrConfPash[index];
    },

    getKindBaseInfo: function getKindBaseInfo(kindId) {
        var content = this.arrConfPash[ConfData.JsonIndex.T_GAME_KIND].content;
        var kindBaseinfo = content.kindBaseinfo;
        for (var key in kindBaseinfo) {
            if (kindBaseinfo[key].Fkind_id == kindId) {
                return kindBaseinfo[key];
            }
        }
        return null;
    },

    getKindBaseInfos: function getKindBaseInfos(typeId) // typeId:0  表示拉取全部
    {
        var kindBaseinfos = this.arrConfPash[ConfData.JsonIndex.T_GAME_KIND].content.kindBaseinfo;
        if (typeId == 0) {
            return kindBaseinfos;
        } else {
            var tempKindBaseInfos = [];
            for (var key in kindBaseinfos) {
                if (kindBaseinfos[key].Ftype_id == typeId) {
                    tempKindBaseInfos.push(kindBaseinfos[key]);
                }
            }
            return tempKindBaseInfos;
        }
    },

    getSceneLoadRes: function getSceneLoadRes(kindId, sceneName) {
        var baseInfo = this.getKindBaseInfo(kindId);
        var url = this.arrConfPash[ConfData.JsonIndex.T_GAME_KIND].content[baseInfo.alias][sceneName];
        return url;
    },
    getRoomArea: function getRoomArea(kindId, kindSeq) {
        var areaBaseinfos = this.arrConfPash[ConfData.JsonIndex.T_ROOM_AREA].content.areaBaseinfo;

        for (var key in areaBaseinfos) {
            if (areaBaseinfos[key].Fkind_id == kindId && areaBaseinfos[key].Fkind_seq == kindSeq) {
                return areaBaseinfos[key];
            }
        }
    },
    getGameNode: function getGameNode(areaId) {
        var areaSeq = arguments.length <= 1 || arguments[1] === undefined ? null : arguments[1];

        var nodeBaseinfos = this.arrConfPash[ConfData.JsonIndex.T_GAME_NODE].content.nodeBaseinfo;
        if (areaSeq == null) {
            var tempNodes = [];
            for (var key in nodeBaseinfos) {
                if (nodeBaseinfos[key].Farea_id == areaId) {
                    tempNodes.push(nodeBaseinfos[key]);
                }
            }
            return tempNodes;
        } else {
            for (var key in nodeBaseinfos) {
                if (nodeBaseinfos[key].Farea_id == areaId && nodeBaseinfos[key].Farea_seq == areaSeq) {
                    return nodeBaseinfos[key];
                }
            }
        }
    },
    getGameRoom: function getGameRoom(nodeId) {
        var nodeSeq = arguments.length <= 1 || arguments[1] === undefined ? null : arguments[1];

        var roomBaseinfo = this.arrConfPash[ConfData.JsonIndex.T_GAME_ROOM].content.roomBaseinfo;

        for (var key in roomBaseinfo) {
            if (roomBaseinfo[key].Fnode_id == nodeId) {
                return roomBaseinfo[key];
            }
        }
    },
    getServerInfo: function getServerInfo(serverId) {
        var serverBaseinfos = this.arrConfPash[ConfData.JsonIndex.T_SERVER_INFO].content.serverBaseinfo;
        if (serverId == 0) {
            return serverBaseinfos;
        } else {
            var tempServerBaseInfos = [];
            for (var key in serverBaseinfos) {
                if (serverBaseinfos[key].Fserver_id == serverId) {
                    tempServerBaseInfos.push(serverBaseinfos[key]);
                    break;
                }
            }
            return tempServerBaseInfos[0];
        }
    },
    getGoodsName: function getGoodsName(kindId, subGoodsId) // goodsId = kindId+subGoodsId
    {
        var newKindId = kindId.toString();
        var s1 = "0000" + newKindId;
        newKindId = s1.substr(newKindId.length, 4);

        var newSubGoodsId = parseInt(subGoodsId).toString(16);
        var s2 = "0000" + newSubGoodsId;
        newSubGoodsId = s2.substr(newSubGoodsId.length, 4);

        var goodsId = "0x" + newKindId + newSubGoodsId;
        var goods = this.arrConfPash[ConfData.JsonIndex.T_GOODS].content;
        return goods[goodsId];
    }
});

cc._RFpop();
},{}],"ConstDef":[function(require,module,exports){
"use strict";
cc._RFpush(module, '56724jFu6RN3beM+T397APj', 'ConstDef');
// Global/service/ConstDef.js

var CONNECT_CALLBACK_STATUS = cc.Enum({
    //===================【主命令】======================
    MIAN_LOGON: 0x0001,
    MIAN_GUIDE: 0x0002,
    MIAN_HOME: 0x0003,
    MIAN_CHAT: 0x0004,

    //==================【登录场景】======================
    LOGON_WAIT_LOGON: 0X00010001, // 等待登录
    LOGON_WAIT_REGISTER: 0X00010002, // 等待注册
    LOGON_GET_ONLINE_COUNT: 0X00010003, // 拉取游戏在线玩家人数
    LOGON_GET_GAME_INFO: 0X00010004, // 拉取游戏信息
    LOGON_GET_PLAYERS_BASE_INFO: 0X00010005, // 拉取玩家基本信息

    //===================【引导场景】====================  
    GUIDE_SET_CLIENT_DATA: 0X00020001, // 修改信息

    //===================【聊天场景】====================
    CHAT_WAIT_CHAT: 0X00040001, // 等待聊天
    CHAT_WAIT_GET_CHAT: 0X00040002, // 拉取聊天记录
    CHAT_WAIT_GET_RELATION: 0X00040003, // 拉取好友关系
    CHAT_WAIT_SET_RELATION: 0X00040004, // 设置好友关系

    //================================================== 
    STATUS_INIT: 0 });
// 初始化，无动作

var BACK_PACK_GOODS_MAIN_ID = 8000;
// -- [战斗开启模式] --
var BATTLE_OPEN_MODE = cc.Enum({
    TABLE: 1, // 桌子模式
    COPY: 2, // 副本模式
    MAKE: 4, // 撮合模式
    WILD: 8, // 野战模式
    MATCH: 16, // 比赛模式

    CANCEL: 0xFF });

// 取消
var MATCH_MODE = cc.Enum({
    NONE: 0,
    OUT_AT_ONCE: 1,
    FIXED_ROUND: 2,

    compatible_MAKE: 101, // 兼容速配模式
    compatible_DATE: 102 });

// 兼容约战模式
var MATCH_STATUS = cc.Enum({
    INIT: 0,
    WAIT_POOL: 1,
    PHASE_1_BEGIN: 2,
    PHASE_1_END: 3,
    PHASE_2_BEGIN: 4,
    PHASE_2_END: 5,
    PHASE_3_BEGIN: 6,
    PHASE_3_END: 7,
    OVER: 8,
    END: 9,
    CANCEL: 10
});

var MATCH_RESULT = cc.Enum({
    NONE: 0,

    OutAtOnce_OUT: 1,
    OutAtOnce_DOWN: 2,
    OutAtOnce_UP: 3,
    OutAtOnce_WIN: 4,

    FixedRound_OUT: 10,
    FixedRound_UP: 11,
    FixedRound_WIN: 12,

    ON_GAME_OVER: 100,

    SEND_FUND_POOL: 101
});

var TIME = cc.Enum({
    DAY_LONG: 86400, // 60*60*24
    WEEK_LONG: 604800, // DAY_LONG*7
    BEIJING_TIME_MARGIN: 28800 });

// 60*60*8
var SERVER_URL = {
    logon: "ws://203.195.129.201:9004/",
    game: "",
    chat: "ws://203.195.129.201:9027/"
};

var FIGHT_RESULT = {
    DRAW: 0,
    LOSE: 1,
    WIN: 2,

    // 刚进房间检查、扣除
    ENTER_ROOM: 3,
    // 每场战斗前置扣费（抽水）
    PRE_FIGHT: 4,
    // 每场战斗结束检查
    AFTER_FIGHT: 5,

    // 比赛报名费
    MATCH_SIGN: 6, // 比赛报名
    MATCH_REVOKE: 7, // 撤销

    // -- 其他奖励
    N_Continue_AWARD: 8,
    MATCH_AWARD: 9 };

// 比赛奖励(包含中途淘汰)

var MESSAGE = {
    // --------------------------------------------
    CMD_MAIN_KERNEL: 0x0000,
    // --------------------------------------------
    HEART: 0x0001,
    HEART_RSP: 0x0002,

    // --------------------------------------------
    CMD_MAIN_PLATFORM: 0x0001,
    // --------------------------------------------
    CREATE_ACCOUNT_REQ: 0x0001,
    CREATE_ACCOUNT_SUCCESS: 0x0002,
    CREATE_ACCOUNT_FAILED: 0x0003,
    GET_ACCOUNT_ID_REQ: 0x000a,
    GET_ACCOUNT_ID_SUCCESS: 0x000b,
    GET_ACCOUNT_ID_FAILED: 0x000c,
    LOGON_PLATFORM_REQ: 0x0010,
    LOGON_PLATFORM_SUCCESS: 0x0011,
    LOGON_PLATFORM_FAILED: 0x0012,
    SEND_ROOMS_NOTIFY: 0x0025,
    SEND_ROOMS_FINISH: 0x0026,
    UPDATE_ONLINE_COUNT_REQ: 0x0027,
    UPDATE_ONLINE_COUNT_SUCCESS: 0x0028,
    UPDATE_ONLINE_COUNT_FAILED: 0x0029,
    ENTER_ROOM_REQ: 0x002a,
    ENTER_ROOM_SUCCESS: 0x002b,
    ENTER_ROOM_FAILED: 0x002c,
    GET_ROOM_PLAYERS_REQ: 0x0030,
    SEND_ROOM_PLAYERS_NOTIFY: 0x0031,
    SEND_ROOM_TEAMS_NOTIFY: 0x0032,
    SEND_ROOM_BATTLES_NOTIFY: 0x0033,
    SEND_ROOM_PLAYERS_FINISH: 0x0034,
    PLAYER_ENTER_ROOM_NOTIFY: 0x0035,
    PLAYER_LEAVE_ROOM_NOTIFY: 0x0036,
    GET_GAME_INFO_REQ: 0x003b,
    GET_GAME_INFO_SUCCESS: 0x003c,
    GET_GAME_INFO_FAILED: 0x003d,
    GET_PLAYERS_BASE_INFO_REQ: 0x0041,
    GET_PLAYERS_BASE_INFO_SUCCESS: 0x0042,
    GET_PLAYERS_BASE_INFO_FAILED: 0x0043,
    BALANCE_NOTIFY: 0x004a,
    // -- 聊天[HTTP]
    CHAT_REQ: 0x004b,
    CHAT_SUCCESS: 0x004c,
    CHAT_FAILED: 0x004d,
    // -- 拉取聊天记录[HTTP]
    GET_CHAT_REQ: 0x004e,
    GET_CHAT_SUCCESS: 0x004f,
    GET_CHAT_FAILED: 0x0050,
    // -- 拉取好友[HTTP]
    GET_RELATION_REQ: 0x0051,
    GET_RELATION_SUCCESS: 0x0052,
    GET_RELATION_FAILED: 0x0053,
    // -- 好友参数修改（关注、粉丝、黑名单、朋友圈权限等）[HTTP]
    SET_RELATION_REQ: 0x0054,
    SET_RELATION_SUCCESS: 0x0055,
    SET_RELATION_FAILED: 0x0056,

    // --------------------------------------------
    CMD_MAIN_GAME: 0x0002,
    // --------------------------------------------
    LEAVE_TEAM_REQ: 0x0009,
    LEAVE_TEAM_NOTIFY: 0x000c,
    TEAM_ALL_READY_REQ: 0x0018,
    TEAM_ALL_READY_SUCCESS: 0x0019,
    TEAM_ALL_READY_FAILED: 0x001a,
    TEAM_ALL_READY_NOTIFY: 0x001b,
    ENTER_BATTLE_REQ: 0x0024,
    ENTER_BATTLE_SUCCESS: 0x0025,
    ENTER_BATTLE_FAILED: 0x0026,
    ENTER_BATTLE_NOTIFY: 0x0027,
    FIGHT_READY_REQ: 0x002d,
    FIGHT_READY_SUCCESS: 0x002e,
    FIGHT_READY_FAILED: 0x002f,
    FIGHT_READY_NOTIFY: 0x0030,
    SCENE_READY_REQ: 0x0031,
    SCENE_READY_SUCCESS: 0x0032,
    SCENE_READY_FAILED: 0x0033,
    SCENE_READY_NOTIFY: 0x0034,
    FIGHT_BEGIN_NOTIFY: 0x0035,
    FIGHT_END_NOTIFY: 0x0036,
    FIGHT_STATUS_NOTIFY: 0x0037,
    GET_TEAM_MEMBERS_REQ: 0x0038,
    GET_TEAM_MEMBERS_SUCCESS: 0x0039,
    GET_TEAM_MEMBERS_FAILED: 0x0040,
    GET_MATCH_DATA_NOTIFY: 0x003b,
    // -- 拉取比赛人数（人满即开、十分钟开赛等并发比赛）
    GET_MATCH_CUR_COUNT_REQ: 0x003c,
    GET_MATCH_CUR_COUNT_SUCCESS: 0x003d,
    GET_MATCH_CUR_COUNT_FAILED: 0x003e
};

// -------------------------------------------------------

module.exports = {
    CONNECT_CALLBACK_STATUS: CONNECT_CALLBACK_STATUS,
    TIME: TIME,
    BACK_PACK_GOODS_MAIN_ID: BACK_PACK_GOODS_MAIN_ID,
    BATTLE_OPEN_MODE: BATTLE_OPEN_MODE,
    MATCH_MODE: MATCH_MODE,
    MATCH_STATUS: MATCH_STATUS,
    MATCH_RESULT: MATCH_RESULT,
    FIGHT_RESULT: FIGHT_RESULT,
    SERVER_URL: SERVER_URL,
    MESSAGE: MESSAGE
};

cc._RFpop();
},{}],"GlobalManager":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'b99f4jwHGJBF5GWT7VXRNoM', 'GlobalManager');
// Global/service/GlobalManager.js

var constDef = require("ConstDef");
var messageHandle = require("MessageHandle");
var ProtocolMessage = require("ProtocolMessage");
var HintManager = require("HintManager");
var Utils = require("Utils");

var GlobalManager = cc.Class({
    "extends": cc.Component,

    properties: {
        selfData: require("SelfData"),

        confData: require("ConfData"),

        serverData: require("ServerData"),

        audio: require("AudioManager"),

        hint: {
            "default": null,
            type: cc.Node
        },
        load: {
            "default": null,
            type: cc.Node
        },
        game: {
            "default": null,
            type: cc.Node
        },
        vectLogonMsg: [],
        vectGameMsg: [],
        vectChatMsg: []
    },

    statics: {
        instance: null
    },

    onLoad: function onLoad() {
        GlobalManager.instance = this;
        cc.game.addPersistRootNode(this.node);

        GlobalManager.instance.SocketManager = require("USocket");
        GlobalManager.instance.SocketManager.init(this.openHandler, this.messageHandler, this.closeHandler, this.sendFailedHandler, true);

        GlobalManager.instance.schedule(function () {
            // -- 同时最多只能连接 1 个游戏服务器
            if (GlobalManager.instance.SocketManager.IsConnected(constDef.SERVER_URL.game)) {
                var nowTS = Math.floor(new Date().getTime() / 1000);
                if (nowTS - GlobalManager.instance.selfData.nHeartRspTS >= 5) {
                    GlobalManager.instance.SocketManager.CloseSocket(constDef.SERVER_URL.game);
                } else {
                    var msg = new ProtocolMessage(constDef.MESSAGE.CMD_MAIN_KERNEL, constDef.MESSAGE.HEART, false);
                    GlobalManager.instance.SocketManager.SendMessage(constDef.SERVER_URL.game, msg);
                }
            }
        }, 1);

        GlobalManager.instance.schedule(function () {
            if (GlobalManager.instance.selfData.nBattleID !== 0) {
                if (!GlobalManager.instance.SocketManager.IsConnected(constDef.SERVER_URL.game)) {
                    var curComp = GlobalManager.instance.hint.getComponent("HintManager");
                    curComp.ShowHint("网络断开，正在重新连接。。。", HintManager.HintMode.NONE_BUTTON);
                    GlobalManager.instance.GetGameController(GlobalManager.instance.selfData.nCurGameID).SendMsg(gameConstDef.CONNECT_CALLBACK_STATUS.HOME_ENTER_ROOM);
                }
            }
        }, 3);

        this.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_KERNEL, constDef.MESSAGE.HEART_RSP, messageHandle.handler_HEART_RSP);
        this.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_PLATFORM, constDef.MESSAGE.CREATE_ACCOUNT_SUCCESS, messageHandle.handler_CREATE_ACCOUNT_SUCCESS);
        this.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_PLATFORM, constDef.MESSAGE.CREATE_ACCOUNT_FAILED, messageHandle.handler_CREATE_ACCOUNT_FAILED);
        this.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_PLATFORM, constDef.MESSAGE.LOGON_PLATFORM_SUCCESS, messageHandle.handler_LOGON_PLATFORM_SUCCESS);
        this.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_PLATFORM, constDef.MESSAGE.LOGON_PLATFORM_FAILED, messageHandle.handler_LOGON_PLATFORM_FAILED);
        this.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_PLATFORM, constDef.MESSAGE.UPDATE_ONLINE_COUNT_SUCCESS, messageHandle.handler_UPDATE_ONLINE_COUNT_SUCCESS);
        this.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_PLATFORM, constDef.MESSAGE.UPDATE_ONLINE_COUNT_FAILED, messageHandle.handler_UPDATE_ONLINE_COUNT_FAILED);
        //chat相关
        this.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_PLATFORM, constDef.MESSAGE.CHAT_SUCCESS, messageHandle.handler_CHAT_SUCCESS);
        this.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_PLATFORM, constDef.MESSAGE.CHAT_FAILED, messageHandle.handler_CHAT_FAILED);
        this.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_PLATFORM, constDef.MESSAGE.GET_CHAT_SUCCESS, messageHandle.handler_GET_CHAT_SUCCESS);
        this.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_PLATFORM, constDef.MESSAGE.GET_CHAT_FAILED, messageHandle.handler_GET_CHAT_FAILED);
        this.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_PLATFORM, constDef.MESSAGE.GET_RELATION_SUCCESS, messageHandle.handler_GET_RELATION_SUCCESS);
        this.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_PLATFORM, constDef.MESSAGE.GET_RELATION_FAILED, messageHandle.handler_GET_RELATION_FAILED);
        this.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_PLATFORM, constDef.MESSAGE.SET_RELATION_SUCCESS, messageHandle.handler_SET_RELATION_SUCCESS);
        this.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_PLATFORM, constDef.MESSAGE.SET_RELATION_FAILED, messageHandle.handler_SET_RELATION_FAILED);
    },

    RegMsgHandler: function RegMsgHandler(mainID, subID, func) {
        this.node.on("[0x" + mainID.toString(16) + "][0x" + subID.toString(16) + "]", func);
    },
    openHandler: function openHandler(url) {
        if (url == constDef.SERVER_URL.logon) {
            var msg = GlobalManager.instance.vectLogonMsg.shift();

            GlobalManager.instance.SocketManager.SendMessage(constDef.SERVER_URL.logon, msg);
        } else if (url == constDef.SERVER_URL.chat) {
            var msg = GlobalManager.instance.vectChatMsg.shift();

            GlobalManager.instance.SocketManager.SendMessage(constDef.SERVER_URL.chat, msg);
        } else {
            GlobalManager.instance.selfData.nHeartRspTS = Math.floor(new Date().getTime() / 1000);

            var msg = GlobalManager.instance.vectGameMsg.shift();
            GlobalManager.instance.SocketManager.SendMessage(constDef.SERVER_URL.game, msg);
        }
    },
    closeHandler: function closeHandler(url, errCode) {
        if (url == constDef.SERVER_URL.logon) {
            if (GlobalManager.instance.vectLogonMsg.length > 0) GlobalManager.instance.ConnectLogonServer();
        }
    },
    sendFailedHandler: function sendFailedHandler(url) {},
    messageHandler: function messageHandler(mainCmdID, subCmdID, bodyMsg) {
        var strMsgID = "[0x" + mainCmdID.toString(16) + "][0x" + subCmdID.toString(16) + "]";
        GlobalManager.instance.node.emit(strMsgID, { msgBody: bodyMsg, instanceGlobal: GlobalManager.instance });
    },
    // -----------------------------------------
    GetRightTime: function GetRightTime() {
        var localTime = Math.floor(new Date().getTime() / 1000);
        return GlobalManager.instance.selfData.nLocalServerTimeDiff + localTime;
    },
    // -----------------------------------------
    GetDayTs: function GetDayTs(now) {
        var during = now - (now + constDef.TIME.BEIJING_TIME_MARGIN) % constDef.TIME.DAY_LONG;
        return during;
    },
    // -----------------------------------------
    SaveUserAccountPassword: function SaveUserAccountPassword() {
        cc.sys.localStorage.setItem('accountName', GlobalManager.instance.selfData.sAccountName);
        cc.sys.localStorage.setItem('password', GlobalManager.instance.selfData.sPassword);
    },

    // -----------------------------------------
    GameNodeAddComponent: function GameNodeAddComponent(gameId) {
        var callback = arguments.length <= 1 || arguments[1] === undefined ? null : arguments[1];

        var gameInfo = GlobalManager.instance.confData.getKindBaseInfo(gameId);
        var alias = gameInfo.alias;
        GlobalManager.instance.game.addComponent(alias + "GameController");
        GlobalManager.instance.game.getChildByName("gameData").addComponent(alias + "GameData");
        GlobalManager.instance.game.getComponent(alias + "GameController").gameRegisterMessage();
        if (callback != null) callback();
    },
    //--------------------------------------------------------------------------------------
    GetGameData: function GetGameData(gameId) {
        var gameInfo = GlobalManager.instance.confData.getKindBaseInfo(gameId);
        var alias = gameInfo.alias;
        var gameData = GlobalManager.instance.game.getChildByName("gameData").getComponent(alias + "GameData");
        return gameData;
    },
    // ======================================================================================
    GetGameController: function GetGameController(gameId) {

        var gameInfo = GlobalManager.instance.confData.getKindBaseInfo(gameId);
        var alias = gameInfo.alias;
        var gameController = GlobalManager.instance.game.getComponent(alias + "GameController");
        return gameController;
    },
    // --------------------------------------------------------------------------------------
    ConnectLogonServer: function ConnectLogonServer() {
        GlobalManager.instance.SocketManager.AddServer(constDef.SERVER_URL.logon);
    },
    // --------------------------------------------------------------------------------------
    ConnectGameServer: function ConnectGameServer(gameStatus) {
        GlobalManager.instance.selfData.nGameConnectStatus = gameStatus;
        GlobalManager.instance.SocketManager.AddServer(constDef.SERVER_URL.game);
    },
    // --------------------------------------------------------------------------------------
    ConnectChatServer: function ConnectChatServer() {
        GlobalManager.instance.SocketManager.AddServer(constDef.SERVER_URL.chat);
    },
    // --------------------------------------------------------------------------------------
    SendLogonMsg: function SendLogonMsg(objMsg) {
        GlobalManager.instance.vectLogonMsg.push(objMsg);
        if (!GlobalManager.instance.SocketManager.IsConnected(constDef.SERVER_URL.logon)) {
            GlobalManager.instance.ConnectLogonServer();
        }
    },
    // --------------------------------------------------------------------------------------
    SendGameMsg: function SendGameMsg(objMsg) {
        GlobalManager.instance.vectGameMsg.push(objMsg);

        if (GlobalManager.instance.SocketManager.IsConnected(constDef.SERVER_URL.game)) {
            var msg = GlobalManager.instance.vectGameMsg.shift();
            GlobalManager.instance.SocketManager.SendMessage(constDef.SERVER_URL.game, msg);
        } else {
            GlobalManager.instance.ConnectGameServer();
        }
    },
    // --------------------------------------------------------------------------------------
    SendChatMsg: function SendChatMsg(objMsg) {
        GlobalManager.instance.vectChatMsg.push(objMsg);

        if (GlobalManager.instance.SocketManager.IsConnected(constDef.SERVER_URL.chat)) {
            var msg = GlobalManager.instance.vectChatMsg.shift();
            GlobalManager.instance.SocketManager.SendMessage(constDef.SERVER_URL.chat, msg);
        } else {
            GlobalManager.instance.ConnectChatServer();
        }
    },
    // --------------------------------------------------------------------------------------
    SendMsg: function SendMsg(status) {
        switch (status) {
            case constDef.CONNECT_CALLBACK_STATUS.LOGON_WAIT_LOGON:
                {

                    var msg = new ProtocolMessage(constDef.MESSAGE.CMD_MAIN_PLATFORM, constDef.MESSAGE.LOGON_PLATFORM_REQ, false);
                    ProtocolMessage.AddVectItemString(msg._body_msg, GlobalManager.instance.selfData.sAccountName);
                    ProtocolMessage.AddVectItemString(msg._body_msg, Utils.md5Encrypt(GlobalManager.instance.selfData.sPassword));
                    ProtocolMessage.AddVectItemInt(msg._body_msg, GlobalManager.instance.selfData.nCurGameID);
                    ProtocolMessage.AddVectItemInt(msg._body_msg, GlobalManager.instance.selfData.nCurGameID);

                    GlobalManager.instance.SendLogonMsg(msg);
                    break;
                }
            case constDef.CONNECT_CALLBACK_STATUS.LOGON_WAIT_REGISTER:
                {
                    var msg = new ProtocolMessage(constDef.MESSAGE.CMD_MAIN_PLATFORM, constDef.MESSAGE.CREATE_ACCOUNT_REQ, false);
                    ProtocolMessage.AddVectItemString(msg._body_msg, GlobalManager.instance.selfData.sAccountName);
                    ProtocolMessage.AddVectItemString(msg._body_msg, Utils.md5Encrypt(GlobalManager.instance.selfData.sPassword));
                    ProtocolMessage.AddVectItemInt(msg._body_msg, 0);
                    ProtocolMessage.AddVectItemString(msg._body_msg, "");
                    ProtocolMessage.AddVectItemString(msg._body_msg, "");
                    ProtocolMessage.AddVectItemInt(msg._body_msg, GlobalManager.instance.selfData.nCurGameID);
                    ProtocolMessage.AddVectItemInt(msg._body_msg, GlobalManager.instance.selfData.nCurGameID);
                    ProtocolMessage.AddVectItemByte(msg._body_msg, 0);
                    GlobalManager.instance.SendLogonMsg(msg);
                    break;
                }
            case constDef.CONNECT_CALLBACK_STATUS.LOGON_GET_ONLINE_COUNT:
                {
                    var msg = new ProtocolMessage(constDef.MESSAGE.CMD_MAIN_PLATFORM, constDef.MESSAGE.UPDATE_ONLINE_COUNT_REQ, false);
                    ProtocolMessage.AddVectItemInt(msg._body_msg, GlobalManager.instance.selfData.nCurGameID); // 0表示拉取所有游戏玩家人数
                    GlobalManager.instance.SendLogonMsg(msg);
                    break;
                }
            //=====================================================
            case constDef.CONNECT_CALLBACK_STATUS.CHAT_WAIT_SET_RELATION:
                {
                    var msg = new ProtocolMessage(constDef.MESSAGE.CMD_MAIN_PLATFORM, constDef.MESSAGE.GET_CHAT_REQ, false);
                    ProtocolMessage.AddVectItemInt(msg._body_msg, GlobalManager.instance.selfData.nAccountID);

                    // 1 - nAccountID 和 nPeerID 互相关注
                    // 2 - nAccountID 关注 nPeerID
                    // 3 - nAccountID 取消关注 nPeerID
                    // 4 - nAccountID 把 nPeerID 拉到黑名单
                    // 5 - nAccountID 取消拉黑 nPeerID
                    // 6 - nAccountID 和 nPeerID 互相取消关注
                    ProtocolMessage.AddVectItemInt(msg._body_msg, nType);
                    ProtocolMessage.AddVectItemInt(msg._body_msg, GlobalManager.instance.selfData.nPeerID);
                    GlobalManager.instance.SendChatMsg(msg);
                    break;
                }
        }
    }
});

cc._RFpop();
},{"AudioManager":"AudioManager","ConfData":"ConfData","ConstDef":"ConstDef","HintManager":"HintManager","MessageHandle":"MessageHandle","ProtocolMessage":"ProtocolMessage","SelfData":"SelfData","ServerData":"ServerData","USocket":"USocket","Utils":"Utils"}],"HintManager":[function(require,module,exports){
"use strict";
cc._RFpush(module, '82d6bYyAdFExrY33Laolejh', 'HintManager');
// Global/qisuLib/qisuFrame/Hint/HintManager.js

var constDef = require("ConstDef");

var HintManager = cc.Class({
    "extends": cc.Component,

    properties: {

        hintCallBack: null,

        labelDesc: cc.Label,
        flyNode: cc.Node,
        flyLabel: cc.Label,
        HintFrame: cc.Animation,
        HintFly: cc.Animation
    },

    statics: {
        HintMode: null
    },

    // use this for initialization
    onLoad: function onLoad() {

        HintManager.HintMode = cc.Enum({
            SIMPLE_FLY: 0, // 简单飘窗方式
            NONE_BUTTON: 1, // 对话框无按钮
            OK_BUTTON: 2, // 对话框只有确定、取消按钮
            OK_CANCEL_BUTTON: 3 // 对话框有确定、取消按钮
        });

        var hintNode = this.node.getChildByName("HintFrame");
        hintNode.setCascadeOpacityEnabled(false);

        var self = this;
        var loadDir = "common/base/popAnim";
        cc.loader.loadResAll(loadDir, cc.AnimationClip, function (err, assets) {
            cc.loader.loadRes(loadDir + "/hint_fly", cc.AnimationClip, function (err, animationClip) {
                self.HintFly.addClip(animationClip);
            });
            cc.loader.loadRes(loadDir + "/hint_fly_reset", cc.AnimationClip, function (err, animationClip) {
                self.HintFly.addClip(animationClip);
            });

            cc.loader.loadRes(loadDir + "/PopHide", cc.AnimationClip, function (err, animationClip) {
                self.HintFrame.addClip(animationClip);
            });
            cc.loader.loadRes(loadDir + "/PopHideReset", cc.AnimationClip, function (err, animationClip) {
                self.HintFrame.addClip(animationClip);
            });
            cc.loader.loadRes(loadDir + "/PopShow", cc.AnimationClip, function (err, animationClip) {
                self.HintFrame.addClip(animationClip);
            });
            cc.loader.loadRes(loadDir + "/PopShowReset", cc.AnimationClip, function (err, animationClip) {
                self.HintFrame.addClip(animationClip);
            });
        });
    },
    ShowFly: function ShowFly(val) {
        var curScene = cc.director.getScene();
        var curNode = cc.find("Canvas", curScene);

        this.flyNode.parent = curNode;
        this.flyNode.active = true;
        this.flyLabel.string = val;

        var menuAnim = this.flyNode.getComponent(cc.Animation);
        menuAnim.play('hint_fly_reset');
        menuAnim.play('hint_fly');
    },

    ShowHint: function ShowHint(val, mode, callback) {
        var curScene = cc.director.getScene();
        var curNode = cc.find("Canvas", curScene);

        this.node.parent = curNode;
        this.node.x = 0;
        this.node.y = 0;

        this.hintCallBack = callback;
        this.labelDesc.string = val;

        this.flyNode.active = false;
        this.node.active = true;

        this.node.on(cc.Node.EventType.MOUSE_DOWN, function (event) {
            event.stopPropagation();
        });
        this.node.on(cc.Node.EventType.TOUCH_END, function (event) {
            event.stopPropagation();
        });
        this.node.on(cc.Node.EventType.TOUCH_START, function (event) {
            event.stopPropagation();
        });
        //是否显示确定按钮   mode ： 1 不显示 
        var confirmButton = cc.find("HintFrame/btn", this.node);
        if (mode == HintManager.HintMode.NONE_BUTTON) {
            confirmButton.active = false;
        } else {
            confirmButton.active = true;
        }
        var menuAnim = this.node.getChildByName("HintFrame").getComponent(cc.Animation);

        menuAnim.play('PopShowReset');
        menuAnim.play('PopShow');
    },
    HideHint: function HideHint() {
        var menuAnim = this.node.getComponent(cc.Animation);
        menuAnim.play('PopHideReset');
        menuAnim.play('PopHide');
    },
    OnHideHint: function OnHideHint() {
        this.node.active = false;

        this.node.parent = null;

        if (this.hintCallBack !== undefined && this.hintCallBack !== null) {
            this.hintCallBack();
        }
    }
});

cc._RFpop();
},{"ConstDef":"ConstDef"}],"HotUpdate":[function(require,module,exports){
"use strict";
cc._RFpush(module, '87e92TyGi5LGJVMQDVbBrQ1', 'HotUpdate');
// Global/qisuLib/qisuFrame/HotUpdate/HotUpdate.js

cc.Class({
    "extends": cc.Component,

    properties: {
        updatePanel: {
            "default": null,
            type: cc.Node
        },
        manifestUrl: {
            "default": null,
            url: cc.RawAsset
        },
        percent: {
            "default": null,
            type: cc.Label
        },
        storageDir: "blackjack-remote-asset"
    },

    checkCb: function checkCb(event) {
        cc.log('Code: ' + event.getEventCode());
        switch (event.getEventCode()) {
            case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
                cc.log("No local manifest file found, hot update skipped.");
                cc.eventManager.removeListener(this._checkListener);
                break;
            case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
            case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
                cc.log("Fail to download manifest file, hot update skipped.");
                cc.eventManager.removeListener(this._checkListener);
                break;
            case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
                cc.log("Already up to date with the latest remote version.");
                cc.eventManager.removeListener(this._checkListener);
                break;
            case jsb.EventAssetsManager.NEW_VERSION_FOUND:
                this._needUpdate = true;

                this.updatePanel.active = true;

                var curScene = cc.director.getScene();
                var curNode = cc.find("Canvas", curScene);
                this.updatePanel.parent = curNode;
                this.updatePanel.x = 0;
                this.updatePanel.y = 0;

                this.percent.string = '00.00%';
                cc.eventManager.removeListener(this._checkListener);
                break;
            default:
                break;
        }
    },

    updateCb: function updateCb(event) {
        var needRestart = false;
        var failed = false;
        switch (event.getEventCode()) {
            case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
                cc.log('No local manifest file found, hot update skipped.');
                failed = true;
                break;
            case jsb.EventAssetsManager.UPDATE_PROGRESSION:
                var percent = event.getPercent();
                var percentByFile = event.getPercentByFile();

                var msg = event.getMessage();
                if (msg) {
                    cc.log(msg);
                }
                cc.log(percent.toFixed(2) + '%');
                this.percent.string = percent + '%';
                break;
            case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
            case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
                cc.log('Fail to download manifest file, hot update skipped.');
                failed = true;
                break;
            case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
                cc.log('Already up to date with the latest remote version.');
                failed = true;
                break;
            case jsb.EventAssetsManager.UPDATE_FINISHED:
                cc.log('Update finished. ' + event.getMessage());

                needRestart = true;
                break;
            case jsb.EventAssetsManager.UPDATE_FAILED:
                cc.log('Update failed. ' + event.getMessage());

                this._failCount++;
                if (this._failCount < 5) {
                    this._am.downloadFailedAssets();
                } else {
                    cc.log('Reach maximum fail count, exit update process');
                    this._failCount = 0;
                    failed = true;
                }
                break;
            case jsb.EventAssetsManager.ERROR_UPDATING:
                cc.log('Asset update error: ' + event.getAssetId() + ', ' + event.getMessage());
                break;
            case jsb.EventAssetsManager.ERROR_DECOMPRESS:
                cc.log(event.getMessage());
                break;
            default:
                break;
        }

        if (failed) {
            cc.eventManager.removeListener(this._updateListener);
            this.updatePanel.active = false;
        }

        if (needRestart) {
            cc.eventManager.removeListener(this._updateListener);
            // Prepend the manifest's search path
            var searchPaths = jsb.fileUtils.getSearchPaths();
            var newPaths = this._am.getLocalManifest().getSearchPaths();
            Array.prototype.unshift(searchPaths, newPaths);
            // This value will be retrieved and appended to the default search path during game startup,
            // please refer to samples/js-tests/main.js for detailed usage.
            // !!! Re-add the search paths in main.js is very important, otherwise, new scripts won't take effect.
            cc.sys.localStorage.setItem('HotUpdateSearchPaths', JSON.stringify(searchPaths));

            jsb.fileUtils.setSearchPaths(searchPaths);
            cc.game.restart();
        }
    },

    hotUpdate: function hotUpdate() {
        if (this._am && this._needUpdate) {
            this._updateListener = new jsb.EventListenerAssetsManager(this._am, this.updateCb.bind(this));
            cc.eventManager.addListener(this._updateListener, 1);

            this._failCount = 0;
            this._am.update();
        }
    },

    // use this for initialization
    onLoad: function onLoad() {
        // Hot update is only available in Native build
        if (!cc.sys.isNative) {
            return;
        }
        var storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : '/') + this.storageDir;
        cc.log('Storage path for remote asset : ' + storagePath);

        // cc.log('Local manifest URL : ' + this.manifestUrl);
        this._am = new jsb.AssetsManager(this.manifestUrl, storagePath);
        this._am.retain();

        this._needUpdate = false;
        if (this._am.getLocalManifest().isLoaded()) {
            this._checkListener = new jsb.EventListenerAssetsManager(this._am, this.checkCb.bind(this));
            cc.eventManager.addListener(this._checkListener, 1);

            this._am.checkUpdate();
        }
    },

    onDestroy: function onDestroy() {
        this._am && this._am.release();
    }
});

cc._RFpop();
},{}],"LoadManager":[function(require,module,exports){
"use strict";
cc._RFpush(module, '2ad714d/7hM9pN3RZSdf1iB', 'LoadManager');
// Global/qisuLib/qisuFrame/Load/LoadManager.js

var GlobalManager = require("GlobalManager");
var constDef = require("ConstDef");
var HintManager = require("HintManager");
cc.Class({
    "extends": cc.Component,

    // -- 静态加载
    // -- 动态加载（预加载、即时加载）
    // 动态即时加载只有在很少的情况下使用；游戏中大部分使用动态预加载；

    properties: {
        progressBar: cc.ProgressBar,
        labelProgress: cc.Label,
        backgroundPic: cc.Sprite,
        logo: cc.Sprite,
        progressBG: cc.Sprite,

        _load_scene: null, // 当前正在加载的场景
        _load_urls: null, // 传入的待加载资源的url列表（不包含场景）
        // arrUrls.push({type:"Spine",url:"card/back"});
        _progress: 0, // 当前加载准确进度，用于控制进度条走动（控制条进度不是实时的）
        _totalCount: 0, // 待加载资源总数（包含1个场景）
        _callback: null, // 资源加载完毕后的回调函数
        _DirRes: Array, // 资源加载完成后，资源数据保存在该数组中
        _resCompletedcount: 0, // 已经加载完成的动态资源
        _barSpeed: 0, // 滚动条的速度
        _rolltime: 0.2 },
    // 进度条走动到指定位置的时间    
    onLoad: function onLoad() {
        if (this._DirRes === null) {
            this._DirRes = new Array();
        }
    },

    OpenGame: function OpenGame(kindID) {
        // -- 加载 bg、logo、progressBG、progress、字体
        // -- 并替换这些资源
        // -- 加载 load_urls
        // -- 调用 ShowGame()

        GlobalManager.instance.selfData.nCurGameID = kindID;

        var self = this;
        var kindBaseInfo = GlobalManager.instance.confData.getKindBaseInfo(kindID);
        if (kindBaseInfo == null) return;
        var alias = kindBaseInfo.alias;
        var progressImg = self.progressBar.node.getChildByName("img").getComponent(cc.Sprite);

        var loadDir = "Games/" + alias + "/res/image/base";
        cc.loader.loadResAll(loadDir, cc.SpriteFrame, function (err, assets) {
            if (!err) {
                cc.loader.loadRes(loadDir + "/background", cc.SpriteFrame, function (err, spriteFrame) {
                    self.backgroundPic.spriteFrame = spriteFrame;
                });
                cc.loader.loadRes(loadDir + "/logo", cc.SpriteFrame, function (err, spriteFrame) {
                    self.logo.spriteFrame = spriteFrame;
                });
                cc.loader.loadRes(loadDir + "/progressBar", cc.SpriteFrame, function (err, spriteFrame) {
                    progressImg.spriteFrame = spriteFrame;
                });
                cc.loader.loadRes(loadDir + "/progressBG", cc.SpriteFrame, function (err, spriteFrame) {
                    self.progressBG.spriteFrame = spriteFrame;
                });

                var load_urls = GlobalManager.instance.confData.getSceneLoadRes(kindID, alias + "_home");
                self.ShowGame(alias + "_home", load_urls, true, null);
            }
        });
    },

    Show: function Show(load_scene) {
        var callback = arguments.length <= 1 || arguments[1] === undefined ? null : arguments[1];

        // -- 获取 load_urls
        // -- 调用 ShowGame()

        var load_urls = GlobalManager.instance.confData.getSceneLoadRes(GlobalManager.instance.selfData.nCurGameID, load_scene);
        var load_urls = GlobalManager.instance.confData.getSceneLoadRes(GlobalManager.instance.selfData.nCurGameID, load_scene);
        this.ShowGame(load_scene, load_urls, false);
    },

    ShowGame: function ShowGame(load_scene) {
        var load_urls = arguments.length <= 1 || arguments[1] === undefined ? null : arguments[1];
        var isReversal = arguments.length <= 2 || arguments[2] === undefined ? false : arguments[2];
        var callback = arguments.length <= 3 || arguments[3] === undefined ? null : arguments[3];

        this._load_scene = load_scene;
        this._load_urls = load_urls;
        this._callback = callback;
        this._progress = 0;
        this._resCompletedcount = 0;
        this._totalCount = 1;

        var curScene = cc.director.getScene();
        var curNode = cc.find("Canvas", curScene);

        this.node.parent = curNode;
        if (isReversal) {
            this.node.rotation = 90;
        } else {
            this.node.rotation = 0;
        }

        this.node.x = 0;
        this.node.y = 0;
        var widget = this.node.addComponent(cc.Widget);
        widget.top = 0;
        widget.left = 0;
        widget.right = 0;
        widget.bottom = 0;

        this.progressBar.progress = 0;

        if (this._load_urls) {
            this._totalCount += this._load_urls.length;
        }

        cc.director.preloadScene(load_scene, this._lodesceneCallback.bind(this));
    },
    _lodesceneCallback: function _lodesceneCallback(error) {
        if (error === false) {
            cc.log("加载场景出错！");
            return;
        }
        this._progress = 1 / this._totalCount;
        this._speed = (this._progress - this.progressBar.progress) / this._rolltime;

        if (this._load_urls !== null) {
            if (this._resCompletedcount + 1 < this._totalCount) {
                this._lodeRes();
            }
        }
    },

    _lodeRes: function _lodeRes() {
        var url = this._load_urls[this._resCompletedcount].url;
        var resType = this._load_urls[this._resCompletedcount].type;
        var loadCallBack = this._completeCallback.bind(this);
        switch (this._curType) {
            case 'SpriteFrame':
                // specify the type to load sub asset from texture's url
                cc.loader.loadRes(url, cc.SpriteFrame, loadCallBack);
                break;
            case 'Spine':
                // specify the type to avoid the duplicated name from spine atlas
                cc.loader.loadRes(url, sp.SkeletonData, loadCallBack);
                break;
            case 'Font':
                cc.loader.loadRes(url, cc.Font, loadCallBack);
                break;
            case 'Animation':
            case 'Prefab':
            case 'Scene':
            case 'Texture':
            case 'Txt':
            case 'Audio':
                cc.loader.loadRes(url, loadCallBack);
                break;
            default:
                cc.loader.load(url, loadCallBack);
                break;
        }

        this._resCompletedcount++;
    },

    _completeCallback: function _completeCallback(error, res) {
        this._progress = (this._resCompletedcount + 1) / this._totalCount;
        this._speed = (this._progress - this.progressBar.progress) / this._rolltime;
        this._DirRes[this._load_urls[this._resCompletedcount - 1].url] = res;
        if (this._resCompletedcount + 1 < this._totalCount) {
            this._lodeRes();
        }
    },
    update: function update(dt) {
        if (this._totalCount === 0) return;

        var del = this._speed * dt;
        var progress = this.progressBar.progress;
        if (progress >= 1) {
            this.labelProgress.string = "100%";

            this.node.parent = null;
            GlobalManager.instance.hint.parent = null;

            if (this._callback !== null) {
                this._callback();
            }
            this._callback = null;

            cc.director.loadScene(this._load_scene);

            return;
        }

        if (progress < this._progress) {
            if (progress + del > this._progress) progress = this._progress;else progress += del;
        }
        this.progressBar.progress = progress;
        this.labelProgress.string = Math.round(progress * 100) + "%";
    },

    GetRes: function GetRes(url) {
        if (typeof this._DirRes[url] === "undefined") return null;
        if (this._DirRes[url] === null) return null;

        return this._DirRes[url];
    },

    RemoveRes: function RemoveRes(url) {
        if (typeof this._DirRes[url] === "undefined") return null;
        if (this._DirRes[url] === null) return;

        cc.loader.releaseRes(url);

        this._DirRes[url] = null;
    },

    RemoveAllRes: function RemoveAllRes() {
        cc.loader.releaseAll();
        this._DirRes = new Array();
    }

});

cc._RFpop();
},{"ConstDef":"ConstDef","GlobalManager":"GlobalManager","HintManager":"HintManager"}],"LogonUI":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'c5414c0V0hLQJtQrva00IpE', 'LogonUI');
// resources/Games/Yingsanzhang/scene/sceneLogon/LogonUI.js

var GlobalManager = require("GlobalManager");
var HintManager = require("HintManager");
var ProtocolMessage = require("ProtocolMessage");
var constDef = require("ConstDef");
var Utils = require("Utils");

cc.Class({
    "extends": cc.Component,

    properties: {
        inputAccountName: {
            "default": null,
            type: cc.EditBox
        },
        inputPassword: {
            "default": null,
            type: cc.EditBox
        },
        inputAccountNameR: {
            "default": null,
            type: cc.EditBox
        },
        inputPasswordR: {
            "default": null,
            type: cc.EditBox
        },
        inputPasswordR1: {
            "default": null,
            type: cc.EditBox
        }
    },

    onLoad: function onLoad() {

        var accountname = cc.sys.localStorage.getItem("accountName");
        var password = cc.sys.localStorage.getItem("password");

        if (accountname == "") return;
        if (accountname == null) return;
        if (typeof accountname == "undefined") return;

        this.inputAccountName.string = accountname;
        this.inputPassword.string = password;
    },

    switchLogonRegister: function switchLogonRegister() {
        var curScene = cc.director.getScene();
        var curNode = cc.find("Canvas/accountPane/switchBtn", curScene);
        if (curNode.getComponent(cc.Label).string == "快速注册") {
            curNode.getComponent(cc.Label).string = "返回登录";
            var nodeLogon = this.node.getChildByName("accountPane").getChildByName("logonPane");
            var nodeRegister = this.node.getChildByName("accountPane").getChildByName("registerPane");
            nodeRegister.active = true;
            nodeLogon.active = false;
        } else {
            curNode.getComponent(cc.Label).string = "快速注册";
            var nodeLogon = this.node.getChildByName("accountPane").getChildByName("logonPane");
            var nodeRegister = this.node.getChildByName("accountPane").getChildByName("registerPane");
            nodeRegister.active = false;
            nodeLogon.active = true;
        }
    },
    logonClick: function logonClick() {
        if (this.inputPassword.string === "" || this.inputAccountName.string === "") {
            var curComp = GlobalManager.instance.hint.getComponent("HintManager");
            curComp.ShowHint("账号或密码不能为空！", HintManager.HintMode.OK_BUTTON);
            return;
        }

        var curComp = GlobalManager.instance.hint.getComponent("HintManager");
        curComp.ShowHint("正在进入游戏，请稍等...", HintManager.HintMode.NONE_BUTTON);

        GlobalManager.instance.selfData.sAccountName = this.inputAccountName.string;
        GlobalManager.instance.selfData.sPassword = this.inputPassword.string;

        GlobalManager.instance.SendMsg(constDef.CONNECT_CALLBACK_STATUS.LOGON_WAIT_LOGON);
    },
    registerClick: function registerClick() {
        if (this.inputPasswordR.string !== this.inputPasswordR1.string) {
            var curComp = GlobalManager.instance.hint.getComponent("HintManager");
            curComp.ShowHint("两次密码输入不一致，请重新输入！", HintManager.HintMode.OK_BUTTON);
            return;
        }
        if (this.inputPasswordR.string === "" || this.inputAccountNameR.string === "") {
            var curComp = GlobalManager.instance.hint.getComponent("HintManager");
            curComp.ShowHint("账号或密码不能为空！", HintManager.HintMode.OK_BUTTON);
            return;
        }

        var curComp = GlobalManager.instance.hint.getComponent("HintManager");
        curComp.ShowHint("正在进入游戏，请稍等...", HintManager.HintMode.NONE_BUTTON);

        GlobalManager.instance.selfData.sAccountName = this.inputAccountNameR.string;
        GlobalManager.instance.selfData.sPassword = this.inputPasswordR.string;

        GlobalManager.instance.SendMsg(constDef.CONNECT_CALLBACK_STATUS.LOGON_WAIT_REGISTER);
    }
});

cc._RFpop();
},{"ConstDef":"ConstDef","GlobalManager":"GlobalManager","HintManager":"HintManager","ProtocolMessage":"ProtocolMessage","Utils":"Utils"}],"MessageHandle":[function(require,module,exports){
"use strict";
cc._RFpush(module, '66d26+oEj5A6bMStlcdIzB8', 'MessageHandle');
// Global/service/MessageHandle.js

var constDef = require("ConstDef");
var ProtocolMessage = require("ProtocolMessage");

var MessageHandle = {
    // ===========================================================================================================
    handler_HEART_RSP: function handler_HEART_RSP(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;

        var index = 0;
        var serverTime = bodyMsg[index++]._int_value;

        var localTime = Math.floor(new Date().getTime() / 1000);
        instanceGlobal.selfData.nLocalServerTimeDiff = serverTime - localTime;

        // 只要连上游戏服务器就一秒发送一次心跳
        // 若连续五秒未收到心跳响应，则断开链接
        // 是否重连，由重连机制判定（战斗中断线，3秒自动重连）
        instanceGlobal.selfData.nHeartRspTS = localTime;
    },
    // ===========================================================================================================
    handler_LOGON_PLATFORM_SUCCESS: function handler_LOGON_PLATFORM_SUCCESS(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;

        var index = 0;
        instanceGlobal.selfData.nAccountID = bodyMsg[index++]._int_value;
        instanceGlobal.selfData.sAccountName = bodyMsg[index++]._str_value;

        instanceGlobal.selfData.nLogonTS = bodyMsg[index++]._int_value;
        instanceGlobal.selfData.nLogonRand = bodyMsg[index++]._int_value;
        instanceGlobal.selfData.sLogonKey = bodyMsg[index++]._str_value;

        instanceGlobal.selfData.sNickName = bodyMsg[index++]._str_value;
        instanceGlobal.selfData.nSex = bodyMsg[index++]._int_value;
        instanceGlobal.selfData.nFhead = bodyMsg[index++]._int_value;
        instanceGlobal.selfData.sFcustom_head = bodyMsg[index++]._str_value;
        instanceGlobal.selfData.nFrmbH = bodyMsg[index++]._int_value; //  七砖
        instanceGlobal.selfData.nFrmb = bodyMsg[index++]._int_value;
        instanceGlobal.selfData.nFcharge_rmbH = bodyMsg[index++]._int_value; // 累计充值
        instanceGlobal.selfData.nFcharge_rmb = bodyMsg[index++]._int_value;
        instanceGlobal.selfData.nFmoneyH = bodyMsg[index++]._int_value; // 七豆
        instanceGlobal.selfData.nFmoney = bodyMsg[index++]._int_value;
        instanceGlobal.selfData.nFwalletH = bodyMsg[index++]._int_value; // 七币
        instanceGlobal.selfData.nFwallet = bodyMsg[index++]._int_value;
        instanceGlobal.selfData.sFreal_name = bodyMsg[index++]._str_value;
        instanceGlobal.selfData.sFcard_id = bodyMsg[index++]._str_value;
        instanceGlobal.selfData.sFmobile = bodyMsg[index++]._str_value;
        instanceGlobal.selfData.sFemail = bodyMsg[index++]._str_value;
        instanceGlobal.selfData.nFspreader = bodyMsg[index++]._int_value;

        var serverTime = instanceGlobal.selfData.nLogonTS;
        var localTime = Math.floor(new Date().getTime() / 1000);
        instanceGlobal.selfData.nLocalServerTimeDiff = serverTime - localTime;

        instanceGlobal.SaveUserAccountPassword();

        var gameId = 13;
        instanceGlobal.GameNodeAddComponent(gameId, function () {
            instanceGlobal.selfData.nCurGameID = gameId;
            instanceGlobal.GetGameController(gameId).SendMsg(constDef.CONNECT_CALLBACK_STATUS.LOGON_GET_GAME_INFO);
        });
    },
    // ===========================================================================================================
    handler_CREATE_ACCOUNT_SUCCESS: function handler_CREATE_ACCOUNT_SUCCESS(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;

        var index = 0;
        instanceGlobal.selfData.nAccountID = bodyMsg[index++]._int_value;
        instanceGlobal.selfData.sAccountName = bodyMsg[index++]._str_value;
        var nSpreaderID = bodyMsg[index++]._int_value;
        instanceGlobal.selfData.nLogonTS = bodyMsg[index++]._int_value;
        instanceGlobal.selfData.nLogonRand = bodyMsg[index++]._int_value;
        instanceGlobal.selfData.sLogonKey = bodyMsg[index++]._str_value;

        // ...

        var serverTime = instanceGlobal.selfData.nLogonTS;
        var localTime = Math.floor(new Date().getTime() / 1000);
        instanceGlobal.selfData.nLocalServerTimeDiff = serverTime - localTime;

        instanceGlobal.SaveUserAccountPassword();

        var gameId = 13;
        instanceGlobal.GameNodeAddComponent(gameId, function () {
            instanceGlobal.selfData.nCurGameID = gameId;
            instanceGlobal.GetGameController(gameId).SendMsg(constDef.CONNECT_CALLBACK_STATUS.LOGON_GET_GAME_INFO);
        });
    },
    // ==========================================================================================================
    handler_LOGON_PLATFORM_FAILED: function handler_LOGON_PLATFORM_FAILED(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;

        var index = 0;
        var errorCode = bodyMsg[index]._int_value;
        // ....根据错误码去提示
        var curComp = instanceGlobal.hint.getComponent("HintManager");
        curComp.ShowHint("账号或者密码输入错误！");
    },

    // ===========================================================================================================
    handler_CREATE_ACCOUNT_FAILED: function handler_CREATE_ACCOUNT_FAILED(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;

        var curComp = instanceGlobal.hint.getComponent("HintManager");
        curComp.ShowHint("创建账号失败！");
    },
    // ===========================================================================================================
    handler_UPDATE_ONLINE_COUNT_SUCCESS: function handler_UPDATE_ONLINE_COUNT_SUCCESS(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;

        if (instanceGlobal.selfData.nCurGameID == 0) {
            instanceGlobal.selfData.games.length = 0;
            var itemCount = 2;
            var count = (bodyMsg.length - 1) / itemCount;

            for (var _i = 0; _i < count; _i++) {
                var index1 = 0;
                var item = {};
                item.gameID = bodyMsg[1 + _i * itemCount + index1++]._int_value;
                item.onLineCount = bodyMsg[1 + _i * itemCount + index1++]._int_value;
                instanceGlobal.selfData.games.push(item);
            }
            var Canvas = cc.director.getScene().getChildByName('Canvas');
            var gameNode = cc.find("body/game", Canvas);
            var gameController = gameNode.getComponent("GameController");
            gameController.updateGamesInfo();
        } else {
            var gameInfo = instanceGlobal.confData.getKindBaseInfo(instanceGlobal.selfData.nCurGameID);
            var alias = gameInfo.alias;
            var gameData = instanceGlobal.game.getChildByName("gameData").getComponent(alias + "GameData");
            gameData.rooms.length = 0;
            var itemCount = 2;
            var count = (bodyMsg.length - 1) / itemCount;

            for (var _i2 = 0; _i2 < count; _i2++) {
                var index1 = 0;
                var item = {};
                item.nRoomID = bodyMsg[1 + _i2 * itemCount + index1++]._int_value;
                item.onLineCount = bodyMsg[1 + _i2 * itemCount + index1++]._int_value;
                gameData.rooms.push(item);
            }
        }
    },
    // ===========================================================================================================
    handler_UPDATE_ONLINE_COUNT_FAILED: function handler_UPDATE_ONLINE_COUNT_FAILED(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
    },
    // ===========================================================================================================
    handler_CHAT_SUCCESS: function handler_CHAT_SUCCESS(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
    },
    // ===========================================================================================================
    handler_CHAT_FAILED: function handler_CHAT_FAILED(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
    },
    // ===========================================================================================================
    handler_GET_CHAT_SUCCESS: function handler_GET_CHAT_SUCCESS(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;

        instanceGlobal.selfData.messages = {};
        var messages = instanceGlobal.selfData.messages;

        var index = 0;
        var nAccountID = bodyMsg[index++]._int_value;
        var itemCount = 9;
        var count = (bodyMsg.length - 1) / itemCount;
        for (var _i3 = 0; _i3 < count; _i3++) {
            var index1 = 0;
            var nFid = bodyMsg[1 + _i3 * itemCount + index1++]._int_value;
            messages[nFid] = {};
            messages[nFid].nType = bodyMsg[1 + _i3 * itemCount + index1++]._int_value;
            messages[nFid].nSendID = bodyMsg[1 + _i3 * itemCount + index1++]._int_value;
            messages[nFid].nSendTS = bodyMsg[1 + _i3 * itemCount + index1++]._int_value;
            messages[nFid].nParam1 = bodyMsg[1 + _i3 * itemCount + index1++]._int_value;
            messages[nFid].nParam2 = bodyMsg[1 + _i3 * itemCount + index1++]._int_value;
            messages[nFid].sTitle = bodyMsg[1 + _i3 * itemCount + index1++]._str_value;
            messages[nFid].sContent = bodyMsg[1 + _i3 * itemCount + index1++]._str_value;
            messages[nFid].sAttachment = bodyMsg[1 + _i3 * itemCount + index1++]._str_value;
        }
        instanceGlobal.selfData.refreshChatUI();
    },
    // ===========================================================================================================
    handler_GET_CHAT_FAILED: function handler_GET_CHAT_FAILED(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
    },
    // ===========================================================================================================
    handler_GET_RELATION_SUCCESS: function handler_GET_RELATION_SUCCESS(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;

        var index = 0;
        var nAccountID = bodyMsg[index++]._int_value;
        var itemCount = 2;
        var count = (bodyMsg.length - 1) / itemCount;
        instanceGlobal.selfData.relations = {};
        var relations = instanceGlobal.selfData.relations;
        for (i = 0; i < count; i++) {
            var index1 = 0;
            var nPeerID = bodyMsg[1 + i * itemCount + index1++]._int_value;
            var nParam = bodyMsg[1 + i * itemCount + index1++]._int_value;
            relations[nPeerID] = {};
            relations[nPeerID] = nParam;
        }
    },
    // ===========================================================================================================
    handler_GET_RELATION_FAILED: function handler_GET_RELATION_FAILED(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
    },
    // ===========================================================================================================
    handler_SET_RELATION_SUCCESS: function handler_SET_RELATION_SUCCESS(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;

        var index = 0;
        var nAccountID = bodyMsg[index++]._int_value;
        var nType = bodyMsg[index++]._int_value;
        var nPeerID = bodyMsg[index++]._int_value;
    },
    // ===========================================================================================================
    handler_SET_RELATION_FAILED: function handler_SET_RELATION_FAILED(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
    }
};
// ===========================================================================================================
// ===========================================================================================================
module.exports = MessageHandle;

cc._RFpop();
},{"ConstDef":"ConstDef","ProtocolMessage":"ProtocolMessage"}],"NodeFader":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'd6b28nQIUZG/KNT7+gRPrA7', 'NodeFader');
// Global/qisuLib/Show/NodeFader.js

cc.Class({
    "extends": cc.Component,

    properties: {
        during: 0.5
    },
    GetDuring: function GetDuring() {
        return this.during;
    },
    Show: function Show() {
        var aimNode = arguments.length <= 0 || arguments[0] === undefined ? null : arguments[0];

        var curNode = aimNode;
        if (aimNode === null) curNode = this.node;

        if (curNode.active == true) return;
        curNode.opacity = 0;
        curNode.active = true;

        var seq = cc.sequence(cc.fadeIn(this.during));
        curNode.runAction(seq);
    },
    Hide: function Hide() {
        var aimNode = arguments.length <= 0 || arguments[0] === undefined ? null : arguments[0];

        var curNode = aimNode;
        if (aimNode === null) curNode = this.node;

        var finished = cc.callFunc(function (target, val) {
            curNode.active = val;
        }, curNode, false);

        if (curNode.active === false) return;
        curNode.opacity = 255;

        var seq = cc.sequence(cc.fadeOut(this.during), finished);
        curNode.runAction(seq);
    }
});

cc._RFpop();
},{}],"NodeScaler":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'fc45f+1oYBDN7TA/XQBywy+', 'NodeScaler');
// Global/qisuLib/Show/NodeScaler.js

cc.Class({
    "extends": cc.Component,

    properties: {
        bigScale: 1.2
    },
    onLoad: function onLoad() {},
    onDestroy: function onDestroy() {},
    onEnable: function onEnable() {},
    onDisable: function onDisable() {},
    Show: function Show() {
        if (this.node.active == true) return;
        this.node.scale = 0;
        this.node.active = true;

        var seq = cc.sequence(cc.scaleTo(0.2, this.bigScale), cc.scaleTo(0.2, 1));
        this.node.runAction(seq);
    },
    Hide: function Hide() {
        var finished = cc.callFunc(function (target, val) {
            this.node.active = val;
        }, this, false);

        if (this.node.active === false) return;
        this.node.scale = 1;

        var seq = cc.sequence(cc.scaleTo(0.2, this.bigScale), cc.scaleTo(0.2, 0), finished);
        this.node.runAction(seq);
    },

    ShowA: function ShowA() {
        this.node.scale = 0;

        var seq = cc.sequence(cc.scaleTo(0.2, this.bigScale), cc.scaleTo(0.2, 1));
        this.node.runAction(seq);
    }
});

cc._RFpop();
},{}],"ProtocolItem":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'f4169O4GktMhZFZCxPjcM2k', 'ProtocolItem');
// Global/qisuLib/comm/ProtocolItem.js

var ProtocolItem = function ProtocolItem() {
	this._datatype = 0;
	this._int_value = 0;
	this._str_value = "";
	this._vect_value = {};
};

ProtocolItem.DATATYPE_BYTE = 1;
ProtocolItem.DATATYPE_SHORT = 2;
ProtocolItem.DATATYPE_INT = 3;
ProtocolItem.DATATYPE_STRING = 4;
ProtocolItem.DATATYPE_VECTOR = 5;

ProtocolItem.SendByteMap = [0x70, 0x2F, 0x40, 0x5F, 0x44, 0x8E, 0x6E, 0x45, 0x7E, 0xAB, 0x2C, 0x1F, 0xB4, 0xAC, 0x9D, 0x91, 0x0D, 0x36, 0x9B, 0x0B, 0xD4, 0xC4, 0x39, 0x74, 0xBF, 0x23, 0x16, 0x14, 0x06, 0xEB, 0x04, 0x3E, 0x12, 0x5C, 0x8B, 0xBC, 0x61, 0x63, 0xF6, 0xA5, 0xE1, 0x65, 0xD8, 0xF5, 0x5A, 0x07, 0xF0, 0x13, 0xF2, 0x20, 0x6B, 0x4A, 0x24, 0x59, 0x89, 0x64, 0xD7, 0x42, 0x6A, 0x5E, 0x3D, 0x0A, 0x77, 0xE0, 0x80, 0x27, 0xB8, 0xC5, 0x8C, 0x0E, 0xFA, 0x8A, 0xD5, 0x29, 0x56, 0x57, 0x6C, 0x53, 0x67, 0x41, 0xE8, 0x00, 0x1A, 0xCE, 0x86, 0x83, 0xB0, 0x22, 0x28, 0x4D, 0x3F, 0x26, 0x46, 0x4F, 0x6F, 0x2B, 0x72, 0x3A, 0xF1, 0x8D, 0x97, 0x95, 0x49, 0x84, 0xE5, 0xE3, 0x79, 0x8F, 0x51, 0x10, 0xA8, 0x82, 0xC6, 0xDD, 0xFF, 0xFC, 0xE4, 0xCF, 0xB3, 0x09, 0x5D, 0xEA, 0x9C, 0x34, 0xF9, 0x17, 0x9F, 0xDA, 0x87, 0xF8, 0x15, 0x05, 0x3C, 0xD3, 0xA4, 0x85, 0x2E, 0xFB, 0xEE, 0x47, 0x3B, 0xEF, 0x37, 0x7F, 0x93, 0xAF, 0x69, 0x0C, 0x71, 0x31, 0xDE, 0x21, 0x75, 0xA0, 0xAA, 0xBA, 0x7C, 0x38, 0x02, 0xB7, 0x81, 0x01, 0xFD, 0xE7, 0x1D, 0xCC, 0xCD, 0xBD, 0x1B, 0x7A, 0x2A, 0xAD, 0x66, 0xBE, 0x55, 0x33, 0x03, 0xDB, 0x88, 0xB2, 0x1E, 0x4E, 0xB9, 0xE6, 0xC2, 0xF7, 0xCB, 0x7D, 0xC9, 0x62, 0xC3, 0xA6, 0xDC, 0xA7, 0x50, 0xB5, 0x4B, 0x94, 0xC0, 0x92, 0x4C, 0x11, 0x5B, 0x78, 0xD9, 0xB1, 0xED, 0x19, 0xE9, 0xA1, 0x1C, 0xB6, 0x32, 0x99, 0xA3, 0x76, 0x9E, 0x7B, 0x6D, 0x9A, 0x30, 0xD6, 0xA9, 0x25, 0xC7, 0xAE, 0x96, 0x35, 0xD0, 0xBB, 0xD2, 0xC8, 0xA2, 0x08, 0xF3, 0xD1, 0x73, 0xF4, 0x48, 0x2D, 0x90, 0xCA, 0xE2, 0x58, 0xC1, 0x18, 0x52, 0xFE, 0xDF, 0x68, 0x98, 0x54, 0xEC, 0x60, 0x43, 0x0F];

ProtocolItem.RecvByteMap = [0x51, 0xA1, 0x9E, 0xB0, 0x1E, 0x83, 0x1C, 0x2D, 0xE9, 0x77, 0x3D, 0x13, 0x93, 0x10, 0x45, 0xFF, 0x6D, 0xC9, 0x20, 0x2F, 0x1B, 0x82, 0x1A, 0x7D, 0xF5, 0xCF, 0x52, 0xA8, 0xD2, 0xA4, 0xB4, 0x0B, 0x31, 0x97, 0x57, 0x19, 0x34, 0xDF, 0x5B, 0x41, 0x58, 0x49, 0xAA, 0x5F, 0x0A, 0xEF, 0x88, 0x01, 0xDC, 0x95, 0xD4, 0xAF, 0x7B, 0xE3, 0x11, 0x8E, 0x9D, 0x16, 0x61, 0x8C, 0x84, 0x3C, 0x1F, 0x5A, 0x02, 0x4F, 0x39, 0xFE, 0x04, 0x07, 0x5C, 0x8B, 0xEE, 0x66, 0x33, 0xC4, 0xC8, 0x59, 0xB5, 0x5D, 0xC2, 0x6C, 0xF6, 0x4D, 0xFB, 0xAE, 0x4A, 0x4B, 0xF3, 0x35, 0x2C, 0xCA, 0x21, 0x78, 0x3B, 0x03, 0xFD, 0x24, 0xBD, 0x25, 0x37, 0x29, 0xAC, 0x4E, 0xF9, 0x92, 0x3A, 0x32, 0x4C, 0xDA, 0x06, 0x5E, 0x00, 0x94, 0x60, 0xEC, 0x17, 0x98, 0xD7, 0x3E, 0xCB, 0x6A, 0xA9, 0xD9, 0x9C, 0xBB, 0x08, 0x8F, 0x40, 0xA0, 0x6F, 0x55, 0x67, 0x87, 0x54, 0x80, 0xB2, 0x36, 0x47, 0x22, 0x44, 0x63, 0x05, 0x6B, 0xF0, 0x0F, 0xC7, 0x90, 0xC5, 0x65, 0xE2, 0x64, 0xFA, 0xD5, 0xDB, 0x12, 0x7A, 0x0E, 0xD8, 0x7E, 0x99, 0xD1, 0xE8, 0xD6, 0x86, 0x27, 0xBF, 0xC1, 0x6E, 0xDE, 0x9A, 0x09, 0x0D, 0xAB, 0xE1, 0x91, 0x56, 0xCD, 0xB3, 0x76, 0x0C, 0xC3, 0xD3, 0x9F, 0x42, 0xB6, 0x9B, 0xE5, 0x23, 0xA7, 0xAD, 0x18, 0xC6, 0xF4, 0xB8, 0xBE, 0x15, 0x43, 0x70, 0xE0, 0xE7, 0xBC, 0xF1, 0xBA, 0xA5, 0xA6, 0x53, 0x75, 0xE4, 0xEB, 0xE6, 0x85, 0x14, 0x48, 0xDD, 0x38, 0x2A, 0xCC, 0x7F, 0xB1, 0xC0, 0x71, 0x96, 0xF8, 0x3F, 0x28, 0xF2, 0x69, 0x74, 0x68, 0xB7, 0xA3, 0x50, 0xD0, 0x79, 0x1D, 0xFC, 0xCE, 0x8A, 0x8D, 0x2E, 0x62, 0x30, 0xEA, 0xED, 0x2B, 0x26, 0xB9, 0x81, 0x7C, 0x46, 0x89, 0x73, 0xA2, 0xF7, 0x72];

ProtocolItem.SOCKET_VER = 0x17;
ProtocolItem.SOCKET_BUFFER = 8192;
ProtocolItem.SOCKET_KEY = 0x55;

ProtocolItem.BUFFER_STEP = 100;
ProtocolItem.BUFFER_INIT = 50;
ProtocolItem.BUFFER_RECV = 1024;

module.exports = ProtocolItem;

cc._RFpop();
},{}],"ProtocolMessage":[function(require,module,exports){
"use strict";
cc._RFpush(module, '7d9d2r2p0BBV5qv6lJHgCSR', 'ProtocolMessage');
// Global/qisuLib/comm/ProtocolMessage.js

var ProtocolItem = require("ProtocolItem");

var ProtocolMessage = function ProtocolMessage(nMainCmd, nSubCmd, endian) {
    this._endian = endian;

    // msg head
    this._head_version = 0; // 1字节
    this._head_checkCode = 0; // 1字节
    this._head_msgLen = 0; // 2字节，整个消息长度
    this._head_mainCmdID = nMainCmd; // 2字节
    this._head_subCmdID = nSubCmd; // 2字节

    // msg body
    this._body_msg = new Array(0);

    // 码流
    this.data_buffer = new ArrayBuffer(ProtocolItem.BUFFER_INIT);
    this.data_view = new DataView(this.data_buffer);
    this.data_length = 0;
    this.data_offset = 0;
    this._byte_array = null; // Uint8Array

    // 辅助
    this._receive_seq = 0;
    this._remainLen = 0;
};

ProtocolMessage.GetAvailable = function (msg) {
    return msg.data_length - msg.data_offset;
};
ProtocolMessage.GetRandomNum = function (Min, Max) {
    var Range = Max - Min;
    var Rand = Math.random();
    return Min + Math.round(Rand * Range);
};

ProtocolMessage.GetVersionCodeA = function (serverInfo) {
    if (serverInfo.check === 0) return ProtocolItem.SOCKET_VER;

    return serverInfo.check * ProtocolItem.SOCKET_VER & 0x000000FF;
};

ProtocolMessage.GetCheckCodeA = function (serverInfo, code) {
    if (serverInfo.check === 0) {
        serverInfo.check = ProtocolMessage.GetRandomNum(0, 10000);
    } else {
        code &= 0x000000FF;
        if (code === 0) code = 2;
        serverInfo.check *= code;
        serverInfo.check += ProtocolItem.SOCKET_KEY;
    }

    serverInfo.check &= 0x000000FF;
    if (serverInfo.check === 0) serverInfo.check = 1;

    return serverInfo.check;
};

ProtocolMessage.EncodeMsg = function (msg, serverInfo) {
    // --
    msg.data_length = 0;
    msg.data_offset = 0;

    // --
    ProtocolMessage.encodeByte(msg, ProtocolMessage.GetVersionCodeA(serverInfo));
    ProtocolMessage.encodeByte(msg, 0);
    ProtocolMessage.encodeShort(msg, 0);
    ProtocolMessage.encodeShort(msg, msg._head_mainCmdID);
    ProtocolMessage.encodeShort(msg, msg._head_subCmdID);
    for (var j = 0; j < 21; j++) {
        ProtocolMessage.encodeByte(msg, 0);
    }

    if (ProtocolMessage.recursion_encode_vector(msg, msg._body_msg, true) < 0) return -1;

    // --
    msg.data_offset = 2;
    ProtocolMessage.encodeShort(msg, msg.data_length);

    // --
    var checkCode = 0;
    for (var k = 0; k < msg.data_length - 29; k++) {
        var val = msg.data_view.getUint8(29 + k);
        msg.data_view.setUint8(29 + k, ProtocolItem.SendByteMap[val]);

        checkCode += val;
    }
    checkCode = ProtocolMessage.GetCheckCodeA(serverInfo, checkCode);
    msg.data_offset = 1;
    ProtocolMessage.encodeByte(msg, checkCode);

    // --       
    msg._byte_array = new Uint8Array(msg.data_length);
    for (var n = 0; n < msg.data_length; n++) {
        msg._byte_array[n] = msg.data_view.getUint8(n);
    }

    return 0;
};

ProtocolMessage.recursion_encode_vector = function (msg, value) {
    var beginFlag = arguments.length <= 2 || arguments[2] === undefined ? false : arguments[2];

    if (value === null) {
        return 0;
    }

    if (beginFlag === false) ProtocolMessage.encodeShort(msg, value.length);

    for (var i = 0; i < value.length; i++) {
        ProtocolMessage.encodeByte(msg, value[i]._datatype);
        switch (value[i]._datatype) {
            case ProtocolItem.DATATYPE_BYTE:
                ProtocolMessage.encodeByte(msg, value[i]._int_value);
                break;
            case ProtocolItem.DATATYPE_SHORT:
                ProtocolMessage.encodeShort(msg, value[i]._int_value);
                break;
            case ProtocolItem.DATATYPE_INT:
                ProtocolMessage.encodeInt(msg, value[i]._int_value);
                break;
            case ProtocolItem.DATATYPE_STRING:
                ProtocolMessage.encodeString(msg, value[i]._str_value);
                break;
            case ProtocolItem.DATATYPE_VECTOR:
                if (ProtocolMessage.recursion_encode_vector(msg, value[i]._vect_value) == -1) {
                    return -1;
                }
                break;
            default:
                return -1;
        }
    }

    return 0;
};

ProtocolMessage.Utf8ArrayToStr = function (arrayVal) {
    var out, i, len, c;
    var char2, char3;

    out = "";
    len = arrayVal.length;
    i = 0;
    while (i < len) {
        c = arrayVal[i++];
        switch (c >> 4) {
            case 0:case 1:case 2:case 3:case 4:case 5:case 6:case 7:
                // 0xxxxxxx
                out += String.fromCharCode(c);
                break;
            case 12:case 13:
                // 110x xxxx   10xx xxxx
                char2 = arrayVal[i++];
                out += String.fromCharCode((c & 0x1F) << 6 | char2 & 0x3F);
                break;
            case 14:
                // 1110 xxxx  10xx xxxx  10xx xxxx
                char2 = arrayVal[i++];
                char3 = arrayVal[i++];
                out += String.fromCharCode((c & 0x0F) << 12 | (char2 & 0x3F) << 6 | (char3 & 0x3F) << 0);
                break;
        }
    }

    return out;
};

ProtocolMessage.toUTF8Array = function (str) {
    var utf8 = [];
    for (var i = 0; i < str.length; i++) {
        var charcode = str.charCodeAt(i);
        if (charcode < 0x80) utf8.push(charcode);else if (charcode < 0x800) {
            utf8.push(0xc0 | charcode >> 6, 0x80 | charcode & 0x3f);
        } else if (charcode < 0xd800 || charcode >= 0xe000) {
            utf8.push(0xe0 | charcode >> 12, 0x80 | charcode >> 6 & 0x3f, 0x80 | charcode & 0x3f);
        }
        // surrogate pair
        else {
                i++;
                // UTF-16 encodes 0x10000-0x10FFFF by
                // subtracting 0x10000 and splitting the
                // 20 bits of 0x0-0xFFFFF into two halves
                charcode = 0x10000 + ((charcode & 0x3ff) << 10 | str.charCodeAt(i) & 0x3ff);
                utf8.push(0xf0 | charcode >> 18, 0x80 | charcode >> 12 & 0x3f, 0x80 | charcode >> 6 & 0x3f, 0x80 | charcode & 0x3f);
            }
    }
    return utf8;
};

ProtocolMessage.decodeByte = function (msg) {
    var val = msg.data_view.getUint8(msg.data_offset);
    msg.data_offset++;
    return val;
};
ProtocolMessage.decodeShort = function (msg) {
    var val = msg.data_view.getUint16(msg.data_offset, msg._endian);
    msg.data_offset += 2;
    return val;
};
ProtocolMessage.decodeInt = function (msg) {
    var val = msg.data_view.getUint32(msg.data_offset, msg._endian);
    msg.data_offset += 4;
    return val;
};

ProtocolMessage.encodeByte = function (msg, value) {
    var newLength = msg.data_length;
    if (msg.data_offset + 1 > msg.data_length) newLength = msg.data_offset + 1;
    while (newLength > msg.data_buffer.byteLength) {
        var dataTmp = new Uint8Array(msg.data_buffer.byteLength);
        for (var i = 0; i < msg.data_buffer.byteLength; i++) dataTmp[i] = msg.data_view.getUint8(i);
        msg.data_buffer = new ArrayBuffer(msg.data_buffer.byteLength + ProtocolItem.BUFFER_STEP);
        msg.data_view = new DataView(msg.data_buffer);
        for (var i = 0; i < msg.data_buffer.byteLength; i++) {
            if (i >= dataTmp.byteLength) msg.data_view.setUint8(i, 0);else msg.data_view.setUint8(i, dataTmp[i]);
        }
    }

    msg.data_view.setUint8(msg.data_offset, value);
    msg.data_offset++;
    msg.data_length = newLength;
};
ProtocolMessage.encodeBytes = function (msg, value) {
    for (var i = 0; i < value.length; i++) {
        ProtocolMessage.encodeByte(msg, value[i]);
    }
};
ProtocolMessage.encodeShort = function (msg, value) {
    var newLength = msg.data_length;
    if (msg.data_offset + 2 > msg.data_length) newLength = msg.data_offset + 2;
    while (newLength > msg.data_buffer.byteLength) {
        var dataTmp = new Uint8Array(msg.data_buffer.byteLength);
        for (var i = 0; i < msg.data_buffer.byteLength; i++) dataTmp[i] = msg.data_view.getUint8(i);
        msg.data_buffer = new ArrayBuffer(msg.data_buffer.byteLength + ProtocolItem.BUFFER_STEP);
        msg.data_view = new DataView(msg.data_buffer);
        for (var i = 0; i < msg.data_buffer.byteLength; i++) {
            if (i >= dataTmp.byteLength) msg.data_view.setUint8(i, 0);else msg.data_view.setUint8(i, dataTmp[i]);
        }
    }

    msg.data_view.setUint16(msg.data_offset, value, msg._endian);
    msg.data_offset += 2;
    msg.data_length = newLength;
};
ProtocolMessage.encodeInt = function (msg, value) {
    var newLength = msg.data_length;
    if (msg.data_offset + 4 > msg.data_length) newLength = msg.data_offset + 4;
    while (newLength > msg.data_buffer.byteLength) {
        var dataTmp = new Uint8Array(msg.data_buffer.byteLength);
        for (var i = 0; i < msg.data_buffer.byteLength; i++) dataTmp[i] = msg.data_view.getUint8(i);
        msg.data_buffer = new ArrayBuffer(msg.data_buffer.byteLength + ProtocolItem.BUFFER_STEP);
        msg.data_view = new DataView(msg.data_buffer);
        for (var i = 0; i < msg.data_buffer.byteLength; i++) {
            if (i >= dataTmp.byteLength) msg.data_view.setUint8(i, 0);else msg.data_view.setUint8(i, dataTmp[i]);
        }
    }

    msg.data_view.setUint32(msg.data_offset, value, msg._endian);
    msg.data_offset += 4;
    msg.data_length = newLength;
};
ProtocolMessage.encodeString = function (msg, value) {
    var arrVal = ProtocolMessage.toUTF8Array(value);

    ProtocolMessage.encodeShort(msg, arrVal.length);
    ProtocolMessage.encodeBytes(msg, arrVal);
};

ProtocolMessage.AddVectItemNumber = function (contain, type, value) {
    var pos = arguments.length <= 3 || arguments[3] === undefined ? -1 : arguments[3];

    var item = new ProtocolItem();

    item._datatype = type;
    item._int_value = value;

    if (pos < 0) {
        contain.push(item);
    } else {
        contain.splice(pos, 0, item);
    }

    return contain.length;
};
ProtocolMessage.AddVectItemByte = function (contain, value) {
    var pos = arguments.length <= 2 || arguments[2] === undefined ? -1 : arguments[2];

    return ProtocolMessage.AddVectItemNumber(contain, ProtocolItem.DATATYPE_BYTE, value, pos);
};
ProtocolMessage.AddVectItemShort = function (contain, value) {
    var pos = arguments.length <= 2 || arguments[2] === undefined ? -1 : arguments[2];

    return ProtocolMessage.AddVectItemNumber(contain, ProtocolItem.DATATYPE_SHORT, value, pos);
};
ProtocolMessage.AddVectItemInt = function (contain, value) {
    var pos = arguments.length <= 2 || arguments[2] === undefined ? -1 : arguments[2];

    return ProtocolMessage.AddVectItemNumber(contain, ProtocolItem.DATATYPE_INT, value, pos);
};
ProtocolMessage.AddVectItemString = function (contain, value) {
    var pos = arguments.length <= 2 || arguments[2] === undefined ? -1 : arguments[2];

    var item = new ProtocolItem();

    item._datatype = ProtocolItem.DATATYPE_STRING;
    item._str_value = value;

    if (pos < 0) {
        contain.push(item);
    } else {
        contain.splice(pos, 0, item);
    }

    return contain.length;
};
ProtocolMessage.AddVectItemVect = function (contain) {
    var pos = arguments.length <= 1 || arguments[1] === undefined ? -1 : arguments[1];

    var item = new ProtocolItem();

    item._datatype = ProtocolItem.DATATYPE_VECTOR;
    item._vect_value = new Array(0);

    if (pos < 0) {
        contain.push(item);
    } else {
        contain.splice(pos, 0, item);
    }

    return contain.length;
};

module.exports = ProtocolMessage;

cc._RFpop();
},{"ProtocolItem":"ProtocolItem"}],"SceneEntry":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'f31844jA4dM842dZR9v2gMX', 'SceneEntry');
// Global/qisuLib/Show/SceneEntry.js

cc.Class({
    'extends': cc.Component,

    properties: {
        menuAnim: {
            'default': null,
            type: cc.Animation
        }
    },
    onLoad: function onLoad() {
        this.menuAnim.play('menu_reset');

        this.scheduleOnce((function () {
            this.menuAnim.play('menu_intro');
        }).bind(this), 0.5);
    },

    start: function start() {}
});

cc._RFpop();
},{}],"SelfData":[function(require,module,exports){
"use strict";
cc._RFpush(module, '1b434tZnR1GMYCdHmu6MknN', 'SelfData');
// Global/service/data/SelfData.js

var ProtocolMessage = require("ProtocolMessage");
var constDef = require("ConstDef");

cc.Class({
        "extends": cc.Component,

        properties: {
                // -------[平台数据]---------------------------
                nAccountID: 0,
                sAccountName: "",
                sPassword: "",
                sNickName: "",
                nSex: 0,
                nFhead: 0,
                sFcustom_head: "",
                nFrmbH: 0,
                nFrmb: 0,
                nFcharge_rmbH: 0,
                nFcharge_rmb: 0,
                nFmoneyH: 0,
                nFmoney: 0,
                nFwalletH: 0,
                nFwallet: 0,
                sFreal_name: "",
                sFcard_id: "",
                sFmobile: "",
                sFemail: "",
                nFspreader: 0,

                // -------[令牌数据]---------------------------
                nLogonTS: 0,
                nLogonRand: 0,
                sLogonKey: "",

                // -- 在登录口连接回调中当前状态，用于决定连接后的动作
                nLogonConnectStatus: 0,
                nGameConnectStatus: 0,
                nChatConnectStatus: 0,

                nHeartRspTS: 0, // 心跳响应时间戳

                // -------[全服玩家列表]---------------------------
                players: [], // -- 房间用户 item={nAccountID / nOffLine / nTeamID / baseInfo={nAccountID/sNickName/nSex/nFhead/sFcustom_head}}
                teams: [], // -- 房间队伍 item={nTeamID / nStatus / nOpenMode / playerIDs[nPlayerID]}
                battles: [], // -- 房间战斗 item={nBattleID / TeamIDs[nTeamID]}

                // --------------------------------------
                nLocalServerTimeDiff: 0, //本地和服务器时间差

                // -------[队伍]---------------------------
                nTeamID: 0,
                nOpenMode: 0,

                // -------[战斗]---------------------------
                nBattleID: 0,
                nBattleStatus: 0, //0 初始化   战斗结束      1 战斗中
                nBattleStatusTS: 0, //战斗状态时间

                // -----[游戏]----------------------------
                games: [], // --item={gameID/onLineCount},
                nCurGameID: 0,

                // ------[聊天]----------------------------
                messages: null, // 消息 {key = nFid  value ={nType,nSendID,nSendTS,nParam1,nParam2,sTitle,sContent,sAttachment} }
                relations: null },
        // 好友关系 {key=peerId  value=relation}
        onLoad: function onLoad() {},
        refreshChatUI: function refreshChatUI() {
                var curScene = cc.director.getScene();
                var Canvas = curScene.getChildByName("Canvas");
                var main = Canvas.getComponent("main");
                if (main) main.initChatUI();
        }
});

cc._RFpop();
},{"ConstDef":"ConstDef","ProtocolMessage":"ProtocolMessage"}],"ServerData":[function(require,module,exports){
"use strict";
cc._RFpush(module, '2f5c5TC37tGWaY7hIDx2KBL', 'ServerData');
// Global/service/data/ServerData.js

cc.Class({
    "extends": cc.Component,

    properties: {
        servers: []
    },

    // use this for initialization
    onLoad: function onLoad() {}

});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();
},{}],"ServerInfo":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'a6b7205wadFupmAq6KGOgH8', 'ServerInfo');
// Global/qisuLib/comm/ServerInfo.js

var ServerInfo = function ServerInfo(url) {
    this._url = url;

    this._web_sock = null;

    this.check = 0;

    this.curMsg = null;
    this._flag_receive_step = 0;
    this._msg = null;
    this.vectMsgQueue = new Array(0);
    this.nCurReceiveSeq = 0;

    this.timer = null;
    this.waitTimes = 0;

    this.StartTimer = function () {
        this.timer = window.setInterval(this.onTimer(), 1000);
    };
    this.StopTimer = function () {
        clearInterval(this.timer);
    };

    this.onTimer = function () {
        if (this.vectMsgQueue.length > 0) this.waitTimes++;
    };
};

module.exports = ServerInfo;

cc._RFpop();
},{}],"USocket":[function(require,module,exports){
"use strict";
cc._RFpush(module, '6850cveKLRCUbRbGwFvssy7', 'USocket');
// Global/qisuLib/comm/USocket.js

var ProtocolMessage = require("ProtocolMessage");
var ServerInfo = require("ServerInfo");
var ProtocolItem = require("ProtocolItem");

var servers = {};

var openHandler = null;
var closeHandler = null;
var sendFailedHandler = null;
var messageHandler = null;

var bLogFlag = false;

function onOpen(evt) {
    var url = this.urlVal;
    if (evt.currentTarget !== undefined && evt.currentTarget !== null) {
        url = evt.currentTarget.url;
    }

    if (servers[url] === undefined) {
        return;
    }
    if (servers[url]._web_sock === null) {
        return;
    }

    console.log('websocket opened: ' + servers[url]._url);

    servers[url].StartTimer();

    if (openHandler !== null) {
        openHandler(url);
    }
}
function onClose(evt) {
    var url = this.urlVal;
    if (evt.currentTarget !== undefined && evt.currentTarget !== null) {
        url = evt.currentTarget.url;
    }
    console.log('websocket close: ' + url);
    USocket.CloseSocket(url, USocket.SOCK_CLOSE_PEER);
}
function onMessage(evt) {
    var url = this.urlVal;
    if (evt.currentTarget !== undefined && evt.currentTarget !== null) {
        url = evt.currentTarget.url;
    }

    var serverinfo = servers[url];

    if (serverinfo === undefined) {
        return;
    }
    if (serverinfo._web_sock === null) {
        return;
    }

    if (typeof evt.data == "string") {
        textHandler(url, JSON.parse(evt.data));
    } else {
        var data = new DataView(evt.data);
        if (binaryHandler(url, data, serverinfo) < 0) {
            USocket.CloseSocket(url, USocket.SOCK_CLOSE_DECODE_ERR);
        }

        // let reader = new FileReader();  
        // reader.onload = function(evt)
        // { 
        //     if(evt.target.readyState == FileReader.DONE)
        //     { 
        //         var data = new DataView(evt.target.result); 
        //         if (binaryHandler(url, data,serverinfo)<0)
        //         {
        //             USocket.CloseSocket(url, USocket.SOCK_CLOSE_DECODE_ERR);
        //         } 
        //     } 
        // }; 
        // reader.readAsArrayBuffer(evt.data);
    }
}

function onError(evt) {
    var url = this.urlVal;
    if (evt.currentTarget !== undefined && evt.currentTarget !== null) {
        url = evt.currentTarget.url;
    }

    if (servers[url] === undefined) {
        return;
    }
    if (servers[url]._web_sock === null) {
        return;
    }

    if (sendFailedHandler !== null) {
        sendFailedHandler(url);
    }
}

function IsLittleEndian() {
    var buffer = new ArrayBuffer(2);
    new DataView(buffer).setInt16(0, 256, true /* littleEndian */);

    // return new Int16Array(buffer)[0] === 256;
    if (new Uint8Array(buffer)[0] === 0) return false;else return true;
}

var USocket = {
    isLittleEndian: false,

    init: function init(_openHandler, _messageHandler, _closeHandler, _sendFailedHandler, _bLogFlag) {
        this.isLittleEndian = IsLittleEndian();

        messageHandler = _messageHandler;
        openHandler = _openHandler;
        closeHandler = _closeHandler;
        sendFailedHandler = _sendFailedHandler;

        bLogFlag = _bLogFlag;
    },

    IsConnected: function IsConnected(url) {
        if (url.charAt(url.length - 1) != '/') {
            url += "/";
        }
        if (servers[url] === undefined) return false;
        if (servers[url]._web_sock === null) return false;
        return true;
    },

    AddServer: function AddServer(url) // "ws://203.195.129.201:5338/"
    {
        if (url.charAt(url.length - 1) != '/') {
            url += "/";
        }

        if (servers[url] === undefined) {
            servers[url] = new ServerInfo(url);
            servers[url]._web_sock = new WebSocket(url);
            servers[url]._web_sock.binaryType = "arraybuffer";
            servers[url]._web_sock.urlVal = url;
            servers[url]._web_sock.onopen = onOpen;
            servers[url]._web_sock.onclose = onClose;
            servers[url]._web_sock.onmessage = onMessage;
            servers[url]._web_sock.onerror = onError;
        } else {
            if (servers[url]._web_sock === null) {
                servers[url].check = 0;
                servers[url]._web_sock = new WebSocket(url);
                servers[url]._web_sock.binaryType = "arraybuffer";
                servers[url]._web_sock.urlVal = url;
            } else {}
        }
    },

    CloseSocket: function CloseSocket(url) {
        var errCode = arguments.length <= 1 || arguments[1] === undefined ? 0 : arguments[1];

        if (url.charAt(url.length - 1) != '/') {
            url += "/";
        }

        if (servers[url] === undefined) {
            return;
        }
        if (servers[url]._web_sock === null) {
            return;
        }

        servers[url].StopTimer();
        servers[url]._web_sock.close();

        delete servers[url];

        if (closeHandler !== null) {
            closeHandler(url, errCode);
        }
    },

    SendMessage: function SendMessage(url, msg) {
        if (url.charAt(url.length - 1) != '/') {
            url += "/";
        }

        if (servers[url] === undefined) return -1;
        if (servers[url]._web_sock === null) return -1;
        if (servers[url]._web_sock.readyState != WebSocket.OPEN) return -1;

        var ret = ProtocolMessage.EncodeMsg(msg, servers[url]);
        if (ret !== 0) return -2;
        servers[url]._web_sock.send(msg._byte_array.buffer);

        return 0;
    }
};

USocket.SOCK_CLOSE_SELF = 0;
USocket.SOCK_CLOSE_PEER = 1;
USocket.SOCK_CLOSE_DECODE_ERR = 2;

function textHandler(url, objData) {}

function recursion_decode_vector(_msg) {
    var len = ProtocolMessage.decodeShort(_msg);
    var vect = new Array(len);

    for (var i = 0; i < len; i++) {
        var item = new ProtocolItem();
        item._datatype = ProtocolMessage.decodeByte(_msg);

        switch (item._datatype) {
            case ProtocolItem.DATATYPE_BYTE:
                item._int_value = ProtocolMessage.decodeByte(_msg);
                break;
            case ProtocolItem.DATATYPE_SHORT:
                item._int_value = ProtocolMessage.decodeShort(_msg);
                break;
            case ProtocolItem.DATATYPE_INT:
                item._int_value = ProtocolMessage.decodeInt(_msg);
                break;
            case ProtocolItem.DATATYPE_STRING:

                var strlen = ProtocolMessage.decodeShort(_msg);
                if (strlen > 0) {
                    var pszVal = new Uint8Array(strlen);
                    for (var t = 0; t < strlen; t++) pszVal[t] = ProtocolMessage.decodeByte(_msg);
                    item._str_value = ProtocolMessage.Utf8ArrayToStr(pszVal);
                } else {
                    item._str_value = "";
                }
                break;
            case ProtocolItem.DATATYPE_VECTOR:
                item._vect_value = recursion_decode_vector(_msg);
                break;
            default:
                return null;
        }

        vect[i] = item;
    }

    return vect;
}

function binaryHandler(url, data, serverinfo) {
    // 此处要传入serverinfo，因为chrome下获取不到servers（FileReader异步转换Blob到ArrayBuffer）
    // var serverinfo = servers[url];

    if (serverinfo._msg === null) serverinfo._msg = new ProtocolMessage(0, 0, USocket.isLittleEndian);
    if (serverinfo._msg.data_buffer.byteLength < serverinfo._msg.data_length + data.byteLength) {
        var dataTmp = new Uint8Array(serverinfo._msg.data_length);
        for (var i = 0; i < serverinfo._msg.data_length; i++) dataTmp[i] = serverinfo._msg.data_view.getUint8(i);
        serverinfo._msg.data_buffer = new ArrayBuffer(serverinfo._msg.data_length + data.byteLength);
        serverinfo._msg.data_view = new DataView(serverinfo._msg.data_buffer);
        for (var i = 0; i < serverinfo._msg.data_length; i++) serverinfo._msg.data_view.setUint8(i, dataTmp[i]);
    }
    for (var a1 = 0; a1 < data.byteLength; a1++) serverinfo._msg.data_view.setUint8(serverinfo._msg.data_length + a1, data.getUint8(a1));
    serverinfo._msg.data_length += data.byteLength;

    while (true) {
        if (serverinfo._msg.data_length === 0) break;

        if (serverinfo._flag_receive_step === 0) {
            serverinfo._msg.data_offset = 0;
            serverinfo.curMsg = new ProtocolMessage(0, 0, USocket.isLittleEndian);
        }

        if (serverinfo._flag_receive_step <= 1) {
            if (serverinfo._msg.data_length < 2) {
                serverinfo._flag_receive_step = 1;
                return 0;
            }

            serverinfo.curMsg._head_version = ProtocolMessage.decodeByte(serverinfo._msg);
            serverinfo.curMsg._head_checkCode = ProtocolMessage.decodeByte(serverinfo._msg);
            serverinfo._flag_receive_step = 0;

            if (serverinfo.curMsg._head_version != ProtocolItem.SOCKET_VER) {
                console.log("解码失败（开始标志错误），客户端关闭连接！");
                return -1;
            }
        }

        if (serverinfo._flag_receive_step <= 2) {
            if (ProtocolMessage.GetAvailable(serverinfo._msg) < 2) {
                serverinfo._flag_receive_step = 2;
                return 0;
            }

            serverinfo.curMsg._head_msgLen = ProtocolMessage.decodeShort(serverinfo._msg);
            serverinfo._flag_receive_step = 0;

            serverinfo._msg._remainLen = serverinfo.curMsg._head_msgLen - 4;
        }

        if (serverinfo._flag_receive_step <= 3) {
            if (ProtocolMessage.GetAvailable(serverinfo._msg) < serverinfo._msg._remainLen) {
                serverinfo._msg._remainLen -= ProtocolMessage.GetAvailable(serverinfo._msg);
                serverinfo._flag_receive_step = 3;
                return 0;
            }
            serverinfo._flag_receive_step = 0;
        }

        serverinfo.curMsg._head_mainCmdID = ProtocolMessage.decodeShort(serverinfo._msg);
        serverinfo.curMsg._head_subCmdID = ProtocolMessage.decodeShort(serverinfo._msg);

        for (var i = 0; i < 13; i++) {
            ProtocolMessage.decodeByte(serverinfo._msg);
        }
        serverinfo.curMsg._receive_seq = ProtocolMessage.decodeInt(serverinfo._msg);
        for (var i = 0; i < 4; i++) {
            ProtocolMessage.decodeByte(serverinfo._msg);
        }

        var checkCode = 0;
        for (var k = 29; k < serverinfo.curMsg._head_msgLen; k++) {
            var val = ProtocolItem.RecvByteMap[serverinfo._msg.data_view.getUint8(k)];
            serverinfo._msg.data_view.setUint8(k, val);

            checkCode += val;
        }
        checkCode &= 0x000000FF;
        if (checkCode != serverinfo.curMsg._head_checkCode) {
            console.log("解码失败，校验码错误！");
            return -1;
        }

        while (serverinfo._msg.data_offset < serverinfo.curMsg._head_msgLen - 1) {
            var item = new ProtocolItem();
            item._datatype = ProtocolMessage.decodeByte(serverinfo._msg);

            switch (item._datatype) {
                case ProtocolItem.DATATYPE_BYTE:
                    item._int_value = ProtocolMessage.decodeByte(serverinfo._msg);
                    break;
                case ProtocolItem.DATATYPE_SHORT:
                    item._int_value = ProtocolMessage.decodeShort(serverinfo._msg);
                    break;
                case ProtocolItem.DATATYPE_INT:
                    item._int_value = ProtocolMessage.decodeInt(serverinfo._msg);
                    break;
                case ProtocolItem.DATATYPE_STRING:
                    var len = ProtocolMessage.decodeShort(serverinfo._msg);
                    if (len > 0) {
                        var pszVal = new Uint8Array(len);
                        for (var i = 0; i < len; i++) pszVal[i] = ProtocolMessage.decodeByte(serverinfo._msg);
                        item._str_value = ProtocolMessage.Utf8ArrayToStr(pszVal);
                    } else {
                        item._str_value = "";
                    }
                    break;
                case ProtocolItem.DATATYPE_VECTOR:
                    item._vect_value = recursion_decode_vector(serverinfo._msg);
                    break;
                default:
                    console.log("解码失败（异常），客户端关闭连接！");
                    return -1;
            }

            serverinfo.curMsg._body_msg.push(item);
        }

        var strCmd = "[" + serverinfo.curMsg._head_mainCmdID.toString(16) + ":" + serverinfo.curMsg._head_subCmdID.toString(16) + "]";
        if (bLogFlag) console.log("=========================> RECEIVE MESSAGE, TYPE" + strCmd + ", SEQ[" + serverinfo.curMsg._receive_seq + "]");
        serverinfo._msg.data_length -= serverinfo.curMsg._head_msgLen;
        serverinfo._msg.data_offset = 0;
        for (var i = 0; i < serverinfo._msg.data_length; i++) {
            serverinfo._msg.data_buffer[i] = serverinfo._msg.data_buffer[serverinfo.curMsg._head_msgLen + i];
        }
        var adjustLen = serverinfo._msg.data_length < ProtocolItem.BUFFER_RECV ? ProtocolItem.BUFFER_RECV : serverinfo._msg.data_length;
        if (serverinfo._msg.data_buffer.byteLength != adjustLen) {
            var dataTmp = new Uint8Array(serverinfo._msg.data_length);
            for (var i = 0; i < serverinfo._msg.data_length; i++) dataTmp[i] = serverinfo._msg.data_view.getUint8(i);
            serverinfo._msg.data_buffer = new ArrayBuffer(adjustLen);
            serverinfo._msg.data_view = new DataView(serverinfo._msg.data_buffer);
            for (var i = 0; i < serverinfo._msg.data_length; i++) serverinfo._msg.data_view.setUint8(i, dataTmp[i]);
        }

        if (serverinfo.curMsg._receive_seq == 0) {
            messageHandler(serverinfo.curMsg._head_mainCmdID, serverinfo.curMsg._head_subCmdID, serverinfo.curMsg._body_msg);
            continue;
        }

        if (serverinfo.curMsg._receive_seq < serverinfo.nCurReceiveSeq + 1) {
            console.log("====[FATAL ERROR]====> RECEIVE MESSAGE, TYPE" + strCmd + ", SEQ[" + serverinfo.curMsg._receive_seq + "]");
            return -1;
        } else {
            var x = 0;
            for (x = 0; x < serverinfo.vectMsgQueue.length; x++) {
                if (serverinfo.vectMsgQueue[x]._receive_seq == serverinfo.curMsg._receive_seq) {
                    // 重复接收的消息是否考虑继续 continue;
                    console.log("====[FATAL ERROR]====> RECEIVE MESSAGE, TYPE" + strCmd + ", SEQ[" + serverinfo.curMsg._receive_seq + "]");
                    return -1;
                }
                if (serverinfo.vectMsgQueue[x]._receive_seq > serverinfo.curMsg._receive_seq) break;
            }
            if (x == serverinfo.vectMsgQueue.length) {
                serverinfo.vectMsgQueue.push(serverinfo.curMsg);
            } else {
                serverinfo.vectMsgQueue.splice(x, 0, serverinfo.curMsg);
            }

            for (x = 0; x < serverinfo.vectMsgQueue.length; x++) {
                var msgItem = serverinfo.vectMsgQueue[x];
                if (msgItem._receive_seq == serverinfo.nCurReceiveSeq + 1) {
                    serverinfo.nCurReceiveSeq = serverinfo.nCurReceiveSeq + 1;
                    messageHandler(msgItem._head_mainCmdID, msgItem._head_subCmdID, msgItem._body_msg);
                } else break;
            }
            serverinfo.vectMsgQueue.splice(0, x);

            if (serverinfo.vectMsgQueue.length == 0) serverinfo.waitTimes = 0;else {
                console.log("====[ERROR]====> RECEIVE MESSAGE, TYPE" + strCmd + ", SEQ[" + serverinfo.curMsg._receive_seq + "], vect length[" + serverinfo.vectMsgQueue.length + "]");
                if (serverinfo.waitTimes > 5) {
                    console.log("====[FATAL ERROR, timeout]====> RECEIVE MESSAGE, TYPE" + strCmd + ", SEQ[" + serverinfo.curMsg._receive_seq + "], vect length[" + serverinfo.vectMsgQueue.length + "]");
                    return -1;
                }
            }
            if (serverinfo.vectMsgQueue.length > 100) {
                console.log("====[FATAL ERROR]====> RECEIVE MESSAGE, TYPE" + strCmd + ", SEQ[" + serverinfo.curMsg._receive_seq + "], vect length[" + serverinfo.vectMsgQueue.length + "]");
                return -1;
            }
        }
    }

    return 0;
}

module.exports = USocket;

cc._RFpop();
},{"ProtocolItem":"ProtocolItem","ProtocolMessage":"ProtocolMessage","ServerInfo":"ServerInfo"}],"Utils":[function(require,module,exports){
"use strict";
cc._RFpush(module, '61a91CJcNtEAqhjsZHkMJvO', 'Utils');
// Global/qisuLib/base/Utils.js

var md5 = require("md5");

var Utils = {
    SwapArrayItems: function SwapArrayItems(arr, index1, index2) {
        arr[index1] = arr.splice(index2, 1, arr[index1])[0];
        return arr;
    },

    md5Encrypt: function md5Encrypt(val) {
        return md5.md5(val);
    },

    // 获取数字字串，比如 1234567 => 123.4万
    // 输入参数应为正整数
    GetNumberString: function GetNumberString(val) {
        if (val < 10000) {
            return val.toString();
        } else if (val >= 10000 && val < 100000000) {
            val = val / 10000;
            val = val.toFixed(1);
            return val.toString() + "万";
        } else {
            val = val / 10000;
            val = val / 10000;
            val = val.toFixed(1);
            return val.toString() + "亿";
        }
    },

    GetHexString: function GetHexString(val) {
        var tempName = val.toString(16);
        for (var i = 0; i < 8; i++) {
            if (tempName.length >= 8) break;
            tempName = "0" + tempName;
        }
        tempName = "0x" + tempName;
        return tempName;
    },
    CalcAngle: function CalcAngle(start, end) {
        var diff_x = end.x - start.x;
        var diff_y = end.y - start.y;
        if (end.x === start.x) {
            if (diff_y >= 0) return 0;else return 180;
        } else if (end.y === start.y) {
            if (diff_x >= 0) return 90;else return 270;
        } else {
            if (diff_x > 0 && diff_y > 0) {
                return 360 * Math.atan(diff_x / diff_y) / (2 * Math.PI);
            } else if (diff_x < 0 && diff_y < 0) {
                return 360 * Math.atan(diff_x / diff_y) / (2 * Math.PI) - 180;
            } else if (diff_x > 0 && diff_y < 0) {
                return 360 * Math.atan(diff_x / diff_y) / (2 * Math.PI) - 180;
            } else if (diff_x < 0 && diff_y > 0) {
                return 360 * Math.atan(diff_x / diff_y) / (2 * Math.PI);
            } else {
                return 0;
            }
        }
    }
};

module.exports = Utils;

cc._RFpop();
},{"md5":"md5"}],"YingsanzhangConstDef":[function(require,module,exports){
"use strict";
cc._RFpush(module, '5edcaQBsAZCqINHb3wb1tri', 'YingsanzhangConstDef');
// resources/Games/Yingsanzhang/src/YingsanzhangConstDef.js

var CONNECT_CALLBACK_STATUS = cc.Enum({
    //===================【主命令】======================
    MIAN_LOGON: 0x0001,
    MIAN_GUIDE: 0x0002,
    MIAN_HOME: 0x0003,

    //===================【引导场景】====================  
    GUIDE_SET_CLIENT_DATA: 0X00020001, // 修改信息

    //====================【主场景】=====================  
    HOME_ENTER_ROOM: 0x00030001, //进入房间

    HOME_LEAVE_TEAM: 0x00030002, //离开队伍

    //================================================== 
    STATUS_INIT: 0 });

// 初始化，无动作

var CARDS_TYPE = cc.Enum({
    NONE: 0, // 不符合规则
    TYPE_ER_SAN_WU: 1, // 1 235
    TYPE_Dan_ZHANG: 2, // 2 单张
    TYPE_DUI_ZI: 3, // 3 对子
    TYPE_SHUN_ZI: 4, // 4 顺子
    TYPE_TONG_HUA: 5, // 5 同花
    TYPE_TONG_HUA_SHUN: 6, // 6 同花顺
    TYPE_BAO_ZI: 7 });
// 7 豹子
var PLAYER_OPERATION_TYPE = {
    OPERATION_DISCARD: 1,
    OPERATION_LOOKCARD: 2,
    OPERATION_LOSE: 3
};
var FIGHT_RESULT = {
    LOSE: 1,
    WIN: 2
};
var FIGHT_STATUS = cc.Enum({
    INIT: 0,
    BEGIN: 1,
    WAIT_BET: 2,
    FIGHTING: 3,
    END: 4,

    C_READY_BEGIN: 101,
    C_CANCEL_BEGIN: 102,

    C_BEGIN: 103,

    C_BEGIN_SEND_CARD: 104, // 发三张牌 104 ~ 106

    C_BEGIN_SEND_READY: 108, // 发完牌

    C_BET_START: 110,

    C_END: 115, // 收到战斗战斗结束消息的时候设置为该状态（开牌、弹窗、飞钱、飘钱）

    C_END_P1: 121, // 播放弹窗前
    C_END_P2: 122, // 弹窗播放结束，紧接着播放飘钱
    C_END_FINISH: 123
});

var COIN_TYPE = cc.Enum({
    diamond: 0, //钻石
    gold: 1 //金币
});

var GAME_WAIT_TIME = {
    GRAB_BANKER_WAIT_TIME: 10,
    FIRST_OUT_CARD_WAIT_TIME: 25,
    OUT_CARD_WAIT_TIME: 25,
    OUT_CARD_ONLY_PASEE_WAIT_TIME: 10,
    OUT_CARD_LESS_ONLY_PASEE_WAIT_TIME: 3,
    ROCKET_WAIT_TIME: 3,
    READY_WAIT_TIME: 35
};
var CARD_STATUS = cc.Enum({
    OPEN_CARD: 1,
    DARD_CARD: 2
});
var MESSAGE = {
    CMD_MAIN_YingSanZhang: 0x8001,
    // --------------------------------------------
    BET_REQ: 0x0001,
    BET_SUCCESS: 0x0002,
    BET_FAILED: 0x0003,
    BET_NOTIFY: 0x0004,

    FOLLOW_BET_REQ: 0x0005,
    FOLLOW_BET_SUCCESS: 0x0006,
    FOLLOW_BET_FAILED: 0x0007,
    FOLLOW_BET_NOTIFY: 0x0008,

    ADD_BET_REQ: 0x0009,
    ADD_BET_SUCCESS: 0x00010,
    ADD_BET_FAILED: 0x00011,
    ADD_BET_NOTIFY: 0x00012,

    LOOK_CARD_REQ: 0x00013,
    LOOK_CARD_SUCCESS: 0x00014,
    LOOK_CARD_FAILED: 0x00015,
    LOOK_CARD_NOTIFY: 0x00016,

    DISCARD_REQ: 0x00017,
    DISCARD_SUCCESS: 0x00018,
    DISCARD_FAILED: 0x00019,
    DISCARD_NOTIFY: 0x00020,

    COMPARE_CARD_REQ: 0x00021,
    COMPARE_CARD_SUCCESS: 0x00022,
    COMPARE_CARD_FAILED: 0x00023,
    COMPARE_CARD_NOTIFY: 0x00024
};

// -------------------------------------------------------

module.exports = {
    PLAYER_OPERATION_TYPE: PLAYER_OPERATION_TYPE,
    CONNECT_CALLBACK_STATUS: CONNECT_CALLBACK_STATUS,
    MESSAGE: MESSAGE,
    COIN_TYPE: COIN_TYPE,
    FIGHT_STATUS: FIGHT_STATUS,
    GAME_WAIT_TIME: GAME_WAIT_TIME,
    CARD_STATUS: CARD_STATUS,
    CARDS_TYPE: CARDS_TYPE
};

cc._RFpop();
},{}],"YingsanzhangGameController":[function(require,module,exports){
"use strict";
cc._RFpush(module, '662a3kMehJGb6pkIxUsdjzi', 'YingsanzhangGameController');
// resources/Games/Yingsanzhang/src/YingsanzhangGameController.js

var constDef = require("ConstDef");
var gameConstDef = require("YingsanzhangConstDef");
var ProtocolMessage = require("ProtocolMessage");
var HintManager = require("HintManager");
var GlobalManager = require("GlobalManager");
var GameMessage = require("YingsanzhangGameMessage");

cc.Class({
    "extends": cc.Component,

    properties: {
        gameData: require("YingsanzhangGameData")

    },
    onLoad: function onLoad() {},
    gameRegisterMessage: function gameRegisterMessage() {
        GlobalManager.instance.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_PLATFORM, constDef.MESSAGE.ENTER_ROOM_SUCCESS, GameMessage.handler_ENTER_ROOM_SUCCESS);
        GlobalManager.instance.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_PLATFORM, constDef.MESSAGE.ENTER_ROOM_FAILED, GameMessage.handler_ENTER_ROOM_FAILED);

        GlobalManager.instance.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_PLATFORM, constDef.MESSAGE.PLAYER_ENTER_ROOM_NOTIFY, GameMessage.handler_PLAYER_ENTER_ROOM_NOTIFY);
        GlobalManager.instance.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_PLATFORM, constDef.MESSAGE.PLAYER_LEAVE_ROOM_NOTIFY, GameMessage.handler_PLAYER_LEAVE_ROOM_NOTIFY);

        GlobalManager.instance.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_PLATFORM, constDef.MESSAGE.GET_GAME_INFO_SUCCESS, GameMessage.handler_GET_GAME_INFO_SUCCESS);
        GlobalManager.instance.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_PLATFORM, constDef.MESSAGE.GET_GAME_INFO_FAILED, GameMessage.handler_GET_GAME_INFO_FAILED);

        GlobalManager.instance.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_PLATFORM, constDef.MESSAGE.GET_PLAYERS_BASE_INFO_SUCCESS, GameMessage.handler_GET_PLAYERS_BASE_INFO_SUCCESS);
        GlobalManager.instance.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_PLATFORM, constDef.MESSAGE.GET_PLAYERS_BASE_INFO_FAILED, GameMessage.handler_GET_PLAYERS_BASE_INFO_FAILED);

        GlobalManager.instance.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_PLATFORM, constDef.MESSAGE.BALANCE_NOTIFY, GameMessage.handler_BALANCE_NOTIFY);

        GlobalManager.instance.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_GAME, constDef.MESSAGE.LEAVE_TEAM_NOTIFY, GameMessage.handler_LEAVE_TEAM_NOTIFY);
        GlobalManager.instance.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_GAME, constDef.MESSAGE.TEAM_ALL_READY_NOTIFY, GameMessage.handler_TEAM_ALL_READY_NOTIFY);
        GlobalManager.instance.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_GAME, constDef.MESSAGE.TEAM_ALL_READY_SUCCESS, GameMessage.handler_TEAM_ALL_READY_SUCCESS);
        GlobalManager.instance.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_GAME, constDef.MESSAGE.TEAM_ALL_READY_FAILED, GameMessage.handler_TEAM_ALL_READY_FAILED);
        GlobalManager.instance.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_GAME, constDef.MESSAGE.ENTER_BATTLE_NOTIFY, GameMessage.handler_ENTER_BATTLE_NOTIFY);
        GlobalManager.instance.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_GAME, constDef.MESSAGE.ENTER_BATTLE_SUCCESS, GameMessage.handler_ENTER_BATTLE_SUCCESS);
        GlobalManager.instance.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_GAME, constDef.MESSAGE.ENTER_BATTLE_FAILED, GameMessage.handler_ENTER_BATTLE_FAILED);
        GlobalManager.instance.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_GAME, constDef.MESSAGE.FIGHT_READY_SUCCESS, GameMessage.handler_FIGHT_READY_SUCCESS);
        GlobalManager.instance.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_GAME, constDef.MESSAGE.FIGHT_READY_FAILED, GameMessage.handler_FIGHT_READY_FAILED);
        GlobalManager.instance.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_GAME, constDef.MESSAGE.FIGHT_READY_NOTIFY, GameMessage.handler_FIGHT_READY_NOTIFY);
        GlobalManager.instance.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_GAME, constDef.MESSAGE.SCENE_READY_NOTIFY, GameMessage.handler_SCENE_READY_NOTIFY);
        GlobalManager.instance.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_GAME, constDef.MESSAGE.SCENE_READY_SUCCESS, GameMessage.handler_SCENE_READY_SUCCESS);
        GlobalManager.instance.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_GAME, constDef.MESSAGE.SCENE_READY_FAILED, GameMessage.handler_SCENE_READY_FAILED);
        GlobalManager.instance.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_GAME, constDef.MESSAGE.FIGHT_BEGIN_NOTIFY, GameMessage.handler_FIGHT_BEGIN_NOTIFY);
        GlobalManager.instance.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_GAME, constDef.MESSAGE.FIGHT_END_NOTIFY, GameMessage.handler_FIGHT_END_NOTIFY);
        GlobalManager.instance.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_GAME, constDef.MESSAGE.GET_TEAM_MEMBERS_SUCCESS, GameMessage.handler_GET_TEAM_MEMBERS_SUCCESS);
        GlobalManager.instance.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_GAME, constDef.MESSAGE.GET_TEAM_MEMBERS_FAILED, GameMessage.handler_GET_TEAM_MEMBERS_FAILED);
        GlobalManager.instance.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_GAME, constDef.MESSAGE.GET_MATCH_DATA_NOTIFY, GameMessage.handler_GET_MATCH_DATA_NOTIFY);
        GlobalManager.instance.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_GAME, constDef.MESSAGE.GET_MATCH_CUR_COUNT_SUCCESS, GameMessage.handler_GET_MATCH_CUR_COUNT_SUCCESS);
        GlobalManager.instance.RegMsgHandler(constDef.MESSAGE.CMD_MAIN_GAME, constDef.MESSAGE.GET_MATCH_CUR_COUNT_FAILED, GameMessage.handler_GET_MATCH_CUR_COUNT_FAILED);

        GlobalManager.instance.RegMsgHandler(gameConstDef.MESSAGE.CMD_MAIN_YingSanZhang, gameConstDef.MESSAGE.BET_SUCCESS, GameMessage.handler_BET_SUCCESS);
        GlobalManager.instance.RegMsgHandler(gameConstDef.MESSAGE.CMD_MAIN_YingSanZhang, gameConstDef.MESSAGE.BET_FAILED, GameMessage.handler_BET_FAILED);
        GlobalManager.instance.RegMsgHandler(gameConstDef.MESSAGE.CMD_MAIN_YingSanZhang, gameConstDef.MESSAGE.BET_NOTIFY, GameMessage.handler_BET_NOTIFY);

        GlobalManager.instance.RegMsgHandler(gameConstDef.MESSAGE.CMD_MAIN_YingSanZhang, gameConstDef.MESSAGE.FOLLOW_BET_SUCCESS, GameMessage.handler_FOLLOW_BET_SUCCESS);
        GlobalManager.instance.RegMsgHandler(gameConstDef.MESSAGE.CMD_MAIN_YingSanZhang, gameConstDef.MESSAGE.FOLLOW_BET_NOTIFY, GameMessage.handler_FOLLOW_BET_NOTIFY);
        GlobalManager.instance.RegMsgHandler(gameConstDef.MESSAGE.CMD_MAIN_YingSanZhang, gameConstDef.MESSAGE.FOLLOW_BET_FAILED, GameMessage.handler_FOLLOW_BET_FAILED);

        GlobalManager.instance.RegMsgHandler(gameConstDef.MESSAGE.CMD_MAIN_YingSanZhang, gameConstDef.MESSAGE.ADD_BET_SUCCESS, GameMessage.handler_ADD_BET_SUCCESS);
        GlobalManager.instance.RegMsgHandler(gameConstDef.MESSAGE.CMD_MAIN_YingSanZhang, gameConstDef.MESSAGE.ADD_BET_FAILED, GameMessage.handler_ADD_BET_FAILED);
        GlobalManager.instance.RegMsgHandler(gameConstDef.MESSAGE.CMD_MAIN_YingSanZhang, gameConstDef.MESSAGE.ADD_BET_NOTIFY, GameMessage.handler_ADD_BET_NOTIFY);

        GlobalManager.instance.RegMsgHandler(gameConstDef.MESSAGE.CMD_MAIN_YingSanZhang, gameConstDef.MESSAGE.LOOK_CARD_SUCCESS, GameMessage.handler_LOOK_CARD_SUCCESS);
        GlobalManager.instance.RegMsgHandler(gameConstDef.MESSAGE.CMD_MAIN_YingSanZhang, gameConstDef.MESSAGE.LOOK_CARD_NOTIFY, GameMessage.handler_LOOK_CARD_NOTIFY);
        GlobalManager.instance.RegMsgHandler(gameConstDef.MESSAGE.CMD_MAIN_YingSanZhang, gameConstDef.MESSAGE.LOOK_CARD_FAILED, GameMessage.handler_LOOK_CARD_FAILED);

        GlobalManager.instance.RegMsgHandler(gameConstDef.MESSAGE.CMD_MAIN_YingSanZhang, gameConstDef.MESSAGE.DISCARD_SUCCESS, GameMessage.handler_DISCARD_SUCCESS);
        GlobalManager.instance.RegMsgHandler(gameConstDef.MESSAGE.CMD_MAIN_YingSanZhang, gameConstDef.MESSAGE.DISCARD_FAILED, GameMessage.handler_DISCARD_FAILED);
        GlobalManager.instance.RegMsgHandler(gameConstDef.MESSAGE.CMD_MAIN_YingSanZhang, gameConstDef.MESSAGE.DISCARD_NOTIFY, GameMessage.handler_DISCARD_NOTIFY);

        GlobalManager.instance.RegMsgHandler(gameConstDef.MESSAGE.CMD_MAIN_YingSanZhang, gameConstDef.MESSAGE.COMPARE_CARD_SUCCESS, GameMessage.handler_COMPARE_CARD_SUCCESS);
        GlobalManager.instance.RegMsgHandler(gameConstDef.MESSAGE.CMD_MAIN_YingSanZhang, gameConstDef.MESSAGE.COMPARE_CARD_FAILED, GameMessage.handler_COMPARE_CARD_FAILED);
        GlobalManager.instance.RegMsgHandler(gameConstDef.MESSAGE.CMD_MAIN_YingSanZhang, gameConstDef.MESSAGE.COMPARE_CARD_NOTIFY, GameMessage.handler_COMPARE_CARD_NOTIFY);
    },

    RefreshPlayerData: function RefreshPlayerData(type) {
        cc.log("type", type);
    },
    SendMsg: function SendMsg(status) {
        var gameData = GlobalManager.instance.GetGameData(GlobalManager.instance.selfData.nCurGameID);
        switch (status) {
            case constDef.CONNECT_CALLBACK_STATUS.LOGON_GET_GAME_INFO:
                {
                    var _msg = new ProtocolMessage(constDef.MESSAGE.CMD_MAIN_PLATFORM, constDef.MESSAGE.GET_GAME_INFO_REQ, false);
                    ProtocolMessage.AddVectItemInt(_msg._body_msg, GlobalManager.instance.selfData.nAccountID);
                    ProtocolMessage.AddVectItemInt(_msg._body_msg, GlobalManager.instance.selfData.nCurGameID);
                    ProtocolMessage.AddVectItemInt(_msg._body_msg, 0);
                    ProtocolMessage.AddVectItemInt(_msg._body_msg, 0);
                    GlobalManager.instance.SendLogonMsg(_msg);
                    break;
                }
            case constDef.CONNECT_CALLBACK_STATUS.LOGON_GET_PLAYERS_BASE_INFO:
                {
                    cc.log("LOGON_GET_PLAYERS_BASE_INFO");
                    var _msg2 = new ProtocolMessage(constDef.MESSAGE.CMD_MAIN_PLATFORM, constDef.MESSAGE.GET_PLAYERS_BASE_INFO_REQ, false);
                    ProtocolMessage.AddVectItemInt(_msg2._body_msg, GlobalManager.instance.selfData.nAccountID);
                    ProtocolMessage.AddVectItemInt(_msg2._body_msg, GlobalManager.instance.selfData.nCurGameID);

                    var vectIndex = _msg2._body_msg.length;
                    ProtocolMessage.AddVectItemVect(_msg2._body_msg);
                    for (var i = 0; i < gameData.vectTeamList.length; i++) {
                        if (gameData.vectTeamList[i].nAccountID > 0 && gameData.vectTeamList[i].nick == "") {
                            ProtocolMessage.AddVectItemInt(_msg2._body_msg[vectIndex]._vect_value, gameData.vectTeamList[i].nAccountID);
                        }
                    }
                    GlobalManager.instance.SendLogonMsg(_msg2);
                    break;
                }

            // ----------------------
            case gameConstDef.CONNECT_CALLBACK_STATUS.HOME_ENTER_ROOM:
                {
                    var msg = new ProtocolMessage(constDef.MESSAGE.CMD_MAIN_PLATFORM, constDef.MESSAGE.ENTER_ROOM_REQ, false);
                    ProtocolMessage.AddVectItemInt(msg._body_msg, GlobalManager.instance.selfData.nAccountID);
                    ProtocolMessage.AddVectItemInt(msg._body_msg, GlobalManager.instance.selfData.nLogonTS);
                    ProtocolMessage.AddVectItemInt(msg._body_msg, GlobalManager.instance.selfData.nLogonRand);
                    ProtocolMessage.AddVectItemString(msg._body_msg, GlobalManager.instance.selfData.sLogonKey);
                    GlobalManager.instance.SendGameMsg(msg);
                    break;
                }
            case gameConstDef.CONNECT_CALLBACK_STATUS.HOME_LEAVE_TEAM:
                {
                    var _msg3 = new ProtocolMessage(constDef.MESSAGE.CMD_MAIN_GAME, constDef.MESSAGE.LEAVE_TEAM_REQ, false);
                    GlobalManager.instance.SendGameMsg(_msg3);
                    break;
                }
        }
    }
});

cc._RFpop();
},{"ConstDef":"ConstDef","GlobalManager":"GlobalManager","HintManager":"HintManager","ProtocolMessage":"ProtocolMessage","YingsanzhangConstDef":"YingsanzhangConstDef","YingsanzhangGameData":"YingsanzhangGameData","YingsanzhangGameMessage":"YingsanzhangGameMessage"}],"YingsanzhangGameData":[function(require,module,exports){
"use strict";
cc._RFpush(module, '76d56MJW9dLkZuC9dik71Eh', 'YingsanzhangGameData');
// resources/Games/Yingsanzhang/src/YingsanzhangGameData.js

var constDef = require("ConstDef");
var ProtocolMessage = require("ProtocolMessage");
var GlobalManager = require("GlobalManager");
var gameConstDef = require("YingsanzhangConstDef");

cc.Class({
    "extends": cc.Component,

    properties: {

        instanceGlobal: null,

        nGameID: 1,
        rooms: [], //item={nRoomID/onLineCount},
        // -------[队伍]---------------------------
        nTeamID: 0,
        nOpenMode: 0,

        // -------[战斗]---------------------------
        nBattleID: 0,
        nBattleStatus: 0, //0 初始化   战斗结束      1 战斗中
        nBattleStatusTS: 0, //战斗状态时间

        nClientStatus: 0,

        nLeaveRoomFlag: 0, // 0 表示主动离开  1 表示房间解散

        // -- 参战多方队伍ID列表
        // vectTeamList
        vectTeamList: [], // 当前战斗队伍 item = {nTeamID}     
        //                  = {nCardType}   // 牌类型
        //                  = {nLookFlag}   // 是否看牌
        //                  = {nGiveupFlag}   //是否弃牌
        //                  = {nTotalMoney}   //总钱数
        //                  = {puke[0,1,3]}      //牌
        puke: [], //玩家的当前牌，
        nAccountID: 0,
        nBattleID: 0,
        nLogicStatus: 0, //状态
        nLogicTS: 0, // 当前状态时间戳
        nCurSit: 0, // 当前庄座位号
        nCurRate: 0, // 当前底注

        //-------[房间 gameServer]-------------------------------
        nRoomID: 0,
        // -------[GAME相关数据]---------------------------
        nFdiamondH: 0,
        nFdiamondL: 0,
        nFcoinH: 0,
        nFcoinL: 0,
        nFbeginner_flag: 1,

        // -------[比赛相关数据]---------------------------------
        // hashMatchData:{},    // key=matchTS  data={}

        // hashMatchData[ts] = {}

        nMatchCurSignCount: 0, // 比赛当前报名人数
        nMatchTS: 0, // 比赛开始时间
        nMatchFlag: 0,
        nMatchStatus: 0,
        nMatchStatusTS: 0,
        nMatchRemainCount: 0,
        nMatchRank: 0

    },
    //---------------[临时变量]------------------------------

    onLoad: function onLoad() {},
    // -- 获取自己的座位，从1开始；0表示不在房间
    GetSelfSit: function GetSelfSit() {
        if (this.nTeamID === 0) return 0;
        var selfIndex = 0;
        for (selfIndex = 0; selfIndex < this.vectTeamList.length; selfIndex++) {
            if (this.vectTeamList[selfIndex].nTeamID == this.nTeamID) break;
        }
        if (selfIndex == this.vectTeamList.length) return 0;
        return selfIndex + 1;
    },
    ClearOnePlayerData: function ClearOnePlayerData(pos) {
        var item = this.vectTeamList[pos];
        item.nTeamID = 0;
        item.nCardType = -1; // -1表示尚未抢庄，0表示不抢，1~4表示抢庄倍数
        item.nLookFlag = 0;
        item.nGiveupFlag = 255;
        item.puke = [];
        item.puke.push(0);
        item.puke.push(0);
        item.puke.push(0);
        item.nResult = 0;
        item.nTotalMoney = 0;
        item.nAccountID = 0;
        item.nSit = 0;
        item.nick = "";
        item.sex = 0;
        item.head = 0;
        item.customHead = null;
        item.coinH = 0;
        item.coinL = 0;
        item.isOffline = 0;
    },
    ClearBattleData: function ClearBattleData(bStayInGame) {
        if (bStayInGame !== true) bStayInGame = false;

        this.nCurBanker = 0;

        if (bStayInGame === true) {
            for (var i = 0; i < 5; i++) {
                var item = this.vectTeamList[i];
                item.nTeamID = 0;
                item.nCardType = 0;
                item.nLookFlag = 0;
                item.nGiveupFlag = 0;
                item.nTotalMoney = 0;
                item.nAccountID = 0;
                item.nSit = 0;
                item.puke = [];
                item.puke.push(0);
                item.puke.push(0);
                item.puke.push(0);
            }
            this.nClientStatus = 0;
            this.ClientStatusParam = [];
        } else {
            this.nBattleID = 0;
            this.nBattleStatus = 0;
            this.nBattleStatusTS = 0;

            this.vectTeamList = [];
            for (var i = 0; i < 5; i++) {
                var item = {};
                item.nTeamID = 0;
                item.nCardType = 0;
                item.nLookFlag = 0;
                item.nGiveupFlag = 0;
                item.nTotalMoney = 0;
                item.nAccountID = 0;
                item.puke = [];
                item.puke.push(0);
                item.puke.push(0);
                item.puke.push(0);
                item.nResult = 0;
                item.nAccountID = 0;
                item.nick = "";
                item.sex = 0;
                item.head = 0;
                item.customHead = null;
                item.coinH = 0;
                item.coinL = 0;
                this.vectTeamList.push(item);
            }
            this.nClientStatus = 0;
            this.ClientStatusParam = [];
        }
    },

    InitBattleData: function InitBattleData(bodyMsg) {
        var index = 0;
        this.nAccountID = bodyMsg[index++]._int_value;
        this.nBattleID = bodyMsg[index++]._int_value;
        this.nLogicStatus = bodyMsg[index++]._int_value;
        this.nLogicTS = bodyMsg[index++]._int_value;

        this.nCurSit = bodyMsg[index++]._int_value;
        this.nCurRate = bodyMsg[index++]._int_value;

        var vectList = bodyMsg[index++]._vect_value;
        var itemCount = 8;
        var count = vectList.length / itemCount;
        for (var i = 0; i < count; i++) {
            var index1 = 0;
            var item = this.vectTeamList[i];
            item.nTeamID = vectList[i * itemCount + index1++]._int_value;
            item.nCardType = vectList[i * itemCount + index1++]._int_value - 1;
            item.nLookFlag = vectList[i * itemCount + index1++]._int_value;
            item.nGiveupFlag = vectList[i * itemCount + index1++]._int_value;
            item.nTotalMoney = vectList[i * itemCount + index1++]._int_value;
            item.puke[0] = vectList[i * itemCount + index1++]._int_value;
            item.puke[1] = vectList[i * itemCount + index1++]._int_value;
            item.puke[2] = vectList[i * itemCount + index1++]._int_value;
        }

        //获取队伍成员账号ID
        var msg = new ProtocolMessage(constDef.MESSAGE.CMD_MAIN_GAME, constDef.MESSAGE.GET_TEAM_MEMBERS_REQ, false);
        var vectIndex = 0;
        ProtocolMessage.AddVectItemVect(msg._body_msg);
        for (var i = 0; i < this.vectTeamList.length; i++) {
            if (this.vectTeamList[i].nTeamID > 0) {
                ProtocolMessage.AddVectItemInt(msg._body_msg[vectIndex]._vect_value, this.vectTeamList[i].nTeamID);
            }
        }
        GlobalManager.instance.SocketManager.SendMessage(constDef.SERVER_URL.game, msg);
    },
    ClearMatchData: function ClearMatchData() {
        this.nMatchCurSignCount = 0;
        this.nMatchTS = 0;
        this.nMatchFlag = 0;
        this.nMatchStatus = 0;
        this.nMatchStatusTS = 0;
        this.nMatchRemainCount = 0;
        this.nMatchRank = 0;
    },
    RefreshData: function RefreshData(nDataType) {
        if (nDataType === null) nDataType = 0;
        if (typeof nDataType == "undefined") nDataType = 0;

        var curScene = cc.director.getScene();
        var Canvas = curScene.getChildByName("Canvas");
        var WarUI = Canvas.getComponent("Yingsanzhang_WarUI");
        if (WarUI) {
            if (nDataType == 0) WarUI.RefreshUI();else if (nDataType == 1) WarUI.RefreshEndUI();
        }
    },
    RefreshPlayerData: function RefreshPlayerData(nDataType) {
        // -- 0 : 全部刷新
        // -- 1 : 只刷新玩家基本数据
        // -- 2 : 不刷新牌的数目
        // -- 3 : 不刷新牌

        if (nDataType === null) nDataType = 0;
        if (typeof nDataType == "undefined") nDataType = 0;

        var curScene = cc.director.getScene();
        var Canvas = curScene.getChildByName("Canvas");
        var WarUI = Canvas.getComponent("Yingsanzhang_WarUI");
        if (WarUI) {
            WarUI.RefreshPlayerData(nDataType);
        }
    },

    RefreshGameWait: function RefreshGameWait() {
        var curScene = cc.director.getScene();
        var Canvas = curScene.getChildByName("Canvas");
        var matchWaitPanel = Canvas.getChildByName("waitPanel");
        if (matchWaitPanel) {
            matchWaitPanel.getComponent("wait").RefreshUI();
        }
    },

    initCurGameRemainCount: function initCurGameRemainCount() // 计算当前这局比赛人数    不需要考虑打立出局
    {
        var curNodeBaseInfo = this.getCurNodeBaseInfo();
        switch (this.nMatchStatus) {
            case constDef.MATCH_STATUS.INIT:
                {
                    this.nMatchRemainCount = this.nMatchCurSignCount;
                    break;
                }
            case constDef.MATCH_STATUS.PHASE_1_BEGIN:
                {
                    if (curNodeBaseInfo.Fphase_1_mode == constDef.MATCH_MODE.FIXED_ROUND) {
                        var rounds = curNodeBaseInfo.Fphase_1_param3.substr(0, curNodeBaseInfo.Fphase_1_param3.length - 1);
                        var perRoundPersonArr = rounds.split(";");
                        if (this.nMatchRemainCount == 0) {
                            this.nMatchRemainCount = perRoundPersonArr[0];
                            break;
                        }

                        for (var i = 1; i < perRoundPersonArr.length; i++) {
                            if (perRoundPersonArr[i - 1] == this.nMatchRemainCount) {
                                this.nMatchRemainCount = perRoundPersonArr[i];
                                break;
                            }
                        }
                    } else if (curNodeBaseInfo.Fphase_1_mode == constDef.MATCH_MODE.OUT_AT_ONCE) {
                        if (this.nMatchRemainCount == 0) {
                            this.nMatchRemainCount = this.nMatchCurSignCount;
                        }
                    }
                    break;
                }
            case constDef.MATCH_STATUS.PHASE_2_BEGIN:
                {

                    if (curNodeBaseInfo.Fphase_2_mode == constDef.MATCH_MODE.FIXED_ROUND) {
                        var rounds = curNodeBaseInfo.Fphase_2_param3.substr(0, curNodeBaseInfo.Fphase_2_param3.length - 1);
                        var perRoundPersonArr = rounds.split(";");
                        for (var i = 0; i < perRoundPersonArr.length; i++) {
                            if (perRoundPersonArr[i - 1] == this.nMatchRemainCount) {
                                this.nMatchRemainCount = perRoundPersonArr[i];
                                break;
                            }
                        }
                    } else if (curNodeBaseInfo.Fphase_2_mode == constDef.MATCH_MODE.OUT_AT_ONCE) {
                        if (this.nMatchRemainCount == 0) {
                            this.nMatchRemainCount = this.nMatchCurSignCount;
                        }
                    }
                    break;
                }
        }
    },
    getCurNodeBaseInfo: function getCurNodeBaseInfo() {
        var gameData = GlobalManager.instance.GetGameData(GlobalManager.instance.selfData.nCurGameID);
        var roomArea = GlobalManager.instance.confData.getRoomArea(GlobalManager.instance.selfData.nCurGameID, 2); // 2表示比赛
        var nodeBaseinfos = GlobalManager.instance.confData.getGameNode(roomArea.Farea_id);
        for (var i = 0; i < nodeBaseinfos.length; i++) {
            var room = GlobalManager.instance.confData.getGameRoom(nodeBaseinfos[i].Fnode_id);
            if (room.Froom_id == gameData.nRoomID) {
                var curNodeBaseInfo = nodeBaseinfos[i];
                break;
            }
        }
        return curNodeBaseInfo;
    },
    // 从大到小排序
    OrderPuke: function OrderPuke(arr) {
        var tempArr = [];
        // 大王
        for (var t = 0; t < arr.length; t++) {
            var cardValue = arr[t];
            if (cardValue == 95) {
                tempArr.push(cardValue);
            }
        }
        // 小王
        for (var t = 0; t < arr.length; t++) {
            var cardValue = arr[t];
            if (cardValue == 94) {
                tempArr.push(cardValue);
            }
        }

        // 1、2
        for (var i = 2; i > 0; i--) {
            for (var t = 0; t < arr.length; t++) {
                var cardValue = arr[t];
                var LowValue = cardValue & 0x0f;
                if (LowValue == i) {
                    tempArr.push(cardValue);
                }
            }
        }
        // 3-Q
        for (var i = 13; i > 2; i--) {
            for (var t = 0; t < arr.length; t++) {
                var cardValue = arr[t];
                var LowValue = cardValue & 0x0f;
                if (LowValue == i) {
                    tempArr.push(cardValue);
                }
            }
        }
        return tempArr;
    },
    GetCardVal: function GetCardVal(card) {
        return card & 0x0F;
    },

    GetCardCommonVal: function GetCardCommonVal(card) {
        if (card == 0) return 0;
        var val = this.GetCardVal(card);
        if (val <= 2) val += 11;else if (val <= 13) val -= 2;
        return val;
    },

    // 出牌规则检查
    CheckCardsValid: function CheckCardsValid(cards) {
        var count = cards.length;
        for (var i = 0; i < count; i++) {
            if (cards[i] < 0x11) return gameConstDef.CARDS_TYPE.NONE;
            if (cards[i] > 0x1D && cards[i] < 0x21) return gameConstDef.CARDS_TYPE.NONE;
            if (cards[i] > 0x2D && cards[i] < 0x31) return gameConstDef.CARDS_TYPE.NONE;
            if (cards[i] > 0x3D && cards[i] < 0x41) return gameConstDef.CARDS_TYPE.NONE;
            if (cards[i] > 0x4D && cards[i] < 0x5E) return gameConstDef.CARDS_TYPE.NONE;
            if (cards[i] > 0x5F) return gameConstDef.CARDS_TYPE.NONE;
        }

        var newCards = this.OrderPuke(cards);

        if (count == 0) return gameConstDef.CARDS_TYPE.NONE;
        if (count == 1) return (gameConstDef.CARDS_TYPE.TYPE_X << 16) + newCards[0];
        if (count == 2) {
            if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1])) return (gameConstDef.CARDS_TYPE.TYPE_XX << 16) + newCards[0];else if (newCards[0] == 0x5F && newCards[1] == 0x5E) return gameConstDef.CARDS_TYPE.ROCKET << 16;else return gameConstDef.CARDS_TYPE.NONE;
        }
        if (count == 3) {
            if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) && this.GetCardVal(newCards[1]) == this.GetCardVal(newCards[2])) return (gameConstDef.CARDS_TYPE.TYPE_XXX << 16) + newCards[0];else return gameConstDef.CARDS_TYPE.NONE;
        }
        if (count == 4) {
            if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) && this.GetCardVal(newCards[1]) == this.GetCardVal(newCards[2]) && this.GetCardVal(newCards[2]) == this.GetCardVal(newCards[3])) return (gameConstDef.CARDS_TYPE.BOMB << 16) + newCards[0];else {
                if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) && this.GetCardVal(newCards[1]) == this.GetCardVal(newCards[2])) return (gameConstDef.CARDS_TYPE.PLANE_S_1 << 16) + newCards[1];else if (this.GetCardVal(newCards[1]) == this.GetCardVal(newCards[2]) && this.GetCardVal(newCards[2]) == this.GetCardVal(newCards[3])) return (gameConstDef.CARDS_TYPE.PLANE_S_1 << 16) + newCards[2];else return gameConstDef.CARDS_TYPE.NONE;
            }
        }

        if (count == 5) {
            if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) && this.GetCardVal(newCards[1]) == this.GetCardVal(newCards[2])) {
                if (this.GetCardVal(newCards[3]) == this.GetCardVal(newCards[4])) return (gameConstDef.CARDS_TYPE.PLANE_B_1 << 16) + newCards[0];else return gameConstDef.CARDS_TYPE.NONE;
            } else if (this.GetCardVal(newCards[2]) == this.GetCardVal(newCards[3]) && this.GetCardVal(newCards[3]) == this.GetCardVal(newCards[4])) {
                if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1])) return (gameConstDef.CARDS_TYPE.PLANE_B_1 << 16) + newCards[2];else return gameConstDef.CARDS_TYPE.NONE;
            } else {
                if (this.GetCardCommonVal(newCards[0]) >= 13) return gameConstDef.CARDS_TYPE.NONE;

                if (this.GetCardCommonVal(newCards[0]) == this.GetCardCommonVal(newCards[1]) + 1 && this.GetCardCommonVal(newCards[1]) == this.GetCardCommonVal(newCards[2]) + 1 && this.GetCardCommonVal(cards[2]) == this.GetCardCommonVal(cards[3]) + 1 && this.GetCardCommonVal(cards[3]) == this.GetCardCommonVal(newCards[4]) + 1) return (gameConstDef.CARDS_TYPE.SHUNZI_5 << 16) + newCards[4];else return gameConstDef.CARDS_TYPE.NONE;
            }
        }

        if (count == 6) {
            if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) && this.GetCardVal(newCards[1]) == this.GetCardVal(newCards[2]) && this.GetCardVal(newCards[2]) == this.GetCardVal(newCards[3])) {
                return (gameConstDef.CARDS_TYPE.SHIP_S << 16) + newCards[0];
            }
            if (this.GetCardVal(newCards[1]) == this.GetCardVal(newCards[2]) && this.GetCardVal(newCards[2]) == this.GetCardVal(newCards[3]) && this.GetCardVal(newCards[3]) == this.GetCardVal(newCards[4])) return (gameConstDef.CARDS_TYPE.SHIP_S << 16) + newCards[1];
            if (this.GetCardVal(newCards[2]) == this.GetCardVal(newCards[3]) && this.GetCardVal(newCards[3]) == this.GetCardVal(newCards[4]) && this.GetCardVal(newCards[4]) == this.GetCardVal(newCards[5])) {
                return (gameConstDef.CARDS_TYPE.SHIP_S << 16) + newCards[2];
            }

            if (this.GetCardCommonVal(newCards[0]) >= 13) return gameConstDef.CARDS_TYPE.NONE;

            if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) && this.GetCardVal(newCards[1]) == this.GetCardVal(newCards[2]) && this.GetCardVal(newCards[3]) == this.GetCardVal(newCards[4]) && this.GetCardVal(newCards[4]) == this.GetCardVal(newCards[5]) && this.GetCardCommonVal(newCards[2]) == this.GetCardCommonVal(newCards[3]) + 1) return (gameConstDef.CARDS_TYPE.LIAN_SHUN_2 << 16) + newCards[3];

            if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) && this.GetCardVal(newCards[2]) == this.GetCardVal(newCards[3]) && this.GetCardVal(newCards[4]) == this.GetCardVal(newCards[5]) && this.GetCardCommonVal(newCards[1]) == this.GetCardCommonVal(newCards[2]) + 1 && this.GetCardCommonVal(newCards[3]) == this.GetCardCommonVal(newCards[4]) + 1) return (gameConstDef.CARDS_TYPE.LIAN_DUI_3 << 16) + newCards[5];

            if (this.GetCardCommonVal(newCards[0]) == this.GetCardCommonVal(newCards[1]) + 1 && this.GetCardCommonVal(newCards[1]) == this.GetCardCommonVal(newCards[2]) + 1 && this.GetCardCommonVal(newCards[2]) == this.GetCardCommonVal(newCards[3]) + 1 && this.GetCardCommonVal(newCards[3]) == this.GetCardCommonVal(newCards[4]) + 1 && this.GetCardCommonVal(newCards[4]) == this.GetCardCommonVal(newCards[5]) + 1) return (gameConstDef.CARDS_TYPE.SHUNZI_6 << 16) + newCards[5];else return gameConstDef.CARDS_TYPE.NONE;
        }

        if (count == 7) {
            if (this.GetCardCommonVal(newCards[0]) >= 13) return gameConstDef.CARDS_TYPE.NONE;
            if (this.GetCardCommonVal(newCards[0]) == this.GetCardCommonVal(newCards[1]) + 1 && this.GetCardCommonVal(newCards[1]) == this.GetCardCommonVal(newCards[2]) + 1 && this.GetCardCommonVal(newCards[2]) == this.GetCardCommonVal(newCards[3]) + 1 && this.GetCardCommonVal(newCards[3]) == this.GetCardCommonVal(newCards[4]) + 1 && this.GetCardCommonVal(newCards[4]) == this.GetCardCommonVal(newCards[5]) + 1 && this.GetCardCommonVal(newCards[5]) == this.GetCardCommonVal(newCards[6]) + 1) return (gameConstDef.CARDS_TYPE.SHUNZI_7 << 16) + newCards[6];else return gameConstDef.CARDS_TYPE.NONE;
        }

        if (count == 8) {
            if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) && this.GetCardVal(newCards[1]) == this.GetCardVal(newCards[2]) && this.GetCardVal(newCards[2]) == this.GetCardVal(newCards[3])) {
                if (this.GetCardVal(newCards[4]) == this.GetCardVal(newCards[5]) && this.GetCardVal(newCards[5]) == this.GetCardVal(newCards[6]) && this.GetCardVal(newCards[6]) == this.GetCardVal(newCards[7])) return gameConstDef.CARDS_TYPE.NONE;
                if (this.GetCardVal(newCards[4]) == this.GetCardVal(newCards[5]) && this.GetCardVal(newCards[6]) == this.GetCardVal(newCards[7])) return (gameConstDef.CARDS_TYPE.SHIP_B << 16) + newCards[0];
                return gameConstDef.CARDS_TYPE.NONE;
            }

            if (this.GetCardVal(newCards[2]) == this.GetCardVal(newCards[3]) && this.GetCardVal(newCards[3]) == this.GetCardVal(newCards[4]) && this.GetCardVal(newCards[4]) == this.GetCardVal(newCards[5])) {
                if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) && this.GetCardVal(newCards[6]) == this.GetCardVal(newCards[7])) return (gameConstDef.CARDS_TYPE.SHIP_B << 16) + newCards[2];
                return gameConstDef.CARDS_TYPE.NONE;
            }
            if (this.GetCardVal(newCards[4]) == this.GetCardVal(newCards[5]) && this.GetCardVal(newCards[5]) == this.GetCardVal(newCards[6]) && this.GetCardVal(newCards[6]) == this.GetCardVal(newCards[7])) {
                if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) && this.GetCardVal(newCards[2]) == this.GetCardVal(newCards[3])) return (gameConstDef.CARDS_TYPE.SHIP_B << 16) + newCards[4];
                return gameConstDef.CARDS_TYPE.NONE;
            }

            if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) && this.GetCardVal(newCards[1]) == this.GetCardVal(newCards[2])) {
                if (this.GetCardVal(newCards[3]) == this.GetCardVal(newCards[4]) && this.GetCardVal(newCards[4]) == this.GetCardVal(newCards[5])) {
                    if (this.GetCardCommonVal(newCards[0]) >= 13) return gameConstDef.CARDS_TYPE.NONE;
                    if (this.GetCardVal(newCards[5]) == this.GetCardVal(newCards[6])) return gameConstDef.CARDS_TYPE.NONE;
                    if (this.GetCardCommonVal(newCards[2]) == this.GetCardCommonVal(newCards[3]) + 1) return (gameConstDef.CARDS_TYPE.PLANE_S_2 << 16) + newCards[3];
                    return gameConstDef.CARDS_TYPE.NONE;
                }
                return gameConstDef.CARDS_TYPE.NONE;
            }
            if (this.GetCardVal(newCards[1]) == this.GetCardVal(newCards[2]) && this.GetCardVal(newCards[2]) == this.GetCardVal(newCards[3])) {
                if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1])) return gameConstDef.CARDS_TYPE.NONE;
                if (this.GetCardVal(newCards[4]) == this.GetCardVal(newCards[5]) && this.GetCardVal(newCards[5]) == this.GetCardVal(newCards[6])) {
                    if (this.GetCardCommonVal(newCards[1]) >= 13) return gameConstDef.CARDS_TYPE.NONE;
                    if (this.GetCardVal(newCards[6]) == this.GetCardVal(newCards[7])) return gameConstDef.CARDS_TYPE.NONE;
                    if (this.GetCardCommonVal(newCards[3]) == this.GetCardCommonVal(newCards[4]) + 1) return (gameConstDef.CARDS_TYPE.PLANE_S_2 << 16) + newCards[4];
                    return gameConstDef.CARDS_TYPE.NONE;
                }
                return gameConstDef.CARDS_TYPE.NONE;
            }

            if (this.GetCardVal(newCards[2]) == this.GetCardVal(newCards[3]) && this.GetCardVal(newCards[3]) == this.GetCardVal(newCards[4])) {
                if (this.GetCardVal(newCards[5]) == this.GetCardVal(newCards[6]) && this.GetCardVal(newCards[6]) == this.GetCardVal(newCards[7])) {
                    if (this.GetCardCommonVal(newCards[2]) >= 13) return gameConstDef.CARDS_TYPE.NONE;
                    if (this.GetCardVal(newCards[1]) == this.GetCardVal(newCards[2])) return gameConstDef.CARDS_TYPE.NONE;
                    if (this.GetCardCommonVal(newCards[4]) == this.GetCardCommonVal(newCards[5]) + 1) return (gameConstDef.CARDS_TYPE.PLANE_S_2 << 16) + newCards[5];
                    return gameConstDef.CARDS_TYPE.NONE;
                }
                return gameConstDef.CARDS_TYPE.NONE;
            }

            if (this.GetCardCommonVal(newCards[0]) >= 13) return gameConstDef.CARDS_TYPE.NONE;
            if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) && this.GetCardVal(newCards[2]) == this.GetCardVal(newCards[3]) && this.GetCardVal(newCards[4]) == this.GetCardVal(newCards[5]) && this.GetCardVal(newCards[6]) == this.GetCardVal(newCards[7]) && this.GetCardCommonVal(newCards[1]) == this.GetCardCommonVal(newCards[2]) + 1 && this.GetCardCommonVal(newCards[3]) == this.GetCardCommonVal(newCards[4]) + 1 && this.GetCardCommonVal(newCards[5]) == this.GetCardCommonVal(newCards[6]) + 1) return (gameConstDef.CARDS_TYPE.LIAN_DUI_4 << 16) + newCards[6];

            if (this.GetCardCommonVal(newCards[0]) == this.GetCardCommonVal(newCards[1]) + 1 && this.GetCardCommonVal(newCards[1]) == this.GetCardCommonVal(newCards[2]) + 1 && this.GetCardCommonVal(newCards[2]) == this.GetCardCommonVal(newCards[3]) + 1 && this.GetCardCommonVal(newCards[3]) == this.GetCardCommonVal(newCards[4]) + 1 && this.GetCardCommonVal(newCards[4]) == this.GetCardCommonVal(newCards[5]) + 1 && this.GetCardCommonVal(newCards[5]) == this.GetCardCommonVal(newCards[6]) + 1 && this.GetCardCommonVal(newCards[6]) == this.GetCardCommonVal(newCards[7]) + 1) return (gameConstDef.CARDS_TYPE.SHUNZI_8 << 16) + newCards[7];
            return gameConstDef.CARDS_TYPE.NONE;
        }
        if (count == 9) {
            if (this.GetCardCommonVal(newCards[0]) >= 13) return gameConstDef.CARDS_TYPE.NONE;

            if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) && this.GetCardVal(newCards[1]) == this.GetCardVal(newCards[2]) && this.GetCardVal(newCards[3]) == this.GetCardVal(newCards[4]) && this.GetCardVal(newCards[4]) == this.GetCardVal(newCards[5]) && this.GetCardVal(newCards[6]) == this.GetCardVal(newCards[7]) && this.GetCardVal(newCards[7]) == this.GetCardVal(newCards[8]) && this.GetCardCommonVal(newCards[2]) == this.GetCardCommonVal(newCards[3]) + 1 && this.GetCardCommonVal(newCards[5]) == this.GetCardCommonVal(newCards[6]) + 1) return (gameConstDef.CARDS_TYPE.LIAN_SHUN_3 << 16) + newCards[6];

            if (this.GetCardCommonVal(newCards[0]) == this.GetCardCommonVal(newCards[1]) + 1 && this.GetCardCommonVal(newCards[1]) == this.GetCardCommonVal(newCards[2]) + 1 && this.GetCardCommonVal(newCards[2]) == this.GetCardCommonVal(newCards[3]) + 1 && this.GetCardCommonVal(newCards[3]) == this.GetCardCommonVal(newCards[4]) + 1 && this.GetCardCommonVal(newCards[4]) == this.GetCardCommonVal(newCards[5]) + 1 && this.GetCardCommonVal(newCards[5]) == this.GetCardCommonVal(newCards[6]) + 1 && this.GetCardCommonVal(newCards[6]) == this.GetCardCommonVal(newCards[7]) + 1 && this.GetCardCommonVal(newCards[7]) == this.GetCardCommonVal(newCards[8]) + 1) return (gameConstDef.CARDS_TYPE.SHUNZI_9 << 16) + newCards[8];

            return gameConstDef.CARDS_TYPE.NONE;
        }

        if (count == 10) {
            if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) && this.GetCardVal(newCards[1]) == this.GetCardVal(newCards[2]) && this.GetCardVal(newCards[3]) == this.GetCardVal(newCards[4]) && this.GetCardVal(newCards[4]) == this.GetCardVal(newCards[5])) {
                if (this.GetCardCommonVal(newCards[0]) >= 13) return gameConstDef.CARDS_TYPE.NONE;
                if (this.GetCardCommonVal(newCards[2]) != this.GetCardCommonVal(newCards[3]) + 1) return gameConstDef.CARDS_TYPE.NONE;
                if (this.GetCardVal(newCards[6]) == this.GetCardVal(newCards[7]) && this.GetCardVal(newCards[8]) == this.GetCardVal(newCards[9]) && this.GetCardVal(newCards[8]) != this.GetCardVal(newCards[7])) return (gameConstDef.CARDS_TYPE.PLANE_B_2 << 16) + newCards[3];
                return gameConstDef.CARDS_TYPE.NONE;
            }

            if (this.GetCardVal(newCards[2]) == this.GetCardVal(newCards[3]) && this.GetCardVal(newCards[3]) == this.GetCardVal(newCards[4]) && this.GetCardVal(newCards[5]) == this.GetCardVal(newCards[6]) && this.GetCardVal(newCards[6]) == this.GetCardVal(newCards[7])) {
                if (this.GetCardCommonVal(newCards[4]) != this.GetCardCommonVal(newCards[5]) + 1) return gameConstDef.CARDS_TYPE.NONE;
                if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) && this.GetCardVal(newCards[8]) == this.GetCardVal(newCards[9])) return (gameConstDef.CARDS_TYPE.PLANE_B_2 << 16) + cards[6];
                return gameConstDef.CARDS_TYPE.NONE;
            }

            if (this.GetCardVal(newCards[4]) == this.GetCardVal(newCards[5]) && this.GetCardVal(newCards[5]) == this.GetCardVal(newCards[6]) && this.GetCardVal(newCards[7]) == this.GetCardVal(newCards[8]) && this.GetCardVal(newCards[8]) == this.GetCardVal(newCards[9])) {
                if (this.GetCardCommonVal(newCards[6]) != this.GetCardCommonVal(newCards[7]) + 1) return gameConstDef.CARDS_TYPE.NONE;
                if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) && this.GetCardVal(newCards[2]) == this.GetCardVal(newCards[3]) && this.GetCardVal(newCards[1]) != this.GetCardVal(newCards[2])) return (gameConstDef.CARDS_TYPE.PLANE_B_2 << 16) + newCards[7];
                return gameConstDef.CARDS_TYPE.NONE;
            }

            if (this.GetCardCommonVal(newCards[0]) >= 13) return gameConstDef.CARDS_TYPE.NONE;

            if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) && this.GetCardVal(newCards[2]) == this.GetCardVal(newCards[3]) && this.GetCardVal(newCards[4]) == this.GetCardVal(newCards[5]) && this.GetCardVal(newCards[6]) == this.GetCardVal(newCards[7]) && this.GetCardVal(newCards[8]) == this.GetCardVal(newCards[9]) && this.GetCardCommonVal(newCards[1]) == this.GetCardCommonVal(newCards[2]) + 1 && this.GetCardCommonVal(newCards[3]) == this.GetCardCommonVal(newCards[4]) + 1 && this.GetCardCommonVal(newCards[5]) == this.GetCardCommonVal(newCards[6]) + 1 && this.GetCardCommonVal(newCards[7]) == this.GetCardCommonVal(newCards[8]) + 1) return (gameConstDef.CARDS_TYPE.LIAN_DUI_5 << 16) + newCards[8];

            if (this.GetCardCommonVal(newCards[0]) == this.GetCardCommonVal(newCards[1]) + 1 && this.GetCardCommonVal(newCards[1]) == this.GetCardCommonVal(newCards[2]) + 1 && this.GetCardCommonVal(newCards[2]) == this.GetCardCommonVal(newCards[3]) + 1 && this.GetCardCommonVal(newCards[3]) == this.GetCardCommonVal(newCards[4]) + 1 && this.GetCardCommonVal(newCards[4]) == this.GetCardCommonVal(newCards[5]) + 1 && this.GetCardCommonVal(newCards[5]) == this.GetCardCommonVal(newCards[6]) + 1 && this.GetCardCommonVal(newCards[6]) == this.GetCardCommonVal(newCards[7]) + 1 && this.GetCardCommonVal(newCards[7]) == this.GetCardCommonVal(newCards[8]) + 1 && this.GetCardCommonVal(newCards[8]) == this.GetCardCommonVal(newCards[9]) + 1) return (gameConstDef.CARDS_TYPE.SHUNZI_10 << 16) + newCards[9];
            return gameConstDef.CARDS_TYPE.NONE;
        }

        if (count == 11) {
            if (this.GetCardCommonVal(newCards[0]) >= 13) return gameConstDef.CARDS_TYPE.NONE;
            if (this.GetCardCommonVal(newCards[0]) == this.GetCardCommonVal(newCards[1]) + 1 && this.GetCardCommonVal(newCards[1]) == this.GetCardCommonVal(newCards[2]) + 1 && this.GetCardCommonVal(newCards[2]) == this.GetCardCommonVal(newCards[3]) + 1 && this.GetCardCommonVal(newCards[3]) == this.GetCardCommonVal(newCards[4]) + 1 && this.GetCardCommonVal(newCards[4]) == this.GetCardCommonVal(newCards[5]) + 1 && this.GetCardCommonVal(newCards[5]) == this.GetCardCommonVal(newCards[6]) + 1 && this.GetCardCommonVal(newCards[6]) == this.GetCardCommonVal(newCards[7]) + 1 && this.GetCardCommonVal(newCards[7]) == this.GetCardCommonVal(newCards[8]) + 1 && this.GetCardCommonVal(newCards[8]) == this.GetCardCommonVal(newCards[9]) + 1 && this.GetCardCommonVal(newCards[9]) == this.GetCardCommonVal(newCards[10]) + 1) return (gameConstDef.CARDS_TYPE.SHUNZI_11 << 16) + newCards[10];
            return gameConstDef.CARDS_TYPE.NONE;
        }

        if (count == 12) {
            if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) && this.GetCardVal(newCards[1]) == this.GetCardVal(newCards[2]) && this.GetCardVal(newCards[3]) == this.GetCardVal(newCards[4]) && this.GetCardVal(newCards[4]) == this.GetCardVal(newCards[5]) && this.GetCardVal(newCards[6]) == this.GetCardVal(newCards[7]) && this.GetCardVal(newCards[7]) == this.GetCardVal(newCards[8]) && this.GetCardVal(newCards[9]) == this.GetCardVal(newCards[9]) && this.GetCardVal(newCards[10]) == this.GetCardVal(newCards[11])) {
                if (this.GetCardCommonVal(newCards[2]) == this.GetCardCommonVal(newCards[3]) + 1 && this.GetCardCommonVal(newCards[5]) == this.GetCardCommonVal(newCards[6]) + 1 && this.GetCardCommonVal(newCards[8]) == this.GetCardCommonVal(newCards[9]) + 1) return (gameConstDef.CARDS_TYPE.LIAN_SHUN_4 << 16) + newCards[9];
                return gameConstDef.CARDS_TYPE.NONE;
            }

            if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) && this.GetCardVal(newCards[1]) == this.GetCardVal(newCards[2]) && this.GetCardVal(newCards[3]) == this.GetCardVal(newCards[4]) && this.GetCardVal(newCards[4]) == this.GetCardVal(newCards[5]) && this.GetCardVal(newCards[6]) == this.GetCardVal(newCards[7]) && this.GetCardVal(newCards[7]) == this.GetCardVal(newCards[8])) {
                // if ((this.GetCardVal(newCards[9]) == this.GetCardVal(newCards[10])) || (this.GetCardVal(newCards[10]) == this.GetCardVal(newCards[11]))) return gameConstDef.CARDS_TYPE.NONE;
                // if (this.GetCardVal(newCards[9]) == this.GetCardVal(newCards[8])) return gameConstDef.CARDS_TYPE.NONE;
                if (this.GetCardCommonVal(newCards[2]) == this.GetCardCommonVal(newCards[3]) + 1 && this.GetCardCommonVal(newCards[5]) == this.GetCardCommonVal(newCards[6]) + 1) return (gameConstDef.CARDS_TYPE.PLANE_S_3 << 16) + newCards[6];
                return gameConstDef.CARDS_TYPE.NONE;
            }

            if (this.GetCardVal(newCards[9]) == this.GetCardVal(newCards[10]) && this.GetCardVal(newCards[10]) == this.GetCardVal(newCards[11]) && this.GetCardVal(newCards[3]) == this.GetCardVal(newCards[4]) && this.GetCardVal(newCards[4]) == this.GetCardVal(newCards[5]) && this.GetCardVal(newCards[6]) == this.GetCardVal(newCards[7]) && this.GetCardVal(newCards[7]) == this.GetCardVal(newCards[8])) {
                // if ((this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1])) || (this.GetCardVal(newCards[1]) == this.GetCardVal(newCards[2]))) return gameConstDef.CARDS_TYPE.NONE;
                // if (this.GetCardVal(newCards[2]) == this.GetCardVal(newCards[3])) return gameConstDef.CARDS_TYPE.NONE;
                if (this.GetCardCommonVal(newCards[5]) == this.GetCardCommonVal(newCards[6]) + 1 && this.GetCardCommonVal(newCards[8]) == this.GetCardCommonVal(newCards[9]) + 1) return (gameConstDef.CARDS_TYPE.PLANE_S_3 << 16) + cards[9];
                return gameConstDef.CARDS_TYPE.NONE;
            }

            if (this.GetCardVal(newCards[1]) == this.GetCardVal(newCards[2]) && this.GetCardVal(newCards[2]) == this.GetCardVal(newCards[3]) && this.GetCardVal(newCards[4]) == this.GetCardVal(newCards[5]) && this.GetCardVal(newCards[5]) == this.GetCardVal(newCards[6]) && this.GetCardVal(newCards[7]) == this.GetCardVal(newCards[8]) && this.GetCardVal(newCards[8]) == this.GetCardVal(newCards[9])) {
                if (this.GetCardVal(newCards[10]) == this.GetCardVal(newCards[11])) return gameConstDef.CARDS_TYPE.NONE;
                if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1])) return gameConstDef.CARDS_TYPE.NONE;
                if (this.GetCardVal(newCards[9]) == this.GetCardVal(newCards[10])) return gameConstDef.CARDS_TYPE.NONE;
                if (this.GetCardCommonVal(newCards[3]) == this.GetCardCommonVal(newCards[4]) + 1 && this.GetCardCommonVal(newCards[6]) == this.GetCardCommonVal(newCards[7]) + 1) return (gameConstDef.CARDS_TYPE.PLANE_S_3 << 16) + newCards[7];
                return gameConstDef.CARDS_TYPE.NONE;
            }

            if (this.GetCardVal(newCards[2]) == this.GetCardVal(newCards[3]) && this.GetCardVal(newCards[3]) == this.GetCardVal(newCards[4]) && this.GetCardVal(newCards[5]) == this.GetCardVal(newCards[6]) && this.GetCardVal(newCards[6]) == this.GetCardVal(newCards[7]) && this.GetCardVal(newCards[8]) == this.GetCardVal(newCards[9]) && this.GetCardVal(newCards[9]) == this.GetCardVal(newCards[10])) {
                if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1])) return gameConstDef.CARDS_TYPE.NONE;
                if (this.GetCardVal(newCards[2]) == this.GetCardVal(newCards[1])) return gameConstDef.CARDS_TYPE.NONE;
                if (this.GetCardVal(newCards[10]) == this.GetCardVal(newCards[11])) return gameConstDef.CARDS_TYPE.NONE;
                if (this.GetCardCommonVal(newCards[4]) == this.GetCardCommonVal(newCards[5]) + 1 && this.GetCardCommonVal(newCards[7]) == this.GetCardCommonVal(newCards[8]) + 1) return (gameConstDef.CARDS_TYPE.PLANE_S_3 << 16) + newCards[8];
                return gameConstDef.CARDS_TYPE.NONE;
            }

            if (this.GetCardCommonVal(newCards[0]) >= 13) return gameConstDef.CARDS_TYPE.NONE;

            if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) && this.GetCardVal(newCards[2]) == this.GetCardVal(newCards[3]) && this.GetCardVal(newCards[10]) == this.GetCardVal(newCards[11]) && this.GetCardVal(newCards[4]) == this.GetCardVal(newCards[5]) && this.GetCardVal(newCards[6]) == this.GetCardVal(newCards[7]) && this.GetCardVal(newCards[8]) == this.GetCardVal(newCards[9]) && this.GetCardCommonVal(newCards[1]) == this.GetCardCommonVal(newCards[2]) + 1 && this.GetCardCommonVal(newCards[3]) == this.GetCardCommonVal(newCards[4]) + 1 && this.GetCardCommonVal(newCards[5]) == this.GetCardCommonVal(newCards[6]) + 1 && this.GetCardCommonVal(newCards[7]) == this.GetCardCommonVal(newCards[8]) + 1 && this.GetCardCommonVal(newCards[9]) == this.GetCardCommonVal(newCards[10]) + 1) return (gameConstDef.CARDS_TYPE.LIAN_DUI_6 << 16) + newCards[10];

            if (this.GetCardCommonVal(newCards[0]) == this.GetCardCommonVal(newCards[1]) + 1 && this.GetCardCommonVal(newCards[1]) == this.GetCardCommonVal(newCards[2]) + 1 && this.GetCardCommonVal(newCards[2]) == this.GetCardCommonVal(newCards[3]) + 1 && this.GetCardCommonVal(newCards[3]) == this.GetCardCommonVal(newCards[4]) + 1 && this.GetCardCommonVal(newCards[4]) == this.GetCardCommonVal(newCards[5]) + 1 && this.GetCardCommonVal(newCards[5]) == this.GetCardCommonVal(newCards[6]) + 1 && this.GetCardCommonVal(newCards[6]) == this.GetCardCommonVal(newCards[7]) + 1 && this.GetCardCommonVal(newCards[7]) == this.GetCardCommonVal(newCards[8]) + 1 && this.GetCardCommonVal(newCards[8]) == this.GetCardCommonVal(newCards[9]) + 1 && this.GetCardCommonVal(newCards[9]) == this.GetCardCommonVal(newCards[10]) + 1 && this.GetCardCommonVal(newCards[10]) == this.GetCardCommonVal(newCards[11]) + 1) return (gameConstDef.CARDS_TYPE.SHUNZI_12 << 16) + newCards[11];
            return gameConstDef.CARDS_TYPE.NONE;
        }

        if (count == 14) {
            if (this.GetCardCommonVal(newCards[0]) >= 13) return gameConstDef.CARDS_TYPE.NONE;

            if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) && this.GetCardVal(newCards[2]) == this.GetCardVal(newCards[3]) && this.GetCardVal(newCards[10]) == this.GetCardVal(newCards[11]) && this.GetCardVal(newCards[4]) == this.GetCardVal(newCards[5]) && this.GetCardVal(newCards[6]) == this.GetCardVal(newCards[7]) && this.GetCardVal(newCards[8]) == this.GetCardVal(newCards[9]) && this.GetCardVal(newCards[12]) == this.GetCardVal(newCards[13]) && this.GetCardCommonVal(newCards[1]) == this.GetCardCommonVal(newCards[2]) + 1 && this.GetCardCommonVal(newCards[3]) == this.GetCardCommonVal(newCards[4]) + 1 && this.GetCardCommonVal(newCards[5]) == this.GetCardCommonVal(newCards[6]) + 1 && this.GetCardCommonVal(newCards[7]) == this.GetCardCommonVal(newCards[8]) + 1 && this.GetCardCommonVal(newCards[9]) == this.GetCardCommonVal(newCards[10]) + 1 && this.GetCardCommonVal(newCards[11]) == this.GetCardCommonVal(newCards[12]) + 1) return (gameConstDef.CARDS_TYPE.LIAN_DUI_7 << 16) + newCards[12];
            return gameConstDef.CARDS_TYPE.NONE;
        }

        if (count == 15) {
            if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) && this.GetCardVal(newCards[1]) == this.GetCardVal(newCards[2]) && this.GetCardVal(newCards[3]) == this.GetCardVal(newCards[4]) && this.GetCardVal(newCards[4]) == this.GetCardVal(newCards[5]) && this.GetCardVal(newCards[6]) == this.GetCardVal(newCards[7]) && this.GetCardVal(newCards[7]) == this.GetCardVal(newCards[8])) {
                if (this.GetCardVal(newCards[9]) == this.GetCardVal(newCards[10]) && this.GetCardVal(newCards[11]) == this.GetCardVal(newCards[12]) && this.GetCardVal(newCards[13]) == this.GetCardVal(newCards[14])) {
                    if (this.GetCardCommonVal(newCards[2]) == this.GetCardCommonVal(newCards[3]) + 1 && this.GetCardCommonVal(newCards[5]) == this.GetCardCommonVal(newCards[6]) + 1) {
                        if (this.GetCardVal(newCards[10]) != this.GetCardVal(newCards[11]) && this.GetCardVal(newCards[12]) != this.GetCardVal(newCards[13])) {
                            return (gameConstDef.CARDS_TYPE.PLANE_B_3 << 16) + newCards[6];
                        }
                    }
                }
                return gameConstDef.CARDS_TYPE.NONE;
            }

            if (this.GetCardVal(newCards[2]) == this.GetCardVal(newCards[3]) && this.GetCardVal(newCards[3]) == this.GetCardVal(newCards[4]) && this.GetCardVal(newCards[5]) == this.GetCardVal(newCards[6]) && this.GetCardVal(newCards[6]) == this.GetCardVal(newCards[8]) && this.GetCardVal(newCards[8]) == this.GetCardVal(newCards[9]) && this.GetCardVal(newCards[9]) == this.GetCardVal(newCards[10])) {
                if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) && this.GetCardVal(newCards[11]) == this.GetCardVal(newCards[12]) && this.GetCardVal(newCards[13]) == this.GetCardVal(newCards[14])) {
                    if (this.GetCardCommonVal(newCards[4]) == this.GetCardCommonVal(newCards[5]) + 1 && this.GetCardCommonVal(newCards[7]) == this.GetCardCommonVal(newCards[8]) + 1) {
                        if (this.GetCardVal(newCards[12]) != this.GetCardVal(newCards[13])) return (gameConstDef.CARDS_TYPE.PLANE_B_3 << 16) + newCards[8];
                    }
                }
                return gameConstDef.CARDS_TYPE.NONE;
            }

            if (this.GetCardVal(newCards[4]) == this.GetCardVal(newCards[5]) && this.GetCardVal(newCards[5]) == this.GetCardVal(newCards[6]) && this.GetCardVal(newCards[7]) == this.GetCardVal(newCards[8]) && this.GetCardVal(newCards[8]) == this.GetCardVal(newCards[9]) && this.GetCardVal(newCards[10]) == this.GetCardVal(newCards[11]) && this.GetCardVal(newCards[11]) == this.GetCardVal(newCards[12])) {
                if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) && this.GetCardVal(newCards[2]) == this.GetCardVal(newCards[3]) && this.GetCardVal(newCards[13]) == this.GetCardVal(newCards[14])) {
                    if (this.GetCardCommonVal(newCards[6]) == this.GetCardCommonVal(newCards[7]) + 1 && this.GetCardCommonVal(newCards[9]) == this.GetCardCommonVal(newCards[10]) + 1) {
                        if (this.GetCardVal(newCards[1]) != this.GetCardVal(newCards[2])) return (gameConstDef.CARDS_TYPE.PLANE_B_3 << 16) + cards[10];
                    }
                }
                return gameConstDef.CARDS_TYPE.NONE;
            }

            if (this.GetCardVal(newCards[6]) == this.GetCardVal(newCards[7]) && this.GetCardVal(newCards[7]) == this.GetCardVal(newCards[8]) && this.GetCardVal(newCards[9]) == this.GetCardVal(newCards[10]) && this.GetCardVal(newCards[10]) == this.GetCardVal(newCards[11]) && this.GetCardVal(newCards[12]) == this.GetCardVal(newCards[13]) && this.GetCardVal(newCards[13]) == this.GetCardVal(newCards[14])) {
                if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) && this.GetCardVal(newCards[2]) == this.GetCardVal(newCards[3]) && this.GetCardVal(newCards[4]) == this.GetCardVal(newCards[5])) {
                    if (this.GetCardCommonVal(newCards[8]) == this.GetCardCommonVal(newCards[9]) + 1 && this.GetCardCommonVal(newCards[11]) == this.GetCardCommonVal(newCards[12]) + 1) {
                        if (this.GetCardVal(newCards[1]) != this.GetCardVal(newCards[2]) && this.GetCardVal(newCards[3]) != this.GetCardVal(newCards[4])) return (gameConstDef.CARDS_TYPE.PLANE_B_3 << 16) + newCards[12];
                    }
                }
                return gameConstDef.CARDS_TYPE.NONE;
            }

            if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) && this.GetCardVal(newCards[1]) == this.GetCardVal(newCards[2]) && this.GetCardVal(newCards[3]) == this.GetCardVal(newCards[4]) && this.GetCardVal(newCards[4]) == this.GetCardVal(newCards[5]) && this.GetCardVal(newCards[6]) == this.GetCardVal(newCards[7]) && this.GetCardVal(newCards[7]) == this.GetCardVal(newCards[8]) && this.GetCardVal(newCards[9]) == this.GetCardVal(newCards[10]) && this.GetCardVal(newCards[10]) == this.GetCardVal(newCards[11]) && this.GetCardVal(newCards[12]) == this.GetCardVal(newCards[13]) && this.GetCardVal(newCards[13]) == this.GetCardVal(newCards[14])) {
                if (this.GetCardCommonVal(newCards[2]) == this.GetCardCommonVal(newCards[3]) + 1 && this.GetCardCommonVal(newCards[5]) == this.GetCardCommonVal(newCards[6]) + 1 && this.GetCardCommonVal(newCards[8]) == this.GetCardCommonVal(newCards[9]) + 1 && this.GetCardCommonVal(newCards[11]) == this.GetCardCommonVal(newCards[12]) + 1) return (gameConstDef.CARDS_TYPE.LIAN_SHUN_5 << 16) + newCards[12];
                return gameConstDef.CARDS_TYPE.NONE;
            }
            return gameConstDef.CARDS_TYPE.NONE;
        }

        if (count == 16) {
            if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) && this.GetCardVal(newCards[1]) == this.GetCardVal(newCards[2]) && this.GetCardVal(newCards[3]) == this.GetCardVal(newCards[4]) && this.GetCardVal(newCards[4]) == this.GetCardVal(newCards[5]) && this.GetCardVal(newCards[6]) == this.GetCardVal(newCards[7]) && this.GetCardVal(newCards[7]) == this.GetCardVal(newCards[8]) && this.GetCardVal(newCards[9]) == this.GetCardVal(newCards[10]) && this.GetCardVal(newCards[10]) == this.GetCardVal(newCards[11])) {
                if (this.GetCardVal(newCards[12]) == this.GetCardVal(newCards[13]) || this.GetCardVal(newCards[13]) == this.GetCardVal(newCards[14]) || this.GetCardVal(newCards[14]) == this.GetCardVal(newCards[15])) return gameConstDef.CARDS_TYPE.NONE;
                if (this.GetCardVal(newCards[12]) == this.GetCardVal(newCards[11])) return gameConstDef.CARDS_TYPE.NONE;
                if (this.GetCardCommonVal(newCards[2]) == this.GetCardCommonVal(newCards[3]) + 1 && this.GetCardCommonVal(newCards[5]) == this.GetCardCommonVal(newCards[6]) + 1 && this.GetCardCommonVal(newCards[8]) == this.GetCardCommonVal(newCards[9]) + 1) return (gameConstDef.CARDS_TYPE.PLANE_S_4 << 16) + newCards[9];
                return gameConstDef.CARDS_TYPE.NONE;
            }

            if (this.GetCardVal(newCards[1]) == this.GetCardVal(newCards[2]) && this.GetCardVal(newCards[2]) == this.GetCardVal(newCards[3]) && this.GetCardVal(newCards[4]) == this.GetCardVal(newCards[5]) && this.GetCardVal(newCards[5]) == this.GetCardVal(newCards[6]) && this.GetCardVal(newCards[7]) == this.GetCardVal(newCards[8]) && this.GetCardVal(newCards[8]) == this.GetCardVal(newCards[9]) && this.GetCardVal(newCards[10]) == this.GetCardVal(newCards[11]) && this.GetCardVal(newCards[11]) == this.GetCardVal(newCards[12])) {
                if (this.GetCardVal(newCards[13]) == this.GetCardVal(newCards[14]) || this.GetCardVal(newCards[14]) == this.GetCardVal(newCards[15])) return gameConstDef.CARDS_TYPE.NONE;
                if (this.GetCardVal(newCards[12]) == this.GetCardVal(newCards[13])) return gameConstDef.CARDS_TYPE.NONE;
                if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1])) return gameConstDef.CARDS_TYPE.NONE;
                if (this.GetCardCommonVal(newCards[3]) == this.GetCardCommonVal(newCards[4]) + 1 && this.GetCardCommonVal(newCards[6]) == this.GetCardCommonVal(newCards[7]) + 1 && this.GetCardCommonVal(newCards[9]) == this.GetCardCommonVal(newCards[10]) + 1) return (gameConstDef.CARDS_TYPE.PLANE_S_4 << 16) + newCards[10];
                return gameConstDef.CARDS_TYPE.NONE;
            }

            if (this.GetCardVal(newCards[2]) == this.GetCardVal(newCards[3]) && this.GetCardVal(newCards[3]) == this.GetCardVal(newCards[4]) && this.GetCardVal(newCards[5]) == this.GetCardVal(newCards[6]) && this.GetCardVal(newCards[6]) == this.GetCardVal(newCards[7]) && this.GetCardVal(newCards[8]) == this.GetCardVal(newCards[9]) && this.GetCardVal(newCards[9]) == this.GetCardVal(newCards[10]) && this.GetCardVal(newCards[11]) == this.GetCardVal(newCards[12]) && this.GetCardVal(newCards[12]) == this.GetCardVal(newCards[13])) {
                if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) || this.GetCardVal(newCards[14]) == this.GetCardVal(newCards[15])) return gameConstDef.CARDS_TYPE.NONE;
                if (this.GetCardVal(newCards[1]) == this.GetCardVal(newCards[2])) return gameConstDef.CARDS_TYPE.NONE;
                if (this.GetCardVal(newCards[13]) == this.GetCardVal(newCards[14])) return gameConstDef.CARDS_TYPE.NONE;
                if (this.GetCardCommonVal(newCards[4]) == this.GetCardCommonVal(newCards[5]) + 1 && this.GetCardCommonVal(newCards[7]) == this.GetCardCommonVal(newCards[8]) + 1 && this.GetCardCommonVal(newCards[10]) == this.GetCardCommonVal(newCards[11]) + 1) return (gameConstDef.CARDS_TYPE.PLANE_S_4 << 16) + newCards[11];
                return gameConstDef.CARDS_TYPE.NONE;
            }

            if (this.GetCardVal(newCards[3]) == this.GetCardVal(newCards[4]) && this.GetCardVal(newCards[4]) == this.GetCardVal(newCards[5]) && this.GetCardVal(newCards[6]) == this.GetCardVal(newCards[7]) && this.GetCardVal(newCards[7]) == this.GetCardVal(newCards[8]) && this.GetCardVal(newCards[9]) == this.GetCardVal(newCards[10]) && this.GetCardVal(newCards[10]) == this.GetCardVal(newCards[11]) && this.GetCardVal(newCards[12]) == this.GetCardVal(newCards[13]) && this.GetCardVal(newCards[13]) == this.GetCardVal(newCards[14])) {
                if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) || this.GetCardVal(newCards[1]) == this.GetCardVal(newCards[2])) return gameConstDef.CARDS_TYPE.NONE;
                if (this.GetCardVal(newCards[2]) == this.GetCardVal(newCards[3])) return gameConstDef.CARDS_TYPE.NONE;
                if (this.GetCardVal(newCards[14]) == this.GetCardVal(newCards[15])) return gameConstDef.CARDS_TYPE.NONE;
                if (this.GetCardCommonVal(newCards[5]) == this.GetCardCommonVal(newCards[6]) + 1 && this.GetCardCommonVal(newCards[8]) == this.GetCardCommonVal(newCards[9]) + 1 && this.GetCardCommonVal(newCards[11]) == this.GetCardCommonVal(newCards[12]) + 1) return (gameConstDef.CARDS_TYPE.PLANE_S_4 << 16) + newCards[12];
                return gameConstDef.CARDS_TYPE.NONE;
            }

            if (this.GetCardVal(newCards[4]) == this.GetCardVal(newCards[5]) && this.GetCardVal(newCards[5]) == this.GetCardVal(newCards[6]) && this.GetCardVal(newCards[7]) == this.GetCardVal(newCards[8]) && this.GetCardVal(newCards[8]) == this.GetCardVal(newCards[9]) && this.GetCardVal(newCards[10]) == this.GetCardVal(newCards[11]) && this.GetCardVal(newCards[11]) == this.GetCardVal(newCards[12]) && this.GetCardVal(newCards[13]) == this.GetCardVal(newCards[14]) && this.GetCardVal(newCards[14]) == this.GetCardVal(newCards[15])) {
                if (this.GetCardVal(newCards[3]) == this.GetCardVal(newCards[4])) return gameConstDef.CARDS_TYPE.NONE;
                if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) || this.GetCardVal(newCards[1]) == this.GetCardVal(newCards[2]) || this.GetCardVal(newCards[2]) == this.GetCardVal(newCards[3])) return gameConstDef.CARDS_TYPE.NONE;
                if (this.GetCardCommonVal(newCards[6]) == this.GetCardCommonVal(newCards[7]) + 1 && this.GetCardCommonVal(newCards[9]) == this.GetCardCommonVal(newCards[10]) + 1 && this.GetCardCommonVal(newCards[12]) == this.GetCardCommonVal(newCards[13]) + 1) return (gameConstDef.CARDS_TYPE.PLANE_S_4 << 16) + newCards[13];
                return gameConstDef.CARDS_TYPE.NONE;
            }

            if (this.GetCardCommonVal(newCards[0]) >= 13) return gameConstDef.CARDS_TYPE.NONE;
            if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) && this.GetCardVal(newCards[2]) == this.GetCardVal(newCards[3]) && this.GetCardVal(newCards[10]) == this.GetCardVal(newCards[11]) && this.GetCardVal(newCards[4]) == this.GetCardVal(newCards[5]) && this.GetCardVal(newCards[6]) == this.GetCardVal(newCards[7]) && this.GetCardVal(newCards[8]) == this.GetCardVal(newCards[9]) && this.GetCardVal(newCards[12]) == this.GetCardVal(newCards[13]) && this.GetCardVal(newCards[14]) == this.GetCardVal(newCards[15]) && this.GetCardCommonVal(newCards[1]) == this.GetCardCommonVal(newCards[2]) + 1 && this.GetCardCommonVal(newCards[3]) == this.GetCardCommonVal(newCards[4]) + 1 && this.GetCardCommonVal(newCards[5]) == this.GetCardCommonVal(newCards[6]) + 1 && this.GetCardCommonVal(newCards[7]) == this.GetCardCommonVal(newCards[8]) + 1 && this.GetCardCommonVal(newCards[9]) == this.GetCardCommonVal(newCards[10]) + 1 && this.GetCardCommonVal(newCards[11]) == this.GetCardCommonVal(newCards[12]) + 1 && this.GetCardCommonVal(newCards[13]) == this.GetCardCommonVal(newCards[14]) + 1) return (gameConstDef.CARDS_TYPE.LIAN_DUI_8 << 16) + newCards[14];
            return gameConstDef.CARDS_TYPE.NONE;
        }

        if (count == 18) {
            if (this.GetCardCommonVal(newCards[0]) >= 13) return gameConstDef.CARDS_TYPE.NONE;

            if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) && this.GetCardVal(newCards[1]) == this.GetCardVal(newCards[2]) && this.GetCardVal(newCards[3]) == this.GetCardVal(newCards[4]) && this.GetCardVal(newCards[4]) == this.GetCardVal(newCards[5]) && this.GetCardVal(newCards[6]) == this.GetCardVal(newCards[7]) && this.GetCardVal(newCards[7]) == this.GetCardVal(newCards[8]) && this.GetCardVal(newCards[9]) == this.GetCardVal(newCards[10]) && this.GetCardVal(newCards[10]) == this.GetCardVal(newCards[11]) && this.GetCardVal(newCards[12]) == this.GetCardVal(newCards[13]) && this.GetCardVal(newCards[13]) == this.GetCardVal(newCards[14]) && this.GetCardVal(newCards[15]) == this.GetCardVal(newCards[16]) && this.GetCardVal(newCards[16]) == this.GetCardVal(newCards[17])) {
                if (this.GetCardCommonVal(newCards[2]) == this.GetCardCommonVal(newCards[3]) + 1 && this.GetCardCommonVal(newCards[5]) == this.GetCardCommonVal(newCards[6]) + 1 && this.GetCardCommonVal(newCards[8]) == this.GetCardCommonVal(newCards[9]) + 1 && this.GetCardCommonVal(newCards[11]) == this.GetCardCommonVal(newCards[12]) + 1 && this.GetCardCommonVal(newCards[14]) == this.GetCardCommonVal(newCards[15]) + 1) return (gameConstDef.CARDS_TYPE.LIAN_SHUN_6 << 16) + newCards[15];
                return gameConstDef.CARDS_TYPE.NONE;
            }

            if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) && this.GetCardVal(newCards[2]) == this.GetCardVal(newCards[3]) && this.GetCardVal(newCards[10]) == this.GetCardVal(newCards[11]) && this.GetCardVal(newCards[4]) == this.GetCardVal(newCards[5]) && this.GetCardVal(newCards[6]) == this.GetCardVal(newCards[7]) && this.GetCardVal(newCards[8]) == this.GetCardVal(newCards[9]) && this.GetCardVal(newCards[12]) == this.GetCardVal(newCards[13]) && this.GetCardVal(newCards[14]) == this.GetCardVal(newCards[15]) && this.GetCardVal(newCards[16]) == this.GetCardVal(newCards[17]) && this.GetCardCommonVal(newCards[1]) == this.GetCardCommonVal(newCards[2]) + 1 && this.GetCardCommonVal(newCards[3]) == this.GetCardCommonVal(newCards[4]) + 1 && this.GetCardCommonVal(newCards[5]) == this.GetCardCommonVal(newCards[6]) + 1 && this.GetCardCommonVal(newCards[7]) == this.GetCardCommonVal(newCards[8]) + 1 && this.GetCardCommonVal(newCards[9]) == this.GetCardCommonVal(newCards[10]) + 1 && this.GetCardCommonVal(newCards[11]) == this.GetCardCommonVal(newCards[12]) + 1 && this.GetCardCommonVal(newCards[13]) == this.GetCardCommonVal(newCards[14]) + 1 && this.GetCardCommonVal(newCards[15]) == this.GetCardCommonVal(newCards[16]) + 1) return (gameConstDef.CARDS_TYPE.LIAN_DUI_9 << 16) + newCards[16];

            return gameConstDef.CARDS_TYPE.NONE;
        }

        if (count == 20) {
            if (this.GetCardCommonVal(newCards[0]) >= 13) return gameConstDef.CARDS_TYPE.NONE;
            if (this.GetCardVal(newCards[0]) == this.GetCardVal(newCards[1]) && this.GetCardVal(newCards[2]) == this.GetCardVal(newCards[3]) && this.GetCardVal(newCards[10]) == this.GetCardVal(newCards[11]) && this.GetCardVal(newCards[4]) == this.GetCardVal(newCards[5]) && this.GetCardVal(newCards[6]) == this.GetCardVal(newCards[7]) && this.GetCardVal(newCards[8]) == this.GetCardVal(newCards[9]) && this.GetCardVal(newCards[12]) == this.GetCardVal(newCards[13]) && this.GetCardVal(newCards[14]) == this.GetCardVal(newCards[15]) && this.GetCardVal(newCards[16]) == this.GetCardVal(newCards[17]) && this.GetCardVal(newCards[18]) == this.GetCardVal(newCards[19]) && this.GetCardCommonVal(newCards[1]) == this.GetCardCommonVal(newCards[2]) + 1 && this.GetCardCommonVal(newCards[3]) == this.GetCardCommonVal(newCards[4]) + 1 && this.GetCardCommonVal(newCards[5]) == this.GetCardCommonVal(newCards[6]) + 1 && this.GetCardCommonVal(newCards[7]) == this.GetCardCommonVal(newCards[8]) + 1 && this.GetCardCommonVal(newCards[9]) == this.GetCardCommonVal(newCards[10]) + 1 && this.GetCardCommonVal(newCards[11]) == this.GetCardCommonVal(newCards[12]) + 1 && this.GetCardCommonVal(newCards[13]) == this.GetCardCommonVal(newCards[14]) + 1 && this.GetCardCommonVal(newCards[15]) == this.GetCardCommonVal(newCards[16]) + 1 && this.GetCardCommonVal(newCards[17]) == this.GetCardCommonVal(newCards[18]) + 1) return (gameConstDef.CARDS_TYPE.LIAN_DUI_10 << 16) + newCards[18];

            return gameConstDef.CARDS_TYPE.NONE;
        }
        return gameConstDef.CARDS_TYPE.NONE;
    },

    CardsCompare: function CardsCompare(puke1, puke2) {
        var nTypeVal1 = this.CheckCardsValid(puke1);
        var nTypeVal2 = this.CheckCardsValid(puke2);
        var nType1 = nTypeVal1 >> 16;
        var nType2 = nTypeVal2 >> 16;
        var nVal1 = this.GetCardCommonVal(nTypeVal1 & 0xFF);
        var nVal2 = this.GetCardCommonVal(nTypeVal2 & 0xFF);

        if (nType1 == gameConstDef.CARDS_TYPE.ROCKET) return 1;
        if (nType2 == gameConstDef.CARDS_TYPE.ROCKET) return -1;

        if (nType1 == gameConstDef.CARDS_TYPE.BOMB && nType2 != gameConstDef.CARDS_TYPE.BOMB) return 1;
        if (nType1 != gameConstDef.CARDS_TYPE.BOMB && nType2 == gameConstDef.CARDS_TYPE.BOMB) return -1;

        if (nType1 != nType2) return 1;

        if (nVal1 > nVal2) return 1;
        if (nVal1 < nVal2) return -1;

        return 0;
    },
    BeatCardsCobmbiles: function BeatCardsCobmbiles(puke1, puke2) // puke1 当前出的牌    puke2 手中所有牌
    {
        if (puke2.length == 0) return 0;
        var nTypeVal = this.CheckCardsValid(puke1);
        var nType = nTypeVal >> 16;

        var canBeatArr = [];
        if (nType == gameConstDef.CARDS_TYPE.ROCKET) return canBeatArr;

        var puke = this.OrderPuke(puke2);
        var combiles = this.GetCardsCombile(puke, nType);

        for (var i = combiles.length - 1; i >= 0; i--) {
            if (this.CardsCompare(combiles[i], puke1) == 1) {
                canBeatArr.push(combiles[i]);
            };
        }
        if (nType != gameConstDef.CARDS_TYPE.BOMB) {
            var bombCombiles = this.GetCardsCombile(puke, gameConstDef.CARDS_TYPE.BOMB);
            for (var j = 0; j < bombCombiles.length; j++) {
                canBeatArr.push(bombCombiles[j]);
            }
        }
        var rocketCombiles = this.GetCardsCombile(puke, gameConstDef.CARDS_TYPE.ROCKET);
        if (rocketCombiles.length > 0) canBeatArr.push(rocketCombiles[0]);
        return canBeatArr;
    },

    GetCardsTypeXX: function GetCardsTypeXX(puke) {
        var allXX = [];
        if (puke.length < 2) return allXX;

        for (var i = 0; i < puke.length - 1; i++) {
            if (i > 0 && this.GetCardVal(puke[i - 1]) == this.GetCardVal(puke[i])) continue;
            if (this.GetCardVal(puke[i]) == this.GetCardVal(puke[i + 1])) {
                var item = [];
                item.push(puke[i]);
                item.push(puke[i + 1]);
                allXX.push(item);
            }
        }
        return allXX;
    },
    GetCardsTypeXXX: function GetCardsTypeXXX(puke) {
        var allXXX = [];
        if (puke.length < 3) return allXXX;

        for (var i = 0; i < puke.length - 2; i++) {
            if (i > 0 && this.GetCardVal(puke[i - 1]) == this.GetCardVal(puke[i])) continue;
            if (this.GetCardVal(puke[i]) == this.GetCardVal(puke[i + 2])) {
                var item = [];
                item.push(puke[i]);
                item.push(puke[i + 1]);
                item.push(puke[i + 2]);
                allXXX.push(item);
            }
        }
        return allXXX;
    },
    GetCardsCombile: function GetCardsCombile(puke, type) {
        var pukeCombile = [];
        switch (type) {
            case gameConstDef.CARDS_TYPE.TYPE_X:
                {
                    for (var k in puke) {
                        var item = [];
                        item.push(puke[k]);
                        pukeCombile.push(item);
                    }
                    break;
                }
            case gameConstDef.CARDS_TYPE.TYPE_XX:
                {
                    if (puke.length < 2) break;
                    pukeCombile = this.GetCardsTypeXX(puke);
                    break;
                }

            case gameConstDef.CARDS_TYPE.TYPE_XXX:
                {
                    if (puke.length < 3) break;
                    pukeCombile = this.GetCardsTypeXXX(puke);
                    break;
                }
            case gameConstDef.CARDS_TYPE.LIAN_DUI_3:
                {
                    if (puke.length < 6) break;

                    var allXX = this.GetCardsTypeXX(puke);
                    if (allXX.length < 3) break;

                    for (var i = 0; i < allXX.length - 2; i++) {
                        if (this.GetCardCommonVal(allXX[i][0]) >= 13) continue;
                        if (this.GetCardCommonVal(allXX[i][0]) == this.GetCardCommonVal(allXX[i + 1][0]) + 1 && this.GetCardCommonVal(allXX[i + 1][0]) == this.GetCardCommonVal(allXX[i + 2][0]) + 1) {
                            var item = [];
                            item.push(allXX[i][0]);
                            item.push(allXX[i][1]);
                            item.push(allXX[i + 1][0]);
                            item.push(allXX[i + 1][1]);
                            item.push(allXX[i + 2][0]);
                            item.push(allXX[i + 2][1]);
                            pukeCombile.push(item);
                        }
                    }
                    break;
                }
            case gameConstDef.CARDS_TYPE.LIAN_DUI_4:
                {
                    if (puke.length < 8) break;

                    var allXX = this.GetCardsTypeXX(puke);
                    if (allXX.length < 4) break;

                    for (var i = 0; i < allXX.length - 3; i++) {
                        if (this.GetCardCommonVal(allXX[i][0]) >= 13) continue;
                        if (this.GetCardCommonVal(allXX[i][0]) == this.GetCardCommonVal(allXX[i + 1][0]) + 1 && this.GetCardCommonVal(allXX[i + 1][0]) == this.GetCardCommonVal(allXX[i + 2][0]) + 1 && this.GetCardCommonVal(allXX[i + 2][0]) == this.GetCardCommonVal(allXX[i + 3][0]) + 1) {
                            var item = [];
                            item.push(allXX[i][0]);
                            item.push(allXX[i][1]);
                            item.push(allXX[i + 1][0]);
                            item.push(allXX[i + 1][1]);
                            item.push(allXX[i + 2][0]);
                            item.push(allXX[i + 2][1]);
                            item.push(allXX[i + 3][0]);
                            item.push(allXX[i + 3][1]);
                            pukeCombile.push(item);
                        }
                    }
                    break;
                }
            case gameConstDef.CARDS_TYPE.LIAN_DUI_5:
                {
                    if (puke.length < 10) break;

                    var allXX = this.GetCardsTypeXX(puke);
                    if (allXX.length < 5) break;
                    for (var i = 0; i < allXX.length - 4; i++) {
                        if (this.GetCardCommonVal(allXX[i][0]) >= 13) continue;
                        if (this.GetCardCommonVal(allXX[i][0]) == this.GetCardCommonVal(allXX[i + 1][0]) + 1 && this.GetCardCommonVal(allXX[i + 1][0]) == this.GetCardCommonVal(allXX[i + 2][0]) + 1 && this.GetCardCommonVal(allXX[i + 2][0]) == this.GetCardCommonVal(allXX[i + 3][0]) + 1 && this.GetCardCommonVal(allXX[i + 3][0]) == this.GetCardCommonVal(allXX[i + 4][0]) + 1) {
                            var item = [];
                            item.push(allXX[i][0]);
                            item.push(allXX[i][1]);
                            item.push(allXX[i + 1][0]);
                            item.push(allXX[i + 1][1]);
                            item.push(allXX[i + 2][0]);
                            item.push(allXX[i + 2][1]);
                            item.push(allXX[i + 3][0]);
                            item.push(allXX[i + 3][1]);
                            item.push(allXX[i + 4][0]);
                            item.push(allXX[i + 4][1]);
                            pukeCombile.push(item);
                        }
                    }
                    break;
                }
            case gameConstDef.CARDS_TYPE.LIAN_DUI_6:
                {
                    if (puke.length < 12) break;
                    var allXX = this.GetCardsTypeXX(puke);
                    if (allXX.length < 6) break;
                    for (var i = 0; i < allXX.length - 5; i++) {
                        if (this.GetCardCommonVal(allXX[i][0]) >= 13) continue;
                        if (this.GetCardCommonVal(allXX[i][0]) == this.GetCardCommonVal(allXX[i + 1][0]) + 1 && this.GetCardCommonVal(allXX[i + 1][0]) == this.GetCardCommonVal(allXX[i + 2][0]) + 1 && this.GetCardCommonVal(allXX[i + 2][0]) == this.GetCardCommonVal(allXX[i + 3][0]) + 1 && this.GetCardCommonVal(allXX[i + 3][0]) == this.GetCardCommonVal(allXX[i + 4][0]) + 1 && this.GetCardCommonVal(allXX[i + 4][0]) == this.GetCardCommonVal(allXX[i + 5][0]) + 1) {
                            var item = [];
                            item.push(allXX[i][0]);
                            item.push(allXX[i][1]);
                            item.push(allXX[i + 1][0]);
                            item.push(allXX[i + 1][1]);
                            item.push(allXX[i + 2][0]);
                            item.push(allXX[i + 2][1]);
                            item.push(allXX[i + 3][0]);
                            item.push(allXX[i + 3][1]);
                            item.push(allXX[i + 4][0]);
                            item.push(allXX[i + 4][1]);
                            item.push(allXX[i + 5][0]);
                            item.push(allXX[i + 5][1]);
                            pukeCombile.push(item);
                        }
                    }
                    break;
                }
            case gameConstDef.CARDS_TYPE.LIAN_DUI_7:
                {
                    if (puke.length < 14) break;
                    var allXX = this.GetCardsTypeXX(puke);
                    if (allXX.length < 7) break;
                    for (var i = 0; i < allXX.length - 6; i++) {
                        if (this.GetCardCommonVal(allXX[i][0]) >= 13) continue;
                        if (this.GetCardCommonVal(allXX[i][0]) == this.GetCardCommonVal(allXX[i + 1][0]) + 1 && this.GetCardCommonVal(allXX[i + 1][0]) == this.GetCardCommonVal(allXX[i + 2][0]) + 1 && this.GetCardCommonVal(allXX[i + 2][0]) == this.GetCardCommonVal(allXX[i + 3][0]) + 1 && this.GetCardCommonVal(allXX[i + 3][0]) == this.GetCardCommonVal(allXX[i + 4][0]) + 1 && this.GetCardCommonVal(allXX[i + 4][0]) == this.GetCardCommonVal(allXX[i + 5][0]) + 1 && this.GetCardCommonVal(allXX[i + 5][0]) == this.GetCardCommonVal(allXX[i + 6][0]) + 1) {
                            var item = [];
                            item.push(allXX[i][0]);
                            item.push(allXX[i][1]);
                            item.push(allXX[i + 1][0]);
                            item.push(allXX[i + 1][1]);
                            item.push(allXX[i + 2][0]);
                            item.push(allXX[i + 2][1]);
                            item.push(allXX[i + 3][0]);
                            item.push(allXX[i + 3][1]);
                            item.push(allXX[i + 4][0]);
                            item.push(allXX[i + 4][1]);
                            item.push(allXX[i + 5][0]);
                            item.push(allXX[i + 5][1]);
                            item.push(allXX[i + 6][0]);
                            item.push(allXX[i + 6][1]);
                            pukeCombile.push(item);
                        }
                    }
                    break;
                }
            case gameConstDef.CARDS_TYPE.LIAN_DUI_8:
                {
                    if (puke.length < 16) break;
                    var allXX = this.GetCardsTypeXX(puke);
                    if (allXX.length < 8) break;
                    for (var i = 0; i < allXX.length - 7; i++) {
                        if (this.GetCardCommonVal(allXX[i][0]) >= 13) continue;
                        if (this.GetCardCommonVal(allXX[i][0]) == this.GetCardCommonVal(allXX[i + 1][0]) + 1 && this.GetCardCommonVal(allXX[i + 1][0]) == this.GetCardCommonVal(allXX[i + 2][0]) + 1 && this.GetCardCommonVal(allXX[i + 2][0]) == this.GetCardCommonVal(allXX[i + 3][0]) + 1 && this.GetCardCommonVal(allXX[i + 3][0]) == this.GetCardCommonVal(allXX[i + 4][0]) + 1 && this.GetCardCommonVal(allXX[i + 4][0]) == this.GetCardCommonVal(allXX[i + 5][0]) + 1 && this.GetCardCommonVal(allXX[i + 5][0]) == this.GetCardCommonVal(allXX[i + 6][0]) + 1 && this.GetCardCommonVal(allXX[i + 6][0]) == this.GetCardCommonVal(allXX[i + 7][0]) + 1) {
                            var item = [];
                            item.push(allXX[i][0]);
                            item.push(allXX[i][1]);
                            item.push(allXX[i + 1][0]);
                            item.push(allXX[i + 1][1]);
                            item.push(allXX[i + 2][0]);
                            item.push(allXX[i + 2][1]);
                            item.push(allXX[i + 3][0]);
                            item.push(allXX[i + 3][1]);
                            item.push(allXX[i + 4][0]);
                            item.push(allXX[i + 4][1]);
                            item.push(allXX[i + 5][0]);
                            item.push(allXX[i + 5][1]);
                            item.push(allXX[i + 6][0]);
                            item.push(allXX[i + 6][1]);
                            item.push(allXX[i + 7][0]);
                            item.push(allXX[i + 7][1]);
                            pukeCombile.push(item);
                        }
                    }
                    break;
                }
            case gameConstDef.CARDS_TYPE.LIAN_DUI_9:
                {
                    if (puke.length < 18) break;
                    var allXX = this.GetCardsTypeXX(puke);
                    if (allXX.length < 9) break;
                    for (var i = 0; i < allXX.length - 8; i++) {
                        if (this.GetCardCommonVal(allXX[i][0]) >= 13) continue;
                        if (this.GetCardCommonVal(allXX[i][0]) == this.GetCardCommonVal(allXX[i + 1][0]) + 1 && this.GetCardCommonVal(allXX[i + 1][0]) == this.GetCardCommonVal(allXX[i + 2][0]) + 1 && this.GetCardCommonVal(allXX[i + 2][0]) == this.GetCardCommonVal(allXX[i + 3][0]) + 1 && this.GetCardCommonVal(allXX[i + 3][0]) == this.GetCardCommonVal(allXX[i + 4][0]) + 1 && this.GetCardCommonVal(allXX[i + 4][0]) == this.GetCardCommonVal(allXX[i + 5][0]) + 1 && this.GetCardCommonVal(allXX[i + 5][0]) == this.GetCardCommonVal(allXX[i + 6][0]) + 1 && this.GetCardCommonVal(allXX[i + 6][0]) == this.GetCardCommonVal(allXX[i + 7][0]) + 1 && this.GetCardCommonVal(allXX[i + 7][0]) == this.GetCardCommonVal(allXX[i + 8][0]) + 1) {
                            var item = [];
                            item.push(allXX[i][0]);
                            item.push(allXX[i][1]);
                            item.push(allXX[i + 1][0]);
                            item.push(allXX[i + 1][1]);
                            item.push(allXX[i + 2][0]);
                            item.push(allXX[i + 2][1]);
                            item.push(allXX[i + 3][0]);
                            item.push(allXX[i + 3][1]);
                            item.push(allXX[i + 4][0]);
                            item.push(allXX[i + 4][1]);
                            item.push(allXX[i + 5][0]);
                            item.push(allXX[i + 5][1]);
                            item.push(allXX[i + 6][0]);
                            item.push(allXX[i + 6][1]);
                            item.push(allXX[i + 7][0]);
                            item.push(allXX[i + 7][1]);
                            item.push(allXX[i + 8][0]);
                            item.push(allXX[i + 8][1]);
                            pukeCombile.push(item);
                        }
                    }
                    break;
                }
            case gameConstDef.CARDS_TYPE.LIAN_DUI_10:
                {
                    if (puke.length < 20) break;
                    var allXX = this.GetCardsTypeXX(puke);
                    if (allXX.length < 10) break;
                    for (var i = 0; i < allXX.length - 9; i++) {
                        if (this.GetCardCommonVal(allXX[i][0]) >= 13) continue;
                        if (this.GetCardCommonVal(allXX[i][0]) == this.GetCardCommonVal(allXX[i + 1][0]) + 1 && this.GetCardCommonVal(allXX[i + 1][0]) == this.GetCardCommonVal(allXX[i + 2][0]) + 1 && this.GetCardCommonVal(allXX[i + 2][0]) == this.GetCardCommonVal(allXX[i + 3][0]) + 1 && this.GetCardCommonVal(allXX[i + 3][0]) == this.GetCardCommonVal(allXX[i + 4][0]) + 1 && this.GetCardCommonVal(allXX[i + 4][0]) == this.GetCardCommonVal(allXX[i + 5][0]) + 1 && this.GetCardCommonVal(allXX[i + 5][0]) == this.GetCardCommonVal(allXX[i + 6][0]) + 1 && this.GetCardCommonVal(allXX[i + 6][0]) == this.GetCardCommonVal(allXX[i + 7][0]) + 1 && this.GetCardCommonVal(allXX[i + 7][0]) == this.GetCardCommonVal(allXX[i + 8][0]) + 1 && this.GetCardCommonVal(allXX[i + 8][0]) == this.GetCardCommonVal(allXX[i + 9][0]) + 1) {
                            var item = [];
                            item.push(allXX[i][0]);
                            item.push(allXX[i][1]);
                            item.push(allXX[i + 1][0]);
                            item.push(allXX[i + 1][1]);
                            item.push(allXX[i + 2][0]);
                            item.push(allXX[i + 2][1]);
                            item.push(allXX[i + 3][0]);
                            item.push(allXX[i + 3][1]);
                            item.push(allXX[i + 4][0]);
                            item.push(allXX[i + 4][1]);
                            item.push(allXX[i + 5][0]);
                            item.push(allXX[i + 5][1]);
                            item.push(allXX[i + 6][0]);
                            item.push(allXX[i + 6][1]);
                            item.push(allXX[i + 7][0]);
                            item.push(allXX[i + 7][1]);
                            item.push(allXX[i + 8][0]);
                            item.push(allXX[i + 8][1]);
                            item.push(allXX[i + 9][0]);
                            item.push(allXX[i + 9][1]);
                            pukeCombile.push(item);
                        }
                    }
                    break;
                }
            case gameConstDef.CARDS_TYPE.LIAN_SHUN_2:
                {
                    if (puke.length < 6) break;
                    var allXXX = this.GetCardsTypeXXX(puke);
                    if (allXXX.length < 2) break;
                    for (var i = 0; i < allXXX.length - 1; i++) {
                        if (this.GetCardCommonVal(allXXX[i][0]) >= 13) continue;
                        if (this.GetCardCommonVal(allXXX[i][0]) == this.GetCardCommonVal(allXXX[i + 1][0]) + 1) {
                            var item = [];
                            item.push(allXXX[i][0]);
                            item.push(allXXX[i][1]);
                            item.push(allXXX[i][2]);
                            item.push(allXXX[i + 1][0]);
                            item.push(allXXX[i + 1][1]);
                            item.push(allXXX[i + 1][2]);
                            pukeCombile.push(item);
                        }
                    }
                    break;
                }
            case gameConstDef.CARDS_TYPE.LIAN_SHUN_3:
                {
                    if (puke.length < 9) break;
                    var allXXX = this.GetCardsTypeXXX(puke);
                    if (allXXX.length < 3) break;
                    for (var i = 0; i < allXXX.length - 2; i++) {
                        if (this.GetCardCommonVal(allXXX[i][0]) >= 13) continue;
                        if (this.GetCardCommonVal(allXXX[i][0]) == this.GetCardCommonVal(allXXX[i + 1][0]) + 1 && this.GetCardCommonVal(allXXX[i + 1][0]) == this.GetCardCommonVal(allXXX[i + 2][0]) + 1) {
                            var item = [];
                            item.push(allXXX[i][0]);
                            item.push(allXXX[i][1]);
                            item.push(allXXX[i][2]);
                            item.push(allXXX[i + 1][0]);
                            item.push(allXXX[i + 1][1]);
                            item.push(allXXX[i + 1][2]);
                            item.push(allXXX[i + 2][0]);
                            item.push(allXXX[i + 2][1]);
                            item.push(allXXX[i + 2][2]);
                            pukeCombile.push(item);
                        }
                    }
                    break;
                }
            case gameConstDef.CARDS_TYPE.LIAN_SHUN_4:
                {
                    if (puke.length < 12) break;
                    var allXXX = this.GetCardsTypeXXX(puke);
                    if (allXXX.length < 4) break;
                    for (var i = 0; i < allXXX.length - 3; i++) {
                        if (this.GetCardCommonVal(allXXX[i][0]) >= 13) continue;
                        if (this.GetCardCommonVal(allXXX[i][0]) == this.GetCardCommonVal(allXXX[i + 1][0]) + 1 && this.GetCardCommonVal(allXXX[i + 1][0]) == this.GetCardCommonVal(allXXX[i + 2][0]) + 1 && this.GetCardCommonVal(allXXX[i + 2][0]) == this.GetCardCommonVal(allXXX[i + 3][0]) + 1) {
                            var item = [];
                            item.push(allXXX[i][0]);
                            item.push(allXXX[i][1]);
                            item.push(allXXX[i][2]);
                            item.push(allXXX[i + 1][0]);
                            item.push(allXXX[i + 1][1]);
                            item.push(allXXX[i + 1][2]);
                            item.push(allXXX[i + 2][0]);
                            item.push(allXXX[i + 2][1]);
                            item.push(allXXX[i + 2][2]);
                            item.push(allXXX[i + 3][0]);
                            item.push(allXXX[i + 3][1]);
                            item.push(allXXX[i + 3][2]);
                            pukeCombile.push(item);
                        }
                    }
                    break;
                }
            case gameConstDef.CARDS_TYPE.LIAN_SHUN_5:
                {
                    if (puke.length < 15) break;
                    var allXXX = this.GetCardsTypeXXX(puke);
                    if (allXXX.length < 4) break;
                    for (var i = 0; i < allXXX.length - 4; i++) {
                        if (this.GetCardCommonVal(allXXX[i][0]) >= 13) continue;
                        if (this.GetCardCommonVal(allXXX[i][0]) == this.GetCardCommonVal(allXXX[i + 1][0]) + 1 && this.GetCardCommonVal(allXXX[i + 1][0]) == this.GetCardCommonVal(allXXX[i + 2][0]) + 1 && this.GetCardCommonVal(allXXX[i + 2][0]) == this.GetCardCommonVal(allXXX[i + 3][0]) + 1 && this.GetCardCommonVal(allXXX[i + 3][0]) == this.GetCardCommonVal(allXXX[i + 4][0]) + 1) {
                            var item = [];
                            item.push(allXXX[i][0]);
                            item.push(allXXX[i][1]);
                            item.push(allXXX[i][2]);
                            item.push(allXXX[i + 1][0]);
                            item.push(allXXX[i + 1][1]);
                            item.push(allXXX[i + 1][2]);
                            item.push(allXXX[i + 2][0]);
                            item.push(allXXX[i + 2][1]);
                            item.push(allXXX[i + 2][2]);
                            item.push(allXXX[i + 3][0]);
                            item.push(allXXX[i + 3][1]);
                            item.push(allXXX[i + 3][2]);
                            item.push(allXXX[i + 4][0]);
                            item.push(allXXX[i + 4][1]);
                            item.push(allXXX[i + 4][2]);
                            pukeCombile.push(item);
                        }
                    }
                    break;
                }
            case gameConstDef.CARDS_TYPE.LIAN_SHUN_6:
                {
                    if (puke.length < 18) break;
                    var allXXX = this.GetCardsTypeXXX(puke);
                    if (allXXX.length < 5) break;
                    for (var i = 0; i < allXXX.length - 5; i++) {
                        if (this.GetCardCommonVal(allXXX[i][0]) >= 13) continue;
                        if (this.GetCardCommonVal(allXXX[i][0]) == this.GetCardCommonVal(allXXX[i + 1][0]) + 1 && this.GetCardCommonVal(allXXX[i + 1][0]) == this.GetCardCommonVal(allXXX[i + 2][0]) + 1 && this.GetCardCommonVal(allXXX[i + 2][0]) == this.GetCardCommonVal(allXXX[i + 3][0]) + 1 && this.GetCardCommonVal(allXXX[i + 3][0]) == this.GetCardCommonVal(allXXX[i + 4][0]) + 1 && this.GetCardCommonVal(allXXX[i + 4][0]) == this.GetCardCommonVal(allXXX[i + 5][0]) + 1) {
                            var item = [];
                            item.push(allXXX[i][0]);
                            item.push(allXXX[i][1]);
                            item.push(allXXX[i][2]);
                            item.push(allXXX[i + 1][0]);
                            item.push(allXXX[i + 1][1]);
                            item.push(allXXX[i + 1][2]);
                            item.push(allXXX[i + 2][0]);
                            item.push(allXXX[i + 2][1]);
                            item.push(allXXX[i + 2][2]);
                            item.push(allXXX[i + 3][0]);
                            item.push(allXXX[i + 3][1]);
                            item.push(allXXX[i + 3][2]);
                            item.push(allXXX[i + 4][0]);
                            item.push(allXXX[i + 4][1]);
                            item.push(allXXX[i + 4][2]);
                            item.push(allXXX[i + 5][0]);
                            item.push(allXXX[i + 5][1]);
                            item.push(allXXX[i + 5][2]);
                            pukeCombile.push(item);
                        }
                    }
                    break;
                }

            case gameConstDef.CARDS_TYPE.PLANE_S_1:
                {
                    if (puke.length < 4) break;
                    var allXXX = this.GetCardsTypeXXX(puke);
                    if (allXXX.length < 1) break;

                    for (var i = 0; i < allXXX.length; i++) {
                        for (var j = 0; j < puke.length; j++) {
                            if (this.GetCardVal(puke[j]) == this.GetCardVal(allXXX[i][0])) continue;
                            var item = [];
                            item.push(allXXX[i][0]);
                            item.push(allXXX[i][1]);
                            item.push(allXXX[i][2]);
                            item.push(puke[j]);
                            pukeCombile.push(item);
                        }
                    }
                    break;
                }
            case gameConstDef.CARDS_TYPE.PLANE_S_2:
                {
                    if (puke.length < 8) break;
                    var allXXX = this.GetCardsTypeXXX(puke);
                    if (allXXX.length < 2) break;
                    for (var i = 0; i < allXXX.length - 1; i++) {
                        if (this.GetCardCommonVal(allXXX[i][0]) >= 13) continue;
                        if (this.GetCardCommonVal(allXXX[i][0]) !== this.GetCardCommonVal(allXXX[i + 1][0]) + 1) continue;
                        for (var j = 0; j < puke.length; j++) {
                            if (this.GetCardVal(puke[j]) == this.GetCardVal(allXXX[i][0]) || this.GetCardVal(puke[j]) == this.GetCardVal(allXXX[i + 1][0])) continue;
                            for (var _k = 0; _k < puke.length; _k++) {
                                if (this.GetCardVal(puke[_k]) == this.GetCardVal(allXXX[i][0]) || this.GetCardVal(puke[_k]) != this.GetCardVal(allXXX[i + 1][0]) || this.GetCardVal(puke[_k]) == this.GetCardVal(puke[j])) continue;
                                var item = [];
                                item.push(allXXX[i][0]);
                                item.push(allXXX[i][1]);
                                item.push(allXXX[i][2]);
                                item.push(allXXX[i + 1][0]);
                                item.push(allXXX[i + 1][1]);
                                item.push(allXXX[i + 1][2]);
                                item.push(puke[j]);
                                item.push(puke[_k]);
                                pukeCombile.push(item);
                            }
                        }
                    }
                    break;
                }
            case gameConstDef.CARDS_TYPE.PLANE_S_3:
                {
                    if (puke.length < 12) break;
                    var allXXX = this.GetCardsTypeXXX(puke);
                    if (allXXX.length < 3) break;
                    for (var i = 0; i < allXXX.length - 2; i++) {
                        if (this.GetCardCommonVal(allXXX[i][0]) >= 13) continue;
                        if (this.GetCardCommonVal(allXXX[i][0]) !== this.GetCardCommonVal(allXXX[i + 1][0]) + 1 || this.GetCardCommonVal(allXXX[i + 1][0]) !== this.GetCardCommonVal(allXXX[i + 2][0]) + 1) continue;
                        for (var j = 0; j < puke.length; j++) {
                            if (this.GetCardVal(puke[j]) == this.GetCardVal(allXXX[i][0]) || this.GetCardVal(puke[j]) == this.GetCardVal(allXXX[i + 1][0]) || this.GetCardVal(puke[j]) == this.GetCardVal(allXXX[i + 2][0])) continue;
                            for (var _k2 = 0; _k2 < puke.length; _k2++) {
                                if (this.GetCardVal(puke[_k2]) == this.GetCardVal(allXXX[i][0]) || this.GetCardVal(puke[_k2]) == this.GetCardVal(allXXX[i + 1][0]) || this.GetCardVal(puke[_k2]) == this.GetCardVal(allXXX[i + 2][0]) || this.GetCardVal(puke[j]) == this.GetCardVal(puke[_k2])) for (var m = 0; m < puke.length; m++) {
                                    if (this.GetCardVal(puke[m]) == this.GetCardVal(allXXX[i][0]) || this.GetCardVal(puke[m]) == this.GetCardVal(allXXX[i + 1][0]) || this.GetCardVal(puke[m]) == this.GetCardVal(allXXX[i + 2][0]) || this.GetCardVal(puke[m]) == this.GetCardVal(puke[_k2]) || this.GetCardVal(puke[m]) == this.GetCardVal(puke[j])) continue;
                                    var item = [];
                                    item.push(allXXX[i][0]);
                                    item.push(allXXX[i][1]);
                                    item.push(allXXX[i][2]);
                                    item.push(allXXX[i + 1][0]);
                                    item.push(allXXX[i + 1][1]);
                                    item.push(allXXX[i + 1][2]);
                                    item.push(allXXX[i + 2][0]);
                                    item.push(allXXX[i + 2][1]);
                                    item.push(allXXX[i + 2][2]);
                                    item.push(puke[j]);
                                    item.push(puke[_k2]);
                                    item.push(puke[m]);
                                    pukeCombile.push(item);
                                }
                            }
                        }
                    }
                    break;
                }
            case gameConstDef.CARDS_TYPE.PLANE_S_4:
                {
                    if (puke.length < 16) break;
                    var allXXX = this.GetCardsTypeXXX(puke);
                    if (allXXX.length < 4) break;
                    for (var i = 0; i < allXXX.length - 3; i++) {
                        if (this.GetCardCommonVal(allXXX[i][0]) >= 13) continue;
                        if (this.GetCardCommonVal(allXXX[i][0]) !== this.GetCardCommonVal(allXXX[i + 1][0]) + 1 || this.GetCardCommonVal(allXXX[i + 1][0]) !== this.GetCardCommonVal(allXXX[i + 2][0]) + 1 || this.GetCardCommonVal(allXXX[i + 2][0]) !== this.GetCardCommonVal(allXXX[i + 3][0]) + 1) continue;
                        for (var j = 0; j < puke.length; j++) {
                            if (this.GetCardVal(puke[j]) == this.GetCardVal(allXXX[i][0]) || this.GetCardVal(puke[j]) == this.GetCardVal(allXXX[i + 1][0]) || this.GetCardVal(puke[j]) == this.GetCardVal(allXXX[i + 2][0]) || this.GetCardVal(puke[j]) == this.GetCardVal(allXXX[i + 3][0])) continue;
                            for (var _k3 = 0; _k3 < puke.length; _k3++) {
                                if (this.GetCardVal(puke[_k3]) == this.GetCardVal(allXXX[i][0]) || this.GetCardVal(puke[_k3]) == this.GetCardVal(allXXX[i + 1][0]) || this.GetCardVal(puke[_k3]) == this.GetCardVal(allXXX[i + 2][0]) || this.GetCardVal(puke[_k3]) == this.GetCardVal(allXXX[i + 3][0]) || this.GetCardVal(puke[j]) == this.GetCardVal(puke[_k3])) continue;
                                for (var m = 0; m < puke.length; m++) {
                                    if (this.GetCardVal(puke[m]) == this.GetCardVal(allXXX[i][0]) || this.GetCardVal(puke[m]) == this.GetCardVal(allXXX[i + 1][0]) || this.GetCardVal(puke[m]) == this.GetCardVal(allXXX[i + 2][0]) || this.GetCardVal(puke[m]) == this.GetCardVal(allXXX[i + 3][0]) || this.GetCardVal(puke[m]) == this.GetCardVal(puke[_k3]) || this.GetCardVal(puke[m]) == this.GetCardVal(puke[j])) continue;
                                    for (var n = 0; n < puke.length; n++) {
                                        if (this.GetCardVal(puke[n]) == this.GetCardVal(allXXX[i][0]) || this.GetCardVal(puke[n]) == this.GetCardVal(allXXX[i + 1][0]) || this.GetCardVal(puke[n]) == this.GetCardVal(allXXX[i + 2][0]) || this.GetCardVal(puke[n]) == this.GetCardVal(allXXX[i + 3][0]) || this.GetCardVal(puke[n]) == this.GetCardVal(puke[m]) || this.GetCardVal(puke[n]) == this.GetCardVal(puke[j]) || this.GetCardVal(puke[n]) == this.GetCardVal(puke[_k3])) continue;
                                        {
                                            var item = [];
                                            item.push(allXXX[i][0]);
                                            item.push(allXXX[i][1]);
                                            item.push(allXXX[i][2]);
                                            item.push(allXXX[i + 1][0]);
                                            item.push(allXXX[i + 1][1]);
                                            item.push(allXXX[i + 1][2]);
                                            item.push(allXXX[i + 2][0]);
                                            item.push(allXXX[i + 2][1]);
                                            item.push(allXXX[i + 2][2]);
                                            item.push(allXXX[i + 3][0]);
                                            item.push(allXXX[i + 3][1]);
                                            item.push(allXXX[i + 3][2]);
                                            item.push(puke[j]);
                                            item.push(puke[_k3]);
                                            item.push(puke[m]);
                                            item.push(puke[n]);
                                            pukeCombile.push(item);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    break;
                }
            case gameConstDef.CARDS_TYPE.PLANE_S_5:
                {
                    if (puke.length < 20) break;
                    var allXXX = this.GetCardsTypeXXX(puke);
                    if (allXXX.length < 5) break;
                    for (var i = 0; i < allXXX.length; i++) {
                        if (this.GetCardCommonVal(allXXX[i][0]) >= 13) continue;
                        if (this.GetCardCommonVal(allXXX[i][0]) !== this.GetCardCommonVal(allXXX[i + 1][0]) + 1 || this.GetCardCommonVal(allXXX[i + 1][0]) !== this.GetCardCommonVal(allXXX[i + 2][0]) + 1 || this.GetCardCommonVal(allXXX[i + 2][0]) !== this.GetCardCommonVal(allXXX[i + 3][0]) + 1 || this.GetCardCommonVal(allXXX[i + 3][0]) !== this.GetCardCommonVal(allXXX[i + 4][0]) + 1) continue;
                        for (var j = 0; j < puke.length; j++) {
                            if (this.GetCardVal(puke[j]) == this.GetCardVal(allXXX[i][0]) || this.GetCardVal(puke[j]) == this.GetCardVal(allXXX[i + 1][0]) || this.GetCardVal(puke[j]) == this.GetCardVal(allXXX[i + 2][0]) || this.GetCardVal(puke[j]) == this.GetCardVal(allXXX[i + 3][0]) || this.GetCardVal(puke[j]) == this.GetCardVal(allXXX[i + 4][0])) continue;
                            for (var _k4 = 0; _k4 < puke.length; _k4++) {
                                if (this.GetCardVal(puke[_k4]) == this.GetCardVal(allXXX[i][0]) || this.GetCardVal(puke[_k4]) == this.GetCardVal(allXXX[i + 1][0]) || this.GetCardVal(puke[_k4]) == this.GetCardVal(allXXX[i + 2][0]) || this.GetCardVal(puke[_k4]) == this.GetCardVal(allXXX[i + 3][0]) || this.GetCardVal(puke[_k4]) == this.GetCardVal(allXXX[i + 4][0]) || this.GetCardVal(puke[j]) == this.GetCardVal(puke[_k4])) continue;
                                for (var m = 0; m < puke.length; m++) {
                                    if (this.GetCardVal(puke[m]) == this.GetCardVal(allXXX[i][0]) || this.GetCardVal(puke[m]) == this.GetCardVal(allXXX[i + 1][0]) || this.GetCardVal(puke[m]) == this.GetCardVal(allXXX[i + 2][0]) || this.GetCardVal(puke[m]) == this.GetCardVal(allXXX[i + 3][0]) || this.GetCardVal(puke[m]) == this.GetCardVal(allXXX[i + 4][0]) || this.GetCardVal(puke[m]) == this.GetCardVal(puke[_k4]) || this.GetCardVal(puke[m]) == this.GetCardVal(puke[j])) continue;
                                    for (var n = 0; n < puke.length; n++) {
                                        if (this.GetCardVal(puke[n]) == this.GetCardVal(allXXX[i][0]) || this.GetCardVal(puke[n]) == this.GetCardVal(allXXX[i + 1][0]) || this.GetCardVal(puke[n]) == this.GetCardVal(allXXX[i + 2][0]) || this.GetCardVal(puke[n]) == this.GetCardVal(allXXX[i + 3][0]) || this.GetCardVal(puke[n]) == this.GetCardVal(allXXX[i + 4][0]) || this.GetCardVal(puke[n]) == this.GetCardVal(puke[m]) || this.GetCardVal(puke[n]) == this.GetCardVal(puke[j]) || this.GetCardVal(puke[n]) == this.GetCardVal(puke[_k4])) continue;
                                        for (var t = 0; t < puke.length; t++) {
                                            if (this.GetCardVal(puke[t]) == this.GetCardVal(allXXX[i][0]) || this.GetCardVal(puke[t]) == this.GetCardVal(allXXX[i + 1][0]) || this.GetCardVal(puke[t]) == this.GetCardVal(allXXX[i + 2][0]) || this.GetCardVal(puke[t]) == this.GetCardVal(allXXX[i + 3][0]) || this.GetCardVal(puke[t]) == this.GetCardVal(allXXX[i + 4][0]) || this.GetCardVal(puke[t]) == this.GetCardVal(puke[j]) || this.GetCardVal(puke[t]) == this.GetCardVal(puke[_k4]) || this.GetCardVal(puke[t]) == this.GetCardVal(puke[m]) || this.GetCardVal(puke[t]) == this.GetCardVal(puke[n])) continue;
                                            var item = [];
                                            item.push(allXXX[i][0]);
                                            item.push(allXXX[i][1]);
                                            item.push(allXXX[i][2]);
                                            item.push(allXXX[i + 1][0]);
                                            item.push(allXXX[i + 1][1]);
                                            item.push(allXXX[i + 1][2]);
                                            item.push(allXXX[i + 2][0]);
                                            item.push(allXXX[i + 2][1]);
                                            item.push(allXXX[i + 2][2]);
                                            item.push(allXXX[i + 3][0]);
                                            item.push(allXXX[i + 3][1]);
                                            item.push(allXXX[i + 3][2]);
                                            item.push(allXXX[i + 4][0]);
                                            item.push(allXXX[i + 4][1]);
                                            item.push(allXXX[i + 4][2]);
                                            item.push(puke[j]);
                                            item.push(puke[_k4]);
                                            item.push(puke[m]);
                                            item.push(puke[n]);
                                            item.push(puke[t]);
                                            pukeCombile.push(item);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    break;
                }
            case gameConstDef.CARDS_TYPE.PLANE_B_1:
                {
                    if (puke.length < 5) break;

                    var allXX = this.GetCardsTypeXX(puke);
                    var allXXX = this.GetCardsTypeXXX(puke);
                    if (allXX.length < 2 || allXXX.length < 1) break;

                    for (var i = 0; i < allXXX.length; i++) {
                        for (var j = 0; j < allXX.length; j++) {
                            if (this.GetCardVal(allXX[j][0]) != this.GetCardVal(allXXX[i][0])) {
                                var item = [];
                                item.push(allXXX[i][0]);
                                item.push(allXXX[i][1]);
                                item.push(allXXX[i][2]);
                                item.push(allXX[j][0]);
                                item.push(allXX[j][1]);
                                pukeCombile.push(item);
                            }
                        }
                    }
                    break;
                }
            case gameConstDef.CARDS_TYPE.PLANE_B_2:
                {
                    if (puke.length < 10) break;

                    var allXX = this.GetCardsTypeXX(puke);
                    var allXXX = this.GetCardsTypeXXX(puke);

                    if (allXX.length < 4 || allXXX.length < 2) break;
                    for (var i = 0; i < allXXX.length - 1; i++) {
                        if (this.GetCardCommonVal(allXXX[i][0]) >= 13) continue;
                        if (this.GetCardCommonVal(allXXX[i][0]) != this.GetCardCommonVal(allXXX[i + 1][0]) + 1) continue;

                        for (var j = 0; j < allXX.length; j++) {
                            if (this.GetCardVal(allXX[j][0]) == this.GetCardVal(allXXX[i][0]) || this.GetCardVal(allXX[j][0]) == this.GetCardVal(allXXX[i + 1][0])) continue;
                            for (var _k5 = 0; _k5 < allXX.length; _k5++) {
                                if (this.GetCardVal(allXX[_k5][0]) == this.GetCardVal(allXXX[i][0]) || this.GetCardVal(allXX[_k5][0]) == this.GetCardVal(allXXX[i + 1][0]) || this.GetCardVal(allXX[_k5][0]) == this.GetCardVal(allXX[j][0])) continue;
                                var item = [];
                                item.push(allXXX[i][0]);
                                item.push(allXXX[i][1]);
                                item.push(allXXX[i][2]);
                                item.push(allXXX[i + 1][0]);
                                item.push(allXXX[i + 1][1]);
                                item.push(allXXX[i + 1][2]);
                                item.push(allXXX[j][0]);
                                item.push(allXXX[j][1]);
                                item.push(allXXX[_k5][0]);
                                item.push(allXXX[_k5][1]);
                                pukeCombile.push(item);
                            }
                        }
                    }
                    break;
                }
            case gameConstDef.CARDS_TYPE.PLANE_B_3:
                {
                    if (puke.length < 15) break;

                    var allXX = this.GetCardsTypeXX(puke);
                    var allXXX = this.GetCardsTypeXXX(puke);

                    if (allXX.length < 6 || allXXX.length < 3) break;
                    for (var i = 0; i < allXXX.length - 2; i++) {
                        if (this.GetCardCommonVal(allXXX[i][0]) >= 13) continue;
                        if (this.GetCardCommonVal(allXXX[i][0]) != this.GetCardCommonVal(allXXX[i + 1][0]) + 1 || this.GetCardCommonVal(allXXX[i + 1][0]) != this.GetCardCommonVal(allXXX[i + 2][0]) + 1) continue;
                        for (var j = 0; j < allXX.length; j++) {
                            if (this.GetCardVal(allXX[j][0]) == this.GetCardVal(allXXX[i][0]) || this.GetCardVal(allXX[j][0]) == this.GetCardVal(allXXX[i + 1][0]) || this.GetCardVal(allXX[j][0]) == this.GetCardVal(allXXX[i + 2][0])) continue;
                            for (var _k6 = 0; _k6 < allXX.length; _k6++) {
                                if (this.GetCardVal(allXX[_k6][0]) == this.GetCardVal(allXXX[i][0]) || this.GetCardVal(allXX[_k6][0]) == this.GetCardVal(allXXX[i + 1][0]) || this.GetCardVal(allXX[_k6][0]) == this.GetCardVal(allXXX[i + 2][0]) || this.GetCardVal(allXX[_k6][0]) == this.GetCardVal(allXX[j][0])) continue;
                                for (var t = 0; t < allXX.length; t++) {
                                    if (this.GetCardVal(allXX[t][0]) == this.GetCardVal(allXXX[i][0]) || this.GetCardVal(allXX[t][0]) == this.GetCardVal(allXXX[i + 1][0]) || this.GetCardVal(allXX[t][0]) == this.GetCardVal(allXXX[i + 2][0]) || this.GetCardVal(allXX[t][0]) == this.GetCardVal(allXX[j][0]) || this.GetCardVal(allXX[t][0]) == this.GetCardVal(allXX[_k6][0])) continue;
                                    var item = [];
                                    item.push(allXXX[i][0]);
                                    item.push(allXXX[i][1]);
                                    item.push(allXXX[i][2]);
                                    item.push(allXXX[i + 1][0]);
                                    item.push(allXXX[i + 1][1]);
                                    item.push(allXXX[i + 1][2]);
                                    item.push(allXXX[i + 2][0]);
                                    item.push(allXXX[i + 2][1]);
                                    item.push(allXXX[i + 2][2]);
                                    item.push(allXXX[j][0]);
                                    item.push(allXXX[j][1]);
                                    item.push(allXXX[_k6][0]);
                                    item.push(allXXX[_k6][1]);
                                    item.push(allXXX[t][0]);
                                    item.push(allXXX[t][1]);
                                    pukeCombile.push(item);
                                }
                            }
                        }
                    }
                }
            case gameConstDef.CARDS_TYPE.PLANE_B_3:
                {
                    if (puke.length < 18) break;

                    var allXX = this.GetCardsTypeXX(puke);
                    var allXXX = this.GetCardsTypeXXX(puke);

                    if (allXX.length < 8 || allXXX.length < 4) break;
                    for (var i = 0; i < allXXX.length - 3; i++) {
                        if (this.GetCardCommonVal(allXXX[i][0]) >= 13) continue;
                        if (this.GetCardCommonVal(allXXX[i][0]) != this.GetCardCommonVal(allXXX[i + 1][0]) + 1 || this.GetCardCommonVal(allXXX[i + 1][0]) != this.GetCardCommonVal(allXXX[i + 2][0]) + 1 || this.GetCardCommonVal(allXXX[i + 2][0]) != this.GetCardCommonVal(allXXX[i + 3][0]) + 1) continue;
                        for (var j = 0; j < allXX.length; j++) {
                            if (this.GetCardVal(allXX[j][0]) == this.GetCardVal(allXXX[i][0]) || this.GetCardVal(allXX[j][0]) == this.GetCardVal(allXXX[i + 1][0]) || this.GetCardVal(allXX[j][0]) == this.GetCardVal(allXXX[i + 2][0]) || this.GetCardVal(allXX[j][0]) == this.GetCardVal(allXXX[i + 3][0])) continue;
                            for (var _k7 = 0; _k7 < allXX.length; _k7++) {
                                if (this.GetCardVal(allXX[_k7][0]) == this.GetCardVal(allXXX[i][0]) || this.GetCardVal(allXX[_k7][0]) == this.GetCardVal(allXXX[i + 1][0]) || this.GetCardVal(allXX[_k7][0]) == this.GetCardVal(allXXX[i + 2][0]) || this.GetCardVal(allXX[_k7][0]) == this.GetCardVal(allXXX[i + 3][0]) || this.GetCardVal(allXX[_k7][0]) == this.GetCardVal(allXX[j][0])) continue;
                                for (var t = 0; t < allXX.length; t++) {
                                    if (this.GetCardVal(allXX[t][0]) == this.GetCardVal(allXXX[i][0]) || this.GetCardVal(allXX[t][0]) == this.GetCardVal(allXXX[i + 1][0]) || this.GetCardVal(allXX[t][0]) == this.GetCardVal(allXXX[i + 2][0]) || this.GetCardVal(allXX[t][0]) == this.GetCardVal(allXXX[i + 3][0]) || this.GetCardVal(allXX[t][0]) == this.GetCardVal(allXX[j][0]) || this.GetCardVal(allXX[t][0]) == this.GetCardVal(allXX[_k7][0])) continue;
                                    for (var m = 0; m < allXX.length; m++) {
                                        if (this.GetCardVal(allXX[m][0]) == this.GetCardVal(allXXX[i][0]) || this.GetCardVal(allXX[m][0]) == this.GetCardVal(allXXX[i + 1][0]) || this.GetCardVal(allXX[m][0]) == this.GetCardVal(allXXX[i + 2][0]) || this.GetCardVal(allXX[m][0]) == this.GetCardVal(allXXX[i + 3][0]) || this.GetCardVal(allXX[m][0]) == this.GetCardVal(allXX[j][0]) || this.GetCardVal(allXX[m][0]) == this.GetCardVal(allXX[_k7][0]) || this.GetCardVal(allXX[m][0]) == this.GetCardVal(allXX[t][0])) continue;
                                        var item = [];
                                        item.push(allXXX[i][0]);
                                        item.push(allXXX[i][1]);
                                        item.push(allXXX[i][2]);
                                        item.push(allXXX[i + 1][0]);
                                        item.push(allXXX[i + 1][1]);
                                        item.push(allXXX[i + 1][2]);
                                        item.push(allXXX[i + 2][0]);
                                        item.push(allXXX[i + 2][1]);
                                        item.push(allXXX[i + 2][2]);
                                        item.push(allXXX[i + 3][0]);
                                        item.push(allXXX[i + 3][1]);
                                        item.push(allXXX[i + 3][2]);
                                        item.push(allXXX[j][0]);
                                        item.push(allXXX[j][1]);
                                        item.push(allXXX[_k7][0]);
                                        item.push(allXXX[_k7][1]);
                                        item.push(allXXX[t][0]);
                                        item.push(allXXX[t][1]);
                                        item.push(allXXX[m][0]);
                                        item.push(allXXX[m][1]);
                                        pukeCombile.push(item);
                                    }
                                }
                            }
                        }
                    }
                }
            case gameConstDef.CARDS_TYPE.SHUNZI_5:
                {
                    if (puke.length < 5) break;
                    for (var i = 0; i < puke.length - 4; i++) {
                        var firstVal = this.GetCardCommonVal(puke[i]);
                        if (firstVal >= 13) continue;
                        var isExist1 = 0;
                        var isExist2 = 0;
                        var isExist3 = 0;
                        var isExist4 = 0;
                        var j = 0;
                        while (j < puke.length) {
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 1) {
                                isExist1 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 2) {
                                isExist2 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 3) {
                                isExist3 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 4) {
                                isExist4 = j;j++;continue;
                            }
                            j++;
                        }
                        if (isExist1 > 0 && isExist2 > 0 && isExist3 > 0 && isExist4 > 0) {
                            var item = [];
                            item.push(puke[i]);
                            item.push(puke[isExist1]);
                            item.push(puke[isExist2]);
                            item.push(puke[isExist3]);
                            item.push(puke[isExist4]);
                            pukeCombile.push(item);
                        }
                    }
                    break;
                }
            case gameConstDef.CARDS_TYPE.SHUNZI_6:
                {
                    if (puke.length < 6) break;
                    for (var i = 0; i < puke.length - 5; i++) {
                        var firstVal = this.GetCardCommonVal(puke[i]);
                        if (firstVal >= 13) continue;
                        var isExist1 = 0;var isExist2 = 0;
                        var isExist3 = 0;var isExist4 = 0;
                        var isExist5 = 0;
                        var j = 0;
                        while (j < puke.length) {
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 1) {
                                isExist1 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 2) {
                                isExist2 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 3) {
                                isExist3 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 4) {
                                isExist4 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 5) {
                                isExist5 = j;j++;continue;
                            }
                            j++;
                        }
                        if (isExist1 > 0 && isExist2 > 0 && isExist3 > 0 && isExist4 > 0 && isExist5 > 0) {
                            var item = [];
                            item.push(puke[i]);
                            item.push(puke[isExist1]);
                            item.push(puke[isExist2]);
                            item.push(puke[isExist3]);
                            item.push(puke[isExist4]);
                            item.push(puke[isExist5]);
                            pukeCombile.push(item);
                        }
                    }
                    break;
                }
            case gameConstDef.CARDS_TYPE.SHUNZI_7:
                {
                    if (puke.length < 7) break;
                    for (var i = 0; i < puke.length - 6; i++) {
                        var firstVal = this.GetCardCommonVal(puke[i]);
                        if (firstVal >= 13) continue;
                        var isExist1 = 0;var isExist2 = 0;
                        var isExist3 = 0;var isExist4 = 0;
                        var isExist5 = 0;var isExist6 = 0;
                        var j = 0;
                        while (j < puke.length) {
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 1) {
                                isExist1 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 2) {
                                isExist2 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 3) {
                                isExist3 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 4) {
                                isExist4 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 5) {
                                isExist5 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 6) {
                                isExist6 = j;j++;continue;
                            }
                            j++;
                        }
                        if (isExist1 > 0 && isExist2 > 0 && isExist3 > 0 && isExist4 > 0 && isExist5 > 0 && isExist6 > 0) {
                            var item = [];
                            item.push(puke[i]);
                            item.push(puke[isExist1]);
                            item.push(puke[isExist2]);
                            item.push(puke[isExist3]);
                            item.push(puke[isExist4]);
                            item.push(puke[isExist5]);
                            item.push(puke[isExist6]);
                            pukeCombile.push(item);
                        }
                    }
                    break;
                }
            case gameConstDef.CARDS_TYPE.SHUNZI_8:
                {
                    if (puke.length < 8) break;
                    for (var i = 0; i < puke.length - 7; i++) {
                        var firstVal = this.GetCardCommonVal(puke[i]);
                        if (firstVal >= 13) continue;
                        var isExist1 = 0;var isExist2 = 0;
                        var isExist3 = 0;var isExist4 = 0;
                        var isExist5 = 0;var isExist6 = 0;var isExist7 = 0;
                        var j = 0;
                        while (j < puke.length) {
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 1) {
                                isExist1 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 2) {
                                isExist2 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 3) {
                                isExist3 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 4) {
                                isExist4 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 5) {
                                isExist5 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 6) {
                                isExist6 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 7) {
                                isExist7 = j;j++;continue;
                            }
                            j++;
                        }
                        if (isExist1 > 0 && isExist2 > 0 && isExist3 > 0 && isExist4 > 0 && isExist5 > 0 && isExist6 > 0 && isExist7 > 0) {
                            var item = [];
                            item.push(puke[i]);
                            item.push(puke[isExist1]);
                            item.push(puke[isExist2]);
                            item.push(puke[isExist3]);
                            item.push(puke[isExist4]);
                            item.push(puke[isExist5]);
                            item.push(puke[isExist6]);
                            item.push(puke[isExist7]);
                            pukeCombile.push(item);
                        }
                    }
                    break;
                }
            case gameConstDef.CARDS_TYPE.SHUNZI_9:
                {
                    if (puke.length < 9) break;
                    for (var i = 0; i < puke.length - 8; i++) {
                        var firstVal = this.GetCardCommonVal(puke[i]);
                        if (firstVal >= 13) continue;
                        var isExist1 = 0;var isExist2 = 0;var isExist3 = 0;
                        var isExist4 = 0;var isExist5 = 0;var isExist6 = 0;
                        var isExist7 = 0;var isExist8 = 0;
                        var j = 0;
                        while (j < puke.length) {
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 1) {
                                isExist1 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 2) {
                                isExist2 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 3) {
                                isExist3 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 4) {
                                isExist4 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 5) {
                                isExist5 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 6) {
                                isExist6 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 7) {
                                isExist7 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 8) {
                                isExist8 = j;j++;continue;
                            }
                            j++;
                        }
                        if (isExist1 > 0 && isExist2 > 0 && isExist3 > 0 && isExist4 > 0 && isExist5 > 0 && isExist6 > 0 && isExist7 > 0 && isExist8 > 0) {
                            var item = [];
                            item.push(puke[i]);
                            item.push(puke[isExist1]);
                            item.push(puke[isExist2]);
                            item.push(puke[isExist3]);
                            item.push(puke[isExist4]);
                            item.push(puke[isExist5]);
                            item.push(puke[isExist6]);
                            item.push(puke[isExist7]);
                            item.push(puke[isExist8]);
                            pukeCombile.push(item);
                        }
                    }
                    break;
                }
            case gameConstDef.CARDS_TYPE.SHUNZI_10:
                {
                    if (puke.length < 10) break;
                    for (var i = 0; i < puke.length - 9; i++) {
                        var firstVal = this.GetCardCommonVal(puke[i]);
                        if (firstVal >= 13) continue;
                        var isExist1 = 0;var isExist2 = 0;var isExist3 = 0;
                        var isExist4 = 0;var isExist5 = 0;var isExist6 = 0;
                        var isExist7 = 0;var isExist8 = 0;var isExist9 = 0;
                        var j = 0;
                        while (j < puke.length) {
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 1) {
                                isExist1 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 2) {
                                isExist2 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 3) {
                                isExist3 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 4) {
                                isExist4 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 5) {
                                isExist5 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 6) {
                                isExist6 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 7) {
                                isExist7 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 8) {
                                isExist8 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 9) {
                                isExist9 = j;j++;continue;
                            }
                            j++;
                        }
                        if (isExist1 > 0 && isExist2 > 0 && isExist3 > 0 && isExist4 > 0 && isExist5 > 0 && isExist6 > 0 && isExist7 > 0 && isExist8 > 0 && isExist9 > 0) {
                            var item = [];
                            item.push(puke[i]);
                            item.push(puke[isExist1]);
                            item.push(puke[isExist2]);
                            item.push(puke[isExist3]);
                            item.push(puke[isExist4]);
                            item.push(puke[isExist5]);
                            item.push(puke[isExist6]);
                            item.push(puke[isExist7]);
                            item.push(puke[isExist8]);
                            item.push(puke[isExist9]);
                            pukeCombile.push(item);
                        }
                    }
                    break;
                }
            case gameConstDef.CARDS_TYPE.SHUNZI_11:
                {
                    if (puke.length < 11) break;
                    for (var i = 0; i < puke.length - 10; i++) {
                        var firstVal = this.GetCardCommonVal(puke[i]);
                        if (firstVal >= 13) continue;
                        var isExist1 = 0;var isExist2 = 0;var isExist3 = 0;
                        var isExist4 = 0;var isExist5 = 0;var isExist6 = 0;
                        var isExist7 = 0;var isExist8 = 0;var isExist9 = 0;
                        var isExist10 = 0;
                        var j = 0;
                        while (j < puke.length) {
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 1) {
                                isExist1 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 2) {
                                isExist2 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 3) {
                                isExist3 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 4) {
                                isExist4 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 5) {
                                isExist5 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 6) {
                                isExist6 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 7) {
                                isExist7 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 8) {
                                isExist8 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 9) {
                                isExist9 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 10) {
                                isExist10 = j;j++;continue;
                            }
                            j++;
                        }
                        if (isExist1 > 0 && isExist2 > 0 && isExist3 > 0 && isExist4 > 0 && isExist5 > 0 && isExist6 > 0 && isExist7 > 0 && isExist8 > 0 && isExist9 > 0 && isExist10 > 0) {
                            var item = [];
                            item.push(puke[i]);
                            item.push(puke[isExist1]);
                            item.push(puke[isExist2]);
                            item.push(puke[isExist3]);
                            item.push(puke[isExist4]);
                            item.push(puke[isExist5]);
                            item.push(puke[isExist6]);
                            item.push(puke[isExist7]);
                            item.push(puke[isExist8]);
                            item.push(puke[isExist9]);
                            item.push(puke[isExist10]);
                            pukeCombile.push(item);
                        }
                    }
                    break;
                }
            case gameConstDef.CARDS_TYPE.SHUNZI_12:
                {
                    if (puke.length < 12) break;
                    for (var i = 0; i < puke.length - 11; i++) {
                        var firstVal = this.GetCardCommonVal(puke[i]);
                        if (firstVal >= 13) continue;
                        var isExist1 = 0;var isExist2 = 0;var isExist3 = 0;
                        var isExist4 = 0;var isExist5 = 0;var isExist6 = 0;
                        var isExist7 = 0;var isExist8 = 0;var isExist9 = 0;
                        var isExist10 = 0;var isExist11 = 0;
                        var j = 0;
                        while (j < puke.length) {
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 1) {
                                isExist1 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 2) {
                                isExist2 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 3) {
                                isExist3 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 4) {
                                isExist4 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 5) {
                                isExist5 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 6) {
                                isExist6 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 7) {
                                isExist7 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 8) {
                                isExist8 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 9) {
                                isExist9 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 10) {
                                isExist10 = j;j++;continue;
                            }
                            if (firstVal == this.GetCardCommonVal(puke[j]) + 11) {
                                isExist11 = j;j++;continue;
                            }
                            j++;
                        }
                        if (isExist1 > 0 && isExist2 > 0 && isExist3 > 0 && isExist4 > 0 && isExist5 > 0 && isExist6 > 0 && isExist7 > 0 && isExist8 > 0 && isExist9 > 0 && isExist10 > 0 && isExist11 > 0) {
                            var item = [];
                            item.push(puke[i]);
                            item.push(puke[isExist1]);
                            item.push(puke[isExist2]);
                            item.push(puke[isExist3]);
                            item.push(puke[isExist4]);
                            item.push(puke[isExist5]);
                            item.push(puke[isExist6]);
                            item.push(puke[isExist7]);
                            item.push(puke[isExist8]);
                            item.push(puke[isExist9]);
                            item.push(puke[isExist10]);
                            item.push(puke[isExist11]);
                            pukeCombile.push(item);
                        }
                    }
                    break;
                }
            case gameConstDef.CARDS_TYPE.SHIP_S:
                {
                    if (puke.length < 6) break;
                    for (var i = 0; i < puke.length; i++) {
                        if (this.GetCardVal(puke[i]) !== this.GetCardVal(puke[i + 1]) || this.GetCardVal(puke[i + 1]) !== this.GetCardVal(puke[i + 2]) || this.GetCardVal(puke[i + 2]) !== this.GetCardVal(puke[i + 3])) continue;
                        for (var j = 0; j < puke.length; j++) {
                            if (this.GetCardVal(puke[i]) == this.GetCardVal(puke[j])) continue;
                            for (var _k8 = 0; _k8 < puke.length; _k8++) {
                                if (this.GetCardVal(puke[i]) == this.GetCardVal(puke[_k8]) || this.GetCardVal(puke[j]) == this.GetCardVal(puke[_k8])) continue;
                                var item = [];
                                item = puke.slice(i, i + 4);
                                item.push(puke[j]);
                                item.push(puke[_k8]);
                                pukeCombile.push(item);
                            }
                        }
                    }
                    break;
                }
            case gameConstDef.CARDS_TYPE.SHIP_S:
                {
                    if (puke.length < 8) break;
                    var allXX = this.GetCardsTypeXX(puke);
                    if (allXX.length < 2) break;

                    for (var i = 0; i < puke.length; i++) {
                        if (this.GetCardVal(puke[i]) !== this.GetCardVal(puke[i + 1]) || this.GetCardVal(puke[i + 1]) !== this.GetCardVal(puke[i + 2]) || this.GetCardVal(puke[i + 2]) !== this.GetCardVal(puke[i + 3])) continue;
                        for (var j = 0; j < allXX.length; j++) {
                            if (this.GetCardVal(allXX[j][0]) == this.GetCardVal(puke[i])) continue;
                            for (var _k9 = 0; _k9 < allXX.length; _k9++) {
                                if (this.GetCardVal(allXX[_k9][0]) == this.GetCardVal(puke[i]) || this.GetCardVal(allXX[_k9][0]) == this.GetCardVal(allXX[j][0])) continue;
                                var item = [];
                                item = puke.slice(i, i + 4);
                                item.push(allXX[j][0]);
                                item.push(allXX[j][1]);
                                item.push(allXX[_k9][0]);
                                item.push(allXX[_k9][1]);
                                pukeCombile.push(item);
                            }
                        }
                    }
                    break;
                }
            case gameConstDef.CARDS_TYPE.BOMB:
                {
                    if (puke.length < 4) break;
                    for (var i = 0; i < puke.length; i++) {
                        if (this.GetCardVal(puke[i]) == this.GetCardVal(puke[i + 1]) && this.GetCardVal(puke[i + 1]) == this.GetCardVal(puke[i + 2]) && this.GetCardVal(puke[i + 2]) == this.GetCardVal(puke[i + 3])) {
                            var item = [];
                            item = puke.slice(i, i + 4);
                            pukeCombile.push(item);
                        }
                    }
                    break;
                }
            case gameConstDef.CARDS_TYPE.ROCKET:
                {
                    if (puke.length < 2) break;
                    if (puke[0] == 0x5F && puke[1] == 0x5E) {
                        var item = [];
                        item.push(puke[0]);
                        item.push(puke[1]);
                        pukeCombile.push(item);
                    }
                    break;
                }
        }
        return pukeCombile;
    }
});

cc._RFpop();
},{"ConstDef":"ConstDef","GlobalManager":"GlobalManager","ProtocolMessage":"ProtocolMessage","YingsanzhangConstDef":"YingsanzhangConstDef"}],"YingsanzhangGameMessage":[function(require,module,exports){
"use strict";
cc._RFpush(module, '96789cp9oVKd6/yY2TlOceH', 'YingsanzhangGameMessage');
// resources/Games/Yingsanzhang/src/YingsanzhangGameMessage.js

var constDef = require("ConstDef");
var ProtocolMessage = require("ProtocolMessage");
var gameConstDef = require("YingsanzhangConstDef");

var GameMessage = {
    // ==========================================================================================================
    handler_GET_GAME_INFO_SUCCESS: function handler_GET_GAME_INFO_SUCCESS(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
        var gameData = instanceGlobal.GetGameData(instanceGlobal.selfData.nCurGameID);

        var index = 5;
        gameData.nFdiamondH = bodyMsg[index++]._int_value;
        gameData.nFdiamondL = bodyMsg[index++]._int_value;
        gameData.nFcoinH = bodyMsg[index++]._int_value;
        gameData.nFcoinL = bodyMsg[index++]._int_value;

        if (gameData.nFbeginner_flag > 0) {
            var curComp = instanceGlobal.load.getComponent("LoadManager");
            curComp.OpenGame(instanceGlobal.selfData.nCurGameID);
        } else {
            var curComp = instanceGlobal.load.getComponent("LoadManager");
            curComp.Show('zhajinhua_guide');
        }
    },

    // ===========================================================================================================
    handler_GET_GAME_INFO_FAILED: function handler_GET_GAME_INFO_FAILED(event) {
        cc.log("handler_GET_GAME_INFO_FAILED");

        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
    },
    // ==========================================================================================================
    handler_GET_PLAYERS_BASE_INFO_SUCCESS: function handler_GET_PLAYERS_BASE_INFO_SUCCESS(event) {
        cc.log("handler_GET_PLAYERS_BASE_INFO_SUCCESS");
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
        var gameData = instanceGlobal.GetGameData(instanceGlobal.selfData.nCurGameID);

        var index = 0;
        var item = {};
        var nAccountID = bodyMsg[index++]._int_value;
        var teamsList = gameData.vectTeamList;
        var teamsCount = teamsList.length;
        for (var i = 0; i < teamsCount; i++) {
            if (nAccountID === teamsList[i].nAccountID) {
                teamsList[i].nick = bodyMsg[index++]._str_value;
                teamsList[i].nSex = bodyMsg[index++]._int_value;
                teamsList[i].nFhead = bodyMsg[index++]._int_value;
                teamsList[i].sFcustom_head = bodyMsg[index++]._int_value;
                var nValH = bodyMsg[index++]._int_value;
                var nValL = bodyMsg[index++]._int_value;
                var nval = bodyMsg[index++]._int_value;
                teamsList[i].nTotalMoney = bodyMsg[index++]._int_value;
                teamsList[i].nCoinH = bodyMsg[index++]._int_value;
                teamsList[i].nCoinL = bodyMsg[index++]._int_value;
                break;
            }
        }
        gameData.RefreshPlayerData();
    },

    // ==========================================================================================================
    handler_GET_PLAYERS_BASE_INFO_FAILED: function handler_GET_PLAYERS_BASE_INFO_FAILED(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
    },
    // ==========================================================================================================
    handler_GET_TEAM_MEMBERS_SUCCESS: function handler_GET_TEAM_MEMBERS_SUCCESS(event) {
        cc.log("handler_GET_TEAM_MEMBERS_SUCCESS");
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
        var gameData = instanceGlobal.GetGameData(instanceGlobal.selfData.nCurGameID);

        for (var i = 0; i < bodyMsg.length; i++) {
            var vectList = bodyMsg[i]._vect_value;
            var index = 0;
            var nTeamID = vectList[index++]._int_value;
            var nAccountID = vectList[index++]._int_value;
            var teamList = gameData.vectTeamList;
            for (var j = 0; j < teamList.length; j++) {
                if (nTeamID == teamList[j].nTeamID) {
                    teamList[j].nAccountID = nAccountID;
                    break;
                }
            }
        }
        instanceGlobal.GetGameController(instanceGlobal.selfData.nCurGameID).SendMsg(constDef.CONNECT_CALLBACK_STATUS.LOGON_GET_PLAYERS_BASE_INFO);
    },
    // ========================================================================================================
    handler_GET_TEAM_MEMBERS_FAILED: function handler_GET_TEAM_MEMBERS_FAILED(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
    },
    // ===========================================================================================================
    handler_GET_MATCH_DATA_NOTIFY: function handler_GET_MATCH_DATA_NOTIFY(event) {
        cc.log("handler_GET_MATCH_DATA_NOTIFY");
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
        var gameData = instanceGlobal.GetGameData(instanceGlobal.selfData.nCurGameID);

        var index = 0;
        if (bodyMsg.length > 1) // 未报名只传一个字段   nMatchSignTS=0
            {
                var nMatchSignTS = bodyMsg[index++]._int_value;
                var nMatchFlag = bodyMsg[index++]._int_value;
                var nTeamID = bodyMsg[index++]._int_value;
                var nMatchStatus = bodyMsg[index++]._int_value;
                var nMatchStatusTS = bodyMsg[index++]._int_value;
                var nMatchRemainCount = bodyMsg[index++]._int_value;
                var nMatchRank = bodyMsg[index++]._int_value;

                if (nMatchFlag == constDef.MATCH_RESULT.NONE || nTeamID == gameData.nTeamID) {
                    gameData.nMatchTS = nMatchSignTS;
                    gameData.nMatchFlag = nMatchFlag;
                    gameData.nTeamID = nTeamID;
                    gameData.nMatchStatus = nMatchStatus;
                    gameData.nMatchStatusTS = nMatchStatusTS;
                    gameData.nMatchRemainCount = nMatchRemainCount;
                    gameData.nMatchRank = nMatchRank;
                }

                if (nMatchFlag >= constDef.MATCH_RESULT.OutAtOnce_OUT && nMatchFlag <= constDef.MATCH_RESULT.FixedRound_WIN) {
                    gameData.RefreshData();
                }
            }
    },
    // ===========================================================================================================
    handler_GET_MATCH_CUR_COUNT_SUCCESS: function handler_GET_MATCH_CUR_COUNT_SUCCESS(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
        var gameData = instanceGlobal.GetGameData(instanceGlobal.selfData.nCurGameID);

        var index = 0;
        var nMatchTS = bodyMsg[index++]._int_value;
        var nMatchCurSignCount = bodyMsg[index++]._int_value;
        gameData.nMatchCurSignCount = nMatchCurSignCount;
        gameData.RefreshGameWait();
    },
    // ===========================================================================================================
    handler_BALANCE_NOTIFY: function handler_BALANCE_NOTIFY(event) {
        cc.log("handler_BALANCE_NOTIFY");
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
        var gameData = instanceGlobal.GetGameData(instanceGlobal.selfData.nCurGameID);

        if (bodyMsg.length > 1) {
            var index = 0;
            var nAccountID = bodyMsg[index++]._int_value;
            var nType = bodyMsg[index++]._int_value;
            if (nType == constDef.FIGHT_RESULT.MATCH_REVOKE) // 比赛解散
                {
                    gameData.nMatchTS = 0;
                    gameData.RefreshGameWait();
                }
        }
    },
    // ===========================================================================================================
    handler_ENTER_ROOM_SUCCESS: function handler_ENTER_ROOM_SUCCESS(event) {
        cc.log("handler_ENTER_ROOM_SUCCESS");
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
        var gameData = instanceGlobal.GetGameData(instanceGlobal.selfData.nCurGameID);

        if (instanceGlobal.confData.bHoldPlayersInfo === true) {
            var msg = new ProtocolMessage(constDef.MESSAGE.CMD_MAIN_PLATFORM, constDef.MESSAGE.GET_ROOM_PLAYERS_REQ, false);
            instanceGlobal.SocketManager.SendMessage(constDef.SERVER_URL.game, msg);
        }

        gameData.ClearBattleData();

        if (bodyMsg.length > 0) {
            gameData.InitBattleData(bodyMsg);
            var curComp = instanceGlobal.load.getComponent("LoadManager");
            curComp.Show('Yingsanzhang_war');
        } else {
            if (gameData.nOpenMode == constDef.BATTLE_OPEN_MODE.MATCH) {
                var curComp = instanceGlobal.load.getComponent("LoadManager");
                curComp.Show('Yingsanzhang_gameWait');
            } else {
                var msg2 = new ProtocolMessage(constDef.MESSAGE.CMD_MAIN_GAME, constDef.MESSAGE.ENTER_BATTLE_REQ, false);
                ProtocolMessage.AddVectItemInt(msg2._body_msg, 0); // 快速加入，桌子ID为0
                instanceGlobal.SocketManager.SendMessage(constDef.SERVER_URL.game, msg2);
            }
        }
    },
    // ===========================================================================================================
    handler_ENTER_ROOM_FAILED: function handler_ENTER_ROOM_FAILED(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;

        var hintComp = instanceGlobal.hint.getComponent("HintManager");
        hintComp.ShowHint("进入服务器失败！");
    },
    // ==========================================================================================================
    handler_PLAYER_ENTER_ROOM_NOTIFY: function handler_PLAYER_ENTER_ROOM_NOTIFY(event) {
        cc.log("handler_PLAYER_ENTER_ROOM_NOTIFY");
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
        var gameData = instanceGlobal.GetGameData(instanceGlobal.selfData.nCurGameID);

        var index = 0;
        var nAccountID = bodyMsg[index++]._int_value;
        var nTeamID = bodyMsg[index++]._int_value;

        var item = {};
        var players = instanceGlobal.selfData.players;
        var playersCount = players.length;

        if (instanceGlobal.confData.bHoldPlayersInfo === true) {
            var isExsit = false;
            item.nAccountID = bodyMsg[index]._int_value;
            for (var i = 0; i < playersCount; i++) {
                if (item.nAccountID === players[i].nAccountID) {
                    isExsit = true;
                }
            }
            if (!isExsit) {
                players.push(item);
            }
        }

        // =====
        for (var t = 0; t < gameData.vectTeamList.length; t++) {
            var itemFighter = gameData.vectTeamList[t];
            if (itemFighter.nTeamID == nTeamID) {
                itemFighter.isOffline = 0;
                gameData.RefreshPlayerData(1);
                break;
            }
        }
    },
    // ==========================================================================================================
    handler_PLAYER_LEAVE_ROOM_NOTIFY: function handler_PLAYER_LEAVE_ROOM_NOTIFY(event) {
        cc.log("handler_PLAYER_LEAVE_ROOM_NOTIFY");
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
        var gameData = instanceGlobal.GetGameData(instanceGlobal.selfData.nCurGameID);

        var index = 0;
        var nAccountID = bodyMsg[index++]._int_value;
        var nIsOffline = bodyMsg[index++]._int_value; // 1-断线，但仍在战斗中
        var players = instanceGlobal.selfData.players;
        var playersCount = players.length;

        if (instanceGlobal.confData.bHoldPlayersInfo === true) {
            for (var i = 0; i < playersCount; i++) {
                if (nAccountID === players[i].nAccountID) {
                    if (nIsOffline == 1) {} // 设置断线标志 。。。
                    else players.splice(i, 1);
                    break;
                }
            }
        }

        var t = 0;
        for (t = 0; t < gameData.vectTeamList.length; t++) {
            if (gameData.vectTeamList[t].nAccountID == nAccountID) {
                gameData.vectTeamList[t].isOffline = nIsOffline;
                break;
            }
        }
        // ----当有人离开或断线 ，不在战斗中所有人都离开房间
        if (nIsOffline == 1) {
            if (gameData.nBattleStatus == gameConstDef.FIGHT_STATUS.INIT) {
                gameData.nLeaveRoomFlag = 1;
                instanceGlobal.GetGameController(instanceGlobal.selfData.nCurGameID).SendMsg(gameConstDef.CONNECT_CALLBACK_STATUS.HOME_LEAVE_TEAM);
            } else {
                if (gameData.nBattleStatus == gameConstDef.FIGHT_STATUS.END) gameData.nLeaveRoomFlag = 1;
                gameData.RefreshPlayerData(1);
            }
        }
    },
    // ===========================================================================================================
    handler_TEAM_ALL_READY_SUCCESS: function handler_TEAM_ALL_READY_SUCCESS(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
        var gameData = instanceGlobal.GetGameData(instanceGlobal.selfData.nCurGameID);

        var index = 0;
        var nTeamID = bodyMsg[index++]._int_value;
        var nMatchTS = bodyMsg[index++]._int_value;

        gameData.nTeamID = nTeamID;
        gameData.nMatchTS = nMatchTS;

        if (nMatchTS > 0) {
            gameData.nMatchCurSignCount += 1;
        } else {
            gameData.nMatchCurSignCount -= 1;
        }
        gameData.RefreshGameWait();
    },
    // ===========================================================================================================
    handler_TEAM_ALL_READY_NOTIFY: function handler_TEAM_ALL_READY_NOTIFY(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
    },
    // ===========================================================================================================
    handler_TEAM_ALL_READY_FAILED: function handler_TEAM_ALL_READY_FAILED(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
    },
    // ===========================================================================================================
    handler_LEAVE_TEAM_NOTIFY: function handler_LEAVE_TEAM_NOTIFY(event) {
        cc.log("handler_LEAVE_TEAM_NOTIFY");
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
        var gameData = instanceGlobal.GetGameData(instanceGlobal.selfData.nCurGameID);

        var index = 0;
        var nAccountID = bodyMsg[index++]._int_value;

        if (nAccountID == instanceGlobal.selfData.nAccountID) {
            if (gameData.nLeaveRoomFlag == 1 && gameData.nBattleStatus == gameConstDef.FIGHT_STATUS.INIT) {
                gameData.nLeaveRoomFlag = 0;
                instanceGlobal.GetGameController(instanceGlobal.selfData.nCurGameID).SendMsg(gameConstDef.CONNECT_CALLBACK_STATUS.HOME_ENTER_ROOM);
            }
        }
    },

    // ===========================================================================================================
    handler_ENTER_BATTLE_NOTIFY: function handler_ENTER_BATTLE_NOTIFY(event) {
        cc.log("handler_ENTER_BATTLE_NOTIFY");
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
        var gameData = instanceGlobal.GetGameData(instanceGlobal.selfData.nCurGameID);

        var index = 0;
        var nBattleID = bodyMsg[index++]._int_value;
        if (gameData.nOpenMode == constDef.BATTLE_OPEN_MODE.MATCH) {
            var nMatchStatus = bodyMsg[index++]._int_value;
        }
        var vectList = bodyMsg[index++]._vect_value;

        if (gameData.nOpenMode == constDef.BATTLE_OPEN_MODE.MATCH) {
            var itemCount = 4;
            var count = vectList.length / itemCount;
            var teamIds = [];
            for (var i = 0; i < count; i++) {
                var nTeamID = vectList[i * itemCount + 0]._int_value;
                var nSit = vectList[i * itemCount + 1]._int_value;
                var nAccountID = vectList[i * itemCount + 2]._int_value;
                var nScore = vectList[i * itemCount + 3]._int_value;
                if (nAccountID == instanceGlobal.selfData.nAccountID) {
                    gameData.ClearBattleData();
                    gameData.nBattleID = nBattleID;
                    gameData.nMatchStatus = nMatchStatus;
                    gameData.nTeamID = nTeamID;
                    break;
                }
            }
            if (gameData.nBattleID == nBattleID) {

                for (var j = 0; j < count; j++) {
                    var nTeamID = vectList[j * itemCount + 0]._int_value;
                    var nSit = vectList[j * itemCount + 1]._int_value;
                    var nScore = vectList[j * itemCount + 3]._int_value;
                    var teamItem = gameData.vectTeamList[nSit - 1];
                    teamItem.nTeamID = nTeamID;
                    teamItem.nScore = nScore;
                    teamIds.push(nTeamID);
                }
                gameData.initCurGameRemainCount();
                //获取队伍成员
                var msg = new ProtocolMessage(constDef.MESSAGE.CMD_MAIN_GAME, constDef.MESSAGE.GET_TEAM_MEMBERS_REQ, false);
                var vectIndex = 0;
                ProtocolMessage.AddVectItemVect(msg._body_msg);
                for (var t = 0; t < teamIds.length; t++) {
                    ProtocolMessage.AddVectItemInt(msg._body_msg[vectIndex]._vect_value, teamIds[t]);
                }
                instanceGlobal.SocketManager.SendMessage(constDef.SERVER_URL.game, msg);

                var curComp = instanceGlobal.load.getComponent("LoadManager");
                curComp.Show('Yingsanzhang_war');
            }
        } else {
            var itemCount = 2;
            var count = vectList.length / itemCount;
            if (nBattleID == gameData.nBattleID) {
                for (var i = 0; i < count; i++) {
                    var nTeamID = vectList[i * itemCount + 0]._int_value;
                    var nSit = vectList[i * itemCount + 1]._int_value;
                    if (nTeamID !== gameData.nTeamID) {
                        var teamItem = gameData.vectTeamList[nSit - 1];
                        teamItem.nTeamID = nTeamID;
                        var msg = new ProtocolMessage(constDef.MESSAGE.CMD_MAIN_GAME, constDef.MESSAGE.GET_TEAM_MEMBERS_REQ, false);
                        var vectIndex = 0;
                        ProtocolMessage.AddVectItemVect(msg._body_msg);
                        ProtocolMessage.AddVectItemInt(msg._body_msg[vectIndex]._vect_value, nTeamID);
                        instanceGlobal.SocketManager.SendMessage(constDef.SERVER_URL.game, msg);
                    }
                }
            }
        }
    },
    handler_ENTER_BATTLE_SUCCESS: function handler_ENTER_BATTLE_SUCCESS(event) {
        cc.log("handler_ENTER_BATTLE_SUCCESS");
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
        var gameData = instanceGlobal.GetGameData(instanceGlobal.selfData.nCurGameID);
        gameData.ClearBattleData();

        if (bodyMsg.length > 0) {
            gameData.InitBattleData(bodyMsg);
        }

        var curComp = instanceGlobal.load.getComponent("LoadManager");
        curComp.Show('Yingsanzhang_war');
    },
    handler_ENTER_BATTLE_FAILED: function handler_ENTER_BATTLE_FAILED(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
    },
    // ===========================================================================================================

    handler_FIGHT_READY_SUCCESS: function handler_FIGHT_READY_SUCCESS(event) {
        cc.log("handler_FIGHT_READY_SUCCESS");
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
    },
    // ===========================================================================================================
    handler_FIGHT_READY_FAILED: function handler_FIGHT_READY_FAILED(event) {
        cc.log("handler_FIGHT_READY_FAILED");
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
    },
    handler_FIGHT_READY_NOTIFY: function handler_FIGHT_READY_NOTIFY(event) {
        cc.log("handler_FIGHT_READY_NOTIFY");
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
        var gameData = instanceGlobal.GetGameData(instanceGlobal.selfData.nCurGameID);

        var index = 0;
        var nAccountID = bodyMsg[index++]._int_value;
        var teamList = gameData.vectTeamList;
        for (var j = 0; j < teamList.length; j++) {
            if (nAccountID == teamList[j].nAccountID) {
                teamList[j].isOnReady = 1;
                break;
            }
        }

        if (nAccountID == instanceGlobal.selfData.nAccountID) {
            var msg = new ProtocolMessage(constDef.MESSAGE.CMD_MAIN_GAME, constDef.MESSAGE.SCENE_READY_REQ, false);
            ProtocolMessage.AddVectItemByte(msg._body_msg, 100);
            instanceGlobal.SocketManager.SendMessage(constDef.SERVER_URL.game, msg);
        }

        gameData.RefreshPlayerData(2);
    },
    // ===========================================================================================================
    handler_SCENE_READY_NOTIFY: function handler_SCENE_READY_NOTIFY(event) {
        cc.log("handler_SCENE_READY_NOTIFY");

        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
        var gameData = instanceGlobal.GetGameData(instanceGlobal.selfData.nCurGameID);

        var index = 0;
        var nAccountID = bodyMsg[index++]._int_value;
        if (nAccountID == instanceGlobal.selfData.nAccountID) {
            gameData.RefreshData();
        }
    },
    // ==========================================================================================================
    handler_SCENE_READY_SUCCESS: function handler_SCENE_READY_SUCCESS(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
    },
    // ==========================================================================================================
    handler_SCENE_READY_FAILED: function handler_SCENE_READY_FAILED(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
    },
    // ===========================================================================================================
    handler_FIGHT_BEGIN_NOTIFY: function handler_FIGHT_BEGIN_NOTIFY(event) {
        cc.log("handler_FIGHT_BEGIN_NOTIFY");
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
        var gameData = instanceGlobal.GetGameData(instanceGlobal.selfData.nCurGameID);

        var index = 0;
        gameData.nCurSit = bodyMsg[index++]._int_value;;
        var vectList = bodyMsg[index++]._vect_value;
        var itemCount = 5;
        var count = vectList.length / itemCount;
        var index1 = 0;
        for (var i = 0; i < count; i++) {
            var item = gameData.vectTeamList[i];
            item.nTeamID = vectList[i * itemCount + index1++]._int_value;
            item.nSit = vectList[i * itemCount + index1++]._int_value;
            item.puke[0] = vectList[i * itemCount + index1++]._int_value;
            item.puke[1] = vectList[i * itemCount + index1++]._int_value;
            item.puke[2] = vectList[i * itemCount + index1++]._int_value;
        }

        gameData.nBattleStatus = gameConstDef.FIGHT_STATUS.BEGIN;

        gameData.nClientStatus = gameConstDef.FIGHT_STATUS.C_BEGIN;

        gameData.RefreshData();
    },
    // ===========================================================================================================
    handler_FIGHT_END_NOTIFY: function handler_FIGHT_END_NOTIFY(event) {
        cc.log("handler_FIGHT_END_NOTIFY");
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
        var gameData = instanceGlobal.GetGameData(instanceGlobal.selfData.nCurGameID);

        var index = 0;
        var vectList = bodyMsg[index++]._vect_value;
        var itemCount = 3;
        var count = vectList.length / itemCount;
        var index1 = 0;
        for (var _i = 0; _i < count; _i++) {
            var nTeamID = vectList[index1++]._int_value;
            var nResult = vectList[index1++]._int_value;
            var nMoney = vectList[index1++]._int_value;
            for (var t = 0; t < gameData.vectTeamList.length; t++) {
                if (gameData.vectTeamList[t].nTeamID == nTeamID) {
                    gameData.vectTeamList[t].nResult = nResult;
                    gameData.vectTeamList[t].nMoney = nMoney; // 基数
                    break;
                }
            }
        }
        var arr = null;
        for (var i = 0; i < gameData.puke.length; i++) {
            arr = gameData.puke[i].splice(1, gameData.puke[i].length - 1);
            var temp_arr = gameData.OrderPuke(arr);

            for (var n = 0; n < temp_arr.length; n++) {
                gameData.puke[i].push(temp_arr[n]);
            }
        }
        gameData.nBattleStatus = gameConstDef.FIGHT_STATUS.END;
        gameData.nClientStatus = gameConstDef.FIGHT_STATUS.C_END_SHOW_LEFT_CARDS;
        gameData.RefreshData();
    },

    // =========================================================================================================
    handler_BET_SUCCESS: function handler_BET_SUCCESS(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
    },
    // =========================================================================================================
    handler_BET_FAILED: function handler_BET_FAILED(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
    },
    // =========================================================================================================
    handler_BET_NOTIFY: function handler_BET_NOTIFY(event) {
        /*
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal; 
        var gameData = instanceGlobal.GetGameData(instanceGlobal.selfData.nCurGameID);
         var index = 0;
        var nTeamID = bodyMsg[index++]._int_value;
        var nCurGrabBankerVal = bodyMsg[index]._int_value;
                gameData.nCurStatusTS = instanceGlobal.GetRightTime();       //
         var nCurGrabBankerSeq = 0;
        var teamList = gameData.vectTeamList;
        for(let i=0;i<teamList.length;i++)
        {
            if(teamList[i].nTeamID == nTeamID)
            {
                gameData.nClientStatus = gameConstDef.FIGHT_STATUS.C_BEGIN_GRAB_BANKER + i;
                nCurGrabBankerSeq = i + 1;
                break;
            }
        }
             if(nCurGrabBankerVal > gameData.nCurBankerVal)
        {
            gameData.nCurBankerSeq = nCurGrabBankerSeq;              
            gameData.nCurBankerVal = nCurGrabBankerVal;  
        }
         
        if( nCurGrabBankerSeq == 3 || gameData.nCurBankerVal == 3)
        {
            if(nCurGrabBankerSeq == 3 && gameData.nCurBankerVal == 0)
            {
                //没人叫分，默认第一个人
                gameData.nCurBankerSeq = 1;
                gameData.nCurBankerVal = 1;
            }
            gameData.puke[gameData.nCurBankerSeq-1][0] = 20;
            for(let j=0;j<3;j++)
            {
                gameData.puke[gameData.nCurBankerSeq-1].push( gameData.arrLandCards[j]);    
            }
             gameData.nClientStatus = gameConstDef.FIGHT_STATUS.C_BANKER_FINISH;
            gameData.RefreshData();
                if(gameData.nClientStatus==gameConstDef.FIGHT_STATUS.C_BANKER_FINISH)
            {
                gameData.nCurTurnSeq = gameData.nCurBankerSeq;
                gameData.nBattleStatus=gameConstDef.FIGHT_STATUS.FIGHTING;
                gameData.nClientStatus=gameConstDef.FIGHT_STATUS.C_FIGHTING;
                gameData.RefreshData();
            }
        }
        else 
        {
            gameData.RefreshData();
        }*/
    },
    // =========================================================================================================
    handler_FOLLOW_BET_NOTIFY: function handler_FOLLOW_BET_NOTIFY(event) {

        /*
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal; 
        var gameData = instanceGlobal.GetGameData(instanceGlobal.selfData.nCurGameID);
         var index = 0;
        var totalCount = bodyMsg.length;
        var nTeamID = bodyMsg[index]._int_value;
         var teamList = gameData.vectTeamList;
        var nCurOutPukeSeq = 0;
        gameData.nCurStatusTS = instanceGlobal.GetRightTime();
        for(let i=0;i<teamList.length;i++)
        {
            if(teamList[i].nTeamID == nTeamID)
            {
                nCurOutPukeSeq = i + 1;
                break;
            }
        }
        
        // 是否出牌
        if(totalCount > 2)    // 消息至少含有nTeamID 、battleId
        {
            gameData.arrCurOutPuke.length = 0;
            gameData.arrCurOutPuke.push(totalCount-2);
            for(let i=1;i<totalCount-1;i++)
            {
                var cardValue = bodyMsg[i]._int_value;
                gameData.arrCurOutPuke.push(cardValue);    
            }
            gameData.nCurOutPukeSeq = nCurOutPukeSeq;
              gameData.puke[nCurOutPukeSeq-1][0] -= gameData.arrCurOutPuke[0];
            for(let m=1;m<gameData.arrCurOutPuke.length;m++)
            {
                for(let z=gameData.puke[nCurOutPukeSeq-1].length-1;z>0;z--)
                {
                    if(gameData.puke[nCurOutPukeSeq-1][z] == gameData.arrCurOutPuke[m])
                    { 
                        gameData.puke[nCurOutPukeSeq-1].splice(z,1);
                        break;
                    }
                }     
            }
         }
        
        gameData.nCurTurnSeq = (nCurOutPukeSeq>=3)?1:(nCurOutPukeSeq+1);
         gameData.RefreshData();*/
    },
    // =========================================================================================================
    handler_FOLLOW_BET_SUCCESS: function handler_FOLLOW_BET_SUCCESS(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
    },
    // =========================================================================================================
    handler_FOLLOW_BET_FAILED: function handler_FOLLOW_BET_FAILED(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
    },
    // ============================================================================================================
    handler_ADD_BET_SUCCESS: function handler_ADD_BET_SUCCESS(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
    },
    // ============================================================================================================
    handler_ADD_BET_FAILED: function handler_ADD_BET_FAILED(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
    },
    // ============================================================================================================
    handler_ADD_BET_NOTIFY: function handler_ADD_BET_NOTIFY(event) {
        // var bodyMsg = event.detail.msgBody;
        // var instanceGlobal = event.detail.instanceGlobal;
        // var gameData = instanceGlobal.GetGameData(instanceGlobal.selfData.nCurGameID);

        // var index = 0;
        // var nTeamID = bodyMsg[index++]._int_value;
        // var nFlag   = bodyMsg[index++]._int_value;

        // var teamList = gameData.vectTeamList;
        // for(let i=0;i<teamList.length;i++)
        // {
        //     if(teamList[i].nTeamID == nTeamID)
        //     {
        //         teamList[i].isDeposit = nFlag;
        //         break;
        //     }
        // }
        // gameData.RefreshPlayerData(2);
    },
    // ============================================================================================================
    handler_LOOK_CARD_SUCCESS: function handler_LOOK_CARD_SUCCESS(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
    },
    // ============================================================================================================
    handler_LOOK_CARD_FAILED: function handler_LOOK_CARD_FAILED(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
    },
    // ============================================================================================================
    handler_LOOK_CARD_NOTIFY: function handler_LOOK_CARD_NOTIFY(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
    },
    // ============================================================================================================
    handler_DISCARD_SUCCESS: function handler_DISCARD_SUCCESS(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
    },
    // ============================================================================================================
    handler_DISCARD_FAILED: function handler_DISCARD_FAILED(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
    },
    // ============================================================================================================
    handler_DISCARD_NOTIFY: function handler_DISCARD_NOTIFY(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
    },
    // ============================================================================================================
    handler_COMPARE_CARD_SUCCESS: function handler_COMPARE_CARD_SUCCESS(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
    },
    // ============================================================================================================
    handler_COMPARE_CARD_FAILED: function handler_COMPARE_CARD_FAILED(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
    },
    // ============================================================================================================
    handler_COMPARE_CARD_NOTIFY: function handler_COMPARE_CARD_NOTIFY(event) {
        var bodyMsg = event.detail.msgBody;
        var instanceGlobal = event.detail.instanceGlobal;
    }

};
// ============================================================================================================
module.exports = GameMessage;

cc._RFpop();
},{"ConstDef":"ConstDef","ProtocolMessage":"ProtocolMessage","YingsanzhangConstDef":"YingsanzhangConstDef"}],"Yingsanzhang_AnimUI":[function(require,module,exports){
"use strict";
cc._RFpush(module, '01b4dZnQJhByI248G4STmWF', 'Yingsanzhang_AnimUI');
// resources/Games/Yingsanzhang/scene/sceneWar/Yingsanzhang_AnimUI.js

cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {}

});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();
},{}],"Yingsanzhang_Bet":[function(require,module,exports){
"use strict";
cc._RFpush(module, '1ce06OerxRMH75ztMV6TVRQ', 'Yingsanzhang_Bet');
// resources/Games/Yingsanzhang/res/prefab/Bet/Yingsanzhang_Bet.js

cc.Class({
    "extends": cc.Component,

    properties: {},
    onLoad: function onLoad() {},
    setValueAndType: function setValueAndType(type, val) {
        cc.log("setValueAndType: function(type,val)");
        var img_url;
        switch (type) {
            case 1:
                img_url = "Games/Yingsanzhang/res/prefab/Bet/image/bet_red";
                break;
            case 2:
                img_url = "Games/Yingsanzhang/res/prefab/Bet/image/bet_green";
                break;
            case 3:
                img_url = "Games/Yingsanzhang/res/prefab/Bet/image/bet_org";
                break;
        }
        var sprite = this.node.getComponent(cc.Sprite);
        cc.loader.loadRes(img_url, cc.SpriteFrame, function (error, spriteFrame) {
            if (!error) {
                sprite.spriteFrame = spriteFrame;
            }
        });

        var label = this.node.getChildByName("label").getComponent(cc.Label);

        label.string = val.toString();
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RFpop();
},{}],"Yingsanzhang_Card":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'e3dd8BxKr1CoYN7Bk/zbMph', 'Yingsanzhang_Card');
// resources/Games/Yingsanzhang/res/prefab/Card/Yingsanzhang_Card.js

var CardController = cc.Class({
    "extends": cc.Component,

    properties: {
        //正面白底或者背面图案
        face_Img: {
            "default": null,
            type: cc.Sprite
        },
        //A-10,J-K,大小王
        cardID_Img: {
            "default": null,
            type: cc.Sprite
        },
        //小型牌种类图案
        small_type_Img: {
            "default": null,
            type: cc.Sprite
        },
        //大型牌种类图案
        big_type_Img: {
            "default": null,
            type: cc.Sprite
        },
        cardValue: 0
    },

    // use this for initialization
    onLoad: function onLoad() {},
    SetDisCard: function SetDisCard() {

        var face_url = "Games/Yingsanzhang/res/prefab/Card/image/" + "backGray";
        cc.log("SetDisCard", face_url);
        var face_image = this.face_Img;
        cc.loader.loadRes(face_url, cc.SpriteFrame, function (error, spriteFrame) {
            if (!error) {
                face_image.spriteFrame = spriteFrame;
            }
        });
    },
    SetCardInfo: function SetCardInfo(val) {
        this.cardValue = val;
        var face_image = this.face_Img;
        var cardID_image = this.cardID_Img;
        var small_type_image = this.small_type_Img;
        var big_type_image = this.big_type_Img;

        if (val === 0 || val >= 0x50) {
            cardID_image.node.opacity = 0;
            small_type_image.node.opacity = 0;
            big_type_image.node.opacity = 0;

            var face_url = "Games/Yingsanzhang/res/prefab/Card/image/" + "back";
            if (val == 0x5E) face_url = "Games/Yingsanzhang/res/prefab/Card/image/" + "small_joker";else if (val == 0x5F) face_url = "Games/Yingsanzhang/res/prefab/Card/image/" + "big_joker";

            cc.loader.loadRes(face_url, cc.SpriteFrame, function (error, spriteFrame) {
                if (!error) {
                    face_image.spriteFrame = spriteFrame;
                }
            });
        } else {
            var face_url = "Games/Yingsanzhang/res/prefab/Card/image/" + "face";
            cc.loader.loadRes(face_url, cc.SpriteFrame, function (error, spriteFrame) {
                if (!error) {
                    face_image.spriteFrame = spriteFrame;
                }
            });

            cardID_image.node.opacity = 255;
            small_type_image.node.opacity = 255;
            big_type_image.node.opacity = 255;

            var pukeKind = val >> 4;
            var pukeVal = val & 0xF;

            var small_Type_url = "Games/Yingsanzhang/res/prefab/Card/image/small_puke_kind_" + pukeKind.toString();
            var big_Type_url = "Games/Yingsanzhang/res/prefab/Card/image/big_puke_kind_" + pukeKind.toString();
            var cardID_name_url = "Games/Yingsanzhang/res/prefab/Card/image/black_flag/h" + pukeVal.toString();
            if (pukeKind % 2 === 1) cardID_name_url = "Games/Yingsanzhang/res/prefab/Card/image/red_flag/h" + pukeVal.toString();

            cc.loader.loadRes(cardID_name_url, cc.SpriteFrame, function (error, spriteFrame) {
                if (!error) {
                    cardID_image.spriteFrame = spriteFrame;
                }
            });

            cc.loader.loadRes(small_Type_url, cc.SpriteFrame, function (error, spriteFrame) {
                if (!error) {
                    small_type_image.spriteFrame = spriteFrame;
                }
            });

            cc.loader.loadRes(big_Type_url, cc.SpriteFrame, function (error, spriteFrame) {
                if (!error) {
                    big_type_image.spriteFrame = spriteFrame;
                }
            });
        }
    }
});

cc._RFpop();
},{}],"Yingsanzhang_EndUI":[function(require,module,exports){
"use strict";
cc._RFpush(module, '13d39HAYRFAAoOoWhsVjd9y', 'Yingsanzhang_EndUI');
// resources/Games/Yingsanzhang/scene/sceneWar/Yingsanzhang_EndUI.js

cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {}

});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();
},{}],"Yingsanzhang_HomeUI":[function(require,module,exports){
"use strict";
cc._RFpush(module, '6309fhRL19O8rbRGLanjqGn', 'Yingsanzhang_HomeUI');
// resources/Games/Yingsanzhang/scene/sceneHome/Yingsanzhang_HomeUI.js

var GlobalManager = require("GlobalManager");
var ProtocolMessage = require("ProtocolMessage");
var constDef = require("ConstDef");
var gameConstDef = require("YingsanzhangConstDef");

cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {},
    enter_room: function enter_room() {
        cc.log("enter_room");
        var gameData = GlobalManager.instance.GetGameData(GlobalManager.instance.selfData.nCurGameID);
        // var classicsItemComp = event.target.getComponent("doudizhuJD_classicsItem"); 
        // constDef.SERVER_URL.game = classicsItemComp.serverUrl;
        // gameData.nOpenMode = constDef.BATTLE_OPEN_MODE.TABLE;
        // gameData.nRoomID = classicsItemComp.roomID;
        var areaBaseInfo = GlobalManager.instance.confData.getRoomArea(GlobalManager.instance.selfData.nCurGameID, 1);

        var nodeBaseInfo = GlobalManager.instance.confData.getGameNode(areaBaseInfo.Farea_id);

        var roomBaseInfo = GlobalManager.instance.confData.getGameRoom(nodeBaseInfo[0].Fnode_id);

        var serverBaseInfo = GlobalManager.instance.confData.getServerInfo(roomBaseInfo.Fserver_id);

        gameData.nOpenMode = constDef.BATTLE_OPEN_MODE.TABLE;
        gameData.nRoomID = roomBaseInfo.Froom_id;

        constDef.SERVER_URL.game = "ws://" + serverBaseInfo.Fserver_ip + ":" + serverBaseInfo.Fserver_port + "/";

        GlobalManager.instance.GetGameController(GlobalManager.instance.selfData.nCurGameID).SendMsg(gameConstDef.CONNECT_CALLBACK_STATUS.HOME_ENTER_ROOM);
    }
});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();
},{"ConstDef":"ConstDef","GlobalManager":"GlobalManager","ProtocolMessage":"ProtocolMessage","YingsanzhangConstDef":"YingsanzhangConstDef"}],"Yingsanzhang_MyController":[function(require,module,exports){
"use strict";
cc._RFpush(module, '9d0d0LKXi9E+7w2n3jgtfbn', 'Yingsanzhang_MyController');
// resources/Games/Yingsanzhang/scene/sceneWar/Yingsanzhang_MyController.js

var GlobalManager = require("GlobalManager");
var ProtocolMessage = require("ProtocolMessage");
var constDef = require("ConstDef");
var gameConstDef = require("YingsanzhangConstDef");

cc.Class({
    "extends": cc.Component,

    properties: {

        operation_node: {
            "default": null,
            type: cc.Node
        }

    },

    onLoad: function onLoad() {
        this.refreshUI();
    },
    follow_bet_req: function follow_bet_req() {

        var score = GlobalManager.instance.GetGameData(GlobalManager.instance.selfData.nTeamID).nCurBetVal;
        var msg = new ProtocolMessage(gameConstDef.MESSAGE.CMD_MAIN_YingSanZhang, gameConstDef.MESSAGE.FOLLOW_BET_REQ, false);
        ProtocolMessage.AddVectItemByte(msg._body_msg, score);
        GlobalManager.instance.SocketManager.SendMessage(constDef.SERVER_URL.game, msg);
    },
    add_bet_req: function add_bet_req() {

        var score = GlobalManager.instance.GetGameData(GlobalManager.instance.selfData.nTeamID).nCurBetVal;
        var msg = new ProtocolMessage(gameConstDef.MESSAGE.CMD_MAIN_YingSanZhang, gameConstDef.MESSAGE.ADD_BET_REQ, false);
        ProtocolMessage.AddVectItemByte(msg._body_msg, score);
        GlobalManager.instance.SocketManager.SendMessage(constDef.SERVER_URL.game, msg);
    },
    look_card_req: function look_card_req() {

        var score = GlobalManager.instance.GetGameData(GlobalManager.instance.selfData.nTeamID).nCurBetVal;
        var msg = new ProtocolMessage(gameConstDef.MESSAGE.CMD_MAIN_YingSanZhang, gameConstDef.MESSAGE.LOOK_CARD_REQ, false);
        ProtocolMessage.AddVectItemByte(msg._body_msg, 1);
        GlobalManager.instance.SocketManager.SendMessage(constDef.SERVER_URL.game, msg);
    },
    compare_card_req: function compare_card_req() {

        var score = GlobalManager.instance.GetGameData(GlobalManager.instance.selfData.nTeamID).nCurBetVal;
        var msg = new ProtocolMessage(gameConstDef.MESSAGE.CMD_MAIN_YingSanZhang, gameConstDef.MESSAGE.COMPARE_CARD_REQ, false);
        ProtocolMessage.AddVectItemByte(msg._body_msg, score);
        GlobalManager.instance.SocketManager.SendMessage(constDef.SERVER_URL.game, msg);
    },
    discard_req: function discard_req() {

        var score = GlobalManager.instance.GetGameData(GlobalManager.instance.selfData.nTeamID).nCurBetVal;
        var msg = new ProtocolMessage(gameConstDef.MESSAGE.CMD_MAIN_YingSanZhang, gameConstDef.MESSAGE.DISCARD_REQ, false);
        ProtocolMessage.AddVectItemByte(msg._body_msg, 1);
        GlobalManager.instance.SocketManager.SendMessage(constDef.SERVER_URL.game, msg);
    },
    refreshUI: function refreshUI() {

        var follow_node = this.operation_node.getChildByName("follow_bet");
        var add_node = this.operation_node.getChildByName("add_bet");
        var look_node = this.operation_node.getChildByName("look_card");
        var compare_node = this.operation_node.getChildByName("compare_card");
        var discard_node = this.operation_node.getChildByName("discard");

        var normal_url = "Games/Yingsanzhang/res/image/sceneWar/button_normal";
        var disable_url = "Games/Yingsanzhang/res/image/sceneWar/button_disable";
        var follow_url = "Games/Yingsanzhang/res/image/sceneWar/button_hl";
        var tag = 1;

        if (tag > 0.5) {
            this.loadSpriteFrameWithUrlAndNode(follow_node, follow_url);
            this.loadSpriteFrameWithUrlAndNode(add_node, normal_url);
            this.loadSpriteFrameWithUrlAndNode(look_node, normal_url);
            this.loadSpriteFrameWithUrlAndNode(compare_node, normal_url);
            this.loadSpriteFrameWithUrlAndNode(discard_node, normal_url);
        } else {
            this.loadSpriteFrameWithUrlAndNode(follow_node, disable_url);
            this.loadSpriteFrameWithUrlAndNode(add_node, disable_url);
            this.loadSpriteFrameWithUrlAndNode(look_node, disable_url);
            this.loadSpriteFrameWithUrlAndNode(compare_node, disable_url);
            this.loadSpriteFrameWithUrlAndNode(discard_node, disable_url);
        }
    },
    loadSpriteFrameWithUrlAndNode: function loadSpriteFrameWithUrlAndNode(node, url) {
        cc.loader.loadRes(url, cc.SpriteFrame, function (error, spriteFrame) {
            if (!error) {
                node.getComponent(cc.Sprite).spriteFrame = spriteFrame;
            } else {
                cc.log("loader_url:", url, "error:", error);
            }
        });
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RFpop();
},{"ConstDef":"ConstDef","GlobalManager":"GlobalManager","ProtocolMessage":"ProtocolMessage","YingsanzhangConstDef":"YingsanzhangConstDef"}],"Yingsanzhang_PlayersUI":[function(require,module,exports){
"use strict";
cc._RFpush(module, '01991saMjdGA49jJhHEGJx+', 'Yingsanzhang_PlayersUI');
// resources/Games/Yingsanzhang/scene/sceneWar/Yingsanzhang_PlayersUI.js

var gameConstDef = require("YingsanzhangConstDef");
var GlobalManager = require("GlobalManager");

cc.Class({
    "extends": cc.Component,

    properties: {

        prefab_player: {
            "default": null,
            type: cc.Prefab
        },
        prefab_bet: {
            "default": null,
            type: cc.Prefab
        },
        bet_table: {
            "default": null,
            type: cc.Node
        },
        playersArray: []

    },

    // use this for initialization
    onLoad: function onLoad() {

        for (var i = 0; i < 5; i++) {
            var player = cc.instantiate(this.prefab_player);
            var compon = player.getComponent("Yingsanzhang_Player");
            compon.InitInfo(i + 1);
            this.node.addChild(player);
            this.playersArray.push(player);
        }
    },
    initPlayers: function initPlayers() {
        // var gameData = GlobalManager.instance.GetGameData(GlobalManager.instance.selfData.nCurGameID);
        // var myTeamID = gameData.nTeamID;
        // let nSelfIndex = 0;
        // for (nSelfIndex=0; nSelfIndex<gameData.vectTeamList.length; nSelfIndex++)
        // {
        //     if (gameData.vectTeamList[nSelfIndex].nTeamID == myTeamID) break;
        // }
        // if (nSelfIndex == gameData.vectTeamList.length) return;

        // let nCurIndex = nSelfIndex;
        for (var i = 0; i < this.playersArray.length; i++) {
            var playerComp = this.playersArray[i].getComponent("Yingsanzhang_Player");
            // playerComp.UpDateView(nCurIndex+1);  
            playerComp.UpDateView(i);
            // nCurIndex = (nCurIndex>=2)?0:(nCurIndex+1);
        }
    },
    sendCard: function sendCard() {
        var gameData = GlobalManager.instance.GetGameData(GlobalManager.instance.selfData.nCurGameID);

        for (var i = 0; i < this.playersArray.length; i++) {
            var playerComp = this.playersArray[i].getComponent("Yingsanzhang_Player");
            playerComp.sendCards();
        }
    },
    selfFollowBet: function selfFollowBet() {
        this.addBetFromPos(0, 1000, 1);
    },
    selfAddBet: function selfAddBet() {
        this.addBetFromPos(0, 2000, 2);
    },
    // pos  几号位下注  val 下注多少  type 砝码类型 1、2、3
    addBetFromPos: function addBetFromPos(pos, val, type) {

        var player_allbet_node = this.playersArray[pos].getChildByName("sideNode").getChildByName("bet");
        var position = player_allbet_node.convertToWorldSpace(this.bet_table.getPosition());
        var fromPosition = cc.v2(position.x - 470, position.y + 170);
        var toPosition = this.randomPosition();
        var bet = cc.instantiate(this.prefab_bet);
        var let_js = bet.getComponent("Yingsanzhang_Bet");
        bet.setPosition(fromPosition);
        let_js.setValueAndType(type, val);
        this.bet_table.addChild(bet);
        var actionBy = cc.moveTo(0.5, toPosition);
        bet.runAction(actionBy);
    },
    randomPosition: function randomPosition() {
        var width = this.bet_table.width;
        var height = this.bet_table.height;
        var randomW = Math.random() * width / 2;
        var randomH = Math.random() * height;
        return cc.v2(randomW + width / 4, randomH);
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RFpop();
},{"GlobalManager":"GlobalManager","YingsanzhangConstDef":"YingsanzhangConstDef"}],"Yingsanzhang_Player":[function(require,module,exports){
"use strict";
cc._RFpush(module, '5499ehWVkBJ+aTnkHAb/tDM', 'Yingsanzhang_Player');
// resources/Games/Yingsanzhang/res/prefab/Player/Yingsanzhang_Player.js

var GlobalManager = require("GlobalManager");
var ProtocolMessage = require("ProtocolMessage");
var gameConstDef = require("YingsanzhangConstDef");
cc.Class({
    "extends": cc.Component,

    properties: {

        backGround: {
            "default": null,
            type: cc.Node
        },
        cards_node: {
            "default": null,
            type: cc.Node
        },
        progressBar: {
            "default": null,
            type: cc.ProgressBar
        },
        headImg: {
            "default": null,
            type: cc.Sprite
        },
        nameLabel: {
            "default": null,
            type: cc.Label
        },
        allmoney: {
            "default": null,
            type: cc.Label
        },
        mainNode: {
            "default": null,
            type: cc.Node
        },
        side_node: {
            "default": null,
            type: cc.Node
        },
        lookCard_node: {
            "default": null,
            type: cc.Sprite
        },
        cardType_node: {
            "default": null,
            type: cc.Sprite
        },
        bet: {
            "default": null,
            type: cc.Label
        },
        prefab_card: {
            "default": null,
            type: cc.Prefab
        },
        liewen: {
            "default": null,
            type: cc.Node
        },
        cards_array: [],
        isLook: false

    },

    // use this for initialization
    onLoad: function onLoad() {},

    InitInfo: function InitInfo(sitSeq) {
        this.nSelfPos = sitSeq;
        this.nSelfIndex = sitSeq;

        this.mainNode.opacity = 0;
        this.side_node.opacity = 0;

        switch (sitSeq) {
            case 1:
                {
                    this.node.setPosition(cc.v2(820, -775));
                    this.side_node.setPosition(cc.v2(250, 0));
                }
                break;
            case 2:
                {
                    this.node.setPosition(cc.v2(200, -700));
                    this.side_node.setPosition(cc.v2(250, 0));
                }
                break;
            case 3:
                {
                    this.node.setPosition(cc.v2(200, -330));
                    this.side_node.setPosition(cc.v2(250, 0));
                }
                break;
            case 4:
                {
                    this.node.setPosition(cc.v2(1710, -330));
                    this.side_node.setPosition(cc.v2(-250, 0));
                }
                break;
            case 5:
                {
                    this.node.setPosition(cc.v2(1710, -700));
                    this.side_node.setPosition(cc.v2(-250, 0));
                }
                break;
        }
    },

    UpDateView: function UpDateView(nCurIndex) {
        // this.nSelfIndex = nCurIndex;
        this.RefreshView(nCurIndex);
    },
    RefreshSideView: function RefreshSideView(nCurIndex) {
        var gameData = GlobalManager.instance.GetGameData(GlobalManager.instance.selfData.nCurGameID);
        var playerInfo = gameData.vectTeamList[nCurIndex];
        if (playerInfo.nAccountID === 0) {
            this.node.opacity = 0;
        } else {
            this.node.opacity = 255;
            this.side_node.opacity = 255;
        }
    },
    RefreshView: function RefreshView() {
        var gameData = GlobalManager.instance.GetGameData(GlobalManager.instance.selfData.nCurGameID);
        var playerInfo = gameData.vectTeamList[this.nSelfIndex - 1];

        if (playerInfo.nAccountID === 0) {
            this.node.opacity = 0;
        } else {
            this.node.opacity = 255;
            this.mainNode.opacity = 255;

            if (playerInfo.nick !== null) {
                this.nameLabel.string = playerInfo.nick;
            }
            if (playerInfo.nCoinL !== null) {
                this.allmoney.string = playerInfo.nCoinL;
            }
            // cc.loader.loadRes("Games/Yingsanzhang/res/prefab/Player/image/head/head_"+playerInfo.nFhead,cc.SpriteFrame,function(error,spriteFrame){
            //     if(!error)
            //     {
            //         this.headImg.spriteFrame = spriteFrame;
            //     }
            // });
        }
    },
    //  显示结果  1 弃牌 2 看牌 3 输
    showLookNode: function showLookNode(type) {
        this.lookCard_node.spriteFrame = null;
        var base_url = "Games/Yingsanzhang/res/prefab/Player/image/";
        var type_url;
        switch (type) {
            case gameConstDef.PLAYER_OPERATION_TYPE.OPERATION_DISCARD:
                type_url = "discard";
                break;
            case gameConstDef.PLAYER_OPERATION_TYPE.OPERATION_LOOKCARD:
                type_url = "look";
                break;
            case gameConstDef.PLAYER_OPERATION_TYPE.OPERATION_LOSE:
                type_url = "lose";
                break;
            default:
                break;
        }
        var img_url = base_url + type_url;
        var lookNode = this.lookCard_node;
        cc.loader.loadRes(img_url, cc.SpriteFrame, function (error, spriteFrame) {
            if (!error) {
                lookNode.spriteFrame = spriteFrame;
            }
        });
    },
    // 显示 灰低 牌
    showDisCard: function showDisCard() {
        this.showProgressBar(10);
        for (var i = 0; i < this.cards_array.length; i++) {
            var node = this.cards_array[i];
            var component = node.getComponent("Yingsanzhang_Card");
            component.SetDisCard();
        }
        this.liewen.active = true;
    },
    //显示进度条
    showProgressBar: function showProgressBar(time) {
        this.progressBar.active = true;
        this.progressBar.progress = 1;
        // 以秒为单位的时间间隔
        var interval = 0.1;
        // 重复次数
        var repeat = time / interval;
        //  速度
        var speed = 1 / repeat;
        // 开始延时
        var delay = 0;
        this.schedule(function () {
            this._updateProgressBar(this.progressBar, speed);
        }, interval, repeat, delay);
    },
    timeOver: function timeOver() {
        this.progressBar.active = false;
        this.progressBar.progress = 0;
    },
    _updateProgressBar: function _updateProgressBar(progressBar, speed) {

        var progress = progressBar.progress;
        cc.log("progress:", progress);
        if (progress > 0) {
            progress -= speed;
        } else {
            this.timeOver();
        }
        progressBar.progress = progress;
    },
    sendCards: function sendCards() {
        var gameData = GlobalManager.instance.GetGameData(GlobalManager.instance.selfData.nCurGameID);
        var playerInfo = gameData.vectTeamList[this.nSelfIndex - 1];

        if (playerInfo.nAccountID === 0) {
            return;
        }
        var cards = [];
        cards.push[playerInfo.puke[0]];
        cards.push[playerInfo.puke[1]];
        cards.push[playerInfo.puke[2]];

        this.cards_node.active = true;
        this.cards_array = [];
        this.cards_node.removeAllChildren();
        // 以秒为单位的时间间隔
        var interval = 0.3;
        // 重复次数
        var repeat = 2;
        // 开始延时
        var delay = 0;
        var index = 0;
        this.schedule(function () {
            this.sendCard(cards[index++]);
            if (index >= 3) this.showDisCard();
        }, interval, repeat, delay);
    },

    sendCard: function sendCard(value) {
        cc.log("value:", value);
        var prefab_card = cc.instantiate(this.prefab_card);
        prefab_card.setPosition(cc.v2(0, 0));
        prefab_card.scale = 0.6;
        var component = prefab_card.getComponent("Yingsanzhang_Card");
        component.SetCardInfo(value);
        this.cards_node.addChild(prefab_card);
        this.cards_array.push(prefab_card);
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RFpop();
},{"GlobalManager":"GlobalManager","ProtocolMessage":"ProtocolMessage","YingsanzhangConstDef":"YingsanzhangConstDef"}],"Yingsanzhang_WarUI":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'cdd56htcdZKuo8yb6UlTo4F', 'Yingsanzhang_WarUI');
// resources/Games/Yingsanzhang/scene/sceneWar/Yingsanzhang_WarUI.js

var GlobalManager = require("GlobalManager");
var HintManager = require("HintManager");
var ProtocolMessage = require("ProtocolMessage");
var constDef = require("ConstDef");
var Utils = require("Utils");
var gameConstDef = require("YingsanzhangConstDef");

cc.Class({
    "extends": cc.Component,

    properties: {

        NodePlayersUI: cc.Node,
        NodeMyControllerUI: cc.Node
    },

    // foo: {
    //    default: null,      // The default value will be used only when the component attaching
    //                           to a node for the first time
    //    url: cc.Texture2D,  // optional, default is typeof default
    //    serializable: true, // optional, default is true
    //    visible: true,      // optional, default is true
    //    displayName: 'Foo', // optional
    //    readonly: false,    // optional, default is false
    // },
    // ...
    // use this for initialization
    onLoad: function onLoad() {

        // let msg = new ProtocolMessage(constDef.MESSAGE.CMD_MAIN_GAME,constDef.MESSAGE.FIGHT_READY_REQ,false);
        // ProtocolMessage.AddVectItemByte(msg._body_msg, 1);
        // GlobalManager.instance.SocketManager.SendMessage(constDef.SERVER_URL.game, msg);

    },
    RefreshUI: function RefreshUI() {
        cc.log("RefreshUI");
        this.NodePlayersUI.getComponent("Yingsanzhang_PlayersUI").initPlayers();

        var gameData = GlobalManager.instance.GetGameData(GlobalManager.instance.selfData.nCurGameID);

        if (gameData.nBattleStatus == gameConstDef.FIGHT_STATUS.BEGIN) {
            if (gameData.nClientStatus == gameConstDef.FIGHT_STATUS.C_BEGIN) {
                this.NodeMyControllerUI.getComponent("Yingsanzhang_PlayersUI").sendCard();
            }
        }
    },

    RefreshPlayerData: function RefreshPlayerData() {
        this.NodePlayersUI.getComponent("Yingsanzhang_PlayersUI").initPlayers();
        cc.log("War_RefreshPlayerData");
    },
    // called every frame, uncomment this function to activate update callback
    update: function update(dt) {}
});

cc._RFpop();
},{"ConstDef":"ConstDef","GlobalManager":"GlobalManager","HintManager":"HintManager","ProtocolMessage":"ProtocolMessage","Utils":"Utils","YingsanzhangConstDef":"YingsanzhangConstDef"}],"Yingsanzhang_classicsItem":[function(require,module,exports){
"use strict";
cc._RFpush(module, '20f80YdnJpK3LwEd/SXBq9T', 'Yingsanzhang_classicsItem');
// resources/Games/Yingsanzhang/res/prefab/classicsItem/Yingsanzhang_classicsItem.js

cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {}

});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();
},{}],"Yingsanzhang_gameWait":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'f60beq2y9VMy4M8mlp9ad1K', 'Yingsanzhang_gameWait');
// resources/Games/Yingsanzhang/scene/sceneWaitMatch/Yingsanzhang_gameWait.js

cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {}

});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();
},{}],"backGoods":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'e159bGHAD9Dp6vkYwr15QB7', 'backGoods');
// resources/common/prefab/backGoods/backGoods.js

cc.Class({
    "extends": cc.Component,

    properties: {
        LabelName: cc.Label
    },
    onLoad: function onLoad() {},
    initInfo: function initInfo(data) {
        this.LabelName.string = data.name;
    }
});

cc._RFpop();
},{}],"ccShader_Avg_Black_White_Frag":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'bc9e8z9HOtGGozotTnE/3zV', 'ccShader_Avg_Black_White_Frag');
// Global/qisuLib/Show/Shaders/ccShader_Avg_Black_White_Frag.js

/* 平均值黑白 */

module.exports = "precision mediump float;\n" + "varying vec2 v_texCoord;\n" + "void main()\n" + "{\n" + "    vec3 v = texture2D(CC_Texture0, v_texCoord).rgb;\n" + "    float f = (v.r + v.g + v.b) / 3.0;\n" + "    gl_FragColor = vec4(f, f, f, 1.0);\n" + "}\n";

cc._RFpop();
},{}],"ccShader_Default_Vert_noMVP":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'c73deC76fFDiqHtRr4Ojdz0', 'ccShader_Default_Vert_noMVP');
// Global/qisuLib/Show/Shaders/ccShader_Default_Vert_noMVP.js

module.exports = "\nattribute vec4 a_position;\n attribute vec2 a_texCoord;\n attribute vec4 a_color;\n varying vec2 v_texCoord;\n varying vec4 v_fragmentColor;\n void main()\n {\n     gl_Position = CC_PMatrix  * a_position;\n     v_fragmentColor = a_color;\n     v_texCoord = a_texCoord;\n }\n";

cc._RFpop();
},{}],"ccShader_Default_Vert":[function(require,module,exports){
"use strict";
cc._RFpush(module, '6da62dKjb1JtY3K0U3YaNC6', 'ccShader_Default_Vert');
// Global/qisuLib/Show/Shaders/ccShader_Default_Vert.js

module.exports = "attribute vec4 a_position;\n" + " attribute vec2 a_texCoord;\n" + " attribute vec4 a_color;\n" + " varying vec2 v_texCoord;\n" + " varying vec4 v_fragmentColor;\n" + " void main()\n" + " {\n" + "     gl_Position = ( CC_PMatrix * CC_MVMatrix ) * a_position;\n" + "     v_fragmentColor = a_color;\n" + "     v_texCoord = a_texCoord;\n" + " } \n";

cc._RFpop();
},{}],"chat":[function(require,module,exports){
"use strict";
cc._RFpush(module, '47e622BP2ZCRLlWL296DGu0', 'chat');
// resources/common/prefab/chatItem/chat.js

var GlobalManager = require("GlobalManager");

cc.Class({
    "extends": cc.Component,

    properties: {
        NodeHeadPic: cc.Node,
        NodeLeft: cc.Node,
        NodeRight: cc.Node,
        contentMaxWidth: 0
    },
    onLoad: function onLoad() {},
    initInfo: function initInfo(accountId, content) {
        var curContentLabel = null;
        if (accountId == GlobalManager.instance.selfData.nAccountID) {
            this.node.x = 900;
            curContentLabel = this.NodeLeft.getChildByName("label");
        } else {
            this.node.x = 0;
            curContentLabel = this.NodeRight.getChildByName("label");
        }
        curContentLabel.getComponent(cc.Label).overflow = cc.Label.Overflow.NONE;
        curContentLabel.getComponent(cc.Label).string = content;
        if (curContentLabel.width >= this.contentMaxWidth) {
            curContentLabel.getComponent(cc.Label).overflow = cc.Label.Overflow.RESIZE_HEIGHT;
            curContentLabel.width = this.contentMaxWidth;
        }
        curContentLabel.parent.width = curContentLabel.width + 60;
    }
});

cc._RFpop();
},{"GlobalManager":"GlobalManager"}],"gameHotUpdate":[function(require,module,exports){
"use strict";
cc._RFpush(module, '91efab4fbFK7JYrbzbjOD75', 'gameHotUpdate');
// Global/qisuLib/qisuFrame/HotUpdate/gameHotUpdate.js

cc.Class({
    "extends": cc.Component,

    properties: {
        updatePanel: {
            "default": null,
            type: cc.Node
        },
        manifestUrl: {
            "default": null,
            url: cc.RawAsset
        },
        percent: {
            "default": null,
            type: cc.Label
        },
        storageDir: "blackjack-remote-asset"
    },

    checkCb: function checkCb(event) {
        cc.log('Code: ' + event.getEventCode());
        switch (event.getEventCode()) {
            case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
                cc.log("No local manifest file found, hot update skipped.");
                cc.eventManager.removeListener(this._checkListener);
                break;
            case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
            case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
                cc.log("Fail to download manifest file, hot update skipped.");
                cc.eventManager.removeListener(this._checkListener);
                break;
            case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
                cc.log("Already up to date with the latest remote version.");
                cc.eventManager.removeListener(this._checkListener);
                break;
            case jsb.EventAssetsManager.NEW_VERSION_FOUND:
                this._needUpdate = true;

                this.updatePanel.active = true;

                var curScene = cc.director.getScene();
                var curNode = cc.find("Canvas", curScene);
                this.updatePanel.parent = curNode;
                this.updatePanel.x = 0;
                this.updatePanel.y = 0;

                this.percent.string = '00.00%';
                cc.eventManager.removeListener(this._checkListener);
                break;
            default:
                break;
        }
    },

    updateCb: function updateCb(event) {
        var needRestart = false;
        var failed = false;
        switch (event.getEventCode()) {
            case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
                cc.log('No local manifest file found, hot update skipped.');
                failed = true;
                break;
            case jsb.EventAssetsManager.UPDATE_PROGRESSION:
                var percent = event.getPercent();
                var percentByFile = event.getPercentByFile();

                var msg = event.getMessage();
                if (msg) {
                    cc.log(msg);
                }
                cc.log(percent.toFixed(2) + '%');
                this.percent.string = percent + '%';
                break;
            case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
            case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
                cc.log('Fail to download manifest file, hot update skipped.');
                failed = true;
                break;
            case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
                cc.log('Already up to date with the latest remote version.');
                failed = true;
                break;
            case jsb.EventAssetsManager.UPDATE_FINISHED:
                cc.log('Update finished. ' + event.getMessage());

                needRestart = true;
                break;
            case jsb.EventAssetsManager.UPDATE_FAILED:
                cc.log('Update failed. ' + event.getMessage());

                this._failCount++;
                if (this._failCount < 5) {
                    this._am.downloadFailedAssets();
                } else {
                    cc.log('Reach maximum fail count, exit update process');
                    this._failCount = 0;
                    failed = true;
                }
                break;
            case jsb.EventAssetsManager.ERROR_UPDATING:
                cc.log('Asset update error: ' + event.getAssetId() + ', ' + event.getMessage());
                break;
            case jsb.EventAssetsManager.ERROR_DECOMPRESS:
                cc.log(event.getMessage());
                break;
            default:
                break;
        }

        if (failed) {
            cc.eventManager.removeListener(this._updateListener);
            this.updatePanel.active = false;
        }

        if (needRestart) {
            cc.eventManager.removeListener(this._updateListener);
            // Prepend the manifest's search path
            var searchPaths = jsb.fileUtils.getSearchPaths();
            var newPaths = this._am.getLocalManifest().getSearchPaths();
            Array.prototype.unshift(searchPaths, newPaths);
            // This value will be retrieved and appended to the default search path during game startup,
            // please refer to samples/js-tests/main.js for detailed usage.
            // !!! Re-add the search paths in main.js is very important, otherwise, new scripts won't take effect.
            cc.sys.localStorage.setItem('HotUpdateSearchPaths', JSON.stringify(searchPaths));

            jsb.fileUtils.setSearchPaths(searchPaths);
            cc.game.restart();
        }
    },

    hotUpdate: function hotUpdate() {
        if (this._am && this._needUpdate) {
            this._updateListener = new jsb.EventListenerAssetsManager(this._am, this.updateCb.bind(this));
            cc.eventManager.addListener(this._updateListener, 1);

            this._failCount = 0;
            this._am.update();
        }
    },

    // use this for initialization
    checkUpdate: function checkUpdate() {
        if (!cc.sys.isNative) {
            return;
        }
        var storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : '/') + this.storageDir;

        this._am = new jsb.AssetsManager(this.manifestUrl, storagePath);
        this._am.retain();

        this._needUpdate = false;
        if (this._am.getLocalManifest().isLoaded()) {
            this._checkListener = new jsb.EventListenerAssetsManager(this._am, this.checkCb.bind(this));
            cc.eventManager.addListener(this._checkListener, 1);

            this._am.checkUpdate();
        }
    },
    // onLoad: function () {
    //     // Hot update is only available in Native build
    //     if (!cc.sys.isNative) {
    //         return;
    //     }
    //     var storagePath = ((jsb.fileUtils ? jsb.fileUtils.getWritablePath() : '/') + this.storageDir);
    //     cc.log('Storage path for remote asset : ' + storagePath);

    //     // cc.log('Local manifest URL : ' + this.manifestUrl);
    //     this._am = new jsb.AssetsManager(this.manifestUrl, storagePath);
    //     this._am.retain();

    //     this._needUpdate = false;
    //     if (this._am.getLocalManifest().isLoaded())
    //     {
    //         this._checkListener = new jsb.EventListenerAssetsManager(this._am, this.checkCb.bind(this));
    //         cc.eventManager.addListener(this._checkListener, 1);

    //         this._am.checkUpdate();
    //     }
    // },

    onDestroy: function onDestroy() {
        this._am && this._am.release();
    }
});

cc._RFpop();
},{}],"game":[function(require,module,exports){
"use strict";
cc._RFpush(module, '65df3gLPp1Fc6ikfmBgLlbU', 'game');
// resources/common/prefab/game/game.js

var constDef = require("ConstDef");
var GlobalManager = require("GlobalManager");

cc.Class({
    "extends": cc.Component,

    properties: {
        NodeButton: cc.Node,
        NodeGrid: cc.Node,
        NodeButtonBox: cc.Node,
        SpriteIcon: cc.Sprite,
        LabelNumber: cc.Label,
        LabelPlayerNum: cc.Label,
        LabelGameName: cc.Label,
        LabelDesc: cc.Label,
        selfIndex: 0,
        gameId: 0
    },

    onLoad: function onLoad() {
        var ctx = this.NodeGrid.getComponent(cc.Graphics);
        ctx.moveTo(-540, -125);
        ctx.lineTo(1080, -125);
        ctx.stroke();

        var g = this.NodeButtonBox.getComponent(cc.Graphics);
        g.roundRect(-75, -35, 150, 70, 10);
        g.stroke();

        this.NodeButton.on("touchend", this.onClickInstall, this);
    },
    initInfo: function initInfo(data) {
        this.selfIndex = data.index;
        this.gameId = data.gameId;
        this.LabelNumber.string = data.index;
        this.LabelGameName.string = data.name;
        if (typeof data.onLineCount === "undefined") {
            data.onLineCount = 0;
        }
        this.LabelPlayerNum.string = data.onLineCount + "人";
        this.LabelDesc.string = data.desc;

        var self = this;
        cc.loader.load(data.imgUrl, function (err, texture) {
            var frame = new cc.SpriteFrame(texture);
            self.SpriteIcon.spriteFrame = frame;
        });
    },
    updateOnlineCount: function updateOnlineCount() {
        this.LabelPlayerNum.string = data.playersNum + "人";
    },
    onClickInstall: function onClickInstall(event) {
        var gameId = this.gameId;
        GlobalManager.instance.GameNodeAddComponent(gameId, function () {
            GlobalManager.instance.selfData.nCurGameID = gameId;
            GlobalManager.instance.GetGameController(gameId).SendMsg(constDef.CONNECT_CALLBACK_STATUS.LOGON_GET_GAME_INFO);
        });
    }
});

cc._RFpop();
},{"ConstDef":"ConstDef","GlobalManager":"GlobalManager"}],"main":[function(require,module,exports){
"use strict";
cc._RFpush(module, '9074bEc4iJJ0oTsI756F/cE', 'main');
// Global/service/controller/main.js

var GlobalManager = require("GlobalManager");
var constDef = require("ConstDef");

cc.Class({
    "extends": cc.Component,

    properties: {},

    onLoad: function onLoad() {
        GlobalManager.instance.confData.loadConfJson();
        cc.director.loadScene("logon");
    }

});

cc._RFpop();
},{"ConstDef":"ConstDef","GlobalManager":"GlobalManager"}],"md5":[function(require,module,exports){
"use strict";
cc._RFpush(module, '85178uNPTtLn7ZIB1EhqxSA', 'md5');
// Global/qisuLib/base/md5.js

var md5 = {
        md5: function md5(string) {
                function md5_RotateLeft(lValue, iShiftBits) {
                        return lValue << iShiftBits | lValue >>> 32 - iShiftBits;
                }
                function md5_AddUnsigned(lX, lY) {
                        var lX4, lY4, lX8, lY8, lResult;
                        lX8 = lX & 0x80000000;
                        lY8 = lY & 0x80000000;
                        lX4 = lX & 0x40000000;
                        lY4 = lY & 0x40000000;
                        lResult = (lX & 0x3FFFFFFF) + (lY & 0x3FFFFFFF);
                        if (lX4 & lY4) {
                                return lResult ^ 0x80000000 ^ lX8 ^ lY8;
                        }
                        if (lX4 | lY4) {
                                if (lResult & 0x40000000) {
                                        return lResult ^ 0xC0000000 ^ lX8 ^ lY8;
                                } else {
                                        return lResult ^ 0x40000000 ^ lX8 ^ lY8;
                                }
                        } else {
                                return lResult ^ lX8 ^ lY8;
                        }
                }
                function md5_F(x, y, z) {
                        return x & y | ~x & z;
                }
                function md5_G(x, y, z) {
                        return x & z | y & ~z;
                }
                function md5_H(x, y, z) {
                        return x ^ y ^ z;
                }
                function md5_I(x, y, z) {
                        return y ^ (x | ~z);
                }
                function md5_FF(a, b, c, d, x, s, ac) {
                        a = md5_AddUnsigned(a, md5_AddUnsigned(md5_AddUnsigned(md5_F(b, c, d), x), ac));
                        return md5_AddUnsigned(md5_RotateLeft(a, s), b);
                };
                function md5_GG(a, b, c, d, x, s, ac) {
                        a = md5_AddUnsigned(a, md5_AddUnsigned(md5_AddUnsigned(md5_G(b, c, d), x), ac));
                        return md5_AddUnsigned(md5_RotateLeft(a, s), b);
                };
                function md5_HH(a, b, c, d, x, s, ac) {
                        a = md5_AddUnsigned(a, md5_AddUnsigned(md5_AddUnsigned(md5_H(b, c, d), x), ac));
                        return md5_AddUnsigned(md5_RotateLeft(a, s), b);
                };
                function md5_II(a, b, c, d, x, s, ac) {
                        a = md5_AddUnsigned(a, md5_AddUnsigned(md5_AddUnsigned(md5_I(b, c, d), x), ac));
                        return md5_AddUnsigned(md5_RotateLeft(a, s), b);
                };
                function md5_ConvertToWordArray(string) {
                        var lWordCount;
                        var lMessageLength = string.length;
                        var lNumberOfWords_temp1 = lMessageLength + 8;
                        var lNumberOfWords_temp2 = (lNumberOfWords_temp1 - lNumberOfWords_temp1 % 64) / 64;
                        var lNumberOfWords = (lNumberOfWords_temp2 + 1) * 16;
                        var lWordArray = Array(lNumberOfWords - 1);
                        var lBytePosition = 0;
                        var lByteCount = 0;
                        while (lByteCount < lMessageLength) {
                                lWordCount = (lByteCount - lByteCount % 4) / 4;
                                lBytePosition = lByteCount % 4 * 8;
                                lWordArray[lWordCount] = lWordArray[lWordCount] | string.charCodeAt(lByteCount) << lBytePosition;
                                lByteCount++;
                        }
                        lWordCount = (lByteCount - lByteCount % 4) / 4;
                        lBytePosition = lByteCount % 4 * 8;
                        lWordArray[lWordCount] = lWordArray[lWordCount] | 0x80 << lBytePosition;
                        lWordArray[lNumberOfWords - 2] = lMessageLength << 3;
                        lWordArray[lNumberOfWords - 1] = lMessageLength >>> 29;
                        return lWordArray;
                };
                function md5_WordToHex(lValue) {
                        var WordToHexValue = "",
                            WordToHexValue_temp = "",
                            lByte,
                            lCount;
                        for (lCount = 0; lCount <= 3; lCount++) {
                                lByte = lValue >>> lCount * 8 & 255;
                                WordToHexValue_temp = "0" + lByte.toString(16);
                                WordToHexValue = WordToHexValue + WordToHexValue_temp.substr(WordToHexValue_temp.length - 2, 2);
                        }
                        return WordToHexValue;
                };
                function md5_Utf8Encode(string) {
                        string = string.replace(/\r\n/g, "\n");
                        var utftext = "";
                        for (var n = 0; n < string.length; n++) {
                                var c = string.charCodeAt(n);
                                if (c < 128) {
                                        utftext += String.fromCharCode(c);
                                } else if (c > 127 && c < 2048) {
                                        utftext += String.fromCharCode(c >> 6 | 192);
                                        utftext += String.fromCharCode(c & 63 | 128);
                                } else {
                                        utftext += String.fromCharCode(c >> 12 | 224);
                                        utftext += String.fromCharCode(c >> 6 & 63 | 128);
                                        utftext += String.fromCharCode(c & 63 | 128);
                                }
                        }
                        return utftext;
                };
                var x = Array();
                var k, AA, BB, CC, DD, a, b, c, d;
                var S11 = 7,
                    S12 = 12,
                    S13 = 17,
                    S14 = 22;
                var S21 = 5,
                    S22 = 9,
                    S23 = 14,
                    S24 = 20;
                var S31 = 4,
                    S32 = 11,
                    S33 = 16,
                    S34 = 23;
                var S41 = 6,
                    S42 = 10,
                    S43 = 15,
                    S44 = 21;
                string = md5_Utf8Encode(string);
                x = md5_ConvertToWordArray(string);
                a = 0x67452301;b = 0xEFCDAB89;c = 0x98BADCFE;d = 0x10325476;
                for (k = 0; k < x.length; k += 16) {
                        AA = a;BB = b;CC = c;DD = d;
                        a = md5_FF(a, b, c, d, x[k + 0], S11, 0xD76AA478);
                        d = md5_FF(d, a, b, c, x[k + 1], S12, 0xE8C7B756);
                        c = md5_FF(c, d, a, b, x[k + 2], S13, 0x242070DB);
                        b = md5_FF(b, c, d, a, x[k + 3], S14, 0xC1BDCEEE);
                        a = md5_FF(a, b, c, d, x[k + 4], S11, 0xF57C0FAF);
                        d = md5_FF(d, a, b, c, x[k + 5], S12, 0x4787C62A);
                        c = md5_FF(c, d, a, b, x[k + 6], S13, 0xA8304613);
                        b = md5_FF(b, c, d, a, x[k + 7], S14, 0xFD469501);
                        a = md5_FF(a, b, c, d, x[k + 8], S11, 0x698098D8);
                        d = md5_FF(d, a, b, c, x[k + 9], S12, 0x8B44F7AF);
                        c = md5_FF(c, d, a, b, x[k + 10], S13, 0xFFFF5BB1);
                        b = md5_FF(b, c, d, a, x[k + 11], S14, 0x895CD7BE);
                        a = md5_FF(a, b, c, d, x[k + 12], S11, 0x6B901122);
                        d = md5_FF(d, a, b, c, x[k + 13], S12, 0xFD987193);
                        c = md5_FF(c, d, a, b, x[k + 14], S13, 0xA679438E);
                        b = md5_FF(b, c, d, a, x[k + 15], S14, 0x49B40821);
                        a = md5_GG(a, b, c, d, x[k + 1], S21, 0xF61E2562);
                        d = md5_GG(d, a, b, c, x[k + 6], S22, 0xC040B340);
                        c = md5_GG(c, d, a, b, x[k + 11], S23, 0x265E5A51);
                        b = md5_GG(b, c, d, a, x[k + 0], S24, 0xE9B6C7AA);
                        a = md5_GG(a, b, c, d, x[k + 5], S21, 0xD62F105D);
                        d = md5_GG(d, a, b, c, x[k + 10], S22, 0x2441453);
                        c = md5_GG(c, d, a, b, x[k + 15], S23, 0xD8A1E681);
                        b = md5_GG(b, c, d, a, x[k + 4], S24, 0xE7D3FBC8);
                        a = md5_GG(a, b, c, d, x[k + 9], S21, 0x21E1CDE6);
                        d = md5_GG(d, a, b, c, x[k + 14], S22, 0xC33707D6);
                        c = md5_GG(c, d, a, b, x[k + 3], S23, 0xF4D50D87);
                        b = md5_GG(b, c, d, a, x[k + 8], S24, 0x455A14ED);
                        a = md5_GG(a, b, c, d, x[k + 13], S21, 0xA9E3E905);
                        d = md5_GG(d, a, b, c, x[k + 2], S22, 0xFCEFA3F8);
                        c = md5_GG(c, d, a, b, x[k + 7], S23, 0x676F02D9);
                        b = md5_GG(b, c, d, a, x[k + 12], S24, 0x8D2A4C8A);
                        a = md5_HH(a, b, c, d, x[k + 5], S31, 0xFFFA3942);
                        d = md5_HH(d, a, b, c, x[k + 8], S32, 0x8771F681);
                        c = md5_HH(c, d, a, b, x[k + 11], S33, 0x6D9D6122);
                        b = md5_HH(b, c, d, a, x[k + 14], S34, 0xFDE5380C);
                        a = md5_HH(a, b, c, d, x[k + 1], S31, 0xA4BEEA44);
                        d = md5_HH(d, a, b, c, x[k + 4], S32, 0x4BDECFA9);
                        c = md5_HH(c, d, a, b, x[k + 7], S33, 0xF6BB4B60);
                        b = md5_HH(b, c, d, a, x[k + 10], S34, 0xBEBFBC70);
                        a = md5_HH(a, b, c, d, x[k + 13], S31, 0x289B7EC6);
                        d = md5_HH(d, a, b, c, x[k + 0], S32, 0xEAA127FA);
                        c = md5_HH(c, d, a, b, x[k + 3], S33, 0xD4EF3085);
                        b = md5_HH(b, c, d, a, x[k + 6], S34, 0x4881D05);
                        a = md5_HH(a, b, c, d, x[k + 9], S31, 0xD9D4D039);
                        d = md5_HH(d, a, b, c, x[k + 12], S32, 0xE6DB99E5);
                        c = md5_HH(c, d, a, b, x[k + 15], S33, 0x1FA27CF8);
                        b = md5_HH(b, c, d, a, x[k + 2], S34, 0xC4AC5665);
                        a = md5_II(a, b, c, d, x[k + 0], S41, 0xF4292244);
                        d = md5_II(d, a, b, c, x[k + 7], S42, 0x432AFF97);
                        c = md5_II(c, d, a, b, x[k + 14], S43, 0xAB9423A7);
                        b = md5_II(b, c, d, a, x[k + 5], S44, 0xFC93A039);
                        a = md5_II(a, b, c, d, x[k + 12], S41, 0x655B59C3);
                        d = md5_II(d, a, b, c, x[k + 3], S42, 0x8F0CCC92);
                        c = md5_II(c, d, a, b, x[k + 10], S43, 0xFFEFF47D);
                        b = md5_II(b, c, d, a, x[k + 1], S44, 0x85845DD1);
                        a = md5_II(a, b, c, d, x[k + 8], S41, 0x6FA87E4F);
                        d = md5_II(d, a, b, c, x[k + 15], S42, 0xFE2CE6E0);
                        c = md5_II(c, d, a, b, x[k + 6], S43, 0xA3014314);
                        b = md5_II(b, c, d, a, x[k + 13], S44, 0x4E0811A1);
                        a = md5_II(a, b, c, d, x[k + 4], S41, 0xF7537E82);
                        d = md5_II(d, a, b, c, x[k + 11], S42, 0xBD3AF235);
                        c = md5_II(c, d, a, b, x[k + 2], S43, 0x2AD7D2BB);
                        b = md5_II(b, c, d, a, x[k + 9], S44, 0xEB86D391);
                        a = md5_AddUnsigned(a, AA);
                        b = md5_AddUnsigned(b, BB);
                        c = md5_AddUnsigned(c, CC);
                        d = md5_AddUnsigned(d, DD);
                }
                return (md5_WordToHex(a) + md5_WordToHex(b) + md5_WordToHex(c) + md5_WordToHex(d)).toLowerCase();
        }

};

module.exports = md5;

cc._RFpop();
},{}],"message":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'bb486skCDFA85GWsdJCBBjw', 'message');
// resources/common/prefab/message/message.js

cc.Class({
    "extends": cc.Component,

    properties: {},

    onLoad: function onLoad() {
        var ctx = this.node.getComponent(cc.Graphics);
        ctx.moveTo(0, 0);
        ctx.lineTo(1080, 0);

        ctx.stroke();
    },
    initInfo: function initInfo(data) {}
});

cc._RFpop();
},{}]},{},["Yingsanzhang_PlayersUI","Yingsanzhang_AnimUI","ConfData","Yingsanzhang_EndUI","SelfData","Yingsanzhang_classicsItem","Yingsanzhang_Bet","LoadManager","ServerData","chat","Yingsanzhang_Player","ConstDef","Utils","YingsanzhangConstDef","YingsanzhangGameController","MessageHandle","game","USocket","Yingsanzhang_HomeUI","ccShader_Default_Vert","YingsanzhangGameData","ProtocolMessage","HintManager","md5","HotUpdate","Avg_Black_White","YingsanzhangGameMessage","gameHotUpdate","main","ServerInfo","Yingsanzhang_MyController","message","ccShader_Avg_Black_White_Frag","GlobalManager","LogonUI","ccShader_Default_Vert_noMVP","AudioManager","Yingsanzhang_WarUI","NodeFader","backGoods","Yingsanzhang_Card","ButtonScaler","SceneEntry","ProtocolItem","Yingsanzhang_gameWait","NodeScaler"])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uLy4uL0FwcGxpY2F0aW9ucy9Db2Nvc0NyZWF0b3IuYXBwL0NvbnRlbnRzL1Jlc291cmNlcy9hcHAuYXNhci9ub2RlX21vZHVsZXMvYnJvd3Nlci1wYWNrL19wcmVsdWRlLmpzIiwiYXNzZXRzL0dsb2JhbC9xaXN1TGliL3Fpc3VGcmFtZS9BdWRpby9BdWRpb01hbmFnZXIuanMiLCJhc3NldHMvR2xvYmFsL3Fpc3VMaWIvU2hvdy9BdmdfQmxhY2tfV2hpdGUuanMiLCJhc3NldHMvR2xvYmFsL3Fpc3VMaWIvU2hvdy9CdXR0b25TY2FsZXIuanMiLCJhc3NldHMvR2xvYmFsL3NlcnZpY2UvZGF0YS9Db25mRGF0YS5qcyIsImFzc2V0cy9HbG9iYWwvc2VydmljZS9Db25zdERlZi5qcyIsImFzc2V0cy9HbG9iYWwvc2VydmljZS9HbG9iYWxNYW5hZ2VyLmpzIiwiYXNzZXRzL0dsb2JhbC9xaXN1TGliL3Fpc3VGcmFtZS9IaW50L0hpbnRNYW5hZ2VyLmpzIiwiYXNzZXRzL0dsb2JhbC9xaXN1TGliL3Fpc3VGcmFtZS9Ib3RVcGRhdGUvSG90VXBkYXRlLmpzIiwiYXNzZXRzL0dsb2JhbC9xaXN1TGliL3Fpc3VGcmFtZS9Mb2FkL0xvYWRNYW5hZ2VyLmpzIiwiYXNzZXRzL3Jlc291cmNlcy9HYW1lcy9ZaW5nc2Fuemhhbmcvc2NlbmUvc2NlbmVMb2dvbi9Mb2dvblVJLmpzIiwiYXNzZXRzL0dsb2JhbC9zZXJ2aWNlL01lc3NhZ2VIYW5kbGUuanMiLCJhc3NldHMvR2xvYmFsL3Fpc3VMaWIvU2hvdy9Ob2RlRmFkZXIuanMiLCJhc3NldHMvR2xvYmFsL3Fpc3VMaWIvU2hvdy9Ob2RlU2NhbGVyLmpzIiwiYXNzZXRzL0dsb2JhbC9xaXN1TGliL2NvbW0vUHJvdG9jb2xJdGVtLmpzIiwiYXNzZXRzL0dsb2JhbC9xaXN1TGliL2NvbW0vUHJvdG9jb2xNZXNzYWdlLmpzIiwiYXNzZXRzL0dsb2JhbC9xaXN1TGliL1Nob3cvU2NlbmVFbnRyeS5qcyIsImFzc2V0cy9HbG9iYWwvc2VydmljZS9kYXRhL1NlbGZEYXRhLmpzIiwiYXNzZXRzL0dsb2JhbC9zZXJ2aWNlL2RhdGEvU2VydmVyRGF0YS5qcyIsImFzc2V0cy9HbG9iYWwvcWlzdUxpYi9jb21tL1NlcnZlckluZm8uanMiLCJhc3NldHMvR2xvYmFsL3Fpc3VMaWIvY29tbS9VU29ja2V0LmpzIiwiYXNzZXRzL0dsb2JhbC9xaXN1TGliL2Jhc2UvVXRpbHMuanMiLCJhc3NldHMvcmVzb3VyY2VzL0dhbWVzL1lpbmdzYW56aGFuZy9zcmMvWWluZ3NhbnpoYW5nQ29uc3REZWYuanMiLCJhc3NldHMvcmVzb3VyY2VzL0dhbWVzL1lpbmdzYW56aGFuZy9zcmMvWWluZ3NhbnpoYW5nR2FtZUNvbnRyb2xsZXIuanMiLCJhc3NldHMvcmVzb3VyY2VzL0dhbWVzL1lpbmdzYW56aGFuZy9zcmMvWWluZ3NhbnpoYW5nR2FtZURhdGEuanMiLCJhc3NldHMvcmVzb3VyY2VzL0dhbWVzL1lpbmdzYW56aGFuZy9zcmMvWWluZ3NhbnpoYW5nR2FtZU1lc3NhZ2UuanMiLCJhc3NldHMvcmVzb3VyY2VzL0dhbWVzL1lpbmdzYW56aGFuZy9zY2VuZS9zY2VuZVdhci9ZaW5nc2FuemhhbmdfQW5pbVVJLmpzIiwiYXNzZXRzL3Jlc291cmNlcy9HYW1lcy9ZaW5nc2FuemhhbmcvcmVzL3ByZWZhYi9CZXQvWWluZ3NhbnpoYW5nX0JldC5qcyIsImFzc2V0cy9yZXNvdXJjZXMvR2FtZXMvWWluZ3NhbnpoYW5nL3Jlcy9wcmVmYWIvQ2FyZC9ZaW5nc2FuemhhbmdfQ2FyZC5qcyIsImFzc2V0cy9yZXNvdXJjZXMvR2FtZXMvWWluZ3NhbnpoYW5nL3NjZW5lL3NjZW5lV2FyL1lpbmdzYW56aGFuZ19FbmRVSS5qcyIsImFzc2V0cy9yZXNvdXJjZXMvR2FtZXMvWWluZ3NhbnpoYW5nL3NjZW5lL3NjZW5lSG9tZS9ZaW5nc2FuemhhbmdfSG9tZVVJLmpzIiwiYXNzZXRzL3Jlc291cmNlcy9HYW1lcy9ZaW5nc2Fuemhhbmcvc2NlbmUvc2NlbmVXYXIvWWluZ3NhbnpoYW5nX015Q29udHJvbGxlci5qcyIsImFzc2V0cy9yZXNvdXJjZXMvR2FtZXMvWWluZ3NhbnpoYW5nL3NjZW5lL3NjZW5lV2FyL1lpbmdzYW56aGFuZ19QbGF5ZXJzVUkuanMiLCJhc3NldHMvcmVzb3VyY2VzL0dhbWVzL1lpbmdzYW56aGFuZy9yZXMvcHJlZmFiL1BsYXllci9ZaW5nc2FuemhhbmdfUGxheWVyLmpzIiwiYXNzZXRzL3Jlc291cmNlcy9HYW1lcy9ZaW5nc2Fuemhhbmcvc2NlbmUvc2NlbmVXYXIvWWluZ3NhbnpoYW5nX1dhclVJLmpzIiwiYXNzZXRzL3Jlc291cmNlcy9HYW1lcy9ZaW5nc2FuemhhbmcvcmVzL3ByZWZhYi9jbGFzc2ljc0l0ZW0vWWluZ3NhbnpoYW5nX2NsYXNzaWNzSXRlbS5qcyIsImFzc2V0cy9yZXNvdXJjZXMvR2FtZXMvWWluZ3NhbnpoYW5nL3NjZW5lL3NjZW5lV2FpdE1hdGNoL1lpbmdzYW56aGFuZ19nYW1lV2FpdC5qcyIsImFzc2V0cy9yZXNvdXJjZXMvY29tbW9uL3ByZWZhYi9iYWNrR29vZHMvYmFja0dvb2RzLmpzIiwiYXNzZXRzL0dsb2JhbC9xaXN1TGliL1Nob3cvU2hhZGVycy9jY1NoYWRlcl9BdmdfQmxhY2tfV2hpdGVfRnJhZy5qcyIsImFzc2V0cy9HbG9iYWwvcWlzdUxpYi9TaG93L1NoYWRlcnMvY2NTaGFkZXJfRGVmYXVsdF9WZXJ0X25vTVZQLmpzIiwiYXNzZXRzL0dsb2JhbC9xaXN1TGliL1Nob3cvU2hhZGVycy9jY1NoYWRlcl9EZWZhdWx0X1ZlcnQuanMiLCJhc3NldHMvcmVzb3VyY2VzL2NvbW1vbi9wcmVmYWIvY2hhdEl0ZW0vY2hhdC5qcyIsImFzc2V0cy9HbG9iYWwvcWlzdUxpYi9xaXN1RnJhbWUvSG90VXBkYXRlL2dhbWVIb3RVcGRhdGUuanMiLCJhc3NldHMvcmVzb3VyY2VzL2NvbW1vbi9wcmVmYWIvZ2FtZS9nYW1lLmpzIiwiYXNzZXRzL0dsb2JhbC9zZXJ2aWNlL2NvbnRyb2xsZXIvbWFpbi5qcyIsImFzc2V0cy9HbG9iYWwvcWlzdUxpYi9iYXNlL21kNS5qcyIsImFzc2V0cy9yZXNvdXJjZXMvY29tbW9uL3ByZWZhYi9tZXNzYWdlL21lc3NhZ2UuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2pEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN6REE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDMUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2xLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDaE9BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3JRQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDN0hBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzNLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3JPQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3ZHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNuUEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzVDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUMxQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUMvQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDblZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3hCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQy9FQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDcEJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDbENBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ25iQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ25FQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNwSUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDdklBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDNzREQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDaHZCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDN0JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN6Q0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDekdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUM3QkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN2REE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3JHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNuR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN0UUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzNEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDN0JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUM3QkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNoQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ1JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ05BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ05BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNuQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDN0xBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDaEVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDbkJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDaE5BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJmaWxlIjoiZ2VuZXJhdGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbiBlKHQsbixyKXtmdW5jdGlvbiBzKG8sdSl7aWYoIW5bb10pe2lmKCF0W29dKXt2YXIgYT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2lmKCF1JiZhKXJldHVybiBhKG8sITApO2lmKGkpcmV0dXJuIGkobywhMCk7dmFyIGY9bmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIitvK1wiJ1wiKTt0aHJvdyBmLmNvZGU9XCJNT0RVTEVfTk9UX0ZPVU5EXCIsZn12YXIgbD1uW29dPXtleHBvcnRzOnt9fTt0W29dWzBdLmNhbGwobC5leHBvcnRzLGZ1bmN0aW9uKGUpe3ZhciBuPXRbb11bMV1bZV07cmV0dXJuIHMobj9uOmUpfSxsLGwuZXhwb3J0cyxlLHQsbixyKX1yZXR1cm4gbltvXS5leHBvcnRzfXZhciBpPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7Zm9yKHZhciBvPTA7bzxyLmxlbmd0aDtvKyspcyhyW29dKTtyZXR1cm4gc30pIiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJ2NiYWQzb21nR0pLcEtzUjhUZjgreWt2JywgJ0F1ZGlvTWFuYWdlcicpO1xuLy8gR2xvYmFsL3Fpc3VMaWIvcWlzdUZyYW1lL0F1ZGlvL0F1ZGlvTWFuYWdlci5qc1xuXG5jYy5DbGFzcyh7XG4gICAgXCJleHRlbmRzXCI6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgc3RyU291bmRGaWxlUGF0aDogXCJyZXNvdXJjZXMvY29tbW9uL2F1ZGlvL1wiXG4gICAgfSxcblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge30sXG5cbiAgICBzZXRTb3VuZEZpbGVQYXRoOiBmdW5jdGlvbiBzZXRTb3VuZEZpbGVQYXRoKHZhbCkge1xuICAgICAgICB0aGlzLnN0clNvdW5kRmlsZVBhdGggPSB2YWw7XG4gICAgfSxcblxuICAgIHBsYXk6IGZ1bmN0aW9uIHBsYXkoY2xpcCwgaXNMb29wKSB7XG4gICAgICAgIHZhciB1cmwgPSBjbGlwO1xuICAgICAgICBpZiAodHlwZW9mIGNsaXAgPT0gXCJzdHJpbmdcIikge1xuICAgICAgICAgICAgdXJsID0gY2MudXJsLnJhdyh0aGlzLnN0clNvdW5kRmlsZVBhdGggKyBjbGlwKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNjLmF1ZGlvRW5naW5lLnBsYXlNdXNpYyh1cmwsIGlzTG9vcCk7XG4gICAgfSxcblxuICAgIHBsYXlFZmZlY3Q6IGZ1bmN0aW9uIHBsYXlFZmZlY3QoY2xpcCwgaXNMb29wKSB7XG4gICAgICAgIHZhciB1cmwgPSBjbGlwO1xuICAgICAgICBpZiAodHlwZW9mIGNsaXAgPT0gXCJzdHJpbmdcIikge1xuICAgICAgICAgICAgdXJsID0gY2MudXJsLnJhdyh0aGlzLnN0clNvdW5kRmlsZVBhdGggKyBjbGlwKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNjLmF1ZGlvRW5naW5lLnBsYXlFZmZlY3QodXJsLCBpc0xvb3ApO1xuICAgIH0sXG5cbiAgICBwYXVzZTogZnVuY3Rpb24gcGF1c2UoKSB7XG4gICAgICAgIGNjLmF1ZGlvRW5naW5lLnBhdXNlTXVzaWMoKTtcbiAgICB9LFxuXG4gICAgc3RvcDogZnVuY3Rpb24gc3RvcCgpIHtcbiAgICAgICAgY2MuYXVkaW9FbmdpbmUuc3RvcE11c2ljKCk7XG4gICAgfSxcblxuICAgIHJlc3VtZTogZnVuY3Rpb24gcmVzdW1lKCkge1xuICAgICAgICBjYy5hdWRpb0VuZ2luZS5yZXN1bWVNdXNpYygpO1xuICAgIH1cblxufSk7XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICc4ZDhiMmlwS0VGUFZhTDNRcll5eURRYycsICdBdmdfQmxhY2tfV2hpdGUnKTtcbi8vIEdsb2JhbC9xaXN1TGliL1Nob3cvQXZnX0JsYWNrX1doaXRlLmpzXG5cbnZhciBfZGVmYXVsdF92ZXJ0ID0gcmVxdWlyZShcImNjU2hhZGVyX0RlZmF1bHRfVmVydFwiKTtcbnZhciBfZGVmYXVsdF92ZXJ0X25vX212cCA9IHJlcXVpcmUoXCJjY1NoYWRlcl9EZWZhdWx0X1ZlcnRfbm9NVlBcIik7XG52YXIgX2JsYWNrX3doaXRlX2ZyYWcgPSByZXF1aXJlKFwiY2NTaGFkZXJfQXZnX0JsYWNrX1doaXRlX0ZyYWdcIik7XG5cbnZhciBFZmZlY3RCbGFja1doaXRlID0gY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIGlzQWxsQ2hpbGRyZW5Vc2VyOiBmYWxzZVxuICAgIH0sXG5cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHtcbiAgICAgICAgdGhpcy5fdXNlKCk7XG4gICAgfSxcblxuICAgIF91c2U6IGZ1bmN0aW9uIF91c2UoKSB7XG4gICAgICAgIHRoaXMuX3Byb2dyYW0gPSBuZXcgY2MuR0xQcm9ncmFtKCk7XG4gICAgICAgIGlmIChjYy5zeXMuaXNOYXRpdmUpIHtcbiAgICAgICAgICAgIGNjLmxvZyhcInVzZSBuYXRpdmUgR0xQcm9ncmFtXCIpO1xuICAgICAgICAgICAgdGhpcy5fcHJvZ3JhbS5pbml0V2l0aFN0cmluZyhfZGVmYXVsdF92ZXJ0X25vX212cCwgX2JsYWNrX3doaXRlX2ZyYWcpO1xuICAgICAgICAgICAgdGhpcy5fcHJvZ3JhbS5saW5rKCk7XG4gICAgICAgICAgICB0aGlzLl9wcm9ncmFtLnVwZGF0ZVVuaWZvcm1zKCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLl9wcm9ncmFtLmluaXRXaXRoVmVydGV4U2hhZGVyQnl0ZUFycmF5KF9kZWZhdWx0X3ZlcnQsIF9ibGFja193aGl0ZV9mcmFnKTtcbiAgICAgICAgICAgIHRoaXMuX3Byb2dyYW0uYWRkQXR0cmlidXRlKGNjLm1hY3JvLkFUVFJJQlVURV9OQU1FX1BPU0lUSU9OLCBjYy5tYWNyby5WRVJURVhfQVRUUklCX1BPU0lUSU9OKTtcbiAgICAgICAgICAgIHRoaXMuX3Byb2dyYW0uYWRkQXR0cmlidXRlKGNjLm1hY3JvLkFUVFJJQlVURV9OQU1FX0NPTE9SLCBjYy5tYWNyby5WRVJURVhfQVRUUklCX0NPTE9SKTtcbiAgICAgICAgICAgIHRoaXMuX3Byb2dyYW0uYWRkQXR0cmlidXRlKGNjLm1hY3JvLkFUVFJJQlVURV9OQU1FX1RFWF9DT09SRCwgY2MubWFjcm8uVkVSVEVYX0FUVFJJQl9URVhfQ09PUkRTKTtcbiAgICAgICAgICAgIHRoaXMuX3Byb2dyYW0ubGluaygpO1xuICAgICAgICAgICAgdGhpcy5fcHJvZ3JhbS51cGRhdGVVbmlmb3JtcygpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuc2V0UHJvZ3JhbSh0aGlzLm5vZGUuX3NnTm9kZSwgdGhpcy5fcHJvZ3JhbSk7XG4gICAgfSxcbiAgICBzZXRQcm9ncmFtOiBmdW5jdGlvbiBzZXRQcm9ncmFtKG5vZGUsIHByb2dyYW0pIHtcblxuICAgICAgICBpZiAoY2Muc3lzLmlzTmF0aXZlKSB7XG4gICAgICAgICAgICB2YXIgZ2xQcm9ncmFtX3N0YXRlID0gY2MuR0xQcm9ncmFtU3RhdGUuZ2V0T3JDcmVhdGVXaXRoR0xQcm9ncmFtKHByb2dyYW0pO1xuICAgICAgICAgICAgbm9kZS5zZXRHTFByb2dyYW1TdGF0ZShnbFByb2dyYW1fc3RhdGUpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgbm9kZS5zZXRTaGFkZXJQcm9ncmFtKHByb2dyYW0pO1xuICAgICAgICB9XG5cbiAgICAgICAgdmFyIGNoaWxkcmVuID0gbm9kZS5jaGlsZHJlbjtcbiAgICAgICAgaWYgKCFjaGlsZHJlbikgcmV0dXJuO1xuXG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgY2hpbGRyZW4ubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIHRoaXMuc2V0UHJvZ3JhbShjaGlsZHJlbltpXSwgcHJvZ3JhbSk7XG4gICAgICAgIH1cbiAgICB9XG5cbn0pO1xuXG5jYy5CbGFja1doaXRlID0gbW9kdWxlLmV4cG9ydHMgPSBFZmZlY3RCbGFja1doaXRlO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnZWUzNDdzcVROeERQTHFwc1lSaXZoUVUnLCAnQnV0dG9uU2NhbGVyJyk7XG4vLyBHbG9iYWwvcWlzdUxpYi9TaG93L0J1dHRvblNjYWxlci5qc1xuXG52YXIgR2xvYmFsTWFuYWdlciA9IHJlcXVpcmUoXCJHbG9iYWxNYW5hZ2VyXCIpO1xuXG5jYy5DbGFzcyh7XG4gICAgXCJleHRlbmRzXCI6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgcHJlc3NlZFNjYWxlOiAwLjgsXG4gICAgICAgIHRyYW5zRHVyYXRpb246IDAuMSxcblxuICAgICAgICBzdHJTb3VuZDogXCJidXR0b24ubXAzXCJcbiAgICB9LFxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge1xuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgICAgIHNlbGYuaW5pdFNjYWxlID0gdGhpcy5ub2RlLnNjYWxlO1xuICAgICAgICBzZWxmLnNjYWxlRG93bkFjdGlvbiA9IGNjLnNjYWxlVG8oc2VsZi50cmFuc0R1cmF0aW9uLCBzZWxmLnByZXNzZWRTY2FsZSk7XG4gICAgICAgIHNlbGYuc2NhbGVVcEFjdGlvbiA9IGNjLnNjYWxlVG8oc2VsZi50cmFuc0R1cmF0aW9uLCBzZWxmLmluaXRTY2FsZSk7XG4gICAgICAgIGZ1bmN0aW9uIG9uVG91Y2hEb3duKGV2ZW50KSB7XG4gICAgICAgICAgICB0aGlzLnN0b3BBbGxBY3Rpb25zKCk7XG4gICAgICAgICAgICB0aGlzLnJ1bkFjdGlvbihzZWxmLnNjYWxlRG93bkFjdGlvbik7XG4gICAgICAgIH1cbiAgICAgICAgZnVuY3Rpb24gb25Ub3VjaEVuZChldmVudCkge1xuXG4gICAgICAgICAgICBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLmF1ZGlvLnBsYXlFZmZlY3Qoc2VsZi5zdHJTb3VuZCwgZmFsc2UpO1xuXG4gICAgICAgICAgICB0aGlzLnN0b3BBbGxBY3Rpb25zKCk7XG4gICAgICAgICAgICB0aGlzLnJ1bkFjdGlvbihzZWxmLnNjYWxlVXBBY3Rpb24pO1xuICAgICAgICB9XG4gICAgICAgIGZ1bmN0aW9uIG9uVG91Y2hVcChldmVudCkge1xuICAgICAgICAgICAgdGhpcy5zdG9wQWxsQWN0aW9ucygpO1xuICAgICAgICAgICAgdGhpcy5ydW5BY3Rpb24oc2VsZi5zY2FsZVVwQWN0aW9uKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLm5vZGUub24oJ3RvdWNoc3RhcnQnLCBvblRvdWNoRG93biwgdGhpcy5ub2RlKTtcbiAgICAgICAgdGhpcy5ub2RlLm9uKCd0b3VjaGVuZCcsIG9uVG91Y2hFbmQsIHRoaXMubm9kZSk7XG4gICAgICAgIHRoaXMubm9kZS5vbigndG91Y2htb3ZlJywgb25Ub3VjaFVwLCB0aGlzLm5vZGUpO1xuICAgICAgICB0aGlzLm5vZGUub24oJ3RvdWNoY2FuY2VsJywgb25Ub3VjaFVwLCB0aGlzLm5vZGUpO1xuICAgIH1cbn0pO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnMGU1NzVuR09uSkJ1cG81eExEbTNGaVAnLCAnQ29uZkRhdGEnKTtcbi8vIEdsb2JhbC9zZXJ2aWNlL2RhdGEvQ29uZkRhdGEuanNcblxudmFyIENvbmZEYXRhID0gY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgICBiSG9sZFBsYXllcnNJbmZvOiBmYWxzZSxcblxuICAgICAgICBhcnJDb25mUGFzaDogW10gfSxcbiAgICAvLyB7cGF0aCAvIGNvbnRlbnR9XG4gICAgc3RhdGljczoge1xuICAgICAgICBKc29uSW5kZXg6IG51bGxcbiAgICB9LFxuXG4gICAgbG9hZENhbGxCYWNrOiBmdW5jdGlvbiBsb2FkQ2FsbEJhY2soaW5kZXgsIGNhbGxiYWNrKSB7XG5cbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgICAgICBpZiAoaW5kZXggPj0gc2VsZi5hcnJDb25mUGFzaC5sZW5ndGgpIHtcbiAgICAgICAgICAgIGNhbGxiYWNrKCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY2MubG9hZGVyLmxvYWRSZXMoc2VsZi5hcnJDb25mUGFzaFtpbmRleF0ucGF0aCwgZnVuY3Rpb24gKGVycm9yLCByZXNPYmopIHtcbiAgICAgICAgICAgIHNlbGYuYXJyQ29uZlBhc2hbaW5kZXhdLmNvbnRlbnQgPSByZXNPYmo7XG4gICAgICAgICAgICBzZWxmLmxvYWRDYWxsQmFjayhpbmRleCArIDEsIGNhbGxiYWNrKTtcbiAgICAgICAgfSk7XG4gICAgfSxcblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge1xuICAgICAgICBDb25mRGF0YS5Kc29uSW5kZXggPSBjYy5FbnVtKHtcbiAgICAgICAgICAgIE9USEVSOiAwLFxuICAgICAgICAgICAgVF9HQU1FX0tJTkQ6IDEsXG4gICAgICAgICAgICBUX0dBTUVfTk9ERTogMixcbiAgICAgICAgICAgIFRfR0FNRV9ST09NOiAzLFxuICAgICAgICAgICAgVF9HQU1FX1RZUEU6IDQsXG4gICAgICAgICAgICBUX1JPT01fQVJFQTogNSxcbiAgICAgICAgICAgIFRfU0VSVkVSX0lORk86IDYsXG4gICAgICAgICAgICBUX0dPT0RTOiA3XG4gICAgICAgIH0pO1xuICAgIH0sXG4gICAgY2FsbGJhY2s6IGZ1bmN0aW9uIGNhbGxiYWNrKCkge30sXG4gICAgbG9hZENvbmZKc29uOiBmdW5jdGlvbiBsb2FkQ29uZkpzb24oY2FsbGJhY2spIHtcbiAgICAgICAgdGhpcy5hcnJDb25mUGFzaC5wdXNoKHsgXCJwYXRoXCI6IFwiY29tbW9uL2pzb25Db25mL1BsYXRmb3JtL290aGVyXCIsIFwiY29udGVudFwiOiBudWxsIH0pO1xuICAgICAgICB0aGlzLmFyckNvbmZQYXNoLnB1c2goeyBcInBhdGhcIjogXCJjb21tb24vanNvbkNvbmYvUGxhdGZvcm0vdF9nYW1lX2tpbmRcIiwgXCJjb250ZW50XCI6IG51bGwgfSk7XG4gICAgICAgIHRoaXMuYXJyQ29uZlBhc2gucHVzaCh7IFwicGF0aFwiOiBcImNvbW1vbi9qc29uQ29uZi9QbGF0Zm9ybS90X2dhbWVfbm9kZVwiLCBcImNvbnRlbnRcIjogbnVsbCB9KTtcbiAgICAgICAgdGhpcy5hcnJDb25mUGFzaC5wdXNoKHsgXCJwYXRoXCI6IFwiY29tbW9uL2pzb25Db25mL1BsYXRmb3JtL3RfZ2FtZV9yb29tXCIsIFwiY29udGVudFwiOiBudWxsIH0pO1xuICAgICAgICB0aGlzLmFyckNvbmZQYXNoLnB1c2goeyBcInBhdGhcIjogXCJjb21tb24vanNvbkNvbmYvUGxhdGZvcm0vdF9nYW1lX3R5cGVcIiwgXCJjb250ZW50XCI6IG51bGwgfSk7XG4gICAgICAgIHRoaXMuYXJyQ29uZlBhc2gucHVzaCh7IFwicGF0aFwiOiBcImNvbW1vbi9qc29uQ29uZi9QbGF0Zm9ybS90X3Jvb21fYXJlYVwiLCBcImNvbnRlbnRcIjogbnVsbCB9KTtcbiAgICAgICAgdGhpcy5hcnJDb25mUGFzaC5wdXNoKHsgXCJwYXRoXCI6IFwiY29tbW9uL2pzb25Db25mL1BsYXRmb3JtL3Rfc2VydmVyX2luZm9cIiwgXCJjb250ZW50XCI6IG51bGwgfSk7XG4gICAgICAgIHRoaXMuYXJyQ29uZlBhc2gucHVzaCh7IFwicGF0aFwiOiBcImNvbW1vbi9qc29uQ29uZi9QbGF0Zm9ybS90X2dvb2RzXCIsIFwiY29udGVudFwiOiBudWxsIH0pO1xuICAgICAgICB0aGlzLmxvYWRDYWxsQmFjaygwLCB0aGlzLmNhbGxiYWNrKTtcbiAgICB9LFxuXG4gICAgZ2V0Q29uZkpzb246IGZ1bmN0aW9uIGdldENvbmZKc29uKGluZGV4KSB7XG4gICAgICAgIHJldHVybiB0aGlzLmFyckNvbmZQYXNoW2luZGV4XTtcbiAgICB9LFxuXG4gICAgZ2V0S2luZEJhc2VJbmZvOiBmdW5jdGlvbiBnZXRLaW5kQmFzZUluZm8oa2luZElkKSB7XG4gICAgICAgIHZhciBjb250ZW50ID0gdGhpcy5hcnJDb25mUGFzaFtDb25mRGF0YS5Kc29uSW5kZXguVF9HQU1FX0tJTkRdLmNvbnRlbnQ7XG4gICAgICAgIHZhciBraW5kQmFzZWluZm8gPSBjb250ZW50LmtpbmRCYXNlaW5mbztcbiAgICAgICAgZm9yICh2YXIga2V5IGluIGtpbmRCYXNlaW5mbykge1xuICAgICAgICAgICAgaWYgKGtpbmRCYXNlaW5mb1trZXldLkZraW5kX2lkID09IGtpbmRJZCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBraW5kQmFzZWluZm9ba2V5XTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9LFxuXG4gICAgZ2V0S2luZEJhc2VJbmZvczogZnVuY3Rpb24gZ2V0S2luZEJhc2VJbmZvcyh0eXBlSWQpIC8vIHR5cGVJZDowICDooajnpLrmi4nlj5blhajpg6hcbiAgICB7XG4gICAgICAgIHZhciBraW5kQmFzZWluZm9zID0gdGhpcy5hcnJDb25mUGFzaFtDb25mRGF0YS5Kc29uSW5kZXguVF9HQU1FX0tJTkRdLmNvbnRlbnQua2luZEJhc2VpbmZvO1xuICAgICAgICBpZiAodHlwZUlkID09IDApIHtcbiAgICAgICAgICAgIHJldHVybiBraW5kQmFzZWluZm9zO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdmFyIHRlbXBLaW5kQmFzZUluZm9zID0gW107XG4gICAgICAgICAgICBmb3IgKHZhciBrZXkgaW4ga2luZEJhc2VpbmZvcykge1xuICAgICAgICAgICAgICAgIGlmIChraW5kQmFzZWluZm9zW2tleV0uRnR5cGVfaWQgPT0gdHlwZUlkKSB7XG4gICAgICAgICAgICAgICAgICAgIHRlbXBLaW5kQmFzZUluZm9zLnB1c2goa2luZEJhc2VpbmZvc1trZXldKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gdGVtcEtpbmRCYXNlSW5mb3M7XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgZ2V0U2NlbmVMb2FkUmVzOiBmdW5jdGlvbiBnZXRTY2VuZUxvYWRSZXMoa2luZElkLCBzY2VuZU5hbWUpIHtcbiAgICAgICAgdmFyIGJhc2VJbmZvID0gdGhpcy5nZXRLaW5kQmFzZUluZm8oa2luZElkKTtcbiAgICAgICAgdmFyIHVybCA9IHRoaXMuYXJyQ29uZlBhc2hbQ29uZkRhdGEuSnNvbkluZGV4LlRfR0FNRV9LSU5EXS5jb250ZW50W2Jhc2VJbmZvLmFsaWFzXVtzY2VuZU5hbWVdO1xuICAgICAgICByZXR1cm4gdXJsO1xuICAgIH0sXG4gICAgZ2V0Um9vbUFyZWE6IGZ1bmN0aW9uIGdldFJvb21BcmVhKGtpbmRJZCwga2luZFNlcSkge1xuICAgICAgICB2YXIgYXJlYUJhc2VpbmZvcyA9IHRoaXMuYXJyQ29uZlBhc2hbQ29uZkRhdGEuSnNvbkluZGV4LlRfUk9PTV9BUkVBXS5jb250ZW50LmFyZWFCYXNlaW5mbztcblxuICAgICAgICBmb3IgKHZhciBrZXkgaW4gYXJlYUJhc2VpbmZvcykge1xuICAgICAgICAgICAgaWYgKGFyZWFCYXNlaW5mb3Nba2V5XS5Ga2luZF9pZCA9PSBraW5kSWQgJiYgYXJlYUJhc2VpbmZvc1trZXldLkZraW5kX3NlcSA9PSBraW5kU2VxKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGFyZWFCYXNlaW5mb3Nba2V5XTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0sXG4gICAgZ2V0R2FtZU5vZGU6IGZ1bmN0aW9uIGdldEdhbWVOb2RlKGFyZWFJZCkge1xuICAgICAgICB2YXIgYXJlYVNlcSA9IGFyZ3VtZW50cy5sZW5ndGggPD0gMSB8fCBhcmd1bWVudHNbMV0gPT09IHVuZGVmaW5lZCA/IG51bGwgOiBhcmd1bWVudHNbMV07XG5cbiAgICAgICAgdmFyIG5vZGVCYXNlaW5mb3MgPSB0aGlzLmFyckNvbmZQYXNoW0NvbmZEYXRhLkpzb25JbmRleC5UX0dBTUVfTk9ERV0uY29udGVudC5ub2RlQmFzZWluZm87XG4gICAgICAgIGlmIChhcmVhU2VxID09IG51bGwpIHtcbiAgICAgICAgICAgIHZhciB0ZW1wTm9kZXMgPSBbXTtcbiAgICAgICAgICAgIGZvciAodmFyIGtleSBpbiBub2RlQmFzZWluZm9zKSB7XG4gICAgICAgICAgICAgICAgaWYgKG5vZGVCYXNlaW5mb3Nba2V5XS5GYXJlYV9pZCA9PSBhcmVhSWQpIHtcbiAgICAgICAgICAgICAgICAgICAgdGVtcE5vZGVzLnB1c2gobm9kZUJhc2VpbmZvc1trZXldKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gdGVtcE5vZGVzO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgZm9yICh2YXIga2V5IGluIG5vZGVCYXNlaW5mb3MpIHtcbiAgICAgICAgICAgICAgICBpZiAobm9kZUJhc2VpbmZvc1trZXldLkZhcmVhX2lkID09IGFyZWFJZCAmJiBub2RlQmFzZWluZm9zW2tleV0uRmFyZWFfc2VxID09IGFyZWFTZXEpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG5vZGVCYXNlaW5mb3Nba2V5XTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9LFxuICAgIGdldEdhbWVSb29tOiBmdW5jdGlvbiBnZXRHYW1lUm9vbShub2RlSWQpIHtcbiAgICAgICAgdmFyIG5vZGVTZXEgPSBhcmd1bWVudHMubGVuZ3RoIDw9IDEgfHwgYXJndW1lbnRzWzFdID09PSB1bmRlZmluZWQgPyBudWxsIDogYXJndW1lbnRzWzFdO1xuXG4gICAgICAgIHZhciByb29tQmFzZWluZm8gPSB0aGlzLmFyckNvbmZQYXNoW0NvbmZEYXRhLkpzb25JbmRleC5UX0dBTUVfUk9PTV0uY29udGVudC5yb29tQmFzZWluZm87XG5cbiAgICAgICAgZm9yICh2YXIga2V5IGluIHJvb21CYXNlaW5mbykge1xuICAgICAgICAgICAgaWYgKHJvb21CYXNlaW5mb1trZXldLkZub2RlX2lkID09IG5vZGVJZCkge1xuICAgICAgICAgICAgICAgIHJldHVybiByb29tQmFzZWluZm9ba2V5XTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0sXG4gICAgZ2V0U2VydmVySW5mbzogZnVuY3Rpb24gZ2V0U2VydmVySW5mbyhzZXJ2ZXJJZCkge1xuICAgICAgICB2YXIgc2VydmVyQmFzZWluZm9zID0gdGhpcy5hcnJDb25mUGFzaFtDb25mRGF0YS5Kc29uSW5kZXguVF9TRVJWRVJfSU5GT10uY29udGVudC5zZXJ2ZXJCYXNlaW5mbztcbiAgICAgICAgaWYgKHNlcnZlcklkID09IDApIHtcbiAgICAgICAgICAgIHJldHVybiBzZXJ2ZXJCYXNlaW5mb3M7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB2YXIgdGVtcFNlcnZlckJhc2VJbmZvcyA9IFtdO1xuICAgICAgICAgICAgZm9yICh2YXIga2V5IGluIHNlcnZlckJhc2VpbmZvcykge1xuICAgICAgICAgICAgICAgIGlmIChzZXJ2ZXJCYXNlaW5mb3Nba2V5XS5Gc2VydmVyX2lkID09IHNlcnZlcklkKSB7XG4gICAgICAgICAgICAgICAgICAgIHRlbXBTZXJ2ZXJCYXNlSW5mb3MucHVzaChzZXJ2ZXJCYXNlaW5mb3Nba2V5XSk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiB0ZW1wU2VydmVyQmFzZUluZm9zWzBdO1xuICAgICAgICB9XG4gICAgfSxcbiAgICBnZXRHb29kc05hbWU6IGZ1bmN0aW9uIGdldEdvb2RzTmFtZShraW5kSWQsIHN1Ykdvb2RzSWQpIC8vIGdvb2RzSWQgPSBraW5kSWQrc3ViR29vZHNJZFxuICAgIHtcbiAgICAgICAgdmFyIG5ld0tpbmRJZCA9IGtpbmRJZC50b1N0cmluZygpO1xuICAgICAgICB2YXIgczEgPSBcIjAwMDBcIiArIG5ld0tpbmRJZDtcbiAgICAgICAgbmV3S2luZElkID0gczEuc3Vic3RyKG5ld0tpbmRJZC5sZW5ndGgsIDQpO1xuXG4gICAgICAgIHZhciBuZXdTdWJHb29kc0lkID0gcGFyc2VJbnQoc3ViR29vZHNJZCkudG9TdHJpbmcoMTYpO1xuICAgICAgICB2YXIgczIgPSBcIjAwMDBcIiArIG5ld1N1Ykdvb2RzSWQ7XG4gICAgICAgIG5ld1N1Ykdvb2RzSWQgPSBzMi5zdWJzdHIobmV3U3ViR29vZHNJZC5sZW5ndGgsIDQpO1xuXG4gICAgICAgIHZhciBnb29kc0lkID0gXCIweFwiICsgbmV3S2luZElkICsgbmV3U3ViR29vZHNJZDtcbiAgICAgICAgdmFyIGdvb2RzID0gdGhpcy5hcnJDb25mUGFzaFtDb25mRGF0YS5Kc29uSW5kZXguVF9HT09EU10uY29udGVudDtcbiAgICAgICAgcmV0dXJuIGdvb2RzW2dvb2RzSWRdO1xuICAgIH1cbn0pO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnNTY3MjRqRnU2Uk4zYmVNK1QzOTdBUGonLCAnQ29uc3REZWYnKTtcbi8vIEdsb2JhbC9zZXJ2aWNlL0NvbnN0RGVmLmpzXG5cbnZhciBDT05ORUNUX0NBTExCQUNLX1NUQVRVUyA9IGNjLkVudW0oe1xuICAgIC8vPT09PT09PT09PT09PT09PT09PeOAkOS4u+WRveS7pOOAkT09PT09PT09PT09PT09PT09PT09PT1cbiAgICBNSUFOX0xPR09OOiAweDAwMDEsXG4gICAgTUlBTl9HVUlERTogMHgwMDAyLFxuICAgIE1JQU5fSE9NRTogMHgwMDAzLFxuICAgIE1JQU5fQ0hBVDogMHgwMDA0LFxuXG4gICAgLy89PT09PT09PT09PT09PT09PT3jgJDnmbvlvZXlnLrmma/jgJE9PT09PT09PT09PT09PT09PT09PT09XG4gICAgTE9HT05fV0FJVF9MT0dPTjogMFgwMDAxMDAwMSwgLy8g562J5b6F55m75b2VXG4gICAgTE9HT05fV0FJVF9SRUdJU1RFUjogMFgwMDAxMDAwMiwgLy8g562J5b6F5rOo5YaMXG4gICAgTE9HT05fR0VUX09OTElORV9DT1VOVDogMFgwMDAxMDAwMywgLy8g5ouJ5Y+W5ri45oiP5Zyo57q/546p5a625Lq65pWwXG4gICAgTE9HT05fR0VUX0dBTUVfSU5GTzogMFgwMDAxMDAwNCwgLy8g5ouJ5Y+W5ri45oiP5L+h5oGvXG4gICAgTE9HT05fR0VUX1BMQVlFUlNfQkFTRV9JTkZPOiAwWDAwMDEwMDA1LCAvLyDmi4nlj5bnjqnlrrbln7rmnKzkv6Hmga9cblxuICAgIC8vPT09PT09PT09PT09PT09PT09PeOAkOW8leWvvOWcuuaZr+OAkT09PT09PT09PT09PT09PT09PT09ICBcbiAgICBHVUlERV9TRVRfQ0xJRU5UX0RBVEE6IDBYMDAwMjAwMDEsIC8vIOS/ruaUueS/oeaBr1xuXG4gICAgLy89PT09PT09PT09PT09PT09PT0944CQ6IGK5aSp5Zy65pmv44CRPT09PT09PT09PT09PT09PT09PT1cbiAgICBDSEFUX1dBSVRfQ0hBVDogMFgwMDA0MDAwMSwgLy8g562J5b6F6IGK5aSpXG4gICAgQ0hBVF9XQUlUX0dFVF9DSEFUOiAwWDAwMDQwMDAyLCAvLyDmi4nlj5bogYrlpKnorrDlvZVcbiAgICBDSEFUX1dBSVRfR0VUX1JFTEFUSU9OOiAwWDAwMDQwMDAzLCAvLyDmi4nlj5blpb3lj4vlhbPns7tcbiAgICBDSEFUX1dBSVRfU0VUX1JFTEFUSU9OOiAwWDAwMDQwMDA0LCAvLyDorr7nva7lpb3lj4vlhbPns7tcblxuICAgIC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gXG4gICAgU1RBVFVTX0lOSVQ6IDAgfSk7XG4vLyDliJ3lp4vljJbvvIzml6DliqjkvZxcblxudmFyIEJBQ0tfUEFDS19HT09EU19NQUlOX0lEID0gODAwMDtcbi8vIC0tIFvmiJjmlpflvIDlkK/mqKHlvI9dIC0tXG52YXIgQkFUVExFX09QRU5fTU9ERSA9IGNjLkVudW0oe1xuICAgIFRBQkxFOiAxLCAvLyDmoYzlrZDmqKHlvI9cbiAgICBDT1BZOiAyLCAvLyDlia/mnKzmqKHlvI9cbiAgICBNQUtFOiA0LCAvLyDmkq7lkIjmqKHlvI9cbiAgICBXSUxEOiA4LCAvLyDph47miJjmqKHlvI9cbiAgICBNQVRDSDogMTYsIC8vIOavlOi1m+aooeW8j1xuXG4gICAgQ0FOQ0VMOiAweEZGIH0pO1xuXG4vLyDlj5bmtohcbnZhciBNQVRDSF9NT0RFID0gY2MuRW51bSh7XG4gICAgTk9ORTogMCxcbiAgICBPVVRfQVRfT05DRTogMSxcbiAgICBGSVhFRF9ST1VORDogMixcblxuICAgIGNvbXBhdGlibGVfTUFLRTogMTAxLCAvLyDlhbzlrrnpgJ/phY3mqKHlvI9cbiAgICBjb21wYXRpYmxlX0RBVEU6IDEwMiB9KTtcblxuLy8g5YW85a6557qm5oiY5qih5byPXG52YXIgTUFUQ0hfU1RBVFVTID0gY2MuRW51bSh7XG4gICAgSU5JVDogMCxcbiAgICBXQUlUX1BPT0w6IDEsXG4gICAgUEhBU0VfMV9CRUdJTjogMixcbiAgICBQSEFTRV8xX0VORDogMyxcbiAgICBQSEFTRV8yX0JFR0lOOiA0LFxuICAgIFBIQVNFXzJfRU5EOiA1LFxuICAgIFBIQVNFXzNfQkVHSU46IDYsXG4gICAgUEhBU0VfM19FTkQ6IDcsXG4gICAgT1ZFUjogOCxcbiAgICBFTkQ6IDksXG4gICAgQ0FOQ0VMOiAxMFxufSk7XG5cbnZhciBNQVRDSF9SRVNVTFQgPSBjYy5FbnVtKHtcbiAgICBOT05FOiAwLFxuXG4gICAgT3V0QXRPbmNlX09VVDogMSxcbiAgICBPdXRBdE9uY2VfRE9XTjogMixcbiAgICBPdXRBdE9uY2VfVVA6IDMsXG4gICAgT3V0QXRPbmNlX1dJTjogNCxcblxuICAgIEZpeGVkUm91bmRfT1VUOiAxMCxcbiAgICBGaXhlZFJvdW5kX1VQOiAxMSxcbiAgICBGaXhlZFJvdW5kX1dJTjogMTIsXG5cbiAgICBPTl9HQU1FX09WRVI6IDEwMCxcblxuICAgIFNFTkRfRlVORF9QT09MOiAxMDFcbn0pO1xuXG52YXIgVElNRSA9IGNjLkVudW0oe1xuICAgIERBWV9MT05HOiA4NjQwMCwgLy8gNjAqNjAqMjRcbiAgICBXRUVLX0xPTkc6IDYwNDgwMCwgLy8gREFZX0xPTkcqN1xuICAgIEJFSUpJTkdfVElNRV9NQVJHSU46IDI4ODAwIH0pO1xuXG4vLyA2MCo2MCo4XG52YXIgU0VSVkVSX1VSTCA9IHtcbiAgICBsb2dvbjogXCJ3czovLzIwMy4xOTUuMTI5LjIwMTo5MDA0L1wiLFxuICAgIGdhbWU6IFwiXCIsXG4gICAgY2hhdDogXCJ3czovLzIwMy4xOTUuMTI5LjIwMTo5MDI3L1wiXG59O1xuXG52YXIgRklHSFRfUkVTVUxUID0ge1xuICAgIERSQVc6IDAsXG4gICAgTE9TRTogMSxcbiAgICBXSU46IDIsXG5cbiAgICAvLyDliJrov5vmiL/pl7Tmo4Dmn6XjgIHmiaPpmaRcbiAgICBFTlRFUl9ST09NOiAzLFxuICAgIC8vIOavj+WcuuaImOaWl+WJjee9ruaJo+i0ue+8iOaKveawtO+8iVxuICAgIFBSRV9GSUdIVDogNCxcbiAgICAvLyDmr4/lnLrmiJjmlpfnu5PmnZ/mo4Dmn6VcbiAgICBBRlRFUl9GSUdIVDogNSxcblxuICAgIC8vIOavlOi1m+aKpeWQjei0uVxuICAgIE1BVENIX1NJR046IDYsIC8vIOavlOi1m+aKpeWQjVxuICAgIE1BVENIX1JFVk9LRTogNywgLy8g5pKk6ZSAXG5cbiAgICAvLyAtLSDlhbbku5blpZblirFcbiAgICBOX0NvbnRpbnVlX0FXQVJEOiA4LFxuICAgIE1BVENIX0FXQVJEOiA5IH07XG5cbi8vIOavlOi1m+WlluWKsSjljIXlkKvkuK3pgJTmt5jmsbApXG5cbnZhciBNRVNTQUdFID0ge1xuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgQ01EX01BSU5fS0VSTkVMOiAweDAwMDAsXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICBIRUFSVDogMHgwMDAxLFxuICAgIEhFQVJUX1JTUDogMHgwMDAyLFxuXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICBDTURfTUFJTl9QTEFURk9STTogMHgwMDAxLFxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgQ1JFQVRFX0FDQ09VTlRfUkVROiAweDAwMDEsXG4gICAgQ1JFQVRFX0FDQ09VTlRfU1VDQ0VTUzogMHgwMDAyLFxuICAgIENSRUFURV9BQ0NPVU5UX0ZBSUxFRDogMHgwMDAzLFxuICAgIEdFVF9BQ0NPVU5UX0lEX1JFUTogMHgwMDBhLFxuICAgIEdFVF9BQ0NPVU5UX0lEX1NVQ0NFU1M6IDB4MDAwYixcbiAgICBHRVRfQUNDT1VOVF9JRF9GQUlMRUQ6IDB4MDAwYyxcbiAgICBMT0dPTl9QTEFURk9STV9SRVE6IDB4MDAxMCxcbiAgICBMT0dPTl9QTEFURk9STV9TVUNDRVNTOiAweDAwMTEsXG4gICAgTE9HT05fUExBVEZPUk1fRkFJTEVEOiAweDAwMTIsXG4gICAgU0VORF9ST09NU19OT1RJRlk6IDB4MDAyNSxcbiAgICBTRU5EX1JPT01TX0ZJTklTSDogMHgwMDI2LFxuICAgIFVQREFURV9PTkxJTkVfQ09VTlRfUkVROiAweDAwMjcsXG4gICAgVVBEQVRFX09OTElORV9DT1VOVF9TVUNDRVNTOiAweDAwMjgsXG4gICAgVVBEQVRFX09OTElORV9DT1VOVF9GQUlMRUQ6IDB4MDAyOSxcbiAgICBFTlRFUl9ST09NX1JFUTogMHgwMDJhLFxuICAgIEVOVEVSX1JPT01fU1VDQ0VTUzogMHgwMDJiLFxuICAgIEVOVEVSX1JPT01fRkFJTEVEOiAweDAwMmMsXG4gICAgR0VUX1JPT01fUExBWUVSU19SRVE6IDB4MDAzMCxcbiAgICBTRU5EX1JPT01fUExBWUVSU19OT1RJRlk6IDB4MDAzMSxcbiAgICBTRU5EX1JPT01fVEVBTVNfTk9USUZZOiAweDAwMzIsXG4gICAgU0VORF9ST09NX0JBVFRMRVNfTk9USUZZOiAweDAwMzMsXG4gICAgU0VORF9ST09NX1BMQVlFUlNfRklOSVNIOiAweDAwMzQsXG4gICAgUExBWUVSX0VOVEVSX1JPT01fTk9USUZZOiAweDAwMzUsXG4gICAgUExBWUVSX0xFQVZFX1JPT01fTk9USUZZOiAweDAwMzYsXG4gICAgR0VUX0dBTUVfSU5GT19SRVE6IDB4MDAzYixcbiAgICBHRVRfR0FNRV9JTkZPX1NVQ0NFU1M6IDB4MDAzYyxcbiAgICBHRVRfR0FNRV9JTkZPX0ZBSUxFRDogMHgwMDNkLFxuICAgIEdFVF9QTEFZRVJTX0JBU0VfSU5GT19SRVE6IDB4MDA0MSxcbiAgICBHRVRfUExBWUVSU19CQVNFX0lORk9fU1VDQ0VTUzogMHgwMDQyLFxuICAgIEdFVF9QTEFZRVJTX0JBU0VfSU5GT19GQUlMRUQ6IDB4MDA0MyxcbiAgICBCQUxBTkNFX05PVElGWTogMHgwMDRhLFxuICAgIC8vIC0tIOiBiuWkqVtIVFRQXVxuICAgIENIQVRfUkVROiAweDAwNGIsXG4gICAgQ0hBVF9TVUNDRVNTOiAweDAwNGMsXG4gICAgQ0hBVF9GQUlMRUQ6IDB4MDA0ZCxcbiAgICAvLyAtLSDmi4nlj5bogYrlpKnorrDlvZVbSFRUUF1cbiAgICBHRVRfQ0hBVF9SRVE6IDB4MDA0ZSxcbiAgICBHRVRfQ0hBVF9TVUNDRVNTOiAweDAwNGYsXG4gICAgR0VUX0NIQVRfRkFJTEVEOiAweDAwNTAsXG4gICAgLy8gLS0g5ouJ5Y+W5aW95Y+LW0hUVFBdXG4gICAgR0VUX1JFTEFUSU9OX1JFUTogMHgwMDUxLFxuICAgIEdFVF9SRUxBVElPTl9TVUNDRVNTOiAweDAwNTIsXG4gICAgR0VUX1JFTEFUSU9OX0ZBSUxFRDogMHgwMDUzLFxuICAgIC8vIC0tIOWlveWPi+WPguaVsOS/ruaUue+8iOWFs+azqOOAgeeyieS4neOAgem7keWQjeWNleOAgeaci+WPi+WciOadg+mZkOetie+8iVtIVFRQXVxuICAgIFNFVF9SRUxBVElPTl9SRVE6IDB4MDA1NCxcbiAgICBTRVRfUkVMQVRJT05fU1VDQ0VTUzogMHgwMDU1LFxuICAgIFNFVF9SRUxBVElPTl9GQUlMRUQ6IDB4MDA1NixcblxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgQ01EX01BSU5fR0FNRTogMHgwMDAyLFxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgTEVBVkVfVEVBTV9SRVE6IDB4MDAwOSxcbiAgICBMRUFWRV9URUFNX05PVElGWTogMHgwMDBjLFxuICAgIFRFQU1fQUxMX1JFQURZX1JFUTogMHgwMDE4LFxuICAgIFRFQU1fQUxMX1JFQURZX1NVQ0NFU1M6IDB4MDAxOSxcbiAgICBURUFNX0FMTF9SRUFEWV9GQUlMRUQ6IDB4MDAxYSxcbiAgICBURUFNX0FMTF9SRUFEWV9OT1RJRlk6IDB4MDAxYixcbiAgICBFTlRFUl9CQVRUTEVfUkVROiAweDAwMjQsXG4gICAgRU5URVJfQkFUVExFX1NVQ0NFU1M6IDB4MDAyNSxcbiAgICBFTlRFUl9CQVRUTEVfRkFJTEVEOiAweDAwMjYsXG4gICAgRU5URVJfQkFUVExFX05PVElGWTogMHgwMDI3LFxuICAgIEZJR0hUX1JFQURZX1JFUTogMHgwMDJkLFxuICAgIEZJR0hUX1JFQURZX1NVQ0NFU1M6IDB4MDAyZSxcbiAgICBGSUdIVF9SRUFEWV9GQUlMRUQ6IDB4MDAyZixcbiAgICBGSUdIVF9SRUFEWV9OT1RJRlk6IDB4MDAzMCxcbiAgICBTQ0VORV9SRUFEWV9SRVE6IDB4MDAzMSxcbiAgICBTQ0VORV9SRUFEWV9TVUNDRVNTOiAweDAwMzIsXG4gICAgU0NFTkVfUkVBRFlfRkFJTEVEOiAweDAwMzMsXG4gICAgU0NFTkVfUkVBRFlfTk9USUZZOiAweDAwMzQsXG4gICAgRklHSFRfQkVHSU5fTk9USUZZOiAweDAwMzUsXG4gICAgRklHSFRfRU5EX05PVElGWTogMHgwMDM2LFxuICAgIEZJR0hUX1NUQVRVU19OT1RJRlk6IDB4MDAzNyxcbiAgICBHRVRfVEVBTV9NRU1CRVJTX1JFUTogMHgwMDM4LFxuICAgIEdFVF9URUFNX01FTUJFUlNfU1VDQ0VTUzogMHgwMDM5LFxuICAgIEdFVF9URUFNX01FTUJFUlNfRkFJTEVEOiAweDAwNDAsXG4gICAgR0VUX01BVENIX0RBVEFfTk9USUZZOiAweDAwM2IsXG4gICAgLy8gLS0g5ouJ5Y+W5q+U6LWb5Lq65pWw77yI5Lq65ruh5Y2z5byA44CB5Y2B5YiG6ZKf5byA6LWb562J5bm25Y+R5q+U6LWb77yJXG4gICAgR0VUX01BVENIX0NVUl9DT1VOVF9SRVE6IDB4MDAzYyxcbiAgICBHRVRfTUFUQ0hfQ1VSX0NPVU5UX1NVQ0NFU1M6IDB4MDAzZCxcbiAgICBHRVRfTUFUQ0hfQ1VSX0NPVU5UX0ZBSUxFRDogMHgwMDNlXG59O1xuXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICAgIENPTk5FQ1RfQ0FMTEJBQ0tfU1RBVFVTOiBDT05ORUNUX0NBTExCQUNLX1NUQVRVUyxcbiAgICBUSU1FOiBUSU1FLFxuICAgIEJBQ0tfUEFDS19HT09EU19NQUlOX0lEOiBCQUNLX1BBQ0tfR09PRFNfTUFJTl9JRCxcbiAgICBCQVRUTEVfT1BFTl9NT0RFOiBCQVRUTEVfT1BFTl9NT0RFLFxuICAgIE1BVENIX01PREU6IE1BVENIX01PREUsXG4gICAgTUFUQ0hfU1RBVFVTOiBNQVRDSF9TVEFUVVMsXG4gICAgTUFUQ0hfUkVTVUxUOiBNQVRDSF9SRVNVTFQsXG4gICAgRklHSFRfUkVTVUxUOiBGSUdIVF9SRVNVTFQsXG4gICAgU0VSVkVSX1VSTDogU0VSVkVSX1VSTCxcbiAgICBNRVNTQUdFOiBNRVNTQUdFXG59O1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnYjk5ZjRqd0hHSkJGNUdXVDdWWFJOb00nLCAnR2xvYmFsTWFuYWdlcicpO1xuLy8gR2xvYmFsL3NlcnZpY2UvR2xvYmFsTWFuYWdlci5qc1xuXG52YXIgY29uc3REZWYgPSByZXF1aXJlKFwiQ29uc3REZWZcIik7XG52YXIgbWVzc2FnZUhhbmRsZSA9IHJlcXVpcmUoXCJNZXNzYWdlSGFuZGxlXCIpO1xudmFyIFByb3RvY29sTWVzc2FnZSA9IHJlcXVpcmUoXCJQcm90b2NvbE1lc3NhZ2VcIik7XG52YXIgSGludE1hbmFnZXIgPSByZXF1aXJlKFwiSGludE1hbmFnZXJcIik7XG52YXIgVXRpbHMgPSByZXF1aXJlKFwiVXRpbHNcIik7XG5cbnZhciBHbG9iYWxNYW5hZ2VyID0gY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIHNlbGZEYXRhOiByZXF1aXJlKFwiU2VsZkRhdGFcIiksXG5cbiAgICAgICAgY29uZkRhdGE6IHJlcXVpcmUoXCJDb25mRGF0YVwiKSxcblxuICAgICAgICBzZXJ2ZXJEYXRhOiByZXF1aXJlKFwiU2VydmVyRGF0YVwiKSxcblxuICAgICAgICBhdWRpbzogcmVxdWlyZShcIkF1ZGlvTWFuYWdlclwiKSxcblxuICAgICAgICBoaW50OiB7XG4gICAgICAgICAgICBcImRlZmF1bHRcIjogbnVsbCxcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGVcbiAgICAgICAgfSxcbiAgICAgICAgbG9hZDoge1xuICAgICAgICAgICAgXCJkZWZhdWx0XCI6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlXG4gICAgICAgIH0sXG4gICAgICAgIGdhbWU6IHtcbiAgICAgICAgICAgIFwiZGVmYXVsdFwiOiBudWxsLFxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZVxuICAgICAgICB9LFxuICAgICAgICB2ZWN0TG9nb25Nc2c6IFtdLFxuICAgICAgICB2ZWN0R2FtZU1zZzogW10sXG4gICAgICAgIHZlY3RDaGF0TXNnOiBbXVxuICAgIH0sXG5cbiAgICBzdGF0aWNzOiB7XG4gICAgICAgIGluc3RhbmNlOiBudWxsXG4gICAgfSxcblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge1xuICAgICAgICBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlID0gdGhpcztcbiAgICAgICAgY2MuZ2FtZS5hZGRQZXJzaXN0Um9vdE5vZGUodGhpcy5ub2RlKTtcblxuICAgICAgICBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLlNvY2tldE1hbmFnZXIgPSByZXF1aXJlKFwiVVNvY2tldFwiKTtcbiAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5Tb2NrZXRNYW5hZ2VyLmluaXQodGhpcy5vcGVuSGFuZGxlciwgdGhpcy5tZXNzYWdlSGFuZGxlciwgdGhpcy5jbG9zZUhhbmRsZXIsIHRoaXMuc2VuZEZhaWxlZEhhbmRsZXIsIHRydWUpO1xuXG4gICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2Uuc2NoZWR1bGUoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgLy8gLS0g5ZCM5pe25pyA5aSa5Y+q6IO96L+e5o6lIDEg5Liq5ri45oiP5pyN5Yqh5ZmoXG4gICAgICAgICAgICBpZiAoR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5Tb2NrZXRNYW5hZ2VyLklzQ29ubmVjdGVkKGNvbnN0RGVmLlNFUlZFUl9VUkwuZ2FtZSkpIHtcbiAgICAgICAgICAgICAgICB2YXIgbm93VFMgPSBNYXRoLmZsb29yKG5ldyBEYXRlKCkuZ2V0VGltZSgpIC8gMTAwMCk7XG4gICAgICAgICAgICAgICAgaWYgKG5vd1RTIC0gR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5zZWxmRGF0YS5uSGVhcnRSc3BUUyA+PSA1KSB7XG4gICAgICAgICAgICAgICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuU29ja2V0TWFuYWdlci5DbG9zZVNvY2tldChjb25zdERlZi5TRVJWRVJfVVJMLmdhbWUpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBtc2cgPSBuZXcgUHJvdG9jb2xNZXNzYWdlKGNvbnN0RGVmLk1FU1NBR0UuQ01EX01BSU5fS0VSTkVMLCBjb25zdERlZi5NRVNTQUdFLkhFQVJULCBmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuU29ja2V0TWFuYWdlci5TZW5kTWVzc2FnZShjb25zdERlZi5TRVJWRVJfVVJMLmdhbWUsIG1zZyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9LCAxKTtcblxuICAgICAgICBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLnNjaGVkdWxlKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGlmIChHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLnNlbGZEYXRhLm5CYXR0bGVJRCAhPT0gMCkge1xuICAgICAgICAgICAgICAgIGlmICghR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5Tb2NrZXRNYW5hZ2VyLklzQ29ubmVjdGVkKGNvbnN0RGVmLlNFUlZFUl9VUkwuZ2FtZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIGN1ckNvbXAgPSBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLmhpbnQuZ2V0Q29tcG9uZW50KFwiSGludE1hbmFnZXJcIik7XG4gICAgICAgICAgICAgICAgICAgIGN1ckNvbXAuU2hvd0hpbnQoXCLnvZHnu5zmlq3lvIDvvIzmraPlnKjph43mlrDov57mjqXjgILjgILjgIJcIiwgSGludE1hbmFnZXIuSGludE1vZGUuTk9ORV9CVVRUT04pO1xuICAgICAgICAgICAgICAgICAgICBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLkdldEdhbWVDb250cm9sbGVyKEdsb2JhbE1hbmFnZXIuaW5zdGFuY2Uuc2VsZkRhdGEubkN1ckdhbWVJRCkuU2VuZE1zZyhnYW1lQ29uc3REZWYuQ09OTkVDVF9DQUxMQkFDS19TVEFUVVMuSE9NRV9FTlRFUl9ST09NKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sIDMpO1xuXG4gICAgICAgIHRoaXMuUmVnTXNnSGFuZGxlcihjb25zdERlZi5NRVNTQUdFLkNNRF9NQUlOX0tFUk5FTCwgY29uc3REZWYuTUVTU0FHRS5IRUFSVF9SU1AsIG1lc3NhZ2VIYW5kbGUuaGFuZGxlcl9IRUFSVF9SU1ApO1xuICAgICAgICB0aGlzLlJlZ01zZ0hhbmRsZXIoY29uc3REZWYuTUVTU0FHRS5DTURfTUFJTl9QTEFURk9STSwgY29uc3REZWYuTUVTU0FHRS5DUkVBVEVfQUNDT1VOVF9TVUNDRVNTLCBtZXNzYWdlSGFuZGxlLmhhbmRsZXJfQ1JFQVRFX0FDQ09VTlRfU1VDQ0VTUyk7XG4gICAgICAgIHRoaXMuUmVnTXNnSGFuZGxlcihjb25zdERlZi5NRVNTQUdFLkNNRF9NQUlOX1BMQVRGT1JNLCBjb25zdERlZi5NRVNTQUdFLkNSRUFURV9BQ0NPVU5UX0ZBSUxFRCwgbWVzc2FnZUhhbmRsZS5oYW5kbGVyX0NSRUFURV9BQ0NPVU5UX0ZBSUxFRCk7XG4gICAgICAgIHRoaXMuUmVnTXNnSGFuZGxlcihjb25zdERlZi5NRVNTQUdFLkNNRF9NQUlOX1BMQVRGT1JNLCBjb25zdERlZi5NRVNTQUdFLkxPR09OX1BMQVRGT1JNX1NVQ0NFU1MsIG1lc3NhZ2VIYW5kbGUuaGFuZGxlcl9MT0dPTl9QTEFURk9STV9TVUNDRVNTKTtcbiAgICAgICAgdGhpcy5SZWdNc2dIYW5kbGVyKGNvbnN0RGVmLk1FU1NBR0UuQ01EX01BSU5fUExBVEZPUk0sIGNvbnN0RGVmLk1FU1NBR0UuTE9HT05fUExBVEZPUk1fRkFJTEVELCBtZXNzYWdlSGFuZGxlLmhhbmRsZXJfTE9HT05fUExBVEZPUk1fRkFJTEVEKTtcbiAgICAgICAgdGhpcy5SZWdNc2dIYW5kbGVyKGNvbnN0RGVmLk1FU1NBR0UuQ01EX01BSU5fUExBVEZPUk0sIGNvbnN0RGVmLk1FU1NBR0UuVVBEQVRFX09OTElORV9DT1VOVF9TVUNDRVNTLCBtZXNzYWdlSGFuZGxlLmhhbmRsZXJfVVBEQVRFX09OTElORV9DT1VOVF9TVUNDRVNTKTtcbiAgICAgICAgdGhpcy5SZWdNc2dIYW5kbGVyKGNvbnN0RGVmLk1FU1NBR0UuQ01EX01BSU5fUExBVEZPUk0sIGNvbnN0RGVmLk1FU1NBR0UuVVBEQVRFX09OTElORV9DT1VOVF9GQUlMRUQsIG1lc3NhZ2VIYW5kbGUuaGFuZGxlcl9VUERBVEVfT05MSU5FX0NPVU5UX0ZBSUxFRCk7XG4gICAgICAgIC8vY2hhdOebuOWFs1xuICAgICAgICB0aGlzLlJlZ01zZ0hhbmRsZXIoY29uc3REZWYuTUVTU0FHRS5DTURfTUFJTl9QTEFURk9STSwgY29uc3REZWYuTUVTU0FHRS5DSEFUX1NVQ0NFU1MsIG1lc3NhZ2VIYW5kbGUuaGFuZGxlcl9DSEFUX1NVQ0NFU1MpO1xuICAgICAgICB0aGlzLlJlZ01zZ0hhbmRsZXIoY29uc3REZWYuTUVTU0FHRS5DTURfTUFJTl9QTEFURk9STSwgY29uc3REZWYuTUVTU0FHRS5DSEFUX0ZBSUxFRCwgbWVzc2FnZUhhbmRsZS5oYW5kbGVyX0NIQVRfRkFJTEVEKTtcbiAgICAgICAgdGhpcy5SZWdNc2dIYW5kbGVyKGNvbnN0RGVmLk1FU1NBR0UuQ01EX01BSU5fUExBVEZPUk0sIGNvbnN0RGVmLk1FU1NBR0UuR0VUX0NIQVRfU1VDQ0VTUywgbWVzc2FnZUhhbmRsZS5oYW5kbGVyX0dFVF9DSEFUX1NVQ0NFU1MpO1xuICAgICAgICB0aGlzLlJlZ01zZ0hhbmRsZXIoY29uc3REZWYuTUVTU0FHRS5DTURfTUFJTl9QTEFURk9STSwgY29uc3REZWYuTUVTU0FHRS5HRVRfQ0hBVF9GQUlMRUQsIG1lc3NhZ2VIYW5kbGUuaGFuZGxlcl9HRVRfQ0hBVF9GQUlMRUQpO1xuICAgICAgICB0aGlzLlJlZ01zZ0hhbmRsZXIoY29uc3REZWYuTUVTU0FHRS5DTURfTUFJTl9QTEFURk9STSwgY29uc3REZWYuTUVTU0FHRS5HRVRfUkVMQVRJT05fU1VDQ0VTUywgbWVzc2FnZUhhbmRsZS5oYW5kbGVyX0dFVF9SRUxBVElPTl9TVUNDRVNTKTtcbiAgICAgICAgdGhpcy5SZWdNc2dIYW5kbGVyKGNvbnN0RGVmLk1FU1NBR0UuQ01EX01BSU5fUExBVEZPUk0sIGNvbnN0RGVmLk1FU1NBR0UuR0VUX1JFTEFUSU9OX0ZBSUxFRCwgbWVzc2FnZUhhbmRsZS5oYW5kbGVyX0dFVF9SRUxBVElPTl9GQUlMRUQpO1xuICAgICAgICB0aGlzLlJlZ01zZ0hhbmRsZXIoY29uc3REZWYuTUVTU0FHRS5DTURfTUFJTl9QTEFURk9STSwgY29uc3REZWYuTUVTU0FHRS5TRVRfUkVMQVRJT05fU1VDQ0VTUywgbWVzc2FnZUhhbmRsZS5oYW5kbGVyX1NFVF9SRUxBVElPTl9TVUNDRVNTKTtcbiAgICAgICAgdGhpcy5SZWdNc2dIYW5kbGVyKGNvbnN0RGVmLk1FU1NBR0UuQ01EX01BSU5fUExBVEZPUk0sIGNvbnN0RGVmLk1FU1NBR0UuU0VUX1JFTEFUSU9OX0ZBSUxFRCwgbWVzc2FnZUhhbmRsZS5oYW5kbGVyX1NFVF9SRUxBVElPTl9GQUlMRUQpO1xuICAgIH0sXG5cbiAgICBSZWdNc2dIYW5kbGVyOiBmdW5jdGlvbiBSZWdNc2dIYW5kbGVyKG1haW5JRCwgc3ViSUQsIGZ1bmMpIHtcbiAgICAgICAgdGhpcy5ub2RlLm9uKFwiWzB4XCIgKyBtYWluSUQudG9TdHJpbmcoMTYpICsgXCJdWzB4XCIgKyBzdWJJRC50b1N0cmluZygxNikgKyBcIl1cIiwgZnVuYyk7XG4gICAgfSxcbiAgICBvcGVuSGFuZGxlcjogZnVuY3Rpb24gb3BlbkhhbmRsZXIodXJsKSB7XG4gICAgICAgIGlmICh1cmwgPT0gY29uc3REZWYuU0VSVkVSX1VSTC5sb2dvbikge1xuICAgICAgICAgICAgdmFyIG1zZyA9IEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UudmVjdExvZ29uTXNnLnNoaWZ0KCk7XG5cbiAgICAgICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuU29ja2V0TWFuYWdlci5TZW5kTWVzc2FnZShjb25zdERlZi5TRVJWRVJfVVJMLmxvZ29uLCBtc2cpO1xuICAgICAgICB9IGVsc2UgaWYgKHVybCA9PSBjb25zdERlZi5TRVJWRVJfVVJMLmNoYXQpIHtcbiAgICAgICAgICAgIHZhciBtc2cgPSBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLnZlY3RDaGF0TXNnLnNoaWZ0KCk7XG5cbiAgICAgICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuU29ja2V0TWFuYWdlci5TZW5kTWVzc2FnZShjb25zdERlZi5TRVJWRVJfVVJMLmNoYXQsIG1zZyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLnNlbGZEYXRhLm5IZWFydFJzcFRTID0gTWF0aC5mbG9vcihuZXcgRGF0ZSgpLmdldFRpbWUoKSAvIDEwMDApO1xuXG4gICAgICAgICAgICB2YXIgbXNnID0gR2xvYmFsTWFuYWdlci5pbnN0YW5jZS52ZWN0R2FtZU1zZy5zaGlmdCgpO1xuICAgICAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5Tb2NrZXRNYW5hZ2VyLlNlbmRNZXNzYWdlKGNvbnN0RGVmLlNFUlZFUl9VUkwuZ2FtZSwgbXNnKTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgY2xvc2VIYW5kbGVyOiBmdW5jdGlvbiBjbG9zZUhhbmRsZXIodXJsLCBlcnJDb2RlKSB7XG4gICAgICAgIGlmICh1cmwgPT0gY29uc3REZWYuU0VSVkVSX1VSTC5sb2dvbikge1xuICAgICAgICAgICAgaWYgKEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UudmVjdExvZ29uTXNnLmxlbmd0aCA+IDApIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuQ29ubmVjdExvZ29uU2VydmVyKCk7XG4gICAgICAgIH1cbiAgICB9LFxuICAgIHNlbmRGYWlsZWRIYW5kbGVyOiBmdW5jdGlvbiBzZW5kRmFpbGVkSGFuZGxlcih1cmwpIHt9LFxuICAgIG1lc3NhZ2VIYW5kbGVyOiBmdW5jdGlvbiBtZXNzYWdlSGFuZGxlcihtYWluQ21kSUQsIHN1YkNtZElELCBib2R5TXNnKSB7XG4gICAgICAgIHZhciBzdHJNc2dJRCA9IFwiWzB4XCIgKyBtYWluQ21kSUQudG9TdHJpbmcoMTYpICsgXCJdWzB4XCIgKyBzdWJDbWRJRC50b1N0cmluZygxNikgKyBcIl1cIjtcbiAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5ub2RlLmVtaXQoc3RyTXNnSUQsIHsgbXNnQm9keTogYm9keU1zZywgaW5zdGFuY2VHbG9iYWw6IEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UgfSk7XG4gICAgfSxcbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIEdldFJpZ2h0VGltZTogZnVuY3Rpb24gR2V0UmlnaHRUaW1lKCkge1xuICAgICAgICB2YXIgbG9jYWxUaW1lID0gTWF0aC5mbG9vcihuZXcgRGF0ZSgpLmdldFRpbWUoKSAvIDEwMDApO1xuICAgICAgICByZXR1cm4gR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5zZWxmRGF0YS5uTG9jYWxTZXJ2ZXJUaW1lRGlmZiArIGxvY2FsVGltZTtcbiAgICB9LFxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgR2V0RGF5VHM6IGZ1bmN0aW9uIEdldERheVRzKG5vdykge1xuICAgICAgICB2YXIgZHVyaW5nID0gbm93IC0gKG5vdyArIGNvbnN0RGVmLlRJTUUuQkVJSklOR19USU1FX01BUkdJTikgJSBjb25zdERlZi5USU1FLkRBWV9MT05HO1xuICAgICAgICByZXR1cm4gZHVyaW5nO1xuICAgIH0sXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICBTYXZlVXNlckFjY291bnRQYXNzd29yZDogZnVuY3Rpb24gU2F2ZVVzZXJBY2NvdW50UGFzc3dvcmQoKSB7XG4gICAgICAgIGNjLnN5cy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnYWNjb3VudE5hbWUnLCBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLnNlbGZEYXRhLnNBY2NvdW50TmFtZSk7XG4gICAgICAgIGNjLnN5cy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbSgncGFzc3dvcmQnLCBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLnNlbGZEYXRhLnNQYXNzd29yZCk7XG4gICAgfSxcblxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgR2FtZU5vZGVBZGRDb21wb25lbnQ6IGZ1bmN0aW9uIEdhbWVOb2RlQWRkQ29tcG9uZW50KGdhbWVJZCkge1xuICAgICAgICB2YXIgY2FsbGJhY2sgPSBhcmd1bWVudHMubGVuZ3RoIDw9IDEgfHwgYXJndW1lbnRzWzFdID09PSB1bmRlZmluZWQgPyBudWxsIDogYXJndW1lbnRzWzFdO1xuXG4gICAgICAgIHZhciBnYW1lSW5mbyA9IEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuY29uZkRhdGEuZ2V0S2luZEJhc2VJbmZvKGdhbWVJZCk7XG4gICAgICAgIHZhciBhbGlhcyA9IGdhbWVJbmZvLmFsaWFzO1xuICAgICAgICBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLmdhbWUuYWRkQ29tcG9uZW50KGFsaWFzICsgXCJHYW1lQ29udHJvbGxlclwiKTtcbiAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5nYW1lLmdldENoaWxkQnlOYW1lKFwiZ2FtZURhdGFcIikuYWRkQ29tcG9uZW50KGFsaWFzICsgXCJHYW1lRGF0YVwiKTtcbiAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5nYW1lLmdldENvbXBvbmVudChhbGlhcyArIFwiR2FtZUNvbnRyb2xsZXJcIikuZ2FtZVJlZ2lzdGVyTWVzc2FnZSgpO1xuICAgICAgICBpZiAoY2FsbGJhY2sgIT0gbnVsbCkgY2FsbGJhY2soKTtcbiAgICB9LFxuICAgIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICBHZXRHYW1lRGF0YTogZnVuY3Rpb24gR2V0R2FtZURhdGEoZ2FtZUlkKSB7XG4gICAgICAgIHZhciBnYW1lSW5mbyA9IEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuY29uZkRhdGEuZ2V0S2luZEJhc2VJbmZvKGdhbWVJZCk7XG4gICAgICAgIHZhciBhbGlhcyA9IGdhbWVJbmZvLmFsaWFzO1xuICAgICAgICB2YXIgZ2FtZURhdGEgPSBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLmdhbWUuZ2V0Q2hpbGRCeU5hbWUoXCJnYW1lRGF0YVwiKS5nZXRDb21wb25lbnQoYWxpYXMgKyBcIkdhbWVEYXRhXCIpO1xuICAgICAgICByZXR1cm4gZ2FtZURhdGE7XG4gICAgfSxcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIEdldEdhbWVDb250cm9sbGVyOiBmdW5jdGlvbiBHZXRHYW1lQ29udHJvbGxlcihnYW1lSWQpIHtcblxuICAgICAgICB2YXIgZ2FtZUluZm8gPSBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLmNvbmZEYXRhLmdldEtpbmRCYXNlSW5mbyhnYW1lSWQpO1xuICAgICAgICB2YXIgYWxpYXMgPSBnYW1lSW5mby5hbGlhcztcbiAgICAgICAgdmFyIGdhbWVDb250cm9sbGVyID0gR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5nYW1lLmdldENvbXBvbmVudChhbGlhcyArIFwiR2FtZUNvbnRyb2xsZXJcIik7XG4gICAgICAgIHJldHVybiBnYW1lQ29udHJvbGxlcjtcbiAgICB9LFxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgQ29ubmVjdExvZ29uU2VydmVyOiBmdW5jdGlvbiBDb25uZWN0TG9nb25TZXJ2ZXIoKSB7XG4gICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuU29ja2V0TWFuYWdlci5BZGRTZXJ2ZXIoY29uc3REZWYuU0VSVkVSX1VSTC5sb2dvbik7XG4gICAgfSxcbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIENvbm5lY3RHYW1lU2VydmVyOiBmdW5jdGlvbiBDb25uZWN0R2FtZVNlcnZlcihnYW1lU3RhdHVzKSB7XG4gICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2Uuc2VsZkRhdGEubkdhbWVDb25uZWN0U3RhdHVzID0gZ2FtZVN0YXR1cztcbiAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5Tb2NrZXRNYW5hZ2VyLkFkZFNlcnZlcihjb25zdERlZi5TRVJWRVJfVVJMLmdhbWUpO1xuICAgIH0sXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICBDb25uZWN0Q2hhdFNlcnZlcjogZnVuY3Rpb24gQ29ubmVjdENoYXRTZXJ2ZXIoKSB7XG4gICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuU29ja2V0TWFuYWdlci5BZGRTZXJ2ZXIoY29uc3REZWYuU0VSVkVSX1VSTC5jaGF0KTtcbiAgICB9LFxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgU2VuZExvZ29uTXNnOiBmdW5jdGlvbiBTZW5kTG9nb25Nc2cob2JqTXNnKSB7XG4gICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UudmVjdExvZ29uTXNnLnB1c2gob2JqTXNnKTtcbiAgICAgICAgaWYgKCFHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLlNvY2tldE1hbmFnZXIuSXNDb25uZWN0ZWQoY29uc3REZWYuU0VSVkVSX1VSTC5sb2dvbikpIHtcbiAgICAgICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuQ29ubmVjdExvZ29uU2VydmVyKCk7XG4gICAgICAgIH1cbiAgICB9LFxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgU2VuZEdhbWVNc2c6IGZ1bmN0aW9uIFNlbmRHYW1lTXNnKG9iak1zZykge1xuICAgICAgICBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLnZlY3RHYW1lTXNnLnB1c2gob2JqTXNnKTtcblxuICAgICAgICBpZiAoR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5Tb2NrZXRNYW5hZ2VyLklzQ29ubmVjdGVkKGNvbnN0RGVmLlNFUlZFUl9VUkwuZ2FtZSkpIHtcbiAgICAgICAgICAgIHZhciBtc2cgPSBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLnZlY3RHYW1lTXNnLnNoaWZ0KCk7XG4gICAgICAgICAgICBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLlNvY2tldE1hbmFnZXIuU2VuZE1lc3NhZ2UoY29uc3REZWYuU0VSVkVSX1VSTC5nYW1lLCBtc2cpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5Db25uZWN0R2FtZVNlcnZlcigpO1xuICAgICAgICB9XG4gICAgfSxcbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIFNlbmRDaGF0TXNnOiBmdW5jdGlvbiBTZW5kQ2hhdE1zZyhvYmpNc2cpIHtcbiAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS52ZWN0Q2hhdE1zZy5wdXNoKG9iak1zZyk7XG5cbiAgICAgICAgaWYgKEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuU29ja2V0TWFuYWdlci5Jc0Nvbm5lY3RlZChjb25zdERlZi5TRVJWRVJfVVJMLmNoYXQpKSB7XG4gICAgICAgICAgICB2YXIgbXNnID0gR2xvYmFsTWFuYWdlci5pbnN0YW5jZS52ZWN0Q2hhdE1zZy5zaGlmdCgpO1xuICAgICAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5Tb2NrZXRNYW5hZ2VyLlNlbmRNZXNzYWdlKGNvbnN0RGVmLlNFUlZFUl9VUkwuY2hhdCwgbXNnKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuQ29ubmVjdENoYXRTZXJ2ZXIoKTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICBTZW5kTXNnOiBmdW5jdGlvbiBTZW5kTXNnKHN0YXR1cykge1xuICAgICAgICBzd2l0Y2ggKHN0YXR1cykge1xuICAgICAgICAgICAgY2FzZSBjb25zdERlZi5DT05ORUNUX0NBTExCQUNLX1NUQVRVUy5MT0dPTl9XQUlUX0xPR09OOlxuICAgICAgICAgICAgICAgIHtcblxuICAgICAgICAgICAgICAgICAgICB2YXIgbXNnID0gbmV3IFByb3RvY29sTWVzc2FnZShjb25zdERlZi5NRVNTQUdFLkNNRF9NQUlOX1BMQVRGT1JNLCBjb25zdERlZi5NRVNTQUdFLkxPR09OX1BMQVRGT1JNX1JFUSwgZmFsc2UpO1xuICAgICAgICAgICAgICAgICAgICBQcm90b2NvbE1lc3NhZ2UuQWRkVmVjdEl0ZW1TdHJpbmcobXNnLl9ib2R5X21zZywgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5zZWxmRGF0YS5zQWNjb3VudE5hbWUpO1xuICAgICAgICAgICAgICAgICAgICBQcm90b2NvbE1lc3NhZ2UuQWRkVmVjdEl0ZW1TdHJpbmcobXNnLl9ib2R5X21zZywgVXRpbHMubWQ1RW5jcnlwdChHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLnNlbGZEYXRhLnNQYXNzd29yZCkpO1xuICAgICAgICAgICAgICAgICAgICBQcm90b2NvbE1lc3NhZ2UuQWRkVmVjdEl0ZW1JbnQobXNnLl9ib2R5X21zZywgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5zZWxmRGF0YS5uQ3VyR2FtZUlEKTtcbiAgICAgICAgICAgICAgICAgICAgUHJvdG9jb2xNZXNzYWdlLkFkZFZlY3RJdGVtSW50KG1zZy5fYm9keV9tc2csIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2Uuc2VsZkRhdGEubkN1ckdhbWVJRCk7XG5cbiAgICAgICAgICAgICAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5TZW5kTG9nb25Nc2cobXNnKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSBjb25zdERlZi5DT05ORUNUX0NBTExCQUNLX1NUQVRVUy5MT0dPTl9XQUlUX1JFR0lTVEVSOlxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIG1zZyA9IG5ldyBQcm90b2NvbE1lc3NhZ2UoY29uc3REZWYuTUVTU0FHRS5DTURfTUFJTl9QTEFURk9STSwgY29uc3REZWYuTUVTU0FHRS5DUkVBVEVfQUNDT1VOVF9SRVEsIGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgICAgUHJvdG9jb2xNZXNzYWdlLkFkZFZlY3RJdGVtU3RyaW5nKG1zZy5fYm9keV9tc2csIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2Uuc2VsZkRhdGEuc0FjY291bnROYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgUHJvdG9jb2xNZXNzYWdlLkFkZFZlY3RJdGVtU3RyaW5nKG1zZy5fYm9keV9tc2csIFV0aWxzLm1kNUVuY3J5cHQoR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5zZWxmRGF0YS5zUGFzc3dvcmQpKTtcbiAgICAgICAgICAgICAgICAgICAgUHJvdG9jb2xNZXNzYWdlLkFkZFZlY3RJdGVtSW50KG1zZy5fYm9keV9tc2csIDApO1xuICAgICAgICAgICAgICAgICAgICBQcm90b2NvbE1lc3NhZ2UuQWRkVmVjdEl0ZW1TdHJpbmcobXNnLl9ib2R5X21zZywgXCJcIik7XG4gICAgICAgICAgICAgICAgICAgIFByb3RvY29sTWVzc2FnZS5BZGRWZWN0SXRlbVN0cmluZyhtc2cuX2JvZHlfbXNnLCBcIlwiKTtcbiAgICAgICAgICAgICAgICAgICAgUHJvdG9jb2xNZXNzYWdlLkFkZFZlY3RJdGVtSW50KG1zZy5fYm9keV9tc2csIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2Uuc2VsZkRhdGEubkN1ckdhbWVJRCk7XG4gICAgICAgICAgICAgICAgICAgIFByb3RvY29sTWVzc2FnZS5BZGRWZWN0SXRlbUludChtc2cuX2JvZHlfbXNnLCBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLnNlbGZEYXRhLm5DdXJHYW1lSUQpO1xuICAgICAgICAgICAgICAgICAgICBQcm90b2NvbE1lc3NhZ2UuQWRkVmVjdEl0ZW1CeXRlKG1zZy5fYm9keV9tc2csIDApO1xuICAgICAgICAgICAgICAgICAgICBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLlNlbmRMb2dvbk1zZyhtc2cpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlIGNvbnN0RGVmLkNPTk5FQ1RfQ0FMTEJBQ0tfU1RBVFVTLkxPR09OX0dFVF9PTkxJTkVfQ09VTlQ6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICB2YXIgbXNnID0gbmV3IFByb3RvY29sTWVzc2FnZShjb25zdERlZi5NRVNTQUdFLkNNRF9NQUlOX1BMQVRGT1JNLCBjb25zdERlZi5NRVNTQUdFLlVQREFURV9PTkxJTkVfQ09VTlRfUkVRLCBmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgIFByb3RvY29sTWVzc2FnZS5BZGRWZWN0SXRlbUludChtc2cuX2JvZHlfbXNnLCBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLnNlbGZEYXRhLm5DdXJHYW1lSUQpOyAvLyAw6KGo56S65ouJ5Y+W5omA5pyJ5ri45oiP546p5a625Lq65pWwXG4gICAgICAgICAgICAgICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuU2VuZExvZ29uTXNnKG1zZyk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICAgICAgICAgIGNhc2UgY29uc3REZWYuQ09OTkVDVF9DQUxMQkFDS19TVEFUVVMuQ0hBVF9XQUlUX1NFVF9SRUxBVElPTjpcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBtc2cgPSBuZXcgUHJvdG9jb2xNZXNzYWdlKGNvbnN0RGVmLk1FU1NBR0UuQ01EX01BSU5fUExBVEZPUk0sIGNvbnN0RGVmLk1FU1NBR0UuR0VUX0NIQVRfUkVRLCBmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgIFByb3RvY29sTWVzc2FnZS5BZGRWZWN0SXRlbUludChtc2cuX2JvZHlfbXNnLCBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLnNlbGZEYXRhLm5BY2NvdW50SUQpO1xuXG4gICAgICAgICAgICAgICAgICAgIC8vIDEgLSBuQWNjb3VudElEIOWSjCBuUGVlcklEIOS6kuebuOWFs+azqFxuICAgICAgICAgICAgICAgICAgICAvLyAyIC0gbkFjY291bnRJRCDlhbPms6ggblBlZXJJRFxuICAgICAgICAgICAgICAgICAgICAvLyAzIC0gbkFjY291bnRJRCDlj5bmtojlhbPms6ggblBlZXJJRFxuICAgICAgICAgICAgICAgICAgICAvLyA0IC0gbkFjY291bnRJRCDmioogblBlZXJJRCDmi4nliLDpu5HlkI3ljZVcbiAgICAgICAgICAgICAgICAgICAgLy8gNSAtIG5BY2NvdW50SUQg5Y+W5raI5ouJ6buRIG5QZWVySURcbiAgICAgICAgICAgICAgICAgICAgLy8gNiAtIG5BY2NvdW50SUQg5ZKMIG5QZWVySUQg5LqS55u45Y+W5raI5YWz5rOoXG4gICAgICAgICAgICAgICAgICAgIFByb3RvY29sTWVzc2FnZS5BZGRWZWN0SXRlbUludChtc2cuX2JvZHlfbXNnLCBuVHlwZSk7XG4gICAgICAgICAgICAgICAgICAgIFByb3RvY29sTWVzc2FnZS5BZGRWZWN0SXRlbUludChtc2cuX2JvZHlfbXNnLCBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLnNlbGZEYXRhLm5QZWVySUQpO1xuICAgICAgICAgICAgICAgICAgICBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLlNlbmRDaGF0TXNnKG1zZyk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn0pO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnODJkNmJZeUFkRkV4clkzM0xhb2xlamgnLCAnSGludE1hbmFnZXInKTtcbi8vIEdsb2JhbC9xaXN1TGliL3Fpc3VGcmFtZS9IaW50L0hpbnRNYW5hZ2VyLmpzXG5cbnZhciBjb25zdERlZiA9IHJlcXVpcmUoXCJDb25zdERlZlwiKTtcblxudmFyIEhpbnRNYW5hZ2VyID0gY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG5cbiAgICAgICAgaGludENhbGxCYWNrOiBudWxsLFxuXG4gICAgICAgIGxhYmVsRGVzYzogY2MuTGFiZWwsXG4gICAgICAgIGZseU5vZGU6IGNjLk5vZGUsXG4gICAgICAgIGZseUxhYmVsOiBjYy5MYWJlbCxcbiAgICAgICAgSGludEZyYW1lOiBjYy5BbmltYXRpb24sXG4gICAgICAgIEhpbnRGbHk6IGNjLkFuaW1hdGlvblxuICAgIH0sXG5cbiAgICBzdGF0aWNzOiB7XG4gICAgICAgIEhpbnRNb2RlOiBudWxsXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge1xuXG4gICAgICAgIEhpbnRNYW5hZ2VyLkhpbnRNb2RlID0gY2MuRW51bSh7XG4gICAgICAgICAgICBTSU1QTEVfRkxZOiAwLCAvLyDnroDljZXpo5jnqpfmlrnlvI9cbiAgICAgICAgICAgIE5PTkVfQlVUVE9OOiAxLCAvLyDlr7nor53moYbml6DmjInpkq5cbiAgICAgICAgICAgIE9LX0JVVFRPTjogMiwgLy8g5a+56K+d5qGG5Y+q5pyJ56Gu5a6a44CB5Y+W5raI5oyJ6ZKuXG4gICAgICAgICAgICBPS19DQU5DRUxfQlVUVE9OOiAzIC8vIOWvueivneahhuacieehruWumuOAgeWPlua2iOaMiemSrlxuICAgICAgICB9KTtcblxuICAgICAgICB2YXIgaGludE5vZGUgPSB0aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoXCJIaW50RnJhbWVcIik7XG4gICAgICAgIGhpbnROb2RlLnNldENhc2NhZGVPcGFjaXR5RW5hYmxlZChmYWxzZSk7XG5cbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgICAgICB2YXIgbG9hZERpciA9IFwiY29tbW9uL2Jhc2UvcG9wQW5pbVwiO1xuICAgICAgICBjYy5sb2FkZXIubG9hZFJlc0FsbChsb2FkRGlyLCBjYy5BbmltYXRpb25DbGlwLCBmdW5jdGlvbiAoZXJyLCBhc3NldHMpIHtcbiAgICAgICAgICAgIGNjLmxvYWRlci5sb2FkUmVzKGxvYWREaXIgKyBcIi9oaW50X2ZseVwiLCBjYy5BbmltYXRpb25DbGlwLCBmdW5jdGlvbiAoZXJyLCBhbmltYXRpb25DbGlwKSB7XG4gICAgICAgICAgICAgICAgc2VsZi5IaW50Rmx5LmFkZENsaXAoYW5pbWF0aW9uQ2xpcCk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGNjLmxvYWRlci5sb2FkUmVzKGxvYWREaXIgKyBcIi9oaW50X2ZseV9yZXNldFwiLCBjYy5BbmltYXRpb25DbGlwLCBmdW5jdGlvbiAoZXJyLCBhbmltYXRpb25DbGlwKSB7XG4gICAgICAgICAgICAgICAgc2VsZi5IaW50Rmx5LmFkZENsaXAoYW5pbWF0aW9uQ2xpcCk7XG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgY2MubG9hZGVyLmxvYWRSZXMobG9hZERpciArIFwiL1BvcEhpZGVcIiwgY2MuQW5pbWF0aW9uQ2xpcCwgZnVuY3Rpb24gKGVyciwgYW5pbWF0aW9uQ2xpcCkge1xuICAgICAgICAgICAgICAgIHNlbGYuSGludEZyYW1lLmFkZENsaXAoYW5pbWF0aW9uQ2xpcCk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGNjLmxvYWRlci5sb2FkUmVzKGxvYWREaXIgKyBcIi9Qb3BIaWRlUmVzZXRcIiwgY2MuQW5pbWF0aW9uQ2xpcCwgZnVuY3Rpb24gKGVyciwgYW5pbWF0aW9uQ2xpcCkge1xuICAgICAgICAgICAgICAgIHNlbGYuSGludEZyYW1lLmFkZENsaXAoYW5pbWF0aW9uQ2xpcCk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGNjLmxvYWRlci5sb2FkUmVzKGxvYWREaXIgKyBcIi9Qb3BTaG93XCIsIGNjLkFuaW1hdGlvbkNsaXAsIGZ1bmN0aW9uIChlcnIsIGFuaW1hdGlvbkNsaXApIHtcbiAgICAgICAgICAgICAgICBzZWxmLkhpbnRGcmFtZS5hZGRDbGlwKGFuaW1hdGlvbkNsaXApO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBjYy5sb2FkZXIubG9hZFJlcyhsb2FkRGlyICsgXCIvUG9wU2hvd1Jlc2V0XCIsIGNjLkFuaW1hdGlvbkNsaXAsIGZ1bmN0aW9uIChlcnIsIGFuaW1hdGlvbkNsaXApIHtcbiAgICAgICAgICAgICAgICBzZWxmLkhpbnRGcmFtZS5hZGRDbGlwKGFuaW1hdGlvbkNsaXApO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgIH0sXG4gICAgU2hvd0ZseTogZnVuY3Rpb24gU2hvd0ZseSh2YWwpIHtcbiAgICAgICAgdmFyIGN1clNjZW5lID0gY2MuZGlyZWN0b3IuZ2V0U2NlbmUoKTtcbiAgICAgICAgdmFyIGN1ck5vZGUgPSBjYy5maW5kKFwiQ2FudmFzXCIsIGN1clNjZW5lKTtcblxuICAgICAgICB0aGlzLmZseU5vZGUucGFyZW50ID0gY3VyTm9kZTtcbiAgICAgICAgdGhpcy5mbHlOb2RlLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIHRoaXMuZmx5TGFiZWwuc3RyaW5nID0gdmFsO1xuXG4gICAgICAgIHZhciBtZW51QW5pbSA9IHRoaXMuZmx5Tm9kZS5nZXRDb21wb25lbnQoY2MuQW5pbWF0aW9uKTtcbiAgICAgICAgbWVudUFuaW0ucGxheSgnaGludF9mbHlfcmVzZXQnKTtcbiAgICAgICAgbWVudUFuaW0ucGxheSgnaGludF9mbHknKTtcbiAgICB9LFxuXG4gICAgU2hvd0hpbnQ6IGZ1bmN0aW9uIFNob3dIaW50KHZhbCwgbW9kZSwgY2FsbGJhY2spIHtcbiAgICAgICAgdmFyIGN1clNjZW5lID0gY2MuZGlyZWN0b3IuZ2V0U2NlbmUoKTtcbiAgICAgICAgdmFyIGN1ck5vZGUgPSBjYy5maW5kKFwiQ2FudmFzXCIsIGN1clNjZW5lKTtcblxuICAgICAgICB0aGlzLm5vZGUucGFyZW50ID0gY3VyTm9kZTtcbiAgICAgICAgdGhpcy5ub2RlLnggPSAwO1xuICAgICAgICB0aGlzLm5vZGUueSA9IDA7XG5cbiAgICAgICAgdGhpcy5oaW50Q2FsbEJhY2sgPSBjYWxsYmFjaztcbiAgICAgICAgdGhpcy5sYWJlbERlc2Muc3RyaW5nID0gdmFsO1xuXG4gICAgICAgIHRoaXMuZmx5Tm9kZS5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5ub2RlLmFjdGl2ZSA9IHRydWU7XG5cbiAgICAgICAgdGhpcy5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLk1PVVNFX0RPV04sIGZ1bmN0aW9uIChldmVudCkge1xuICAgICAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfRU5ELCBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX1NUQVJULCBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICB9KTtcbiAgICAgICAgLy/mmK/lkKbmmL7npLrnoa7lrprmjInpkq4gICBtb2RlIO+8miAxIOS4jeaYvuekuiBcbiAgICAgICAgdmFyIGNvbmZpcm1CdXR0b24gPSBjYy5maW5kKFwiSGludEZyYW1lL2J0blwiLCB0aGlzLm5vZGUpO1xuICAgICAgICBpZiAobW9kZSA9PSBIaW50TWFuYWdlci5IaW50TW9kZS5OT05FX0JVVFRPTikge1xuICAgICAgICAgICAgY29uZmlybUJ1dHRvbi5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbmZpcm1CdXR0b24uYWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICB2YXIgbWVudUFuaW0gPSB0aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoXCJIaW50RnJhbWVcIikuZ2V0Q29tcG9uZW50KGNjLkFuaW1hdGlvbik7XG5cbiAgICAgICAgbWVudUFuaW0ucGxheSgnUG9wU2hvd1Jlc2V0Jyk7XG4gICAgICAgIG1lbnVBbmltLnBsYXkoJ1BvcFNob3cnKTtcbiAgICB9LFxuICAgIEhpZGVIaW50OiBmdW5jdGlvbiBIaWRlSGludCgpIHtcbiAgICAgICAgdmFyIG1lbnVBbmltID0gdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5BbmltYXRpb24pO1xuICAgICAgICBtZW51QW5pbS5wbGF5KCdQb3BIaWRlUmVzZXQnKTtcbiAgICAgICAgbWVudUFuaW0ucGxheSgnUG9wSGlkZScpO1xuICAgIH0sXG4gICAgT25IaWRlSGludDogZnVuY3Rpb24gT25IaWRlSGludCgpIHtcbiAgICAgICAgdGhpcy5ub2RlLmFjdGl2ZSA9IGZhbHNlO1xuXG4gICAgICAgIHRoaXMubm9kZS5wYXJlbnQgPSBudWxsO1xuXG4gICAgICAgIGlmICh0aGlzLmhpbnRDYWxsQmFjayAhPT0gdW5kZWZpbmVkICYmIHRoaXMuaGludENhbGxCYWNrICE9PSBudWxsKSB7XG4gICAgICAgICAgICB0aGlzLmhpbnRDYWxsQmFjaygpO1xuICAgICAgICB9XG4gICAgfVxufSk7XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICc4N2U5MlR5R2k1TEdKVk1RRFZiQnJRMScsICdIb3RVcGRhdGUnKTtcbi8vIEdsb2JhbC9xaXN1TGliL3Fpc3VGcmFtZS9Ib3RVcGRhdGUvSG90VXBkYXRlLmpzXG5cbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICB1cGRhdGVQYW5lbDoge1xuICAgICAgICAgICAgXCJkZWZhdWx0XCI6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlXG4gICAgICAgIH0sXG4gICAgICAgIG1hbmlmZXN0VXJsOiB7XG4gICAgICAgICAgICBcImRlZmF1bHRcIjogbnVsbCxcbiAgICAgICAgICAgIHVybDogY2MuUmF3QXNzZXRcbiAgICAgICAgfSxcbiAgICAgICAgcGVyY2VudDoge1xuICAgICAgICAgICAgXCJkZWZhdWx0XCI6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBjYy5MYWJlbFxuICAgICAgICB9LFxuICAgICAgICBzdG9yYWdlRGlyOiBcImJsYWNramFjay1yZW1vdGUtYXNzZXRcIlxuICAgIH0sXG5cbiAgICBjaGVja0NiOiBmdW5jdGlvbiBjaGVja0NiKGV2ZW50KSB7XG4gICAgICAgIGNjLmxvZygnQ29kZTogJyArIGV2ZW50LmdldEV2ZW50Q29kZSgpKTtcbiAgICAgICAgc3dpdGNoIChldmVudC5nZXRFdmVudENvZGUoKSkge1xuICAgICAgICAgICAgY2FzZSBqc2IuRXZlbnRBc3NldHNNYW5hZ2VyLkVSUk9SX05PX0xPQ0FMX01BTklGRVNUOlxuICAgICAgICAgICAgICAgIGNjLmxvZyhcIk5vIGxvY2FsIG1hbmlmZXN0IGZpbGUgZm91bmQsIGhvdCB1cGRhdGUgc2tpcHBlZC5cIik7XG4gICAgICAgICAgICAgICAgY2MuZXZlbnRNYW5hZ2VyLnJlbW92ZUxpc3RlbmVyKHRoaXMuX2NoZWNrTGlzdGVuZXIpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBqc2IuRXZlbnRBc3NldHNNYW5hZ2VyLkVSUk9SX0RPV05MT0FEX01BTklGRVNUOlxuICAgICAgICAgICAgY2FzZSBqc2IuRXZlbnRBc3NldHNNYW5hZ2VyLkVSUk9SX1BBUlNFX01BTklGRVNUOlxuICAgICAgICAgICAgICAgIGNjLmxvZyhcIkZhaWwgdG8gZG93bmxvYWQgbWFuaWZlc3QgZmlsZSwgaG90IHVwZGF0ZSBza2lwcGVkLlwiKTtcbiAgICAgICAgICAgICAgICBjYy5ldmVudE1hbmFnZXIucmVtb3ZlTGlzdGVuZXIodGhpcy5fY2hlY2tMaXN0ZW5lcik7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIGpzYi5FdmVudEFzc2V0c01hbmFnZXIuQUxSRUFEWV9VUF9UT19EQVRFOlxuICAgICAgICAgICAgICAgIGNjLmxvZyhcIkFscmVhZHkgdXAgdG8gZGF0ZSB3aXRoIHRoZSBsYXRlc3QgcmVtb3RlIHZlcnNpb24uXCIpO1xuICAgICAgICAgICAgICAgIGNjLmV2ZW50TWFuYWdlci5yZW1vdmVMaXN0ZW5lcih0aGlzLl9jaGVja0xpc3RlbmVyKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UganNiLkV2ZW50QXNzZXRzTWFuYWdlci5ORVdfVkVSU0lPTl9GT1VORDpcbiAgICAgICAgICAgICAgICB0aGlzLl9uZWVkVXBkYXRlID0gdHJ1ZTtcblxuICAgICAgICAgICAgICAgIHRoaXMudXBkYXRlUGFuZWwuYWN0aXZlID0gdHJ1ZTtcblxuICAgICAgICAgICAgICAgIHZhciBjdXJTY2VuZSA9IGNjLmRpcmVjdG9yLmdldFNjZW5lKCk7XG4gICAgICAgICAgICAgICAgdmFyIGN1ck5vZGUgPSBjYy5maW5kKFwiQ2FudmFzXCIsIGN1clNjZW5lKTtcbiAgICAgICAgICAgICAgICB0aGlzLnVwZGF0ZVBhbmVsLnBhcmVudCA9IGN1ck5vZGU7XG4gICAgICAgICAgICAgICAgdGhpcy51cGRhdGVQYW5lbC54ID0gMDtcbiAgICAgICAgICAgICAgICB0aGlzLnVwZGF0ZVBhbmVsLnkgPSAwO1xuXG4gICAgICAgICAgICAgICAgdGhpcy5wZXJjZW50LnN0cmluZyA9ICcwMC4wMCUnO1xuICAgICAgICAgICAgICAgIGNjLmV2ZW50TWFuYWdlci5yZW1vdmVMaXN0ZW5lcih0aGlzLl9jaGVja0xpc3RlbmVyKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgdXBkYXRlQ2I6IGZ1bmN0aW9uIHVwZGF0ZUNiKGV2ZW50KSB7XG4gICAgICAgIHZhciBuZWVkUmVzdGFydCA9IGZhbHNlO1xuICAgICAgICB2YXIgZmFpbGVkID0gZmFsc2U7XG4gICAgICAgIHN3aXRjaCAoZXZlbnQuZ2V0RXZlbnRDb2RlKCkpIHtcbiAgICAgICAgICAgIGNhc2UganNiLkV2ZW50QXNzZXRzTWFuYWdlci5FUlJPUl9OT19MT0NBTF9NQU5JRkVTVDpcbiAgICAgICAgICAgICAgICBjYy5sb2coJ05vIGxvY2FsIG1hbmlmZXN0IGZpbGUgZm91bmQsIGhvdCB1cGRhdGUgc2tpcHBlZC4nKTtcbiAgICAgICAgICAgICAgICBmYWlsZWQgPSB0cnVlO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBqc2IuRXZlbnRBc3NldHNNYW5hZ2VyLlVQREFURV9QUk9HUkVTU0lPTjpcbiAgICAgICAgICAgICAgICB2YXIgcGVyY2VudCA9IGV2ZW50LmdldFBlcmNlbnQoKTtcbiAgICAgICAgICAgICAgICB2YXIgcGVyY2VudEJ5RmlsZSA9IGV2ZW50LmdldFBlcmNlbnRCeUZpbGUoKTtcblxuICAgICAgICAgICAgICAgIHZhciBtc2cgPSBldmVudC5nZXRNZXNzYWdlKCk7XG4gICAgICAgICAgICAgICAgaWYgKG1zZykge1xuICAgICAgICAgICAgICAgICAgICBjYy5sb2cobXNnKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2MubG9nKHBlcmNlbnQudG9GaXhlZCgyKSArICclJyk7XG4gICAgICAgICAgICAgICAgdGhpcy5wZXJjZW50LnN0cmluZyA9IHBlcmNlbnQgKyAnJSc7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIGpzYi5FdmVudEFzc2V0c01hbmFnZXIuRVJST1JfRE9XTkxPQURfTUFOSUZFU1Q6XG4gICAgICAgICAgICBjYXNlIGpzYi5FdmVudEFzc2V0c01hbmFnZXIuRVJST1JfUEFSU0VfTUFOSUZFU1Q6XG4gICAgICAgICAgICAgICAgY2MubG9nKCdGYWlsIHRvIGRvd25sb2FkIG1hbmlmZXN0IGZpbGUsIGhvdCB1cGRhdGUgc2tpcHBlZC4nKTtcbiAgICAgICAgICAgICAgICBmYWlsZWQgPSB0cnVlO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBqc2IuRXZlbnRBc3NldHNNYW5hZ2VyLkFMUkVBRFlfVVBfVE9fREFURTpcbiAgICAgICAgICAgICAgICBjYy5sb2coJ0FscmVhZHkgdXAgdG8gZGF0ZSB3aXRoIHRoZSBsYXRlc3QgcmVtb3RlIHZlcnNpb24uJyk7XG4gICAgICAgICAgICAgICAgZmFpbGVkID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UganNiLkV2ZW50QXNzZXRzTWFuYWdlci5VUERBVEVfRklOSVNIRUQ6XG4gICAgICAgICAgICAgICAgY2MubG9nKCdVcGRhdGUgZmluaXNoZWQuICcgKyBldmVudC5nZXRNZXNzYWdlKCkpO1xuXG4gICAgICAgICAgICAgICAgbmVlZFJlc3RhcnQgPSB0cnVlO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBqc2IuRXZlbnRBc3NldHNNYW5hZ2VyLlVQREFURV9GQUlMRUQ6XG4gICAgICAgICAgICAgICAgY2MubG9nKCdVcGRhdGUgZmFpbGVkLiAnICsgZXZlbnQuZ2V0TWVzc2FnZSgpKTtcblxuICAgICAgICAgICAgICAgIHRoaXMuX2ZhaWxDb3VudCsrO1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9mYWlsQ291bnQgPCA1KSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2FtLmRvd25sb2FkRmFpbGVkQXNzZXRzKCk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKCdSZWFjaCBtYXhpbXVtIGZhaWwgY291bnQsIGV4aXQgdXBkYXRlIHByb2Nlc3MnKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fZmFpbENvdW50ID0gMDtcbiAgICAgICAgICAgICAgICAgICAgZmFpbGVkID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIGpzYi5FdmVudEFzc2V0c01hbmFnZXIuRVJST1JfVVBEQVRJTkc6XG4gICAgICAgICAgICAgICAgY2MubG9nKCdBc3NldCB1cGRhdGUgZXJyb3I6ICcgKyBldmVudC5nZXRBc3NldElkKCkgKyAnLCAnICsgZXZlbnQuZ2V0TWVzc2FnZSgpKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UganNiLkV2ZW50QXNzZXRzTWFuYWdlci5FUlJPUl9ERUNPTVBSRVNTOlxuICAgICAgICAgICAgICAgIGNjLmxvZyhldmVudC5nZXRNZXNzYWdlKCkpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChmYWlsZWQpIHtcbiAgICAgICAgICAgIGNjLmV2ZW50TWFuYWdlci5yZW1vdmVMaXN0ZW5lcih0aGlzLl91cGRhdGVMaXN0ZW5lcik7XG4gICAgICAgICAgICB0aGlzLnVwZGF0ZVBhbmVsLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKG5lZWRSZXN0YXJ0KSB7XG4gICAgICAgICAgICBjYy5ldmVudE1hbmFnZXIucmVtb3ZlTGlzdGVuZXIodGhpcy5fdXBkYXRlTGlzdGVuZXIpO1xuICAgICAgICAgICAgLy8gUHJlcGVuZCB0aGUgbWFuaWZlc3QncyBzZWFyY2ggcGF0aFxuICAgICAgICAgICAgdmFyIHNlYXJjaFBhdGhzID0ganNiLmZpbGVVdGlscy5nZXRTZWFyY2hQYXRocygpO1xuICAgICAgICAgICAgdmFyIG5ld1BhdGhzID0gdGhpcy5fYW0uZ2V0TG9jYWxNYW5pZmVzdCgpLmdldFNlYXJjaFBhdGhzKCk7XG4gICAgICAgICAgICBBcnJheS5wcm90b3R5cGUudW5zaGlmdChzZWFyY2hQYXRocywgbmV3UGF0aHMpO1xuICAgICAgICAgICAgLy8gVGhpcyB2YWx1ZSB3aWxsIGJlIHJldHJpZXZlZCBhbmQgYXBwZW5kZWQgdG8gdGhlIGRlZmF1bHQgc2VhcmNoIHBhdGggZHVyaW5nIGdhbWUgc3RhcnR1cCxcbiAgICAgICAgICAgIC8vIHBsZWFzZSByZWZlciB0byBzYW1wbGVzL2pzLXRlc3RzL21haW4uanMgZm9yIGRldGFpbGVkIHVzYWdlLlxuICAgICAgICAgICAgLy8gISEhIFJlLWFkZCB0aGUgc2VhcmNoIHBhdGhzIGluIG1haW4uanMgaXMgdmVyeSBpbXBvcnRhbnQsIG90aGVyd2lzZSwgbmV3IHNjcmlwdHMgd29uJ3QgdGFrZSBlZmZlY3QuXG4gICAgICAgICAgICBjYy5zeXMubG9jYWxTdG9yYWdlLnNldEl0ZW0oJ0hvdFVwZGF0ZVNlYXJjaFBhdGhzJywgSlNPTi5zdHJpbmdpZnkoc2VhcmNoUGF0aHMpKTtcblxuICAgICAgICAgICAganNiLmZpbGVVdGlscy5zZXRTZWFyY2hQYXRocyhzZWFyY2hQYXRocyk7XG4gICAgICAgICAgICBjYy5nYW1lLnJlc3RhcnQoKTtcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICBob3RVcGRhdGU6IGZ1bmN0aW9uIGhvdFVwZGF0ZSgpIHtcbiAgICAgICAgaWYgKHRoaXMuX2FtICYmIHRoaXMuX25lZWRVcGRhdGUpIHtcbiAgICAgICAgICAgIHRoaXMuX3VwZGF0ZUxpc3RlbmVyID0gbmV3IGpzYi5FdmVudExpc3RlbmVyQXNzZXRzTWFuYWdlcih0aGlzLl9hbSwgdGhpcy51cGRhdGVDYi5iaW5kKHRoaXMpKTtcbiAgICAgICAgICAgIGNjLmV2ZW50TWFuYWdlci5hZGRMaXN0ZW5lcih0aGlzLl91cGRhdGVMaXN0ZW5lciwgMSk7XG5cbiAgICAgICAgICAgIHRoaXMuX2ZhaWxDb3VudCA9IDA7XG4gICAgICAgICAgICB0aGlzLl9hbS51cGRhdGUoKTtcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHtcbiAgICAgICAgLy8gSG90IHVwZGF0ZSBpcyBvbmx5IGF2YWlsYWJsZSBpbiBOYXRpdmUgYnVpbGRcbiAgICAgICAgaWYgKCFjYy5zeXMuaXNOYXRpdmUpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB2YXIgc3RvcmFnZVBhdGggPSAoanNiLmZpbGVVdGlscyA/IGpzYi5maWxlVXRpbHMuZ2V0V3JpdGFibGVQYXRoKCkgOiAnLycpICsgdGhpcy5zdG9yYWdlRGlyO1xuICAgICAgICBjYy5sb2coJ1N0b3JhZ2UgcGF0aCBmb3IgcmVtb3RlIGFzc2V0IDogJyArIHN0b3JhZ2VQYXRoKTtcblxuICAgICAgICAvLyBjYy5sb2coJ0xvY2FsIG1hbmlmZXN0IFVSTCA6ICcgKyB0aGlzLm1hbmlmZXN0VXJsKTtcbiAgICAgICAgdGhpcy5fYW0gPSBuZXcganNiLkFzc2V0c01hbmFnZXIodGhpcy5tYW5pZmVzdFVybCwgc3RvcmFnZVBhdGgpO1xuICAgICAgICB0aGlzLl9hbS5yZXRhaW4oKTtcblxuICAgICAgICB0aGlzLl9uZWVkVXBkYXRlID0gZmFsc2U7XG4gICAgICAgIGlmICh0aGlzLl9hbS5nZXRMb2NhbE1hbmlmZXN0KCkuaXNMb2FkZWQoKSkge1xuICAgICAgICAgICAgdGhpcy5fY2hlY2tMaXN0ZW5lciA9IG5ldyBqc2IuRXZlbnRMaXN0ZW5lckFzc2V0c01hbmFnZXIodGhpcy5fYW0sIHRoaXMuY2hlY2tDYi5iaW5kKHRoaXMpKTtcbiAgICAgICAgICAgIGNjLmV2ZW50TWFuYWdlci5hZGRMaXN0ZW5lcih0aGlzLl9jaGVja0xpc3RlbmVyLCAxKTtcblxuICAgICAgICAgICAgdGhpcy5fYW0uY2hlY2tVcGRhdGUoKTtcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICBvbkRlc3Ryb3k6IGZ1bmN0aW9uIG9uRGVzdHJveSgpIHtcbiAgICAgICAgdGhpcy5fYW0gJiYgdGhpcy5fYW0ucmVsZWFzZSgpO1xuICAgIH1cbn0pO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnMmFkNzE0ZC83aE05cE4zUlpTZGYxaUInLCAnTG9hZE1hbmFnZXInKTtcbi8vIEdsb2JhbC9xaXN1TGliL3Fpc3VGcmFtZS9Mb2FkL0xvYWRNYW5hZ2VyLmpzXG5cbnZhciBHbG9iYWxNYW5hZ2VyID0gcmVxdWlyZShcIkdsb2JhbE1hbmFnZXJcIik7XG52YXIgY29uc3REZWYgPSByZXF1aXJlKFwiQ29uc3REZWZcIik7XG52YXIgSGludE1hbmFnZXIgPSByZXF1aXJlKFwiSGludE1hbmFnZXJcIik7XG5jYy5DbGFzcyh7XG4gICAgXCJleHRlbmRzXCI6IGNjLkNvbXBvbmVudCxcblxuICAgIC8vIC0tIOmdmeaAgeWKoOi9vVxuICAgIC8vIC0tIOWKqOaAgeWKoOi9ve+8iOmihOWKoOi9veOAgeWNs+aXtuWKoOi9ve+8iVxuICAgIC8vIOWKqOaAgeWNs+aXtuWKoOi9veWPquacieWcqOW+iOWwkeeahOaDheWGteS4i+S9v+eUqO+8m+a4uOaIj+S4reWkp+mDqOWIhuS9v+eUqOWKqOaAgemihOWKoOi9ve+8m1xuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICBwcm9ncmVzc0JhcjogY2MuUHJvZ3Jlc3NCYXIsXG4gICAgICAgIGxhYmVsUHJvZ3Jlc3M6IGNjLkxhYmVsLFxuICAgICAgICBiYWNrZ3JvdW5kUGljOiBjYy5TcHJpdGUsXG4gICAgICAgIGxvZ286IGNjLlNwcml0ZSxcbiAgICAgICAgcHJvZ3Jlc3NCRzogY2MuU3ByaXRlLFxuXG4gICAgICAgIF9sb2FkX3NjZW5lOiBudWxsLCAvLyDlvZPliY3mraPlnKjliqDovb3nmoTlnLrmma9cbiAgICAgICAgX2xvYWRfdXJsczogbnVsbCwgLy8g5Lyg5YWl55qE5b6F5Yqg6L296LWE5rqQ55qEdXJs5YiX6KGo77yI5LiN5YyF5ZCr5Zy65pmv77yJXG4gICAgICAgIC8vIGFyclVybHMucHVzaCh7dHlwZTpcIlNwaW5lXCIsdXJsOlwiY2FyZC9iYWNrXCJ9KTtcbiAgICAgICAgX3Byb2dyZXNzOiAwLCAvLyDlvZPliY3liqDovb3lh4bnoa7ov5vluqbvvIznlKjkuo7mjqfliLbov5vluqbmnaHotbDliqjvvIjmjqfliLbmnaHov5vluqbkuI3mmK/lrp7ml7bnmoTvvIlcbiAgICAgICAgX3RvdGFsQ291bnQ6IDAsIC8vIOW+heWKoOi9vei1hOa6kOaAu+aVsO+8iOWMheWQqzHkuKrlnLrmma/vvIlcbiAgICAgICAgX2NhbGxiYWNrOiBudWxsLCAvLyDotYTmupDliqDovb3lrozmr5XlkI7nmoTlm57osIPlh73mlbBcbiAgICAgICAgX0RpclJlczogQXJyYXksIC8vIOi1hOa6kOWKoOi9veWujOaIkOWQju+8jOi1hOa6kOaVsOaNruS/neWtmOWcqOivpeaVsOe7hOS4rVxuICAgICAgICBfcmVzQ29tcGxldGVkY291bnQ6IDAsIC8vIOW3sue7j+WKoOi9veWujOaIkOeahOWKqOaAgei1hOa6kFxuICAgICAgICBfYmFyU3BlZWQ6IDAsIC8vIOa7muWKqOadoeeahOmAn+W6plxuICAgICAgICBfcm9sbHRpbWU6IDAuMiB9LFxuICAgIC8vIOi/m+W6puadoei1sOWKqOWIsOaMh+WumuS9jee9rueahOaXtumXtCAgICBcbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHtcbiAgICAgICAgaWYgKHRoaXMuX0RpclJlcyA9PT0gbnVsbCkge1xuICAgICAgICAgICAgdGhpcy5fRGlyUmVzID0gbmV3IEFycmF5KCk7XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgT3BlbkdhbWU6IGZ1bmN0aW9uIE9wZW5HYW1lKGtpbmRJRCkge1xuICAgICAgICAvLyAtLSDliqDovb0gYmfjgIFsb2dv44CBcHJvZ3Jlc3NCR+OAgXByb2dyZXNz44CB5a2X5L2TXG4gICAgICAgIC8vIC0tIOW5tuabv+aNoui/meS6m+i1hOa6kFxuICAgICAgICAvLyAtLSDliqDovb0gbG9hZF91cmxzXG4gICAgICAgIC8vIC0tIOiwg+eUqCBTaG93R2FtZSgpXG5cbiAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5zZWxmRGF0YS5uQ3VyR2FtZUlEID0ga2luZElEO1xuXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgdmFyIGtpbmRCYXNlSW5mbyA9IEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuY29uZkRhdGEuZ2V0S2luZEJhc2VJbmZvKGtpbmRJRCk7XG4gICAgICAgIGlmIChraW5kQmFzZUluZm8gPT0gbnVsbCkgcmV0dXJuO1xuICAgICAgICB2YXIgYWxpYXMgPSBraW5kQmFzZUluZm8uYWxpYXM7XG4gICAgICAgIHZhciBwcm9ncmVzc0ltZyA9IHNlbGYucHJvZ3Jlc3NCYXIubm9kZS5nZXRDaGlsZEJ5TmFtZShcImltZ1wiKS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKTtcblxuICAgICAgICB2YXIgbG9hZERpciA9IFwiR2FtZXMvXCIgKyBhbGlhcyArIFwiL3Jlcy9pbWFnZS9iYXNlXCI7XG4gICAgICAgIGNjLmxvYWRlci5sb2FkUmVzQWxsKGxvYWREaXIsIGNjLlNwcml0ZUZyYW1lLCBmdW5jdGlvbiAoZXJyLCBhc3NldHMpIHtcbiAgICAgICAgICAgIGlmICghZXJyKSB7XG4gICAgICAgICAgICAgICAgY2MubG9hZGVyLmxvYWRSZXMobG9hZERpciArIFwiL2JhY2tncm91bmRcIiwgY2MuU3ByaXRlRnJhbWUsIGZ1bmN0aW9uIChlcnIsIHNwcml0ZUZyYW1lKSB7XG4gICAgICAgICAgICAgICAgICAgIHNlbGYuYmFja2dyb3VuZFBpYy5zcHJpdGVGcmFtZSA9IHNwcml0ZUZyYW1lO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIGNjLmxvYWRlci5sb2FkUmVzKGxvYWREaXIgKyBcIi9sb2dvXCIsIGNjLlNwcml0ZUZyYW1lLCBmdW5jdGlvbiAoZXJyLCBzcHJpdGVGcmFtZSkge1xuICAgICAgICAgICAgICAgICAgICBzZWxmLmxvZ28uc3ByaXRlRnJhbWUgPSBzcHJpdGVGcmFtZTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICBjYy5sb2FkZXIubG9hZFJlcyhsb2FkRGlyICsgXCIvcHJvZ3Jlc3NCYXJcIiwgY2MuU3ByaXRlRnJhbWUsIGZ1bmN0aW9uIChlcnIsIHNwcml0ZUZyYW1lKSB7XG4gICAgICAgICAgICAgICAgICAgIHByb2dyZXNzSW1nLnNwcml0ZUZyYW1lID0gc3ByaXRlRnJhbWU7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgY2MubG9hZGVyLmxvYWRSZXMobG9hZERpciArIFwiL3Byb2dyZXNzQkdcIiwgY2MuU3ByaXRlRnJhbWUsIGZ1bmN0aW9uIChlcnIsIHNwcml0ZUZyYW1lKSB7XG4gICAgICAgICAgICAgICAgICAgIHNlbGYucHJvZ3Jlc3NCRy5zcHJpdGVGcmFtZSA9IHNwcml0ZUZyYW1lO1xuICAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICAgdmFyIGxvYWRfdXJscyA9IEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuY29uZkRhdGEuZ2V0U2NlbmVMb2FkUmVzKGtpbmRJRCwgYWxpYXMgKyBcIl9ob21lXCIpO1xuICAgICAgICAgICAgICAgIHNlbGYuU2hvd0dhbWUoYWxpYXMgKyBcIl9ob21lXCIsIGxvYWRfdXJscywgdHJ1ZSwgbnVsbCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH0sXG5cbiAgICBTaG93OiBmdW5jdGlvbiBTaG93KGxvYWRfc2NlbmUpIHtcbiAgICAgICAgdmFyIGNhbGxiYWNrID0gYXJndW1lbnRzLmxlbmd0aCA8PSAxIHx8IGFyZ3VtZW50c1sxXSA9PT0gdW5kZWZpbmVkID8gbnVsbCA6IGFyZ3VtZW50c1sxXTtcblxuICAgICAgICAvLyAtLSDojrflj5YgbG9hZF91cmxzXG4gICAgICAgIC8vIC0tIOiwg+eUqCBTaG93R2FtZSgpXG5cbiAgICAgICAgdmFyIGxvYWRfdXJscyA9IEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuY29uZkRhdGEuZ2V0U2NlbmVMb2FkUmVzKEdsb2JhbE1hbmFnZXIuaW5zdGFuY2Uuc2VsZkRhdGEubkN1ckdhbWVJRCwgbG9hZF9zY2VuZSk7XG4gICAgICAgIHZhciBsb2FkX3VybHMgPSBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLmNvbmZEYXRhLmdldFNjZW5lTG9hZFJlcyhHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLnNlbGZEYXRhLm5DdXJHYW1lSUQsIGxvYWRfc2NlbmUpO1xuICAgICAgICB0aGlzLlNob3dHYW1lKGxvYWRfc2NlbmUsIGxvYWRfdXJscywgZmFsc2UpO1xuICAgIH0sXG5cbiAgICBTaG93R2FtZTogZnVuY3Rpb24gU2hvd0dhbWUobG9hZF9zY2VuZSkge1xuICAgICAgICB2YXIgbG9hZF91cmxzID0gYXJndW1lbnRzLmxlbmd0aCA8PSAxIHx8IGFyZ3VtZW50c1sxXSA9PT0gdW5kZWZpbmVkID8gbnVsbCA6IGFyZ3VtZW50c1sxXTtcbiAgICAgICAgdmFyIGlzUmV2ZXJzYWwgPSBhcmd1bWVudHMubGVuZ3RoIDw9IDIgfHwgYXJndW1lbnRzWzJdID09PSB1bmRlZmluZWQgPyBmYWxzZSA6IGFyZ3VtZW50c1syXTtcbiAgICAgICAgdmFyIGNhbGxiYWNrID0gYXJndW1lbnRzLmxlbmd0aCA8PSAzIHx8IGFyZ3VtZW50c1szXSA9PT0gdW5kZWZpbmVkID8gbnVsbCA6IGFyZ3VtZW50c1szXTtcblxuICAgICAgICB0aGlzLl9sb2FkX3NjZW5lID0gbG9hZF9zY2VuZTtcbiAgICAgICAgdGhpcy5fbG9hZF91cmxzID0gbG9hZF91cmxzO1xuICAgICAgICB0aGlzLl9jYWxsYmFjayA9IGNhbGxiYWNrO1xuICAgICAgICB0aGlzLl9wcm9ncmVzcyA9IDA7XG4gICAgICAgIHRoaXMuX3Jlc0NvbXBsZXRlZGNvdW50ID0gMDtcbiAgICAgICAgdGhpcy5fdG90YWxDb3VudCA9IDE7XG5cbiAgICAgICAgdmFyIGN1clNjZW5lID0gY2MuZGlyZWN0b3IuZ2V0U2NlbmUoKTtcbiAgICAgICAgdmFyIGN1ck5vZGUgPSBjYy5maW5kKFwiQ2FudmFzXCIsIGN1clNjZW5lKTtcblxuICAgICAgICB0aGlzLm5vZGUucGFyZW50ID0gY3VyTm9kZTtcbiAgICAgICAgaWYgKGlzUmV2ZXJzYWwpIHtcbiAgICAgICAgICAgIHRoaXMubm9kZS5yb3RhdGlvbiA9IDkwO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5ub2RlLnJvdGF0aW9uID0gMDtcbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMubm9kZS54ID0gMDtcbiAgICAgICAgdGhpcy5ub2RlLnkgPSAwO1xuICAgICAgICB2YXIgd2lkZ2V0ID0gdGhpcy5ub2RlLmFkZENvbXBvbmVudChjYy5XaWRnZXQpO1xuICAgICAgICB3aWRnZXQudG9wID0gMDtcbiAgICAgICAgd2lkZ2V0LmxlZnQgPSAwO1xuICAgICAgICB3aWRnZXQucmlnaHQgPSAwO1xuICAgICAgICB3aWRnZXQuYm90dG9tID0gMDtcblxuICAgICAgICB0aGlzLnByb2dyZXNzQmFyLnByb2dyZXNzID0gMDtcblxuICAgICAgICBpZiAodGhpcy5fbG9hZF91cmxzKSB7XG4gICAgICAgICAgICB0aGlzLl90b3RhbENvdW50ICs9IHRoaXMuX2xvYWRfdXJscy5sZW5ndGg7XG4gICAgICAgIH1cblxuICAgICAgICBjYy5kaXJlY3Rvci5wcmVsb2FkU2NlbmUobG9hZF9zY2VuZSwgdGhpcy5fbG9kZXNjZW5lQ2FsbGJhY2suYmluZCh0aGlzKSk7XG4gICAgfSxcbiAgICBfbG9kZXNjZW5lQ2FsbGJhY2s6IGZ1bmN0aW9uIF9sb2Rlc2NlbmVDYWxsYmFjayhlcnJvcikge1xuICAgICAgICBpZiAoZXJyb3IgPT09IGZhbHNlKSB7XG4gICAgICAgICAgICBjYy5sb2coXCLliqDovb3lnLrmma/lh7rplJnvvIFcIik7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5fcHJvZ3Jlc3MgPSAxIC8gdGhpcy5fdG90YWxDb3VudDtcbiAgICAgICAgdGhpcy5fc3BlZWQgPSAodGhpcy5fcHJvZ3Jlc3MgLSB0aGlzLnByb2dyZXNzQmFyLnByb2dyZXNzKSAvIHRoaXMuX3JvbGx0aW1lO1xuXG4gICAgICAgIGlmICh0aGlzLl9sb2FkX3VybHMgIT09IG51bGwpIHtcbiAgICAgICAgICAgIGlmICh0aGlzLl9yZXNDb21wbGV0ZWRjb3VudCArIDEgPCB0aGlzLl90b3RhbENvdW50KSB7XG4gICAgICAgICAgICAgICAgdGhpcy5fbG9kZVJlcygpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSxcblxuICAgIF9sb2RlUmVzOiBmdW5jdGlvbiBfbG9kZVJlcygpIHtcbiAgICAgICAgdmFyIHVybCA9IHRoaXMuX2xvYWRfdXJsc1t0aGlzLl9yZXNDb21wbGV0ZWRjb3VudF0udXJsO1xuICAgICAgICB2YXIgcmVzVHlwZSA9IHRoaXMuX2xvYWRfdXJsc1t0aGlzLl9yZXNDb21wbGV0ZWRjb3VudF0udHlwZTtcbiAgICAgICAgdmFyIGxvYWRDYWxsQmFjayA9IHRoaXMuX2NvbXBsZXRlQ2FsbGJhY2suYmluZCh0aGlzKTtcbiAgICAgICAgc3dpdGNoICh0aGlzLl9jdXJUeXBlKSB7XG4gICAgICAgICAgICBjYXNlICdTcHJpdGVGcmFtZSc6XG4gICAgICAgICAgICAgICAgLy8gc3BlY2lmeSB0aGUgdHlwZSB0byBsb2FkIHN1YiBhc3NldCBmcm9tIHRleHR1cmUncyB1cmxcbiAgICAgICAgICAgICAgICBjYy5sb2FkZXIubG9hZFJlcyh1cmwsIGNjLlNwcml0ZUZyYW1lLCBsb2FkQ2FsbEJhY2spO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnU3BpbmUnOlxuICAgICAgICAgICAgICAgIC8vIHNwZWNpZnkgdGhlIHR5cGUgdG8gYXZvaWQgdGhlIGR1cGxpY2F0ZWQgbmFtZSBmcm9tIHNwaW5lIGF0bGFzXG4gICAgICAgICAgICAgICAgY2MubG9hZGVyLmxvYWRSZXModXJsLCBzcC5Ta2VsZXRvbkRhdGEsIGxvYWRDYWxsQmFjayk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdGb250JzpcbiAgICAgICAgICAgICAgICBjYy5sb2FkZXIubG9hZFJlcyh1cmwsIGNjLkZvbnQsIGxvYWRDYWxsQmFjayk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdBbmltYXRpb24nOlxuICAgICAgICAgICAgY2FzZSAnUHJlZmFiJzpcbiAgICAgICAgICAgIGNhc2UgJ1NjZW5lJzpcbiAgICAgICAgICAgIGNhc2UgJ1RleHR1cmUnOlxuICAgICAgICAgICAgY2FzZSAnVHh0JzpcbiAgICAgICAgICAgIGNhc2UgJ0F1ZGlvJzpcbiAgICAgICAgICAgICAgICBjYy5sb2FkZXIubG9hZFJlcyh1cmwsIGxvYWRDYWxsQmFjayk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgIGNjLmxvYWRlci5sb2FkKHVybCwgbG9hZENhbGxCYWNrKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMuX3Jlc0NvbXBsZXRlZGNvdW50Kys7XG4gICAgfSxcblxuICAgIF9jb21wbGV0ZUNhbGxiYWNrOiBmdW5jdGlvbiBfY29tcGxldGVDYWxsYmFjayhlcnJvciwgcmVzKSB7XG4gICAgICAgIHRoaXMuX3Byb2dyZXNzID0gKHRoaXMuX3Jlc0NvbXBsZXRlZGNvdW50ICsgMSkgLyB0aGlzLl90b3RhbENvdW50O1xuICAgICAgICB0aGlzLl9zcGVlZCA9ICh0aGlzLl9wcm9ncmVzcyAtIHRoaXMucHJvZ3Jlc3NCYXIucHJvZ3Jlc3MpIC8gdGhpcy5fcm9sbHRpbWU7XG4gICAgICAgIHRoaXMuX0RpclJlc1t0aGlzLl9sb2FkX3VybHNbdGhpcy5fcmVzQ29tcGxldGVkY291bnQgLSAxXS51cmxdID0gcmVzO1xuICAgICAgICBpZiAodGhpcy5fcmVzQ29tcGxldGVkY291bnQgKyAxIDwgdGhpcy5fdG90YWxDb3VudCkge1xuICAgICAgICAgICAgdGhpcy5fbG9kZVJlcygpO1xuICAgICAgICB9XG4gICAgfSxcbiAgICB1cGRhdGU6IGZ1bmN0aW9uIHVwZGF0ZShkdCkge1xuICAgICAgICBpZiAodGhpcy5fdG90YWxDb3VudCA9PT0gMCkgcmV0dXJuO1xuXG4gICAgICAgIHZhciBkZWwgPSB0aGlzLl9zcGVlZCAqIGR0O1xuICAgICAgICB2YXIgcHJvZ3Jlc3MgPSB0aGlzLnByb2dyZXNzQmFyLnByb2dyZXNzO1xuICAgICAgICBpZiAocHJvZ3Jlc3MgPj0gMSkge1xuICAgICAgICAgICAgdGhpcy5sYWJlbFByb2dyZXNzLnN0cmluZyA9IFwiMTAwJVwiO1xuXG4gICAgICAgICAgICB0aGlzLm5vZGUucGFyZW50ID0gbnVsbDtcbiAgICAgICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuaGludC5wYXJlbnQgPSBudWxsO1xuXG4gICAgICAgICAgICBpZiAodGhpcy5fY2FsbGJhY2sgIT09IG51bGwpIHtcbiAgICAgICAgICAgICAgICB0aGlzLl9jYWxsYmFjaygpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5fY2FsbGJhY2sgPSBudWxsO1xuXG4gICAgICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUodGhpcy5fbG9hZF9zY2VuZSk7XG5cbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChwcm9ncmVzcyA8IHRoaXMuX3Byb2dyZXNzKSB7XG4gICAgICAgICAgICBpZiAocHJvZ3Jlc3MgKyBkZWwgPiB0aGlzLl9wcm9ncmVzcykgcHJvZ3Jlc3MgPSB0aGlzLl9wcm9ncmVzcztlbHNlIHByb2dyZXNzICs9IGRlbDtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnByb2dyZXNzQmFyLnByb2dyZXNzID0gcHJvZ3Jlc3M7XG4gICAgICAgIHRoaXMubGFiZWxQcm9ncmVzcy5zdHJpbmcgPSBNYXRoLnJvdW5kKHByb2dyZXNzICogMTAwKSArIFwiJVwiO1xuICAgIH0sXG5cbiAgICBHZXRSZXM6IGZ1bmN0aW9uIEdldFJlcyh1cmwpIHtcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9EaXJSZXNbdXJsXSA9PT0gXCJ1bmRlZmluZWRcIikgcmV0dXJuIG51bGw7XG4gICAgICAgIGlmICh0aGlzLl9EaXJSZXNbdXJsXSA9PT0gbnVsbCkgcmV0dXJuIG51bGw7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuX0RpclJlc1t1cmxdO1xuICAgIH0sXG5cbiAgICBSZW1vdmVSZXM6IGZ1bmN0aW9uIFJlbW92ZVJlcyh1cmwpIHtcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9EaXJSZXNbdXJsXSA9PT0gXCJ1bmRlZmluZWRcIikgcmV0dXJuIG51bGw7XG4gICAgICAgIGlmICh0aGlzLl9EaXJSZXNbdXJsXSA9PT0gbnVsbCkgcmV0dXJuO1xuXG4gICAgICAgIGNjLmxvYWRlci5yZWxlYXNlUmVzKHVybCk7XG5cbiAgICAgICAgdGhpcy5fRGlyUmVzW3VybF0gPSBudWxsO1xuICAgIH0sXG5cbiAgICBSZW1vdmVBbGxSZXM6IGZ1bmN0aW9uIFJlbW92ZUFsbFJlcygpIHtcbiAgICAgICAgY2MubG9hZGVyLnJlbGVhc2VBbGwoKTtcbiAgICAgICAgdGhpcy5fRGlyUmVzID0gbmV3IEFycmF5KCk7XG4gICAgfVxuXG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJ2M1NDE0YzBWMGhMUUp0UXJ2YTAwSXBFJywgJ0xvZ29uVUknKTtcbi8vIHJlc291cmNlcy9HYW1lcy9ZaW5nc2Fuemhhbmcvc2NlbmUvc2NlbmVMb2dvbi9Mb2dvblVJLmpzXG5cbnZhciBHbG9iYWxNYW5hZ2VyID0gcmVxdWlyZShcIkdsb2JhbE1hbmFnZXJcIik7XG52YXIgSGludE1hbmFnZXIgPSByZXF1aXJlKFwiSGludE1hbmFnZXJcIik7XG52YXIgUHJvdG9jb2xNZXNzYWdlID0gcmVxdWlyZShcIlByb3RvY29sTWVzc2FnZVwiKTtcbnZhciBjb25zdERlZiA9IHJlcXVpcmUoXCJDb25zdERlZlwiKTtcbnZhciBVdGlscyA9IHJlcXVpcmUoXCJVdGlsc1wiKTtcblxuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIGlucHV0QWNjb3VudE5hbWU6IHtcbiAgICAgICAgICAgIFwiZGVmYXVsdFwiOiBudWxsLFxuICAgICAgICAgICAgdHlwZTogY2MuRWRpdEJveFxuICAgICAgICB9LFxuICAgICAgICBpbnB1dFBhc3N3b3JkOiB7XG4gICAgICAgICAgICBcImRlZmF1bHRcIjogbnVsbCxcbiAgICAgICAgICAgIHR5cGU6IGNjLkVkaXRCb3hcbiAgICAgICAgfSxcbiAgICAgICAgaW5wdXRBY2NvdW50TmFtZVI6IHtcbiAgICAgICAgICAgIFwiZGVmYXVsdFwiOiBudWxsLFxuICAgICAgICAgICAgdHlwZTogY2MuRWRpdEJveFxuICAgICAgICB9LFxuICAgICAgICBpbnB1dFBhc3N3b3JkUjoge1xuICAgICAgICAgICAgXCJkZWZhdWx0XCI6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBjYy5FZGl0Qm94XG4gICAgICAgIH0sXG4gICAgICAgIGlucHV0UGFzc3dvcmRSMToge1xuICAgICAgICAgICAgXCJkZWZhdWx0XCI6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBjYy5FZGl0Qm94XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7XG5cbiAgICAgICAgdmFyIGFjY291bnRuYW1lID0gY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiYWNjb3VudE5hbWVcIik7XG4gICAgICAgIHZhciBwYXNzd29yZCA9IGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInBhc3N3b3JkXCIpO1xuXG4gICAgICAgIGlmIChhY2NvdW50bmFtZSA9PSBcIlwiKSByZXR1cm47XG4gICAgICAgIGlmIChhY2NvdW50bmFtZSA9PSBudWxsKSByZXR1cm47XG4gICAgICAgIGlmICh0eXBlb2YgYWNjb3VudG5hbWUgPT0gXCJ1bmRlZmluZWRcIikgcmV0dXJuO1xuXG4gICAgICAgIHRoaXMuaW5wdXRBY2NvdW50TmFtZS5zdHJpbmcgPSBhY2NvdW50bmFtZTtcbiAgICAgICAgdGhpcy5pbnB1dFBhc3N3b3JkLnN0cmluZyA9IHBhc3N3b3JkO1xuICAgIH0sXG5cbiAgICBzd2l0Y2hMb2dvblJlZ2lzdGVyOiBmdW5jdGlvbiBzd2l0Y2hMb2dvblJlZ2lzdGVyKCkge1xuICAgICAgICB2YXIgY3VyU2NlbmUgPSBjYy5kaXJlY3Rvci5nZXRTY2VuZSgpO1xuICAgICAgICB2YXIgY3VyTm9kZSA9IGNjLmZpbmQoXCJDYW52YXMvYWNjb3VudFBhbmUvc3dpdGNoQnRuXCIsIGN1clNjZW5lKTtcbiAgICAgICAgaWYgKGN1ck5vZGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmcgPT0gXCLlv6vpgJ/ms6jlhoxcIikge1xuICAgICAgICAgICAgY3VyTm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZyA9IFwi6L+U5Zue55m75b2VXCI7XG4gICAgICAgICAgICB2YXIgbm9kZUxvZ29uID0gdGhpcy5ub2RlLmdldENoaWxkQnlOYW1lKFwiYWNjb3VudFBhbmVcIikuZ2V0Q2hpbGRCeU5hbWUoXCJsb2dvblBhbmVcIik7XG4gICAgICAgICAgICB2YXIgbm9kZVJlZ2lzdGVyID0gdGhpcy5ub2RlLmdldENoaWxkQnlOYW1lKFwiYWNjb3VudFBhbmVcIikuZ2V0Q2hpbGRCeU5hbWUoXCJyZWdpc3RlclBhbmVcIik7XG4gICAgICAgICAgICBub2RlUmVnaXN0ZXIuYWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgICAgIG5vZGVMb2dvbi5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGN1ck5vZGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmcgPSBcIuW/q+mAn+azqOWGjFwiO1xuICAgICAgICAgICAgdmFyIG5vZGVMb2dvbiA9IHRoaXMubm9kZS5nZXRDaGlsZEJ5TmFtZShcImFjY291bnRQYW5lXCIpLmdldENoaWxkQnlOYW1lKFwibG9nb25QYW5lXCIpO1xuICAgICAgICAgICAgdmFyIG5vZGVSZWdpc3RlciA9IHRoaXMubm9kZS5nZXRDaGlsZEJ5TmFtZShcImFjY291bnRQYW5lXCIpLmdldENoaWxkQnlOYW1lKFwicmVnaXN0ZXJQYW5lXCIpO1xuICAgICAgICAgICAgbm9kZVJlZ2lzdGVyLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICAgICAgbm9kZUxvZ29uLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIH1cbiAgICB9LFxuICAgIGxvZ29uQ2xpY2s6IGZ1bmN0aW9uIGxvZ29uQ2xpY2soKSB7XG4gICAgICAgIGlmICh0aGlzLmlucHV0UGFzc3dvcmQuc3RyaW5nID09PSBcIlwiIHx8IHRoaXMuaW5wdXRBY2NvdW50TmFtZS5zdHJpbmcgPT09IFwiXCIpIHtcbiAgICAgICAgICAgIHZhciBjdXJDb21wID0gR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5oaW50LmdldENvbXBvbmVudChcIkhpbnRNYW5hZ2VyXCIpO1xuICAgICAgICAgICAgY3VyQ29tcC5TaG93SGludChcIui0puWPt+aIluWvhueggeS4jeiDveS4uuepuu+8gVwiLCBIaW50TWFuYWdlci5IaW50TW9kZS5PS19CVVRUT04pO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgdmFyIGN1ckNvbXAgPSBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLmhpbnQuZ2V0Q29tcG9uZW50KFwiSGludE1hbmFnZXJcIik7XG4gICAgICAgIGN1ckNvbXAuU2hvd0hpbnQoXCLmraPlnKjov5vlhaXmuLjmiI/vvIzor7fnqI3nrYkuLi5cIiwgSGludE1hbmFnZXIuSGludE1vZGUuTk9ORV9CVVRUT04pO1xuXG4gICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2Uuc2VsZkRhdGEuc0FjY291bnROYW1lID0gdGhpcy5pbnB1dEFjY291bnROYW1lLnN0cmluZztcbiAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5zZWxmRGF0YS5zUGFzc3dvcmQgPSB0aGlzLmlucHV0UGFzc3dvcmQuc3RyaW5nO1xuXG4gICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuU2VuZE1zZyhjb25zdERlZi5DT05ORUNUX0NBTExCQUNLX1NUQVRVUy5MT0dPTl9XQUlUX0xPR09OKTtcbiAgICB9LFxuICAgIHJlZ2lzdGVyQ2xpY2s6IGZ1bmN0aW9uIHJlZ2lzdGVyQ2xpY2soKSB7XG4gICAgICAgIGlmICh0aGlzLmlucHV0UGFzc3dvcmRSLnN0cmluZyAhPT0gdGhpcy5pbnB1dFBhc3N3b3JkUjEuc3RyaW5nKSB7XG4gICAgICAgICAgICB2YXIgY3VyQ29tcCA9IEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuaGludC5nZXRDb21wb25lbnQoXCJIaW50TWFuYWdlclwiKTtcbiAgICAgICAgICAgIGN1ckNvbXAuU2hvd0hpbnQoXCLkuKTmrKHlr4bnoIHovpPlhaXkuI3kuIDoh7TvvIzor7fph43mlrDovpPlhaXvvIFcIiwgSGludE1hbmFnZXIuSGludE1vZGUuT0tfQlVUVE9OKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5pbnB1dFBhc3N3b3JkUi5zdHJpbmcgPT09IFwiXCIgfHwgdGhpcy5pbnB1dEFjY291bnROYW1lUi5zdHJpbmcgPT09IFwiXCIpIHtcbiAgICAgICAgICAgIHZhciBjdXJDb21wID0gR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5oaW50LmdldENvbXBvbmVudChcIkhpbnRNYW5hZ2VyXCIpO1xuICAgICAgICAgICAgY3VyQ29tcC5TaG93SGludChcIui0puWPt+aIluWvhueggeS4jeiDveS4uuepuu+8gVwiLCBIaW50TWFuYWdlci5IaW50TW9kZS5PS19CVVRUT04pO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgdmFyIGN1ckNvbXAgPSBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLmhpbnQuZ2V0Q29tcG9uZW50KFwiSGludE1hbmFnZXJcIik7XG4gICAgICAgIGN1ckNvbXAuU2hvd0hpbnQoXCLmraPlnKjov5vlhaXmuLjmiI/vvIzor7fnqI3nrYkuLi5cIiwgSGludE1hbmFnZXIuSGludE1vZGUuTk9ORV9CVVRUT04pO1xuXG4gICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2Uuc2VsZkRhdGEuc0FjY291bnROYW1lID0gdGhpcy5pbnB1dEFjY291bnROYW1lUi5zdHJpbmc7XG4gICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2Uuc2VsZkRhdGEuc1Bhc3N3b3JkID0gdGhpcy5pbnB1dFBhc3N3b3JkUi5zdHJpbmc7XG5cbiAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5TZW5kTXNnKGNvbnN0RGVmLkNPTk5FQ1RfQ0FMTEJBQ0tfU1RBVFVTLkxPR09OX1dBSVRfUkVHSVNURVIpO1xuICAgIH1cbn0pO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnNjZkMjYrb0VqNUE2Yk1TdGxjZEl6QjgnLCAnTWVzc2FnZUhhbmRsZScpO1xuLy8gR2xvYmFsL3NlcnZpY2UvTWVzc2FnZUhhbmRsZS5qc1xuXG52YXIgY29uc3REZWYgPSByZXF1aXJlKFwiQ29uc3REZWZcIik7XG52YXIgUHJvdG9jb2xNZXNzYWdlID0gcmVxdWlyZShcIlByb3RvY29sTWVzc2FnZVwiKTtcblxudmFyIE1lc3NhZ2VIYW5kbGUgPSB7XG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICBoYW5kbGVyX0hFQVJUX1JTUDogZnVuY3Rpb24gaGFuZGxlcl9IRUFSVF9SU1AoZXZlbnQpIHtcbiAgICAgICAgdmFyIGJvZHlNc2cgPSBldmVudC5kZXRhaWwubXNnQm9keTtcbiAgICAgICAgdmFyIGluc3RhbmNlR2xvYmFsID0gZXZlbnQuZGV0YWlsLmluc3RhbmNlR2xvYmFsO1xuXG4gICAgICAgIHZhciBpbmRleCA9IDA7XG4gICAgICAgIHZhciBzZXJ2ZXJUaW1lID0gYm9keU1zZ1tpbmRleCsrXS5faW50X3ZhbHVlO1xuXG4gICAgICAgIHZhciBsb2NhbFRpbWUgPSBNYXRoLmZsb29yKG5ldyBEYXRlKCkuZ2V0VGltZSgpIC8gMTAwMCk7XG4gICAgICAgIGluc3RhbmNlR2xvYmFsLnNlbGZEYXRhLm5Mb2NhbFNlcnZlclRpbWVEaWZmID0gc2VydmVyVGltZSAtIGxvY2FsVGltZTtcblxuICAgICAgICAvLyDlj6ropoHov57kuIrmuLjmiI/mnI3liqHlmajlsLHkuIDnp5Llj5HpgIHkuIDmrKHlv4Pot7NcbiAgICAgICAgLy8g6Iul6L+e57ut5LqU56eS5pyq5pS25Yiw5b+D6Lez5ZON5bqU77yM5YiZ5pat5byA6ZO+5o6lXG4gICAgICAgIC8vIOaYr+WQpumHjei/nu+8jOeUsemHjei/nuacuuWItuWIpOWumu+8iOaImOaWl+S4reaWree6v++8jDPnp5Loh6rliqjph43ov57vvIlcbiAgICAgICAgaW5zdGFuY2VHbG9iYWwuc2VsZkRhdGEubkhlYXJ0UnNwVFMgPSBsb2NhbFRpbWU7XG4gICAgfSxcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIGhhbmRsZXJfTE9HT05fUExBVEZPUk1fU1VDQ0VTUzogZnVuY3Rpb24gaGFuZGxlcl9MT0dPTl9QTEFURk9STV9TVUNDRVNTKGV2ZW50KSB7XG4gICAgICAgIHZhciBib2R5TXNnID0gZXZlbnQuZGV0YWlsLm1zZ0JvZHk7XG4gICAgICAgIHZhciBpbnN0YW5jZUdsb2JhbCA9IGV2ZW50LmRldGFpbC5pbnN0YW5jZUdsb2JhbDtcblxuICAgICAgICB2YXIgaW5kZXggPSAwO1xuICAgICAgICBpbnN0YW5jZUdsb2JhbC5zZWxmRGF0YS5uQWNjb3VudElEID0gYm9keU1zZ1tpbmRleCsrXS5faW50X3ZhbHVlO1xuICAgICAgICBpbnN0YW5jZUdsb2JhbC5zZWxmRGF0YS5zQWNjb3VudE5hbWUgPSBib2R5TXNnW2luZGV4KytdLl9zdHJfdmFsdWU7XG5cbiAgICAgICAgaW5zdGFuY2VHbG9iYWwuc2VsZkRhdGEubkxvZ29uVFMgPSBib2R5TXNnW2luZGV4KytdLl9pbnRfdmFsdWU7XG4gICAgICAgIGluc3RhbmNlR2xvYmFsLnNlbGZEYXRhLm5Mb2dvblJhbmQgPSBib2R5TXNnW2luZGV4KytdLl9pbnRfdmFsdWU7XG4gICAgICAgIGluc3RhbmNlR2xvYmFsLnNlbGZEYXRhLnNMb2dvbktleSA9IGJvZHlNc2dbaW5kZXgrK10uX3N0cl92YWx1ZTtcblxuICAgICAgICBpbnN0YW5jZUdsb2JhbC5zZWxmRGF0YS5zTmlja05hbWUgPSBib2R5TXNnW2luZGV4KytdLl9zdHJfdmFsdWU7XG4gICAgICAgIGluc3RhbmNlR2xvYmFsLnNlbGZEYXRhLm5TZXggPSBib2R5TXNnW2luZGV4KytdLl9pbnRfdmFsdWU7XG4gICAgICAgIGluc3RhbmNlR2xvYmFsLnNlbGZEYXRhLm5GaGVhZCA9IGJvZHlNc2dbaW5kZXgrK10uX2ludF92YWx1ZTtcbiAgICAgICAgaW5zdGFuY2VHbG9iYWwuc2VsZkRhdGEuc0ZjdXN0b21faGVhZCA9IGJvZHlNc2dbaW5kZXgrK10uX3N0cl92YWx1ZTtcbiAgICAgICAgaW5zdGFuY2VHbG9iYWwuc2VsZkRhdGEubkZybWJIID0gYm9keU1zZ1tpbmRleCsrXS5faW50X3ZhbHVlOyAvLyAg5LiD56CWXG4gICAgICAgIGluc3RhbmNlR2xvYmFsLnNlbGZEYXRhLm5Gcm1iID0gYm9keU1zZ1tpbmRleCsrXS5faW50X3ZhbHVlO1xuICAgICAgICBpbnN0YW5jZUdsb2JhbC5zZWxmRGF0YS5uRmNoYXJnZV9ybWJIID0gYm9keU1zZ1tpbmRleCsrXS5faW50X3ZhbHVlOyAvLyDntK/orqHlhYXlgLxcbiAgICAgICAgaW5zdGFuY2VHbG9iYWwuc2VsZkRhdGEubkZjaGFyZ2Vfcm1iID0gYm9keU1zZ1tpbmRleCsrXS5faW50X3ZhbHVlO1xuICAgICAgICBpbnN0YW5jZUdsb2JhbC5zZWxmRGF0YS5uRm1vbmV5SCA9IGJvZHlNc2dbaW5kZXgrK10uX2ludF92YWx1ZTsgLy8g5LiD6LGGXG4gICAgICAgIGluc3RhbmNlR2xvYmFsLnNlbGZEYXRhLm5GbW9uZXkgPSBib2R5TXNnW2luZGV4KytdLl9pbnRfdmFsdWU7XG4gICAgICAgIGluc3RhbmNlR2xvYmFsLnNlbGZEYXRhLm5Gd2FsbGV0SCA9IGJvZHlNc2dbaW5kZXgrK10uX2ludF92YWx1ZTsgLy8g5LiD5biBXG4gICAgICAgIGluc3RhbmNlR2xvYmFsLnNlbGZEYXRhLm5Gd2FsbGV0ID0gYm9keU1zZ1tpbmRleCsrXS5faW50X3ZhbHVlO1xuICAgICAgICBpbnN0YW5jZUdsb2JhbC5zZWxmRGF0YS5zRnJlYWxfbmFtZSA9IGJvZHlNc2dbaW5kZXgrK10uX3N0cl92YWx1ZTtcbiAgICAgICAgaW5zdGFuY2VHbG9iYWwuc2VsZkRhdGEuc0ZjYXJkX2lkID0gYm9keU1zZ1tpbmRleCsrXS5fc3RyX3ZhbHVlO1xuICAgICAgICBpbnN0YW5jZUdsb2JhbC5zZWxmRGF0YS5zRm1vYmlsZSA9IGJvZHlNc2dbaW5kZXgrK10uX3N0cl92YWx1ZTtcbiAgICAgICAgaW5zdGFuY2VHbG9iYWwuc2VsZkRhdGEuc0ZlbWFpbCA9IGJvZHlNc2dbaW5kZXgrK10uX3N0cl92YWx1ZTtcbiAgICAgICAgaW5zdGFuY2VHbG9iYWwuc2VsZkRhdGEubkZzcHJlYWRlciA9IGJvZHlNc2dbaW5kZXgrK10uX2ludF92YWx1ZTtcblxuICAgICAgICB2YXIgc2VydmVyVGltZSA9IGluc3RhbmNlR2xvYmFsLnNlbGZEYXRhLm5Mb2dvblRTO1xuICAgICAgICB2YXIgbG9jYWxUaW1lID0gTWF0aC5mbG9vcihuZXcgRGF0ZSgpLmdldFRpbWUoKSAvIDEwMDApO1xuICAgICAgICBpbnN0YW5jZUdsb2JhbC5zZWxmRGF0YS5uTG9jYWxTZXJ2ZXJUaW1lRGlmZiA9IHNlcnZlclRpbWUgLSBsb2NhbFRpbWU7XG5cbiAgICAgICAgaW5zdGFuY2VHbG9iYWwuU2F2ZVVzZXJBY2NvdW50UGFzc3dvcmQoKTtcblxuICAgICAgICB2YXIgZ2FtZUlkID0gMTM7XG4gICAgICAgIGluc3RhbmNlR2xvYmFsLkdhbWVOb2RlQWRkQ29tcG9uZW50KGdhbWVJZCwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgaW5zdGFuY2VHbG9iYWwuc2VsZkRhdGEubkN1ckdhbWVJRCA9IGdhbWVJZDtcbiAgICAgICAgICAgIGluc3RhbmNlR2xvYmFsLkdldEdhbWVDb250cm9sbGVyKGdhbWVJZCkuU2VuZE1zZyhjb25zdERlZi5DT05ORUNUX0NBTExCQUNLX1NUQVRVUy5MT0dPTl9HRVRfR0FNRV9JTkZPKTtcbiAgICAgICAgfSk7XG4gICAgfSxcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIGhhbmRsZXJfQ1JFQVRFX0FDQ09VTlRfU1VDQ0VTUzogZnVuY3Rpb24gaGFuZGxlcl9DUkVBVEVfQUNDT1VOVF9TVUNDRVNTKGV2ZW50KSB7XG4gICAgICAgIHZhciBib2R5TXNnID0gZXZlbnQuZGV0YWlsLm1zZ0JvZHk7XG4gICAgICAgIHZhciBpbnN0YW5jZUdsb2JhbCA9IGV2ZW50LmRldGFpbC5pbnN0YW5jZUdsb2JhbDtcblxuICAgICAgICB2YXIgaW5kZXggPSAwO1xuICAgICAgICBpbnN0YW5jZUdsb2JhbC5zZWxmRGF0YS5uQWNjb3VudElEID0gYm9keU1zZ1tpbmRleCsrXS5faW50X3ZhbHVlO1xuICAgICAgICBpbnN0YW5jZUdsb2JhbC5zZWxmRGF0YS5zQWNjb3VudE5hbWUgPSBib2R5TXNnW2luZGV4KytdLl9zdHJfdmFsdWU7XG4gICAgICAgIHZhciBuU3ByZWFkZXJJRCA9IGJvZHlNc2dbaW5kZXgrK10uX2ludF92YWx1ZTtcbiAgICAgICAgaW5zdGFuY2VHbG9iYWwuc2VsZkRhdGEubkxvZ29uVFMgPSBib2R5TXNnW2luZGV4KytdLl9pbnRfdmFsdWU7XG4gICAgICAgIGluc3RhbmNlR2xvYmFsLnNlbGZEYXRhLm5Mb2dvblJhbmQgPSBib2R5TXNnW2luZGV4KytdLl9pbnRfdmFsdWU7XG4gICAgICAgIGluc3RhbmNlR2xvYmFsLnNlbGZEYXRhLnNMb2dvbktleSA9IGJvZHlNc2dbaW5kZXgrK10uX3N0cl92YWx1ZTtcblxuICAgICAgICAvLyAuLi5cblxuICAgICAgICB2YXIgc2VydmVyVGltZSA9IGluc3RhbmNlR2xvYmFsLnNlbGZEYXRhLm5Mb2dvblRTO1xuICAgICAgICB2YXIgbG9jYWxUaW1lID0gTWF0aC5mbG9vcihuZXcgRGF0ZSgpLmdldFRpbWUoKSAvIDEwMDApO1xuICAgICAgICBpbnN0YW5jZUdsb2JhbC5zZWxmRGF0YS5uTG9jYWxTZXJ2ZXJUaW1lRGlmZiA9IHNlcnZlclRpbWUgLSBsb2NhbFRpbWU7XG5cbiAgICAgICAgaW5zdGFuY2VHbG9iYWwuU2F2ZVVzZXJBY2NvdW50UGFzc3dvcmQoKTtcblxuICAgICAgICB2YXIgZ2FtZUlkID0gMTM7XG4gICAgICAgIGluc3RhbmNlR2xvYmFsLkdhbWVOb2RlQWRkQ29tcG9uZW50KGdhbWVJZCwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgaW5zdGFuY2VHbG9iYWwuc2VsZkRhdGEubkN1ckdhbWVJRCA9IGdhbWVJZDtcbiAgICAgICAgICAgIGluc3RhbmNlR2xvYmFsLkdldEdhbWVDb250cm9sbGVyKGdhbWVJZCkuU2VuZE1zZyhjb25zdERlZi5DT05ORUNUX0NBTExCQUNLX1NUQVRVUy5MT0dPTl9HRVRfR0FNRV9JTkZPKTtcbiAgICAgICAgfSk7XG4gICAgfSxcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgaGFuZGxlcl9MT0dPTl9QTEFURk9STV9GQUlMRUQ6IGZ1bmN0aW9uIGhhbmRsZXJfTE9HT05fUExBVEZPUk1fRkFJTEVEKGV2ZW50KSB7XG4gICAgICAgIHZhciBib2R5TXNnID0gZXZlbnQuZGV0YWlsLm1zZ0JvZHk7XG4gICAgICAgIHZhciBpbnN0YW5jZUdsb2JhbCA9IGV2ZW50LmRldGFpbC5pbnN0YW5jZUdsb2JhbDtcblxuICAgICAgICB2YXIgaW5kZXggPSAwO1xuICAgICAgICB2YXIgZXJyb3JDb2RlID0gYm9keU1zZ1tpbmRleF0uX2ludF92YWx1ZTtcbiAgICAgICAgLy8gLi4uLuagueaNrumUmeivr+eggeWOu+aPkOekulxuICAgICAgICB2YXIgY3VyQ29tcCA9IGluc3RhbmNlR2xvYmFsLmhpbnQuZ2V0Q29tcG9uZW50KFwiSGludE1hbmFnZXJcIik7XG4gICAgICAgIGN1ckNvbXAuU2hvd0hpbnQoXCLotKblj7fmiJbogIXlr4bnoIHovpPlhaXplJnor6/vvIFcIik7XG4gICAgfSxcblxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgaGFuZGxlcl9DUkVBVEVfQUNDT1VOVF9GQUlMRUQ6IGZ1bmN0aW9uIGhhbmRsZXJfQ1JFQVRFX0FDQ09VTlRfRkFJTEVEKGV2ZW50KSB7XG4gICAgICAgIHZhciBib2R5TXNnID0gZXZlbnQuZGV0YWlsLm1zZ0JvZHk7XG4gICAgICAgIHZhciBpbnN0YW5jZUdsb2JhbCA9IGV2ZW50LmRldGFpbC5pbnN0YW5jZUdsb2JhbDtcblxuICAgICAgICB2YXIgY3VyQ29tcCA9IGluc3RhbmNlR2xvYmFsLmhpbnQuZ2V0Q29tcG9uZW50KFwiSGludE1hbmFnZXJcIik7XG4gICAgICAgIGN1ckNvbXAuU2hvd0hpbnQoXCLliJvlu7rotKblj7flpLHotKXvvIFcIik7XG4gICAgfSxcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIGhhbmRsZXJfVVBEQVRFX09OTElORV9DT1VOVF9TVUNDRVNTOiBmdW5jdGlvbiBoYW5kbGVyX1VQREFURV9PTkxJTkVfQ09VTlRfU1VDQ0VTUyhldmVudCkge1xuICAgICAgICB2YXIgYm9keU1zZyA9IGV2ZW50LmRldGFpbC5tc2dCb2R5O1xuICAgICAgICB2YXIgaW5zdGFuY2VHbG9iYWwgPSBldmVudC5kZXRhaWwuaW5zdGFuY2VHbG9iYWw7XG5cbiAgICAgICAgaWYgKGluc3RhbmNlR2xvYmFsLnNlbGZEYXRhLm5DdXJHYW1lSUQgPT0gMCkge1xuICAgICAgICAgICAgaW5zdGFuY2VHbG9iYWwuc2VsZkRhdGEuZ2FtZXMubGVuZ3RoID0gMDtcbiAgICAgICAgICAgIHZhciBpdGVtQ291bnQgPSAyO1xuICAgICAgICAgICAgdmFyIGNvdW50ID0gKGJvZHlNc2cubGVuZ3RoIC0gMSkgLyBpdGVtQ291bnQ7XG5cbiAgICAgICAgICAgIGZvciAodmFyIF9pID0gMDsgX2kgPCBjb3VudDsgX2krKykge1xuICAgICAgICAgICAgICAgIHZhciBpbmRleDEgPSAwO1xuICAgICAgICAgICAgICAgIHZhciBpdGVtID0ge307XG4gICAgICAgICAgICAgICAgaXRlbS5nYW1lSUQgPSBib2R5TXNnWzEgKyBfaSAqIGl0ZW1Db3VudCArIGluZGV4MSsrXS5faW50X3ZhbHVlO1xuICAgICAgICAgICAgICAgIGl0ZW0ub25MaW5lQ291bnQgPSBib2R5TXNnWzEgKyBfaSAqIGl0ZW1Db3VudCArIGluZGV4MSsrXS5faW50X3ZhbHVlO1xuICAgICAgICAgICAgICAgIGluc3RhbmNlR2xvYmFsLnNlbGZEYXRhLmdhbWVzLnB1c2goaXRlbSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB2YXIgQ2FudmFzID0gY2MuZGlyZWN0b3IuZ2V0U2NlbmUoKS5nZXRDaGlsZEJ5TmFtZSgnQ2FudmFzJyk7XG4gICAgICAgICAgICB2YXIgZ2FtZU5vZGUgPSBjYy5maW5kKFwiYm9keS9nYW1lXCIsIENhbnZhcyk7XG4gICAgICAgICAgICB2YXIgZ2FtZUNvbnRyb2xsZXIgPSBnYW1lTm9kZS5nZXRDb21wb25lbnQoXCJHYW1lQ29udHJvbGxlclwiKTtcbiAgICAgICAgICAgIGdhbWVDb250cm9sbGVyLnVwZGF0ZUdhbWVzSW5mbygpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdmFyIGdhbWVJbmZvID0gaW5zdGFuY2VHbG9iYWwuY29uZkRhdGEuZ2V0S2luZEJhc2VJbmZvKGluc3RhbmNlR2xvYmFsLnNlbGZEYXRhLm5DdXJHYW1lSUQpO1xuICAgICAgICAgICAgdmFyIGFsaWFzID0gZ2FtZUluZm8uYWxpYXM7XG4gICAgICAgICAgICB2YXIgZ2FtZURhdGEgPSBpbnN0YW5jZUdsb2JhbC5nYW1lLmdldENoaWxkQnlOYW1lKFwiZ2FtZURhdGFcIikuZ2V0Q29tcG9uZW50KGFsaWFzICsgXCJHYW1lRGF0YVwiKTtcbiAgICAgICAgICAgIGdhbWVEYXRhLnJvb21zLmxlbmd0aCA9IDA7XG4gICAgICAgICAgICB2YXIgaXRlbUNvdW50ID0gMjtcbiAgICAgICAgICAgIHZhciBjb3VudCA9IChib2R5TXNnLmxlbmd0aCAtIDEpIC8gaXRlbUNvdW50O1xuXG4gICAgICAgICAgICBmb3IgKHZhciBfaTIgPSAwOyBfaTIgPCBjb3VudDsgX2kyKyspIHtcbiAgICAgICAgICAgICAgICB2YXIgaW5kZXgxID0gMDtcbiAgICAgICAgICAgICAgICB2YXIgaXRlbSA9IHt9O1xuICAgICAgICAgICAgICAgIGl0ZW0ublJvb21JRCA9IGJvZHlNc2dbMSArIF9pMiAqIGl0ZW1Db3VudCArIGluZGV4MSsrXS5faW50X3ZhbHVlO1xuICAgICAgICAgICAgICAgIGl0ZW0ub25MaW5lQ291bnQgPSBib2R5TXNnWzEgKyBfaTIgKiBpdGVtQ291bnQgKyBpbmRleDErK10uX2ludF92YWx1ZTtcbiAgICAgICAgICAgICAgICBnYW1lRGF0YS5yb29tcy5wdXNoKGl0ZW0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSxcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIGhhbmRsZXJfVVBEQVRFX09OTElORV9DT1VOVF9GQUlMRUQ6IGZ1bmN0aW9uIGhhbmRsZXJfVVBEQVRFX09OTElORV9DT1VOVF9GQUlMRUQoZXZlbnQpIHtcbiAgICAgICAgdmFyIGJvZHlNc2cgPSBldmVudC5kZXRhaWwubXNnQm9keTtcbiAgICAgICAgdmFyIGluc3RhbmNlR2xvYmFsID0gZXZlbnQuZGV0YWlsLmluc3RhbmNlR2xvYmFsO1xuICAgIH0sXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICBoYW5kbGVyX0NIQVRfU1VDQ0VTUzogZnVuY3Rpb24gaGFuZGxlcl9DSEFUX1NVQ0NFU1MoZXZlbnQpIHtcbiAgICAgICAgdmFyIGJvZHlNc2cgPSBldmVudC5kZXRhaWwubXNnQm9keTtcbiAgICAgICAgdmFyIGluc3RhbmNlR2xvYmFsID0gZXZlbnQuZGV0YWlsLmluc3RhbmNlR2xvYmFsO1xuICAgIH0sXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICBoYW5kbGVyX0NIQVRfRkFJTEVEOiBmdW5jdGlvbiBoYW5kbGVyX0NIQVRfRkFJTEVEKGV2ZW50KSB7XG4gICAgICAgIHZhciBib2R5TXNnID0gZXZlbnQuZGV0YWlsLm1zZ0JvZHk7XG4gICAgICAgIHZhciBpbnN0YW5jZUdsb2JhbCA9IGV2ZW50LmRldGFpbC5pbnN0YW5jZUdsb2JhbDtcbiAgICB9LFxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgaGFuZGxlcl9HRVRfQ0hBVF9TVUNDRVNTOiBmdW5jdGlvbiBoYW5kbGVyX0dFVF9DSEFUX1NVQ0NFU1MoZXZlbnQpIHtcbiAgICAgICAgdmFyIGJvZHlNc2cgPSBldmVudC5kZXRhaWwubXNnQm9keTtcbiAgICAgICAgdmFyIGluc3RhbmNlR2xvYmFsID0gZXZlbnQuZGV0YWlsLmluc3RhbmNlR2xvYmFsO1xuXG4gICAgICAgIGluc3RhbmNlR2xvYmFsLnNlbGZEYXRhLm1lc3NhZ2VzID0ge307XG4gICAgICAgIHZhciBtZXNzYWdlcyA9IGluc3RhbmNlR2xvYmFsLnNlbGZEYXRhLm1lc3NhZ2VzO1xuXG4gICAgICAgIHZhciBpbmRleCA9IDA7XG4gICAgICAgIHZhciBuQWNjb3VudElEID0gYm9keU1zZ1tpbmRleCsrXS5faW50X3ZhbHVlO1xuICAgICAgICB2YXIgaXRlbUNvdW50ID0gOTtcbiAgICAgICAgdmFyIGNvdW50ID0gKGJvZHlNc2cubGVuZ3RoIC0gMSkgLyBpdGVtQ291bnQ7XG4gICAgICAgIGZvciAodmFyIF9pMyA9IDA7IF9pMyA8IGNvdW50OyBfaTMrKykge1xuICAgICAgICAgICAgdmFyIGluZGV4MSA9IDA7XG4gICAgICAgICAgICB2YXIgbkZpZCA9IGJvZHlNc2dbMSArIF9pMyAqIGl0ZW1Db3VudCArIGluZGV4MSsrXS5faW50X3ZhbHVlO1xuICAgICAgICAgICAgbWVzc2FnZXNbbkZpZF0gPSB7fTtcbiAgICAgICAgICAgIG1lc3NhZ2VzW25GaWRdLm5UeXBlID0gYm9keU1zZ1sxICsgX2kzICogaXRlbUNvdW50ICsgaW5kZXgxKytdLl9pbnRfdmFsdWU7XG4gICAgICAgICAgICBtZXNzYWdlc1tuRmlkXS5uU2VuZElEID0gYm9keU1zZ1sxICsgX2kzICogaXRlbUNvdW50ICsgaW5kZXgxKytdLl9pbnRfdmFsdWU7XG4gICAgICAgICAgICBtZXNzYWdlc1tuRmlkXS5uU2VuZFRTID0gYm9keU1zZ1sxICsgX2kzICogaXRlbUNvdW50ICsgaW5kZXgxKytdLl9pbnRfdmFsdWU7XG4gICAgICAgICAgICBtZXNzYWdlc1tuRmlkXS5uUGFyYW0xID0gYm9keU1zZ1sxICsgX2kzICogaXRlbUNvdW50ICsgaW5kZXgxKytdLl9pbnRfdmFsdWU7XG4gICAgICAgICAgICBtZXNzYWdlc1tuRmlkXS5uUGFyYW0yID0gYm9keU1zZ1sxICsgX2kzICogaXRlbUNvdW50ICsgaW5kZXgxKytdLl9pbnRfdmFsdWU7XG4gICAgICAgICAgICBtZXNzYWdlc1tuRmlkXS5zVGl0bGUgPSBib2R5TXNnWzEgKyBfaTMgKiBpdGVtQ291bnQgKyBpbmRleDErK10uX3N0cl92YWx1ZTtcbiAgICAgICAgICAgIG1lc3NhZ2VzW25GaWRdLnNDb250ZW50ID0gYm9keU1zZ1sxICsgX2kzICogaXRlbUNvdW50ICsgaW5kZXgxKytdLl9zdHJfdmFsdWU7XG4gICAgICAgICAgICBtZXNzYWdlc1tuRmlkXS5zQXR0YWNobWVudCA9IGJvZHlNc2dbMSArIF9pMyAqIGl0ZW1Db3VudCArIGluZGV4MSsrXS5fc3RyX3ZhbHVlO1xuICAgICAgICB9XG4gICAgICAgIGluc3RhbmNlR2xvYmFsLnNlbGZEYXRhLnJlZnJlc2hDaGF0VUkoKTtcbiAgICB9LFxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgaGFuZGxlcl9HRVRfQ0hBVF9GQUlMRUQ6IGZ1bmN0aW9uIGhhbmRsZXJfR0VUX0NIQVRfRkFJTEVEKGV2ZW50KSB7XG4gICAgICAgIHZhciBib2R5TXNnID0gZXZlbnQuZGV0YWlsLm1zZ0JvZHk7XG4gICAgICAgIHZhciBpbnN0YW5jZUdsb2JhbCA9IGV2ZW50LmRldGFpbC5pbnN0YW5jZUdsb2JhbDtcbiAgICB9LFxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgaGFuZGxlcl9HRVRfUkVMQVRJT05fU1VDQ0VTUzogZnVuY3Rpb24gaGFuZGxlcl9HRVRfUkVMQVRJT05fU1VDQ0VTUyhldmVudCkge1xuICAgICAgICB2YXIgYm9keU1zZyA9IGV2ZW50LmRldGFpbC5tc2dCb2R5O1xuICAgICAgICB2YXIgaW5zdGFuY2VHbG9iYWwgPSBldmVudC5kZXRhaWwuaW5zdGFuY2VHbG9iYWw7XG5cbiAgICAgICAgdmFyIGluZGV4ID0gMDtcbiAgICAgICAgdmFyIG5BY2NvdW50SUQgPSBib2R5TXNnW2luZGV4KytdLl9pbnRfdmFsdWU7XG4gICAgICAgIHZhciBpdGVtQ291bnQgPSAyO1xuICAgICAgICB2YXIgY291bnQgPSAoYm9keU1zZy5sZW5ndGggLSAxKSAvIGl0ZW1Db3VudDtcbiAgICAgICAgaW5zdGFuY2VHbG9iYWwuc2VsZkRhdGEucmVsYXRpb25zID0ge307XG4gICAgICAgIHZhciByZWxhdGlvbnMgPSBpbnN0YW5jZUdsb2JhbC5zZWxmRGF0YS5yZWxhdGlvbnM7XG4gICAgICAgIGZvciAoaSA9IDA7IGkgPCBjb3VudDsgaSsrKSB7XG4gICAgICAgICAgICB2YXIgaW5kZXgxID0gMDtcbiAgICAgICAgICAgIHZhciBuUGVlcklEID0gYm9keU1zZ1sxICsgaSAqIGl0ZW1Db3VudCArIGluZGV4MSsrXS5faW50X3ZhbHVlO1xuICAgICAgICAgICAgdmFyIG5QYXJhbSA9IGJvZHlNc2dbMSArIGkgKiBpdGVtQ291bnQgKyBpbmRleDErK10uX2ludF92YWx1ZTtcbiAgICAgICAgICAgIHJlbGF0aW9uc1tuUGVlcklEXSA9IHt9O1xuICAgICAgICAgICAgcmVsYXRpb25zW25QZWVySURdID0gblBhcmFtO1xuICAgICAgICB9XG4gICAgfSxcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIGhhbmRsZXJfR0VUX1JFTEFUSU9OX0ZBSUxFRDogZnVuY3Rpb24gaGFuZGxlcl9HRVRfUkVMQVRJT05fRkFJTEVEKGV2ZW50KSB7XG4gICAgICAgIHZhciBib2R5TXNnID0gZXZlbnQuZGV0YWlsLm1zZ0JvZHk7XG4gICAgICAgIHZhciBpbnN0YW5jZUdsb2JhbCA9IGV2ZW50LmRldGFpbC5pbnN0YW5jZUdsb2JhbDtcbiAgICB9LFxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgaGFuZGxlcl9TRVRfUkVMQVRJT05fU1VDQ0VTUzogZnVuY3Rpb24gaGFuZGxlcl9TRVRfUkVMQVRJT05fU1VDQ0VTUyhldmVudCkge1xuICAgICAgICB2YXIgYm9keU1zZyA9IGV2ZW50LmRldGFpbC5tc2dCb2R5O1xuICAgICAgICB2YXIgaW5zdGFuY2VHbG9iYWwgPSBldmVudC5kZXRhaWwuaW5zdGFuY2VHbG9iYWw7XG5cbiAgICAgICAgdmFyIGluZGV4ID0gMDtcbiAgICAgICAgdmFyIG5BY2NvdW50SUQgPSBib2R5TXNnW2luZGV4KytdLl9pbnRfdmFsdWU7XG4gICAgICAgIHZhciBuVHlwZSA9IGJvZHlNc2dbaW5kZXgrK10uX2ludF92YWx1ZTtcbiAgICAgICAgdmFyIG5QZWVySUQgPSBib2R5TXNnW2luZGV4KytdLl9pbnRfdmFsdWU7XG4gICAgfSxcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIGhhbmRsZXJfU0VUX1JFTEFUSU9OX0ZBSUxFRDogZnVuY3Rpb24gaGFuZGxlcl9TRVRfUkVMQVRJT05fRkFJTEVEKGV2ZW50KSB7XG4gICAgICAgIHZhciBib2R5TXNnID0gZXZlbnQuZGV0YWlsLm1zZ0JvZHk7XG4gICAgICAgIHZhciBpbnN0YW5jZUdsb2JhbCA9IGV2ZW50LmRldGFpbC5pbnN0YW5jZUdsb2JhbDtcbiAgICB9XG59O1xuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG5tb2R1bGUuZXhwb3J0cyA9IE1lc3NhZ2VIYW5kbGU7XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICdkNmIyOG5RSVVaRy9LTlQ3K2dSUHJBNycsICdOb2RlRmFkZXInKTtcbi8vIEdsb2JhbC9xaXN1TGliL1Nob3cvTm9kZUZhZGVyLmpzXG5cbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICBkdXJpbmc6IDAuNVxuICAgIH0sXG4gICAgR2V0RHVyaW5nOiBmdW5jdGlvbiBHZXREdXJpbmcoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmR1cmluZztcbiAgICB9LFxuICAgIFNob3c6IGZ1bmN0aW9uIFNob3coKSB7XG4gICAgICAgIHZhciBhaW1Ob2RlID0gYXJndW1lbnRzLmxlbmd0aCA8PSAwIHx8IGFyZ3VtZW50c1swXSA9PT0gdW5kZWZpbmVkID8gbnVsbCA6IGFyZ3VtZW50c1swXTtcblxuICAgICAgICB2YXIgY3VyTm9kZSA9IGFpbU5vZGU7XG4gICAgICAgIGlmIChhaW1Ob2RlID09PSBudWxsKSBjdXJOb2RlID0gdGhpcy5ub2RlO1xuXG4gICAgICAgIGlmIChjdXJOb2RlLmFjdGl2ZSA9PSB0cnVlKSByZXR1cm47XG4gICAgICAgIGN1ck5vZGUub3BhY2l0eSA9IDA7XG4gICAgICAgIGN1ck5vZGUuYWN0aXZlID0gdHJ1ZTtcblxuICAgICAgICB2YXIgc2VxID0gY2Muc2VxdWVuY2UoY2MuZmFkZUluKHRoaXMuZHVyaW5nKSk7XG4gICAgICAgIGN1ck5vZGUucnVuQWN0aW9uKHNlcSk7XG4gICAgfSxcbiAgICBIaWRlOiBmdW5jdGlvbiBIaWRlKCkge1xuICAgICAgICB2YXIgYWltTm9kZSA9IGFyZ3VtZW50cy5sZW5ndGggPD0gMCB8fCBhcmd1bWVudHNbMF0gPT09IHVuZGVmaW5lZCA/IG51bGwgOiBhcmd1bWVudHNbMF07XG5cbiAgICAgICAgdmFyIGN1ck5vZGUgPSBhaW1Ob2RlO1xuICAgICAgICBpZiAoYWltTm9kZSA9PT0gbnVsbCkgY3VyTm9kZSA9IHRoaXMubm9kZTtcblxuICAgICAgICB2YXIgZmluaXNoZWQgPSBjYy5jYWxsRnVuYyhmdW5jdGlvbiAodGFyZ2V0LCB2YWwpIHtcbiAgICAgICAgICAgIGN1ck5vZGUuYWN0aXZlID0gdmFsO1xuICAgICAgICB9LCBjdXJOb2RlLCBmYWxzZSk7XG5cbiAgICAgICAgaWYgKGN1ck5vZGUuYWN0aXZlID09PSBmYWxzZSkgcmV0dXJuO1xuICAgICAgICBjdXJOb2RlLm9wYWNpdHkgPSAyNTU7XG5cbiAgICAgICAgdmFyIHNlcSA9IGNjLnNlcXVlbmNlKGNjLmZhZGVPdXQodGhpcy5kdXJpbmcpLCBmaW5pc2hlZCk7XG4gICAgICAgIGN1ck5vZGUucnVuQWN0aW9uKHNlcSk7XG4gICAgfVxufSk7XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICdmYzQ1Zisxb1lCRE43VEEvWFFCeXd5KycsICdOb2RlU2NhbGVyJyk7XG4vLyBHbG9iYWwvcWlzdUxpYi9TaG93L05vZGVTY2FsZXIuanNcblxuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIGJpZ1NjYWxlOiAxLjJcbiAgICB9LFxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge30sXG4gICAgb25EZXN0cm95OiBmdW5jdGlvbiBvbkRlc3Ryb3koKSB7fSxcbiAgICBvbkVuYWJsZTogZnVuY3Rpb24gb25FbmFibGUoKSB7fSxcbiAgICBvbkRpc2FibGU6IGZ1bmN0aW9uIG9uRGlzYWJsZSgpIHt9LFxuICAgIFNob3c6IGZ1bmN0aW9uIFNob3coKSB7XG4gICAgICAgIGlmICh0aGlzLm5vZGUuYWN0aXZlID09IHRydWUpIHJldHVybjtcbiAgICAgICAgdGhpcy5ub2RlLnNjYWxlID0gMDtcbiAgICAgICAgdGhpcy5ub2RlLmFjdGl2ZSA9IHRydWU7XG5cbiAgICAgICAgdmFyIHNlcSA9IGNjLnNlcXVlbmNlKGNjLnNjYWxlVG8oMC4yLCB0aGlzLmJpZ1NjYWxlKSwgY2Muc2NhbGVUbygwLjIsIDEpKTtcbiAgICAgICAgdGhpcy5ub2RlLnJ1bkFjdGlvbihzZXEpO1xuICAgIH0sXG4gICAgSGlkZTogZnVuY3Rpb24gSGlkZSgpIHtcbiAgICAgICAgdmFyIGZpbmlzaGVkID0gY2MuY2FsbEZ1bmMoZnVuY3Rpb24gKHRhcmdldCwgdmFsKSB7XG4gICAgICAgICAgICB0aGlzLm5vZGUuYWN0aXZlID0gdmFsO1xuICAgICAgICB9LCB0aGlzLCBmYWxzZSk7XG5cbiAgICAgICAgaWYgKHRoaXMubm9kZS5hY3RpdmUgPT09IGZhbHNlKSByZXR1cm47XG4gICAgICAgIHRoaXMubm9kZS5zY2FsZSA9IDE7XG5cbiAgICAgICAgdmFyIHNlcSA9IGNjLnNlcXVlbmNlKGNjLnNjYWxlVG8oMC4yLCB0aGlzLmJpZ1NjYWxlKSwgY2Muc2NhbGVUbygwLjIsIDApLCBmaW5pc2hlZCk7XG4gICAgICAgIHRoaXMubm9kZS5ydW5BY3Rpb24oc2VxKTtcbiAgICB9LFxuXG4gICAgU2hvd0E6IGZ1bmN0aW9uIFNob3dBKCkge1xuICAgICAgICB0aGlzLm5vZGUuc2NhbGUgPSAwO1xuXG4gICAgICAgIHZhciBzZXEgPSBjYy5zZXF1ZW5jZShjYy5zY2FsZVRvKDAuMiwgdGhpcy5iaWdTY2FsZSksIGNjLnNjYWxlVG8oMC4yLCAxKSk7XG4gICAgICAgIHRoaXMubm9kZS5ydW5BY3Rpb24oc2VxKTtcbiAgICB9XG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJ2Y0MTY5TzRHa3RNaFpGWkN4UGpjTTJrJywgJ1Byb3RvY29sSXRlbScpO1xuLy8gR2xvYmFsL3Fpc3VMaWIvY29tbS9Qcm90b2NvbEl0ZW0uanNcblxudmFyIFByb3RvY29sSXRlbSA9IGZ1bmN0aW9uIFByb3RvY29sSXRlbSgpIHtcblx0dGhpcy5fZGF0YXR5cGUgPSAwO1xuXHR0aGlzLl9pbnRfdmFsdWUgPSAwO1xuXHR0aGlzLl9zdHJfdmFsdWUgPSBcIlwiO1xuXHR0aGlzLl92ZWN0X3ZhbHVlID0ge307XG59O1xuXG5Qcm90b2NvbEl0ZW0uREFUQVRZUEVfQllURSA9IDE7XG5Qcm90b2NvbEl0ZW0uREFUQVRZUEVfU0hPUlQgPSAyO1xuUHJvdG9jb2xJdGVtLkRBVEFUWVBFX0lOVCA9IDM7XG5Qcm90b2NvbEl0ZW0uREFUQVRZUEVfU1RSSU5HID0gNDtcblByb3RvY29sSXRlbS5EQVRBVFlQRV9WRUNUT1IgPSA1O1xuXG5Qcm90b2NvbEl0ZW0uU2VuZEJ5dGVNYXAgPSBbMHg3MCwgMHgyRiwgMHg0MCwgMHg1RiwgMHg0NCwgMHg4RSwgMHg2RSwgMHg0NSwgMHg3RSwgMHhBQiwgMHgyQywgMHgxRiwgMHhCNCwgMHhBQywgMHg5RCwgMHg5MSwgMHgwRCwgMHgzNiwgMHg5QiwgMHgwQiwgMHhENCwgMHhDNCwgMHgzOSwgMHg3NCwgMHhCRiwgMHgyMywgMHgxNiwgMHgxNCwgMHgwNiwgMHhFQiwgMHgwNCwgMHgzRSwgMHgxMiwgMHg1QywgMHg4QiwgMHhCQywgMHg2MSwgMHg2MywgMHhGNiwgMHhBNSwgMHhFMSwgMHg2NSwgMHhEOCwgMHhGNSwgMHg1QSwgMHgwNywgMHhGMCwgMHgxMywgMHhGMiwgMHgyMCwgMHg2QiwgMHg0QSwgMHgyNCwgMHg1OSwgMHg4OSwgMHg2NCwgMHhENywgMHg0MiwgMHg2QSwgMHg1RSwgMHgzRCwgMHgwQSwgMHg3NywgMHhFMCwgMHg4MCwgMHgyNywgMHhCOCwgMHhDNSwgMHg4QywgMHgwRSwgMHhGQSwgMHg4QSwgMHhENSwgMHgyOSwgMHg1NiwgMHg1NywgMHg2QywgMHg1MywgMHg2NywgMHg0MSwgMHhFOCwgMHgwMCwgMHgxQSwgMHhDRSwgMHg4NiwgMHg4MywgMHhCMCwgMHgyMiwgMHgyOCwgMHg0RCwgMHgzRiwgMHgyNiwgMHg0NiwgMHg0RiwgMHg2RiwgMHgyQiwgMHg3MiwgMHgzQSwgMHhGMSwgMHg4RCwgMHg5NywgMHg5NSwgMHg0OSwgMHg4NCwgMHhFNSwgMHhFMywgMHg3OSwgMHg4RiwgMHg1MSwgMHgxMCwgMHhBOCwgMHg4MiwgMHhDNiwgMHhERCwgMHhGRiwgMHhGQywgMHhFNCwgMHhDRiwgMHhCMywgMHgwOSwgMHg1RCwgMHhFQSwgMHg5QywgMHgzNCwgMHhGOSwgMHgxNywgMHg5RiwgMHhEQSwgMHg4NywgMHhGOCwgMHgxNSwgMHgwNSwgMHgzQywgMHhEMywgMHhBNCwgMHg4NSwgMHgyRSwgMHhGQiwgMHhFRSwgMHg0NywgMHgzQiwgMHhFRiwgMHgzNywgMHg3RiwgMHg5MywgMHhBRiwgMHg2OSwgMHgwQywgMHg3MSwgMHgzMSwgMHhERSwgMHgyMSwgMHg3NSwgMHhBMCwgMHhBQSwgMHhCQSwgMHg3QywgMHgzOCwgMHgwMiwgMHhCNywgMHg4MSwgMHgwMSwgMHhGRCwgMHhFNywgMHgxRCwgMHhDQywgMHhDRCwgMHhCRCwgMHgxQiwgMHg3QSwgMHgyQSwgMHhBRCwgMHg2NiwgMHhCRSwgMHg1NSwgMHgzMywgMHgwMywgMHhEQiwgMHg4OCwgMHhCMiwgMHgxRSwgMHg0RSwgMHhCOSwgMHhFNiwgMHhDMiwgMHhGNywgMHhDQiwgMHg3RCwgMHhDOSwgMHg2MiwgMHhDMywgMHhBNiwgMHhEQywgMHhBNywgMHg1MCwgMHhCNSwgMHg0QiwgMHg5NCwgMHhDMCwgMHg5MiwgMHg0QywgMHgxMSwgMHg1QiwgMHg3OCwgMHhEOSwgMHhCMSwgMHhFRCwgMHgxOSwgMHhFOSwgMHhBMSwgMHgxQywgMHhCNiwgMHgzMiwgMHg5OSwgMHhBMywgMHg3NiwgMHg5RSwgMHg3QiwgMHg2RCwgMHg5QSwgMHgzMCwgMHhENiwgMHhBOSwgMHgyNSwgMHhDNywgMHhBRSwgMHg5NiwgMHgzNSwgMHhEMCwgMHhCQiwgMHhEMiwgMHhDOCwgMHhBMiwgMHgwOCwgMHhGMywgMHhEMSwgMHg3MywgMHhGNCwgMHg0OCwgMHgyRCwgMHg5MCwgMHhDQSwgMHhFMiwgMHg1OCwgMHhDMSwgMHgxOCwgMHg1MiwgMHhGRSwgMHhERiwgMHg2OCwgMHg5OCwgMHg1NCwgMHhFQywgMHg2MCwgMHg0MywgMHgwRl07XG5cblByb3RvY29sSXRlbS5SZWN2Qnl0ZU1hcCA9IFsweDUxLCAweEExLCAweDlFLCAweEIwLCAweDFFLCAweDgzLCAweDFDLCAweDJELCAweEU5LCAweDc3LCAweDNELCAweDEzLCAweDkzLCAweDEwLCAweDQ1LCAweEZGLCAweDZELCAweEM5LCAweDIwLCAweDJGLCAweDFCLCAweDgyLCAweDFBLCAweDdELCAweEY1LCAweENGLCAweDUyLCAweEE4LCAweEQyLCAweEE0LCAweEI0LCAweDBCLCAweDMxLCAweDk3LCAweDU3LCAweDE5LCAweDM0LCAweERGLCAweDVCLCAweDQxLCAweDU4LCAweDQ5LCAweEFBLCAweDVGLCAweDBBLCAweEVGLCAweDg4LCAweDAxLCAweERDLCAweDk1LCAweEQ0LCAweEFGLCAweDdCLCAweEUzLCAweDExLCAweDhFLCAweDlELCAweDE2LCAweDYxLCAweDhDLCAweDg0LCAweDNDLCAweDFGLCAweDVBLCAweDAyLCAweDRGLCAweDM5LCAweEZFLCAweDA0LCAweDA3LCAweDVDLCAweDhCLCAweEVFLCAweDY2LCAweDMzLCAweEM0LCAweEM4LCAweDU5LCAweEI1LCAweDVELCAweEMyLCAweDZDLCAweEY2LCAweDRELCAweEZCLCAweEFFLCAweDRBLCAweDRCLCAweEYzLCAweDM1LCAweDJDLCAweENBLCAweDIxLCAweDc4LCAweDNCLCAweDAzLCAweEZELCAweDI0LCAweEJELCAweDI1LCAweDM3LCAweDI5LCAweEFDLCAweDRFLCAweEY5LCAweDkyLCAweDNBLCAweDMyLCAweDRDLCAweERBLCAweDA2LCAweDVFLCAweDAwLCAweDk0LCAweDYwLCAweEVDLCAweDE3LCAweDk4LCAweEQ3LCAweDNFLCAweENCLCAweDZBLCAweEE5LCAweEQ5LCAweDlDLCAweEJCLCAweDA4LCAweDhGLCAweDQwLCAweEEwLCAweDZGLCAweDU1LCAweDY3LCAweDg3LCAweDU0LCAweDgwLCAweEIyLCAweDM2LCAweDQ3LCAweDIyLCAweDQ0LCAweDYzLCAweDA1LCAweDZCLCAweEYwLCAweDBGLCAweEM3LCAweDkwLCAweEM1LCAweDY1LCAweEUyLCAweDY0LCAweEZBLCAweEQ1LCAweERCLCAweDEyLCAweDdBLCAweDBFLCAweEQ4LCAweDdFLCAweDk5LCAweEQxLCAweEU4LCAweEQ2LCAweDg2LCAweDI3LCAweEJGLCAweEMxLCAweDZFLCAweERFLCAweDlBLCAweDA5LCAweDBELCAweEFCLCAweEUxLCAweDkxLCAweDU2LCAweENELCAweEIzLCAweDc2LCAweDBDLCAweEMzLCAweEQzLCAweDlGLCAweDQyLCAweEI2LCAweDlCLCAweEU1LCAweDIzLCAweEE3LCAweEFELCAweDE4LCAweEM2LCAweEY0LCAweEI4LCAweEJFLCAweDE1LCAweDQzLCAweDcwLCAweEUwLCAweEU3LCAweEJDLCAweEYxLCAweEJBLCAweEE1LCAweEE2LCAweDUzLCAweDc1LCAweEU0LCAweEVCLCAweEU2LCAweDg1LCAweDE0LCAweDQ4LCAweERELCAweDM4LCAweDJBLCAweENDLCAweDdGLCAweEIxLCAweEMwLCAweDcxLCAweDk2LCAweEY4LCAweDNGLCAweDI4LCAweEYyLCAweDY5LCAweDc0LCAweDY4LCAweEI3LCAweEEzLCAweDUwLCAweEQwLCAweDc5LCAweDFELCAweEZDLCAweENFLCAweDhBLCAweDhELCAweDJFLCAweDYyLCAweDMwLCAweEVBLCAweEVELCAweDJCLCAweDI2LCAweEI5LCAweDgxLCAweDdDLCAweDQ2LCAweDg5LCAweDczLCAweEEyLCAweEY3LCAweDcyXTtcblxuUHJvdG9jb2xJdGVtLlNPQ0tFVF9WRVIgPSAweDE3O1xuUHJvdG9jb2xJdGVtLlNPQ0tFVF9CVUZGRVIgPSA4MTkyO1xuUHJvdG9jb2xJdGVtLlNPQ0tFVF9LRVkgPSAweDU1O1xuXG5Qcm90b2NvbEl0ZW0uQlVGRkVSX1NURVAgPSAxMDA7XG5Qcm90b2NvbEl0ZW0uQlVGRkVSX0lOSVQgPSA1MDtcblByb3RvY29sSXRlbS5CVUZGRVJfUkVDViA9IDEwMjQ7XG5cbm1vZHVsZS5leHBvcnRzID0gUHJvdG9jb2xJdGVtO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnN2Q5ZDJyMnAwQkJWNXF2NmxKSGdDU1InLCAnUHJvdG9jb2xNZXNzYWdlJyk7XG4vLyBHbG9iYWwvcWlzdUxpYi9jb21tL1Byb3RvY29sTWVzc2FnZS5qc1xuXG52YXIgUHJvdG9jb2xJdGVtID0gcmVxdWlyZShcIlByb3RvY29sSXRlbVwiKTtcblxudmFyIFByb3RvY29sTWVzc2FnZSA9IGZ1bmN0aW9uIFByb3RvY29sTWVzc2FnZShuTWFpbkNtZCwgblN1YkNtZCwgZW5kaWFuKSB7XG4gICAgdGhpcy5fZW5kaWFuID0gZW5kaWFuO1xuXG4gICAgLy8gbXNnIGhlYWRcbiAgICB0aGlzLl9oZWFkX3ZlcnNpb24gPSAwOyAvLyAx5a2X6IqCXG4gICAgdGhpcy5faGVhZF9jaGVja0NvZGUgPSAwOyAvLyAx5a2X6IqCXG4gICAgdGhpcy5faGVhZF9tc2dMZW4gPSAwOyAvLyAy5a2X6IqC77yM5pW05Liq5raI5oGv6ZW/5bqmXG4gICAgdGhpcy5faGVhZF9tYWluQ21kSUQgPSBuTWFpbkNtZDsgLy8gMuWtl+iKglxuICAgIHRoaXMuX2hlYWRfc3ViQ21kSUQgPSBuU3ViQ21kOyAvLyAy5a2X6IqCXG5cbiAgICAvLyBtc2cgYm9keVxuICAgIHRoaXMuX2JvZHlfbXNnID0gbmV3IEFycmF5KDApO1xuXG4gICAgLy8g56CB5rWBXG4gICAgdGhpcy5kYXRhX2J1ZmZlciA9IG5ldyBBcnJheUJ1ZmZlcihQcm90b2NvbEl0ZW0uQlVGRkVSX0lOSVQpO1xuICAgIHRoaXMuZGF0YV92aWV3ID0gbmV3IERhdGFWaWV3KHRoaXMuZGF0YV9idWZmZXIpO1xuICAgIHRoaXMuZGF0YV9sZW5ndGggPSAwO1xuICAgIHRoaXMuZGF0YV9vZmZzZXQgPSAwO1xuICAgIHRoaXMuX2J5dGVfYXJyYXkgPSBudWxsOyAvLyBVaW50OEFycmF5XG5cbiAgICAvLyDovoXliqlcbiAgICB0aGlzLl9yZWNlaXZlX3NlcSA9IDA7XG4gICAgdGhpcy5fcmVtYWluTGVuID0gMDtcbn07XG5cblByb3RvY29sTWVzc2FnZS5HZXRBdmFpbGFibGUgPSBmdW5jdGlvbiAobXNnKSB7XG4gICAgcmV0dXJuIG1zZy5kYXRhX2xlbmd0aCAtIG1zZy5kYXRhX29mZnNldDtcbn07XG5Qcm90b2NvbE1lc3NhZ2UuR2V0UmFuZG9tTnVtID0gZnVuY3Rpb24gKE1pbiwgTWF4KSB7XG4gICAgdmFyIFJhbmdlID0gTWF4IC0gTWluO1xuICAgIHZhciBSYW5kID0gTWF0aC5yYW5kb20oKTtcbiAgICByZXR1cm4gTWluICsgTWF0aC5yb3VuZChSYW5kICogUmFuZ2UpO1xufTtcblxuUHJvdG9jb2xNZXNzYWdlLkdldFZlcnNpb25Db2RlQSA9IGZ1bmN0aW9uIChzZXJ2ZXJJbmZvKSB7XG4gICAgaWYgKHNlcnZlckluZm8uY2hlY2sgPT09IDApIHJldHVybiBQcm90b2NvbEl0ZW0uU09DS0VUX1ZFUjtcblxuICAgIHJldHVybiBzZXJ2ZXJJbmZvLmNoZWNrICogUHJvdG9jb2xJdGVtLlNPQ0tFVF9WRVIgJiAweDAwMDAwMEZGO1xufTtcblxuUHJvdG9jb2xNZXNzYWdlLkdldENoZWNrQ29kZUEgPSBmdW5jdGlvbiAoc2VydmVySW5mbywgY29kZSkge1xuICAgIGlmIChzZXJ2ZXJJbmZvLmNoZWNrID09PSAwKSB7XG4gICAgICAgIHNlcnZlckluZm8uY2hlY2sgPSBQcm90b2NvbE1lc3NhZ2UuR2V0UmFuZG9tTnVtKDAsIDEwMDAwKTtcbiAgICB9IGVsc2Uge1xuICAgICAgICBjb2RlICY9IDB4MDAwMDAwRkY7XG4gICAgICAgIGlmIChjb2RlID09PSAwKSBjb2RlID0gMjtcbiAgICAgICAgc2VydmVySW5mby5jaGVjayAqPSBjb2RlO1xuICAgICAgICBzZXJ2ZXJJbmZvLmNoZWNrICs9IFByb3RvY29sSXRlbS5TT0NLRVRfS0VZO1xuICAgIH1cblxuICAgIHNlcnZlckluZm8uY2hlY2sgJj0gMHgwMDAwMDBGRjtcbiAgICBpZiAoc2VydmVySW5mby5jaGVjayA9PT0gMCkgc2VydmVySW5mby5jaGVjayA9IDE7XG5cbiAgICByZXR1cm4gc2VydmVySW5mby5jaGVjaztcbn07XG5cblByb3RvY29sTWVzc2FnZS5FbmNvZGVNc2cgPSBmdW5jdGlvbiAobXNnLCBzZXJ2ZXJJbmZvKSB7XG4gICAgLy8gLS1cbiAgICBtc2cuZGF0YV9sZW5ndGggPSAwO1xuICAgIG1zZy5kYXRhX29mZnNldCA9IDA7XG5cbiAgICAvLyAtLVxuICAgIFByb3RvY29sTWVzc2FnZS5lbmNvZGVCeXRlKG1zZywgUHJvdG9jb2xNZXNzYWdlLkdldFZlcnNpb25Db2RlQShzZXJ2ZXJJbmZvKSk7XG4gICAgUHJvdG9jb2xNZXNzYWdlLmVuY29kZUJ5dGUobXNnLCAwKTtcbiAgICBQcm90b2NvbE1lc3NhZ2UuZW5jb2RlU2hvcnQobXNnLCAwKTtcbiAgICBQcm90b2NvbE1lc3NhZ2UuZW5jb2RlU2hvcnQobXNnLCBtc2cuX2hlYWRfbWFpbkNtZElEKTtcbiAgICBQcm90b2NvbE1lc3NhZ2UuZW5jb2RlU2hvcnQobXNnLCBtc2cuX2hlYWRfc3ViQ21kSUQpO1xuICAgIGZvciAodmFyIGogPSAwOyBqIDwgMjE7IGorKykge1xuICAgICAgICBQcm90b2NvbE1lc3NhZ2UuZW5jb2RlQnl0ZShtc2csIDApO1xuICAgIH1cblxuICAgIGlmIChQcm90b2NvbE1lc3NhZ2UucmVjdXJzaW9uX2VuY29kZV92ZWN0b3IobXNnLCBtc2cuX2JvZHlfbXNnLCB0cnVlKSA8IDApIHJldHVybiAtMTtcblxuICAgIC8vIC0tXG4gICAgbXNnLmRhdGFfb2Zmc2V0ID0gMjtcbiAgICBQcm90b2NvbE1lc3NhZ2UuZW5jb2RlU2hvcnQobXNnLCBtc2cuZGF0YV9sZW5ndGgpO1xuXG4gICAgLy8gLS1cbiAgICB2YXIgY2hlY2tDb2RlID0gMDtcbiAgICBmb3IgKHZhciBrID0gMDsgayA8IG1zZy5kYXRhX2xlbmd0aCAtIDI5OyBrKyspIHtcbiAgICAgICAgdmFyIHZhbCA9IG1zZy5kYXRhX3ZpZXcuZ2V0VWludDgoMjkgKyBrKTtcbiAgICAgICAgbXNnLmRhdGFfdmlldy5zZXRVaW50OCgyOSArIGssIFByb3RvY29sSXRlbS5TZW5kQnl0ZU1hcFt2YWxdKTtcblxuICAgICAgICBjaGVja0NvZGUgKz0gdmFsO1xuICAgIH1cbiAgICBjaGVja0NvZGUgPSBQcm90b2NvbE1lc3NhZ2UuR2V0Q2hlY2tDb2RlQShzZXJ2ZXJJbmZvLCBjaGVja0NvZGUpO1xuICAgIG1zZy5kYXRhX29mZnNldCA9IDE7XG4gICAgUHJvdG9jb2xNZXNzYWdlLmVuY29kZUJ5dGUobXNnLCBjaGVja0NvZGUpO1xuXG4gICAgLy8gLS0gICAgICAgXG4gICAgbXNnLl9ieXRlX2FycmF5ID0gbmV3IFVpbnQ4QXJyYXkobXNnLmRhdGFfbGVuZ3RoKTtcbiAgICBmb3IgKHZhciBuID0gMDsgbiA8IG1zZy5kYXRhX2xlbmd0aDsgbisrKSB7XG4gICAgICAgIG1zZy5fYnl0ZV9hcnJheVtuXSA9IG1zZy5kYXRhX3ZpZXcuZ2V0VWludDgobik7XG4gICAgfVxuXG4gICAgcmV0dXJuIDA7XG59O1xuXG5Qcm90b2NvbE1lc3NhZ2UucmVjdXJzaW9uX2VuY29kZV92ZWN0b3IgPSBmdW5jdGlvbiAobXNnLCB2YWx1ZSkge1xuICAgIHZhciBiZWdpbkZsYWcgPSBhcmd1bWVudHMubGVuZ3RoIDw9IDIgfHwgYXJndW1lbnRzWzJdID09PSB1bmRlZmluZWQgPyBmYWxzZSA6IGFyZ3VtZW50c1syXTtcblxuICAgIGlmICh2YWx1ZSA9PT0gbnVsbCkge1xuICAgICAgICByZXR1cm4gMDtcbiAgICB9XG5cbiAgICBpZiAoYmVnaW5GbGFnID09PSBmYWxzZSkgUHJvdG9jb2xNZXNzYWdlLmVuY29kZVNob3J0KG1zZywgdmFsdWUubGVuZ3RoKTtcblxuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdmFsdWUubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgUHJvdG9jb2xNZXNzYWdlLmVuY29kZUJ5dGUobXNnLCB2YWx1ZVtpXS5fZGF0YXR5cGUpO1xuICAgICAgICBzd2l0Y2ggKHZhbHVlW2ldLl9kYXRhdHlwZSkge1xuICAgICAgICAgICAgY2FzZSBQcm90b2NvbEl0ZW0uREFUQVRZUEVfQllURTpcbiAgICAgICAgICAgICAgICBQcm90b2NvbE1lc3NhZ2UuZW5jb2RlQnl0ZShtc2csIHZhbHVlW2ldLl9pbnRfdmFsdWUpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBQcm90b2NvbEl0ZW0uREFUQVRZUEVfU0hPUlQ6XG4gICAgICAgICAgICAgICAgUHJvdG9jb2xNZXNzYWdlLmVuY29kZVNob3J0KG1zZywgdmFsdWVbaV0uX2ludF92YWx1ZSk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIFByb3RvY29sSXRlbS5EQVRBVFlQRV9JTlQ6XG4gICAgICAgICAgICAgICAgUHJvdG9jb2xNZXNzYWdlLmVuY29kZUludChtc2csIHZhbHVlW2ldLl9pbnRfdmFsdWUpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBQcm90b2NvbEl0ZW0uREFUQVRZUEVfU1RSSU5HOlxuICAgICAgICAgICAgICAgIFByb3RvY29sTWVzc2FnZS5lbmNvZGVTdHJpbmcobXNnLCB2YWx1ZVtpXS5fc3RyX3ZhbHVlKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgUHJvdG9jb2xJdGVtLkRBVEFUWVBFX1ZFQ1RPUjpcbiAgICAgICAgICAgICAgICBpZiAoUHJvdG9jb2xNZXNzYWdlLnJlY3Vyc2lvbl9lbmNvZGVfdmVjdG9yKG1zZywgdmFsdWVbaV0uX3ZlY3RfdmFsdWUpID09IC0xKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAtMTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgIHJldHVybiAtMTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiAwO1xufTtcblxuUHJvdG9jb2xNZXNzYWdlLlV0ZjhBcnJheVRvU3RyID0gZnVuY3Rpb24gKGFycmF5VmFsKSB7XG4gICAgdmFyIG91dCwgaSwgbGVuLCBjO1xuICAgIHZhciBjaGFyMiwgY2hhcjM7XG5cbiAgICBvdXQgPSBcIlwiO1xuICAgIGxlbiA9IGFycmF5VmFsLmxlbmd0aDtcbiAgICBpID0gMDtcbiAgICB3aGlsZSAoaSA8IGxlbikge1xuICAgICAgICBjID0gYXJyYXlWYWxbaSsrXTtcbiAgICAgICAgc3dpdGNoIChjID4+IDQpIHtcbiAgICAgICAgICAgIGNhc2UgMDpjYXNlIDE6Y2FzZSAyOmNhc2UgMzpjYXNlIDQ6Y2FzZSA1OmNhc2UgNjpjYXNlIDc6XG4gICAgICAgICAgICAgICAgLy8gMHh4eHh4eHhcbiAgICAgICAgICAgICAgICBvdXQgKz0gU3RyaW5nLmZyb21DaGFyQ29kZShjKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgMTI6Y2FzZSAxMzpcbiAgICAgICAgICAgICAgICAvLyAxMTB4IHh4eHggICAxMHh4IHh4eHhcbiAgICAgICAgICAgICAgICBjaGFyMiA9IGFycmF5VmFsW2krK107XG4gICAgICAgICAgICAgICAgb3V0ICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoKGMgJiAweDFGKSA8PCA2IHwgY2hhcjIgJiAweDNGKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgMTQ6XG4gICAgICAgICAgICAgICAgLy8gMTExMCB4eHh4ICAxMHh4IHh4eHggIDEweHggeHh4eFxuICAgICAgICAgICAgICAgIGNoYXIyID0gYXJyYXlWYWxbaSsrXTtcbiAgICAgICAgICAgICAgICBjaGFyMyA9IGFycmF5VmFsW2krK107XG4gICAgICAgICAgICAgICAgb3V0ICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoKGMgJiAweDBGKSA8PCAxMiB8IChjaGFyMiAmIDB4M0YpIDw8IDYgfCAoY2hhcjMgJiAweDNGKSA8PCAwKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBvdXQ7XG59O1xuXG5Qcm90b2NvbE1lc3NhZ2UudG9VVEY4QXJyYXkgPSBmdW5jdGlvbiAoc3RyKSB7XG4gICAgdmFyIHV0ZjggPSBbXTtcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IHN0ci5sZW5ndGg7IGkrKykge1xuICAgICAgICB2YXIgY2hhcmNvZGUgPSBzdHIuY2hhckNvZGVBdChpKTtcbiAgICAgICAgaWYgKGNoYXJjb2RlIDwgMHg4MCkgdXRmOC5wdXNoKGNoYXJjb2RlKTtlbHNlIGlmIChjaGFyY29kZSA8IDB4ODAwKSB7XG4gICAgICAgICAgICB1dGY4LnB1c2goMHhjMCB8IGNoYXJjb2RlID4+IDYsIDB4ODAgfCBjaGFyY29kZSAmIDB4M2YpO1xuICAgICAgICB9IGVsc2UgaWYgKGNoYXJjb2RlIDwgMHhkODAwIHx8IGNoYXJjb2RlID49IDB4ZTAwMCkge1xuICAgICAgICAgICAgdXRmOC5wdXNoKDB4ZTAgfCBjaGFyY29kZSA+PiAxMiwgMHg4MCB8IGNoYXJjb2RlID4+IDYgJiAweDNmLCAweDgwIHwgY2hhcmNvZGUgJiAweDNmKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBzdXJyb2dhdGUgcGFpclxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBpKys7XG4gICAgICAgICAgICAgICAgLy8gVVRGLTE2IGVuY29kZXMgMHgxMDAwMC0weDEwRkZGRiBieVxuICAgICAgICAgICAgICAgIC8vIHN1YnRyYWN0aW5nIDB4MTAwMDAgYW5kIHNwbGl0dGluZyB0aGVcbiAgICAgICAgICAgICAgICAvLyAyMCBiaXRzIG9mIDB4MC0weEZGRkZGIGludG8gdHdvIGhhbHZlc1xuICAgICAgICAgICAgICAgIGNoYXJjb2RlID0gMHgxMDAwMCArICgoY2hhcmNvZGUgJiAweDNmZikgPDwgMTAgfCBzdHIuY2hhckNvZGVBdChpKSAmIDB4M2ZmKTtcbiAgICAgICAgICAgICAgICB1dGY4LnB1c2goMHhmMCB8IGNoYXJjb2RlID4+IDE4LCAweDgwIHwgY2hhcmNvZGUgPj4gMTIgJiAweDNmLCAweDgwIHwgY2hhcmNvZGUgPj4gNiAmIDB4M2YsIDB4ODAgfCBjaGFyY29kZSAmIDB4M2YpO1xuICAgICAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gdXRmODtcbn07XG5cblByb3RvY29sTWVzc2FnZS5kZWNvZGVCeXRlID0gZnVuY3Rpb24gKG1zZykge1xuICAgIHZhciB2YWwgPSBtc2cuZGF0YV92aWV3LmdldFVpbnQ4KG1zZy5kYXRhX29mZnNldCk7XG4gICAgbXNnLmRhdGFfb2Zmc2V0Kys7XG4gICAgcmV0dXJuIHZhbDtcbn07XG5Qcm90b2NvbE1lc3NhZ2UuZGVjb2RlU2hvcnQgPSBmdW5jdGlvbiAobXNnKSB7XG4gICAgdmFyIHZhbCA9IG1zZy5kYXRhX3ZpZXcuZ2V0VWludDE2KG1zZy5kYXRhX29mZnNldCwgbXNnLl9lbmRpYW4pO1xuICAgIG1zZy5kYXRhX29mZnNldCArPSAyO1xuICAgIHJldHVybiB2YWw7XG59O1xuUHJvdG9jb2xNZXNzYWdlLmRlY29kZUludCA9IGZ1bmN0aW9uIChtc2cpIHtcbiAgICB2YXIgdmFsID0gbXNnLmRhdGFfdmlldy5nZXRVaW50MzIobXNnLmRhdGFfb2Zmc2V0LCBtc2cuX2VuZGlhbik7XG4gICAgbXNnLmRhdGFfb2Zmc2V0ICs9IDQ7XG4gICAgcmV0dXJuIHZhbDtcbn07XG5cblByb3RvY29sTWVzc2FnZS5lbmNvZGVCeXRlID0gZnVuY3Rpb24gKG1zZywgdmFsdWUpIHtcbiAgICB2YXIgbmV3TGVuZ3RoID0gbXNnLmRhdGFfbGVuZ3RoO1xuICAgIGlmIChtc2cuZGF0YV9vZmZzZXQgKyAxID4gbXNnLmRhdGFfbGVuZ3RoKSBuZXdMZW5ndGggPSBtc2cuZGF0YV9vZmZzZXQgKyAxO1xuICAgIHdoaWxlIChuZXdMZW5ndGggPiBtc2cuZGF0YV9idWZmZXIuYnl0ZUxlbmd0aCkge1xuICAgICAgICB2YXIgZGF0YVRtcCA9IG5ldyBVaW50OEFycmF5KG1zZy5kYXRhX2J1ZmZlci5ieXRlTGVuZ3RoKTtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBtc2cuZGF0YV9idWZmZXIuYnl0ZUxlbmd0aDsgaSsrKSBkYXRhVG1wW2ldID0gbXNnLmRhdGFfdmlldy5nZXRVaW50OChpKTtcbiAgICAgICAgbXNnLmRhdGFfYnVmZmVyID0gbmV3IEFycmF5QnVmZmVyKG1zZy5kYXRhX2J1ZmZlci5ieXRlTGVuZ3RoICsgUHJvdG9jb2xJdGVtLkJVRkZFUl9TVEVQKTtcbiAgICAgICAgbXNnLmRhdGFfdmlldyA9IG5ldyBEYXRhVmlldyhtc2cuZGF0YV9idWZmZXIpO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IG1zZy5kYXRhX2J1ZmZlci5ieXRlTGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGlmIChpID49IGRhdGFUbXAuYnl0ZUxlbmd0aCkgbXNnLmRhdGFfdmlldy5zZXRVaW50OChpLCAwKTtlbHNlIG1zZy5kYXRhX3ZpZXcuc2V0VWludDgoaSwgZGF0YVRtcFtpXSk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBtc2cuZGF0YV92aWV3LnNldFVpbnQ4KG1zZy5kYXRhX29mZnNldCwgdmFsdWUpO1xuICAgIG1zZy5kYXRhX29mZnNldCsrO1xuICAgIG1zZy5kYXRhX2xlbmd0aCA9IG5ld0xlbmd0aDtcbn07XG5Qcm90b2NvbE1lc3NhZ2UuZW5jb2RlQnl0ZXMgPSBmdW5jdGlvbiAobXNnLCB2YWx1ZSkge1xuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdmFsdWUubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgUHJvdG9jb2xNZXNzYWdlLmVuY29kZUJ5dGUobXNnLCB2YWx1ZVtpXSk7XG4gICAgfVxufTtcblByb3RvY29sTWVzc2FnZS5lbmNvZGVTaG9ydCA9IGZ1bmN0aW9uIChtc2csIHZhbHVlKSB7XG4gICAgdmFyIG5ld0xlbmd0aCA9IG1zZy5kYXRhX2xlbmd0aDtcbiAgICBpZiAobXNnLmRhdGFfb2Zmc2V0ICsgMiA+IG1zZy5kYXRhX2xlbmd0aCkgbmV3TGVuZ3RoID0gbXNnLmRhdGFfb2Zmc2V0ICsgMjtcbiAgICB3aGlsZSAobmV3TGVuZ3RoID4gbXNnLmRhdGFfYnVmZmVyLmJ5dGVMZW5ndGgpIHtcbiAgICAgICAgdmFyIGRhdGFUbXAgPSBuZXcgVWludDhBcnJheShtc2cuZGF0YV9idWZmZXIuYnl0ZUxlbmd0aCk7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgbXNnLmRhdGFfYnVmZmVyLmJ5dGVMZW5ndGg7IGkrKykgZGF0YVRtcFtpXSA9IG1zZy5kYXRhX3ZpZXcuZ2V0VWludDgoaSk7XG4gICAgICAgIG1zZy5kYXRhX2J1ZmZlciA9IG5ldyBBcnJheUJ1ZmZlcihtc2cuZGF0YV9idWZmZXIuYnl0ZUxlbmd0aCArIFByb3RvY29sSXRlbS5CVUZGRVJfU1RFUCk7XG4gICAgICAgIG1zZy5kYXRhX3ZpZXcgPSBuZXcgRGF0YVZpZXcobXNnLmRhdGFfYnVmZmVyKTtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBtc2cuZGF0YV9idWZmZXIuYnl0ZUxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBpZiAoaSA+PSBkYXRhVG1wLmJ5dGVMZW5ndGgpIG1zZy5kYXRhX3ZpZXcuc2V0VWludDgoaSwgMCk7ZWxzZSBtc2cuZGF0YV92aWV3LnNldFVpbnQ4KGksIGRhdGFUbXBbaV0pO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgbXNnLmRhdGFfdmlldy5zZXRVaW50MTYobXNnLmRhdGFfb2Zmc2V0LCB2YWx1ZSwgbXNnLl9lbmRpYW4pO1xuICAgIG1zZy5kYXRhX29mZnNldCArPSAyO1xuICAgIG1zZy5kYXRhX2xlbmd0aCA9IG5ld0xlbmd0aDtcbn07XG5Qcm90b2NvbE1lc3NhZ2UuZW5jb2RlSW50ID0gZnVuY3Rpb24gKG1zZywgdmFsdWUpIHtcbiAgICB2YXIgbmV3TGVuZ3RoID0gbXNnLmRhdGFfbGVuZ3RoO1xuICAgIGlmIChtc2cuZGF0YV9vZmZzZXQgKyA0ID4gbXNnLmRhdGFfbGVuZ3RoKSBuZXdMZW5ndGggPSBtc2cuZGF0YV9vZmZzZXQgKyA0O1xuICAgIHdoaWxlIChuZXdMZW5ndGggPiBtc2cuZGF0YV9idWZmZXIuYnl0ZUxlbmd0aCkge1xuICAgICAgICB2YXIgZGF0YVRtcCA9IG5ldyBVaW50OEFycmF5KG1zZy5kYXRhX2J1ZmZlci5ieXRlTGVuZ3RoKTtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBtc2cuZGF0YV9idWZmZXIuYnl0ZUxlbmd0aDsgaSsrKSBkYXRhVG1wW2ldID0gbXNnLmRhdGFfdmlldy5nZXRVaW50OChpKTtcbiAgICAgICAgbXNnLmRhdGFfYnVmZmVyID0gbmV3IEFycmF5QnVmZmVyKG1zZy5kYXRhX2J1ZmZlci5ieXRlTGVuZ3RoICsgUHJvdG9jb2xJdGVtLkJVRkZFUl9TVEVQKTtcbiAgICAgICAgbXNnLmRhdGFfdmlldyA9IG5ldyBEYXRhVmlldyhtc2cuZGF0YV9idWZmZXIpO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IG1zZy5kYXRhX2J1ZmZlci5ieXRlTGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGlmIChpID49IGRhdGFUbXAuYnl0ZUxlbmd0aCkgbXNnLmRhdGFfdmlldy5zZXRVaW50OChpLCAwKTtlbHNlIG1zZy5kYXRhX3ZpZXcuc2V0VWludDgoaSwgZGF0YVRtcFtpXSk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBtc2cuZGF0YV92aWV3LnNldFVpbnQzMihtc2cuZGF0YV9vZmZzZXQsIHZhbHVlLCBtc2cuX2VuZGlhbik7XG4gICAgbXNnLmRhdGFfb2Zmc2V0ICs9IDQ7XG4gICAgbXNnLmRhdGFfbGVuZ3RoID0gbmV3TGVuZ3RoO1xufTtcblByb3RvY29sTWVzc2FnZS5lbmNvZGVTdHJpbmcgPSBmdW5jdGlvbiAobXNnLCB2YWx1ZSkge1xuICAgIHZhciBhcnJWYWwgPSBQcm90b2NvbE1lc3NhZ2UudG9VVEY4QXJyYXkodmFsdWUpO1xuXG4gICAgUHJvdG9jb2xNZXNzYWdlLmVuY29kZVNob3J0KG1zZywgYXJyVmFsLmxlbmd0aCk7XG4gICAgUHJvdG9jb2xNZXNzYWdlLmVuY29kZUJ5dGVzKG1zZywgYXJyVmFsKTtcbn07XG5cblByb3RvY29sTWVzc2FnZS5BZGRWZWN0SXRlbU51bWJlciA9IGZ1bmN0aW9uIChjb250YWluLCB0eXBlLCB2YWx1ZSkge1xuICAgIHZhciBwb3MgPSBhcmd1bWVudHMubGVuZ3RoIDw9IDMgfHwgYXJndW1lbnRzWzNdID09PSB1bmRlZmluZWQgPyAtMSA6IGFyZ3VtZW50c1szXTtcblxuICAgIHZhciBpdGVtID0gbmV3IFByb3RvY29sSXRlbSgpO1xuXG4gICAgaXRlbS5fZGF0YXR5cGUgPSB0eXBlO1xuICAgIGl0ZW0uX2ludF92YWx1ZSA9IHZhbHVlO1xuXG4gICAgaWYgKHBvcyA8IDApIHtcbiAgICAgICAgY29udGFpbi5wdXNoKGl0ZW0pO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnRhaW4uc3BsaWNlKHBvcywgMCwgaXRlbSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGNvbnRhaW4ubGVuZ3RoO1xufTtcblByb3RvY29sTWVzc2FnZS5BZGRWZWN0SXRlbUJ5dGUgPSBmdW5jdGlvbiAoY29udGFpbiwgdmFsdWUpIHtcbiAgICB2YXIgcG9zID0gYXJndW1lbnRzLmxlbmd0aCA8PSAyIHx8IGFyZ3VtZW50c1syXSA9PT0gdW5kZWZpbmVkID8gLTEgOiBhcmd1bWVudHNbMl07XG5cbiAgICByZXR1cm4gUHJvdG9jb2xNZXNzYWdlLkFkZFZlY3RJdGVtTnVtYmVyKGNvbnRhaW4sIFByb3RvY29sSXRlbS5EQVRBVFlQRV9CWVRFLCB2YWx1ZSwgcG9zKTtcbn07XG5Qcm90b2NvbE1lc3NhZ2UuQWRkVmVjdEl0ZW1TaG9ydCA9IGZ1bmN0aW9uIChjb250YWluLCB2YWx1ZSkge1xuICAgIHZhciBwb3MgPSBhcmd1bWVudHMubGVuZ3RoIDw9IDIgfHwgYXJndW1lbnRzWzJdID09PSB1bmRlZmluZWQgPyAtMSA6IGFyZ3VtZW50c1syXTtcblxuICAgIHJldHVybiBQcm90b2NvbE1lc3NhZ2UuQWRkVmVjdEl0ZW1OdW1iZXIoY29udGFpbiwgUHJvdG9jb2xJdGVtLkRBVEFUWVBFX1NIT1JULCB2YWx1ZSwgcG9zKTtcbn07XG5Qcm90b2NvbE1lc3NhZ2UuQWRkVmVjdEl0ZW1JbnQgPSBmdW5jdGlvbiAoY29udGFpbiwgdmFsdWUpIHtcbiAgICB2YXIgcG9zID0gYXJndW1lbnRzLmxlbmd0aCA8PSAyIHx8IGFyZ3VtZW50c1syXSA9PT0gdW5kZWZpbmVkID8gLTEgOiBhcmd1bWVudHNbMl07XG5cbiAgICByZXR1cm4gUHJvdG9jb2xNZXNzYWdlLkFkZFZlY3RJdGVtTnVtYmVyKGNvbnRhaW4sIFByb3RvY29sSXRlbS5EQVRBVFlQRV9JTlQsIHZhbHVlLCBwb3MpO1xufTtcblByb3RvY29sTWVzc2FnZS5BZGRWZWN0SXRlbVN0cmluZyA9IGZ1bmN0aW9uIChjb250YWluLCB2YWx1ZSkge1xuICAgIHZhciBwb3MgPSBhcmd1bWVudHMubGVuZ3RoIDw9IDIgfHwgYXJndW1lbnRzWzJdID09PSB1bmRlZmluZWQgPyAtMSA6IGFyZ3VtZW50c1syXTtcblxuICAgIHZhciBpdGVtID0gbmV3IFByb3RvY29sSXRlbSgpO1xuXG4gICAgaXRlbS5fZGF0YXR5cGUgPSBQcm90b2NvbEl0ZW0uREFUQVRZUEVfU1RSSU5HO1xuICAgIGl0ZW0uX3N0cl92YWx1ZSA9IHZhbHVlO1xuXG4gICAgaWYgKHBvcyA8IDApIHtcbiAgICAgICAgY29udGFpbi5wdXNoKGl0ZW0pO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnRhaW4uc3BsaWNlKHBvcywgMCwgaXRlbSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGNvbnRhaW4ubGVuZ3RoO1xufTtcblByb3RvY29sTWVzc2FnZS5BZGRWZWN0SXRlbVZlY3QgPSBmdW5jdGlvbiAoY29udGFpbikge1xuICAgIHZhciBwb3MgPSBhcmd1bWVudHMubGVuZ3RoIDw9IDEgfHwgYXJndW1lbnRzWzFdID09PSB1bmRlZmluZWQgPyAtMSA6IGFyZ3VtZW50c1sxXTtcblxuICAgIHZhciBpdGVtID0gbmV3IFByb3RvY29sSXRlbSgpO1xuXG4gICAgaXRlbS5fZGF0YXR5cGUgPSBQcm90b2NvbEl0ZW0uREFUQVRZUEVfVkVDVE9SO1xuICAgIGl0ZW0uX3ZlY3RfdmFsdWUgPSBuZXcgQXJyYXkoMCk7XG5cbiAgICBpZiAocG9zIDwgMCkge1xuICAgICAgICBjb250YWluLnB1c2goaXRlbSk7XG4gICAgfSBlbHNlIHtcbiAgICAgICAgY29udGFpbi5zcGxpY2UocG9zLCAwLCBpdGVtKTtcbiAgICB9XG5cbiAgICByZXR1cm4gY29udGFpbi5sZW5ndGg7XG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IFByb3RvY29sTWVzc2FnZTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJ2YzMTg0NGpBNGRNODQyZFpSOXYyZ01YJywgJ1NjZW5lRW50cnknKTtcbi8vIEdsb2JhbC9xaXN1TGliL1Nob3cvU2NlbmVFbnRyeS5qc1xuXG5jYy5DbGFzcyh7XG4gICAgJ2V4dGVuZHMnOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIG1lbnVBbmltOiB7XG4gICAgICAgICAgICAnZGVmYXVsdCc6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBjYy5BbmltYXRpb25cbiAgICAgICAgfVxuICAgIH0sXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7XG4gICAgICAgIHRoaXMubWVudUFuaW0ucGxheSgnbWVudV9yZXNldCcpO1xuXG4gICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB0aGlzLm1lbnVBbmltLnBsYXkoJ21lbnVfaW50cm8nKTtcbiAgICAgICAgfSkuYmluZCh0aGlzKSwgMC41KTtcbiAgICB9LFxuXG4gICAgc3RhcnQ6IGZ1bmN0aW9uIHN0YXJ0KCkge31cbn0pO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnMWI0MzR0Wm5SMUdNWUNkSG11Nk1rbk4nLCAnU2VsZkRhdGEnKTtcbi8vIEdsb2JhbC9zZXJ2aWNlL2RhdGEvU2VsZkRhdGEuanNcblxudmFyIFByb3RvY29sTWVzc2FnZSA9IHJlcXVpcmUoXCJQcm90b2NvbE1lc3NhZ2VcIik7XG52YXIgY29uc3REZWYgPSByZXF1aXJlKFwiQ29uc3REZWZcIik7XG5cbmNjLkNsYXNzKHtcbiAgICAgICAgXCJleHRlbmRzXCI6IGNjLkNvbXBvbmVudCxcblxuICAgICAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgICAgICAgICAgLy8gLS0tLS0tLVvlubPlj7DmlbDmja5dLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAgICAgICAgICAgbkFjY291bnRJRDogMCxcbiAgICAgICAgICAgICAgICBzQWNjb3VudE5hbWU6IFwiXCIsXG4gICAgICAgICAgICAgICAgc1Bhc3N3b3JkOiBcIlwiLFxuICAgICAgICAgICAgICAgIHNOaWNrTmFtZTogXCJcIixcbiAgICAgICAgICAgICAgICBuU2V4OiAwLFxuICAgICAgICAgICAgICAgIG5GaGVhZDogMCxcbiAgICAgICAgICAgICAgICBzRmN1c3RvbV9oZWFkOiBcIlwiLFxuICAgICAgICAgICAgICAgIG5Gcm1iSDogMCxcbiAgICAgICAgICAgICAgICBuRnJtYjogMCxcbiAgICAgICAgICAgICAgICBuRmNoYXJnZV9ybWJIOiAwLFxuICAgICAgICAgICAgICAgIG5GY2hhcmdlX3JtYjogMCxcbiAgICAgICAgICAgICAgICBuRm1vbmV5SDogMCxcbiAgICAgICAgICAgICAgICBuRm1vbmV5OiAwLFxuICAgICAgICAgICAgICAgIG5Gd2FsbGV0SDogMCxcbiAgICAgICAgICAgICAgICBuRndhbGxldDogMCxcbiAgICAgICAgICAgICAgICBzRnJlYWxfbmFtZTogXCJcIixcbiAgICAgICAgICAgICAgICBzRmNhcmRfaWQ6IFwiXCIsXG4gICAgICAgICAgICAgICAgc0Ztb2JpbGU6IFwiXCIsXG4gICAgICAgICAgICAgICAgc0ZlbWFpbDogXCJcIixcbiAgICAgICAgICAgICAgICBuRnNwcmVhZGVyOiAwLFxuXG4gICAgICAgICAgICAgICAgLy8gLS0tLS0tLVvku6TniYzmlbDmja5dLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAgICAgICAgICAgbkxvZ29uVFM6IDAsXG4gICAgICAgICAgICAgICAgbkxvZ29uUmFuZDogMCxcbiAgICAgICAgICAgICAgICBzTG9nb25LZXk6IFwiXCIsXG5cbiAgICAgICAgICAgICAgICAvLyAtLSDlnKjnmbvlvZXlj6Pov57mjqXlm57osIPkuK3lvZPliY3nirbmgIHvvIznlKjkuo7lhrPlrprov57mjqXlkI7nmoTliqjkvZxcbiAgICAgICAgICAgICAgICBuTG9nb25Db25uZWN0U3RhdHVzOiAwLFxuICAgICAgICAgICAgICAgIG5HYW1lQ29ubmVjdFN0YXR1czogMCxcbiAgICAgICAgICAgICAgICBuQ2hhdENvbm5lY3RTdGF0dXM6IDAsXG5cbiAgICAgICAgICAgICAgICBuSGVhcnRSc3BUUzogMCwgLy8g5b+D6Lez5ZON5bqU5pe26Ze05oizXG5cbiAgICAgICAgICAgICAgICAvLyAtLS0tLS0tW+WFqOacjeeOqeWutuWIl+ihqF0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgICAgICAgICAgICBwbGF5ZXJzOiBbXSwgLy8gLS0g5oi/6Ze055So5oi3IGl0ZW09e25BY2NvdW50SUQgLyBuT2ZmTGluZSAvIG5UZWFtSUQgLyBiYXNlSW5mbz17bkFjY291bnRJRC9zTmlja05hbWUvblNleC9uRmhlYWQvc0ZjdXN0b21faGVhZH19XG4gICAgICAgICAgICAgICAgdGVhbXM6IFtdLCAvLyAtLSDmiL/pl7TpmJ/kvI0gaXRlbT17blRlYW1JRCAvIG5TdGF0dXMgLyBuT3Blbk1vZGUgLyBwbGF5ZXJJRHNbblBsYXllcklEXX1cbiAgICAgICAgICAgICAgICBiYXR0bGVzOiBbXSwgLy8gLS0g5oi/6Ze05oiY5paXIGl0ZW09e25CYXR0bGVJRCAvIFRlYW1JRHNbblRlYW1JRF19XG5cbiAgICAgICAgICAgICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgICAgICAgICAgIG5Mb2NhbFNlcnZlclRpbWVEaWZmOiAwLCAvL+acrOWcsOWSjOacjeWKoeWZqOaXtumXtOW3rlxuXG4gICAgICAgICAgICAgICAgLy8gLS0tLS0tLVvpmJ/kvI1dLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAgICAgICAgICAgblRlYW1JRDogMCxcbiAgICAgICAgICAgICAgICBuT3Blbk1vZGU6IDAsXG5cbiAgICAgICAgICAgICAgICAvLyAtLS0tLS0tW+aImOaWl10tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgICAgICAgICAgICBuQmF0dGxlSUQ6IDAsXG4gICAgICAgICAgICAgICAgbkJhdHRsZVN0YXR1czogMCwgLy8wIOWIneWni+WMliAgIOaImOaWl+e7k+adnyAgICAgIDEg5oiY5paX5LitXG4gICAgICAgICAgICAgICAgbkJhdHRsZVN0YXR1c1RTOiAwLCAvL+aImOaWl+eKtuaAgeaXtumXtFxuXG4gICAgICAgICAgICAgICAgLy8gLS0tLS1b5ri45oiPXS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgICAgICAgICAgICBnYW1lczogW10sIC8vIC0taXRlbT17Z2FtZUlEL29uTGluZUNvdW50fSxcbiAgICAgICAgICAgICAgICBuQ3VyR2FtZUlEOiAwLFxuXG4gICAgICAgICAgICAgICAgLy8gLS0tLS0tW+iBiuWkqV0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAgICAgICAgICAgbWVzc2FnZXM6IG51bGwsIC8vIOa2iOaBryB7a2V5ID0gbkZpZCAgdmFsdWUgPXtuVHlwZSxuU2VuZElELG5TZW5kVFMsblBhcmFtMSxuUGFyYW0yLHNUaXRsZSxzQ29udGVudCxzQXR0YWNobWVudH0gfVxuICAgICAgICAgICAgICAgIHJlbGF0aW9uczogbnVsbCB9LFxuICAgICAgICAvLyDlpb3lj4vlhbPns7sge2tleT1wZWVySWQgIHZhbHVlPXJlbGF0aW9ufVxuICAgICAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHt9LFxuICAgICAgICByZWZyZXNoQ2hhdFVJOiBmdW5jdGlvbiByZWZyZXNoQ2hhdFVJKCkge1xuICAgICAgICAgICAgICAgIHZhciBjdXJTY2VuZSA9IGNjLmRpcmVjdG9yLmdldFNjZW5lKCk7XG4gICAgICAgICAgICAgICAgdmFyIENhbnZhcyA9IGN1clNjZW5lLmdldENoaWxkQnlOYW1lKFwiQ2FudmFzXCIpO1xuICAgICAgICAgICAgICAgIHZhciBtYWluID0gQ2FudmFzLmdldENvbXBvbmVudChcIm1haW5cIik7XG4gICAgICAgICAgICAgICAgaWYgKG1haW4pIG1haW4uaW5pdENoYXRVSSgpO1xuICAgICAgICB9XG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzJmNWM1VEMzN3RHV2FZN2hJRHgyS0JMJywgJ1NlcnZlckRhdGEnKTtcbi8vIEdsb2JhbC9zZXJ2aWNlL2RhdGEvU2VydmVyRGF0YS5qc1xuXG5jYy5DbGFzcyh7XG4gICAgXCJleHRlbmRzXCI6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgc2VydmVyczogW11cbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7fVxuXG59KTtcbi8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4vLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4vLyB9LFxuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnYTZiNzIwNXdhZEZ1cG1BcTZLR09nSDgnLCAnU2VydmVySW5mbycpO1xuLy8gR2xvYmFsL3Fpc3VMaWIvY29tbS9TZXJ2ZXJJbmZvLmpzXG5cbnZhciBTZXJ2ZXJJbmZvID0gZnVuY3Rpb24gU2VydmVySW5mbyh1cmwpIHtcbiAgICB0aGlzLl91cmwgPSB1cmw7XG5cbiAgICB0aGlzLl93ZWJfc29jayA9IG51bGw7XG5cbiAgICB0aGlzLmNoZWNrID0gMDtcblxuICAgIHRoaXMuY3VyTXNnID0gbnVsbDtcbiAgICB0aGlzLl9mbGFnX3JlY2VpdmVfc3RlcCA9IDA7XG4gICAgdGhpcy5fbXNnID0gbnVsbDtcbiAgICB0aGlzLnZlY3RNc2dRdWV1ZSA9IG5ldyBBcnJheSgwKTtcbiAgICB0aGlzLm5DdXJSZWNlaXZlU2VxID0gMDtcblxuICAgIHRoaXMudGltZXIgPSBudWxsO1xuICAgIHRoaXMud2FpdFRpbWVzID0gMDtcblxuICAgIHRoaXMuU3RhcnRUaW1lciA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdGhpcy50aW1lciA9IHdpbmRvdy5zZXRJbnRlcnZhbCh0aGlzLm9uVGltZXIoKSwgMTAwMCk7XG4gICAgfTtcbiAgICB0aGlzLlN0b3BUaW1lciA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgY2xlYXJJbnRlcnZhbCh0aGlzLnRpbWVyKTtcbiAgICB9O1xuXG4gICAgdGhpcy5vblRpbWVyID0gZnVuY3Rpb24gKCkge1xuICAgICAgICBpZiAodGhpcy52ZWN0TXNnUXVldWUubGVuZ3RoID4gMCkgdGhpcy53YWl0VGltZXMrKztcbiAgICB9O1xufTtcblxubW9kdWxlLmV4cG9ydHMgPSBTZXJ2ZXJJbmZvO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnNjg1MGN2ZUtMUkNVYlJiR3dGdnNzeTcnLCAnVVNvY2tldCcpO1xuLy8gR2xvYmFsL3Fpc3VMaWIvY29tbS9VU29ja2V0LmpzXG5cbnZhciBQcm90b2NvbE1lc3NhZ2UgPSByZXF1aXJlKFwiUHJvdG9jb2xNZXNzYWdlXCIpO1xudmFyIFNlcnZlckluZm8gPSByZXF1aXJlKFwiU2VydmVySW5mb1wiKTtcbnZhciBQcm90b2NvbEl0ZW0gPSByZXF1aXJlKFwiUHJvdG9jb2xJdGVtXCIpO1xuXG52YXIgc2VydmVycyA9IHt9O1xuXG52YXIgb3BlbkhhbmRsZXIgPSBudWxsO1xudmFyIGNsb3NlSGFuZGxlciA9IG51bGw7XG52YXIgc2VuZEZhaWxlZEhhbmRsZXIgPSBudWxsO1xudmFyIG1lc3NhZ2VIYW5kbGVyID0gbnVsbDtcblxudmFyIGJMb2dGbGFnID0gZmFsc2U7XG5cbmZ1bmN0aW9uIG9uT3BlbihldnQpIHtcbiAgICB2YXIgdXJsID0gdGhpcy51cmxWYWw7XG4gICAgaWYgKGV2dC5jdXJyZW50VGFyZ2V0ICE9PSB1bmRlZmluZWQgJiYgZXZ0LmN1cnJlbnRUYXJnZXQgIT09IG51bGwpIHtcbiAgICAgICAgdXJsID0gZXZ0LmN1cnJlbnRUYXJnZXQudXJsO1xuICAgIH1cblxuICAgIGlmIChzZXJ2ZXJzW3VybF0gPT09IHVuZGVmaW5lZCkge1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChzZXJ2ZXJzW3VybF0uX3dlYl9zb2NrID09PSBudWxsKSB7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZygnd2Vic29ja2V0IG9wZW5lZDogJyArIHNlcnZlcnNbdXJsXS5fdXJsKTtcblxuICAgIHNlcnZlcnNbdXJsXS5TdGFydFRpbWVyKCk7XG5cbiAgICBpZiAob3BlbkhhbmRsZXIgIT09IG51bGwpIHtcbiAgICAgICAgb3BlbkhhbmRsZXIodXJsKTtcbiAgICB9XG59XG5mdW5jdGlvbiBvbkNsb3NlKGV2dCkge1xuICAgIHZhciB1cmwgPSB0aGlzLnVybFZhbDtcbiAgICBpZiAoZXZ0LmN1cnJlbnRUYXJnZXQgIT09IHVuZGVmaW5lZCAmJiBldnQuY3VycmVudFRhcmdldCAhPT0gbnVsbCkge1xuICAgICAgICB1cmwgPSBldnQuY3VycmVudFRhcmdldC51cmw7XG4gICAgfVxuICAgIGNvbnNvbGUubG9nKCd3ZWJzb2NrZXQgY2xvc2U6ICcgKyB1cmwpO1xuICAgIFVTb2NrZXQuQ2xvc2VTb2NrZXQodXJsLCBVU29ja2V0LlNPQ0tfQ0xPU0VfUEVFUik7XG59XG5mdW5jdGlvbiBvbk1lc3NhZ2UoZXZ0KSB7XG4gICAgdmFyIHVybCA9IHRoaXMudXJsVmFsO1xuICAgIGlmIChldnQuY3VycmVudFRhcmdldCAhPT0gdW5kZWZpbmVkICYmIGV2dC5jdXJyZW50VGFyZ2V0ICE9PSBudWxsKSB7XG4gICAgICAgIHVybCA9IGV2dC5jdXJyZW50VGFyZ2V0LnVybDtcbiAgICB9XG5cbiAgICB2YXIgc2VydmVyaW5mbyA9IHNlcnZlcnNbdXJsXTtcblxuICAgIGlmIChzZXJ2ZXJpbmZvID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoc2VydmVyaW5mby5fd2ViX3NvY2sgPT09IG51bGwpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmICh0eXBlb2YgZXZ0LmRhdGEgPT0gXCJzdHJpbmdcIikge1xuICAgICAgICB0ZXh0SGFuZGxlcih1cmwsIEpTT04ucGFyc2UoZXZ0LmRhdGEpKTtcbiAgICB9IGVsc2Uge1xuICAgICAgICB2YXIgZGF0YSA9IG5ldyBEYXRhVmlldyhldnQuZGF0YSk7XG4gICAgICAgIGlmIChiaW5hcnlIYW5kbGVyKHVybCwgZGF0YSwgc2VydmVyaW5mbykgPCAwKSB7XG4gICAgICAgICAgICBVU29ja2V0LkNsb3NlU29ja2V0KHVybCwgVVNvY2tldC5TT0NLX0NMT1NFX0RFQ09ERV9FUlIpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gbGV0IHJlYWRlciA9IG5ldyBGaWxlUmVhZGVyKCk7ICBcbiAgICAgICAgLy8gcmVhZGVyLm9ubG9hZCA9IGZ1bmN0aW9uKGV2dClcbiAgICAgICAgLy8geyBcbiAgICAgICAgLy8gICAgIGlmKGV2dC50YXJnZXQucmVhZHlTdGF0ZSA9PSBGaWxlUmVhZGVyLkRPTkUpXG4gICAgICAgIC8vICAgICB7IFxuICAgICAgICAvLyAgICAgICAgIHZhciBkYXRhID0gbmV3IERhdGFWaWV3KGV2dC50YXJnZXQucmVzdWx0KTsgXG4gICAgICAgIC8vICAgICAgICAgaWYgKGJpbmFyeUhhbmRsZXIodXJsLCBkYXRhLHNlcnZlcmluZm8pPDApXG4gICAgICAgIC8vICAgICAgICAge1xuICAgICAgICAvLyAgICAgICAgICAgICBVU29ja2V0LkNsb3NlU29ja2V0KHVybCwgVVNvY2tldC5TT0NLX0NMT1NFX0RFQ09ERV9FUlIpO1xuICAgICAgICAvLyAgICAgICAgIH0gXG4gICAgICAgIC8vICAgICB9IFxuICAgICAgICAvLyB9OyBcbiAgICAgICAgLy8gcmVhZGVyLnJlYWRBc0FycmF5QnVmZmVyKGV2dC5kYXRhKTtcbiAgICB9XG59XG5cbmZ1bmN0aW9uIG9uRXJyb3IoZXZ0KSB7XG4gICAgdmFyIHVybCA9IHRoaXMudXJsVmFsO1xuICAgIGlmIChldnQuY3VycmVudFRhcmdldCAhPT0gdW5kZWZpbmVkICYmIGV2dC5jdXJyZW50VGFyZ2V0ICE9PSBudWxsKSB7XG4gICAgICAgIHVybCA9IGV2dC5jdXJyZW50VGFyZ2V0LnVybDtcbiAgICB9XG5cbiAgICBpZiAoc2VydmVyc1t1cmxdID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoc2VydmVyc1t1cmxdLl93ZWJfc29jayA9PT0gbnVsbCkge1xuICAgICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKHNlbmRGYWlsZWRIYW5kbGVyICE9PSBudWxsKSB7XG4gICAgICAgIHNlbmRGYWlsZWRIYW5kbGVyKHVybCk7XG4gICAgfVxufVxuXG5mdW5jdGlvbiBJc0xpdHRsZUVuZGlhbigpIHtcbiAgICB2YXIgYnVmZmVyID0gbmV3IEFycmF5QnVmZmVyKDIpO1xuICAgIG5ldyBEYXRhVmlldyhidWZmZXIpLnNldEludDE2KDAsIDI1NiwgdHJ1ZSAvKiBsaXR0bGVFbmRpYW4gKi8pO1xuXG4gICAgLy8gcmV0dXJuIG5ldyBJbnQxNkFycmF5KGJ1ZmZlcilbMF0gPT09IDI1NjtcbiAgICBpZiAobmV3IFVpbnQ4QXJyYXkoYnVmZmVyKVswXSA9PT0gMCkgcmV0dXJuIGZhbHNlO2Vsc2UgcmV0dXJuIHRydWU7XG59XG5cbnZhciBVU29ja2V0ID0ge1xuICAgIGlzTGl0dGxlRW5kaWFuOiBmYWxzZSxcblxuICAgIGluaXQ6IGZ1bmN0aW9uIGluaXQoX29wZW5IYW5kbGVyLCBfbWVzc2FnZUhhbmRsZXIsIF9jbG9zZUhhbmRsZXIsIF9zZW5kRmFpbGVkSGFuZGxlciwgX2JMb2dGbGFnKSB7XG4gICAgICAgIHRoaXMuaXNMaXR0bGVFbmRpYW4gPSBJc0xpdHRsZUVuZGlhbigpO1xuXG4gICAgICAgIG1lc3NhZ2VIYW5kbGVyID0gX21lc3NhZ2VIYW5kbGVyO1xuICAgICAgICBvcGVuSGFuZGxlciA9IF9vcGVuSGFuZGxlcjtcbiAgICAgICAgY2xvc2VIYW5kbGVyID0gX2Nsb3NlSGFuZGxlcjtcbiAgICAgICAgc2VuZEZhaWxlZEhhbmRsZXIgPSBfc2VuZEZhaWxlZEhhbmRsZXI7XG5cbiAgICAgICAgYkxvZ0ZsYWcgPSBfYkxvZ0ZsYWc7XG4gICAgfSxcblxuICAgIElzQ29ubmVjdGVkOiBmdW5jdGlvbiBJc0Nvbm5lY3RlZCh1cmwpIHtcbiAgICAgICAgaWYgKHVybC5jaGFyQXQodXJsLmxlbmd0aCAtIDEpICE9ICcvJykge1xuICAgICAgICAgICAgdXJsICs9IFwiL1wiO1xuICAgICAgICB9XG4gICAgICAgIGlmIChzZXJ2ZXJzW3VybF0gPT09IHVuZGVmaW5lZCkgcmV0dXJuIGZhbHNlO1xuICAgICAgICBpZiAoc2VydmVyc1t1cmxdLl93ZWJfc29jayA9PT0gbnVsbCkgcmV0dXJuIGZhbHNlO1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9LFxuXG4gICAgQWRkU2VydmVyOiBmdW5jdGlvbiBBZGRTZXJ2ZXIodXJsKSAvLyBcIndzOi8vMjAzLjE5NS4xMjkuMjAxOjUzMzgvXCJcbiAgICB7XG4gICAgICAgIGlmICh1cmwuY2hhckF0KHVybC5sZW5ndGggLSAxKSAhPSAnLycpIHtcbiAgICAgICAgICAgIHVybCArPSBcIi9cIjtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChzZXJ2ZXJzW3VybF0gPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgc2VydmVyc1t1cmxdID0gbmV3IFNlcnZlckluZm8odXJsKTtcbiAgICAgICAgICAgIHNlcnZlcnNbdXJsXS5fd2ViX3NvY2sgPSBuZXcgV2ViU29ja2V0KHVybCk7XG4gICAgICAgICAgICBzZXJ2ZXJzW3VybF0uX3dlYl9zb2NrLmJpbmFyeVR5cGUgPSBcImFycmF5YnVmZmVyXCI7XG4gICAgICAgICAgICBzZXJ2ZXJzW3VybF0uX3dlYl9zb2NrLnVybFZhbCA9IHVybDtcbiAgICAgICAgICAgIHNlcnZlcnNbdXJsXS5fd2ViX3NvY2sub25vcGVuID0gb25PcGVuO1xuICAgICAgICAgICAgc2VydmVyc1t1cmxdLl93ZWJfc29jay5vbmNsb3NlID0gb25DbG9zZTtcbiAgICAgICAgICAgIHNlcnZlcnNbdXJsXS5fd2ViX3NvY2sub25tZXNzYWdlID0gb25NZXNzYWdlO1xuICAgICAgICAgICAgc2VydmVyc1t1cmxdLl93ZWJfc29jay5vbmVycm9yID0gb25FcnJvcjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGlmIChzZXJ2ZXJzW3VybF0uX3dlYl9zb2NrID09PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgc2VydmVyc1t1cmxdLmNoZWNrID0gMDtcbiAgICAgICAgICAgICAgICBzZXJ2ZXJzW3VybF0uX3dlYl9zb2NrID0gbmV3IFdlYlNvY2tldCh1cmwpO1xuICAgICAgICAgICAgICAgIHNlcnZlcnNbdXJsXS5fd2ViX3NvY2suYmluYXJ5VHlwZSA9IFwiYXJyYXlidWZmZXJcIjtcbiAgICAgICAgICAgICAgICBzZXJ2ZXJzW3VybF0uX3dlYl9zb2NrLnVybFZhbCA9IHVybDtcbiAgICAgICAgICAgIH0gZWxzZSB7fVxuICAgICAgICB9XG4gICAgfSxcblxuICAgIENsb3NlU29ja2V0OiBmdW5jdGlvbiBDbG9zZVNvY2tldCh1cmwpIHtcbiAgICAgICAgdmFyIGVyckNvZGUgPSBhcmd1bWVudHMubGVuZ3RoIDw9IDEgfHwgYXJndW1lbnRzWzFdID09PSB1bmRlZmluZWQgPyAwIDogYXJndW1lbnRzWzFdO1xuXG4gICAgICAgIGlmICh1cmwuY2hhckF0KHVybC5sZW5ndGggLSAxKSAhPSAnLycpIHtcbiAgICAgICAgICAgIHVybCArPSBcIi9cIjtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChzZXJ2ZXJzW3VybF0gPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmIChzZXJ2ZXJzW3VybF0uX3dlYl9zb2NrID09PSBudWxsKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBzZXJ2ZXJzW3VybF0uU3RvcFRpbWVyKCk7XG4gICAgICAgIHNlcnZlcnNbdXJsXS5fd2ViX3NvY2suY2xvc2UoKTtcblxuICAgICAgICBkZWxldGUgc2VydmVyc1t1cmxdO1xuXG4gICAgICAgIGlmIChjbG9zZUhhbmRsZXIgIT09IG51bGwpIHtcbiAgICAgICAgICAgIGNsb3NlSGFuZGxlcih1cmwsIGVyckNvZGUpO1xuICAgICAgICB9XG4gICAgfSxcblxuICAgIFNlbmRNZXNzYWdlOiBmdW5jdGlvbiBTZW5kTWVzc2FnZSh1cmwsIG1zZykge1xuICAgICAgICBpZiAodXJsLmNoYXJBdCh1cmwubGVuZ3RoIC0gMSkgIT0gJy8nKSB7XG4gICAgICAgICAgICB1cmwgKz0gXCIvXCI7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoc2VydmVyc1t1cmxdID09PSB1bmRlZmluZWQpIHJldHVybiAtMTtcbiAgICAgICAgaWYgKHNlcnZlcnNbdXJsXS5fd2ViX3NvY2sgPT09IG51bGwpIHJldHVybiAtMTtcbiAgICAgICAgaWYgKHNlcnZlcnNbdXJsXS5fd2ViX3NvY2sucmVhZHlTdGF0ZSAhPSBXZWJTb2NrZXQuT1BFTikgcmV0dXJuIC0xO1xuXG4gICAgICAgIHZhciByZXQgPSBQcm90b2NvbE1lc3NhZ2UuRW5jb2RlTXNnKG1zZywgc2VydmVyc1t1cmxdKTtcbiAgICAgICAgaWYgKHJldCAhPT0gMCkgcmV0dXJuIC0yO1xuICAgICAgICBzZXJ2ZXJzW3VybF0uX3dlYl9zb2NrLnNlbmQobXNnLl9ieXRlX2FycmF5LmJ1ZmZlcik7XG5cbiAgICAgICAgcmV0dXJuIDA7XG4gICAgfVxufTtcblxuVVNvY2tldC5TT0NLX0NMT1NFX1NFTEYgPSAwO1xuVVNvY2tldC5TT0NLX0NMT1NFX1BFRVIgPSAxO1xuVVNvY2tldC5TT0NLX0NMT1NFX0RFQ09ERV9FUlIgPSAyO1xuXG5mdW5jdGlvbiB0ZXh0SGFuZGxlcih1cmwsIG9iakRhdGEpIHt9XG5cbmZ1bmN0aW9uIHJlY3Vyc2lvbl9kZWNvZGVfdmVjdG9yKF9tc2cpIHtcbiAgICB2YXIgbGVuID0gUHJvdG9jb2xNZXNzYWdlLmRlY29kZVNob3J0KF9tc2cpO1xuICAgIHZhciB2ZWN0ID0gbmV3IEFycmF5KGxlbik7XG5cbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgICAgIHZhciBpdGVtID0gbmV3IFByb3RvY29sSXRlbSgpO1xuICAgICAgICBpdGVtLl9kYXRhdHlwZSA9IFByb3RvY29sTWVzc2FnZS5kZWNvZGVCeXRlKF9tc2cpO1xuXG4gICAgICAgIHN3aXRjaCAoaXRlbS5fZGF0YXR5cGUpIHtcbiAgICAgICAgICAgIGNhc2UgUHJvdG9jb2xJdGVtLkRBVEFUWVBFX0JZVEU6XG4gICAgICAgICAgICAgICAgaXRlbS5faW50X3ZhbHVlID0gUHJvdG9jb2xNZXNzYWdlLmRlY29kZUJ5dGUoX21zZyk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIFByb3RvY29sSXRlbS5EQVRBVFlQRV9TSE9SVDpcbiAgICAgICAgICAgICAgICBpdGVtLl9pbnRfdmFsdWUgPSBQcm90b2NvbE1lc3NhZ2UuZGVjb2RlU2hvcnQoX21zZyk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIFByb3RvY29sSXRlbS5EQVRBVFlQRV9JTlQ6XG4gICAgICAgICAgICAgICAgaXRlbS5faW50X3ZhbHVlID0gUHJvdG9jb2xNZXNzYWdlLmRlY29kZUludChfbXNnKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgUHJvdG9jb2xJdGVtLkRBVEFUWVBFX1NUUklORzpcblxuICAgICAgICAgICAgICAgIHZhciBzdHJsZW4gPSBQcm90b2NvbE1lc3NhZ2UuZGVjb2RlU2hvcnQoX21zZyk7XG4gICAgICAgICAgICAgICAgaWYgKHN0cmxlbiA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHBzelZhbCA9IG5ldyBVaW50OEFycmF5KHN0cmxlbik7XG4gICAgICAgICAgICAgICAgICAgIGZvciAodmFyIHQgPSAwOyB0IDwgc3RybGVuOyB0KyspIHBzelZhbFt0XSA9IFByb3RvY29sTWVzc2FnZS5kZWNvZGVCeXRlKF9tc2cpO1xuICAgICAgICAgICAgICAgICAgICBpdGVtLl9zdHJfdmFsdWUgPSBQcm90b2NvbE1lc3NhZ2UuVXRmOEFycmF5VG9TdHIocHN6VmFsKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBpdGVtLl9zdHJfdmFsdWUgPSBcIlwiO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgUHJvdG9jb2xJdGVtLkRBVEFUWVBFX1ZFQ1RPUjpcbiAgICAgICAgICAgICAgICBpdGVtLl92ZWN0X3ZhbHVlID0gcmVjdXJzaW9uX2RlY29kZV92ZWN0b3IoX21zZyk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9XG5cbiAgICAgICAgdmVjdFtpXSA9IGl0ZW07XG4gICAgfVxuXG4gICAgcmV0dXJuIHZlY3Q7XG59XG5cbmZ1bmN0aW9uIGJpbmFyeUhhbmRsZXIodXJsLCBkYXRhLCBzZXJ2ZXJpbmZvKSB7XG4gICAgLy8g5q2k5aSE6KaB5Lyg5YWlc2VydmVyaW5mb++8jOWboOS4umNocm9tZeS4i+iOt+WPluS4jeWIsHNlcnZlcnPvvIhGaWxlUmVhZGVy5byC5q2l6L2s5o2iQmxvYuWIsEFycmF5QnVmZmVy77yJXG4gICAgLy8gdmFyIHNlcnZlcmluZm8gPSBzZXJ2ZXJzW3VybF07XG5cbiAgICBpZiAoc2VydmVyaW5mby5fbXNnID09PSBudWxsKSBzZXJ2ZXJpbmZvLl9tc2cgPSBuZXcgUHJvdG9jb2xNZXNzYWdlKDAsIDAsIFVTb2NrZXQuaXNMaXR0bGVFbmRpYW4pO1xuICAgIGlmIChzZXJ2ZXJpbmZvLl9tc2cuZGF0YV9idWZmZXIuYnl0ZUxlbmd0aCA8IHNlcnZlcmluZm8uX21zZy5kYXRhX2xlbmd0aCArIGRhdGEuYnl0ZUxlbmd0aCkge1xuICAgICAgICB2YXIgZGF0YVRtcCA9IG5ldyBVaW50OEFycmF5KHNlcnZlcmluZm8uX21zZy5kYXRhX2xlbmd0aCk7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgc2VydmVyaW5mby5fbXNnLmRhdGFfbGVuZ3RoOyBpKyspIGRhdGFUbXBbaV0gPSBzZXJ2ZXJpbmZvLl9tc2cuZGF0YV92aWV3LmdldFVpbnQ4KGkpO1xuICAgICAgICBzZXJ2ZXJpbmZvLl9tc2cuZGF0YV9idWZmZXIgPSBuZXcgQXJyYXlCdWZmZXIoc2VydmVyaW5mby5fbXNnLmRhdGFfbGVuZ3RoICsgZGF0YS5ieXRlTGVuZ3RoKTtcbiAgICAgICAgc2VydmVyaW5mby5fbXNnLmRhdGFfdmlldyA9IG5ldyBEYXRhVmlldyhzZXJ2ZXJpbmZvLl9tc2cuZGF0YV9idWZmZXIpO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHNlcnZlcmluZm8uX21zZy5kYXRhX2xlbmd0aDsgaSsrKSBzZXJ2ZXJpbmZvLl9tc2cuZGF0YV92aWV3LnNldFVpbnQ4KGksIGRhdGFUbXBbaV0pO1xuICAgIH1cbiAgICBmb3IgKHZhciBhMSA9IDA7IGExIDwgZGF0YS5ieXRlTGVuZ3RoOyBhMSsrKSBzZXJ2ZXJpbmZvLl9tc2cuZGF0YV92aWV3LnNldFVpbnQ4KHNlcnZlcmluZm8uX21zZy5kYXRhX2xlbmd0aCArIGExLCBkYXRhLmdldFVpbnQ4KGExKSk7XG4gICAgc2VydmVyaW5mby5fbXNnLmRhdGFfbGVuZ3RoICs9IGRhdGEuYnl0ZUxlbmd0aDtcblxuICAgIHdoaWxlICh0cnVlKSB7XG4gICAgICAgIGlmIChzZXJ2ZXJpbmZvLl9tc2cuZGF0YV9sZW5ndGggPT09IDApIGJyZWFrO1xuXG4gICAgICAgIGlmIChzZXJ2ZXJpbmZvLl9mbGFnX3JlY2VpdmVfc3RlcCA9PT0gMCkge1xuICAgICAgICAgICAgc2VydmVyaW5mby5fbXNnLmRhdGFfb2Zmc2V0ID0gMDtcbiAgICAgICAgICAgIHNlcnZlcmluZm8uY3VyTXNnID0gbmV3IFByb3RvY29sTWVzc2FnZSgwLCAwLCBVU29ja2V0LmlzTGl0dGxlRW5kaWFuKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChzZXJ2ZXJpbmZvLl9mbGFnX3JlY2VpdmVfc3RlcCA8PSAxKSB7XG4gICAgICAgICAgICBpZiAoc2VydmVyaW5mby5fbXNnLmRhdGFfbGVuZ3RoIDwgMikge1xuICAgICAgICAgICAgICAgIHNlcnZlcmluZm8uX2ZsYWdfcmVjZWl2ZV9zdGVwID0gMTtcbiAgICAgICAgICAgICAgICByZXR1cm4gMDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgc2VydmVyaW5mby5jdXJNc2cuX2hlYWRfdmVyc2lvbiA9IFByb3RvY29sTWVzc2FnZS5kZWNvZGVCeXRlKHNlcnZlcmluZm8uX21zZyk7XG4gICAgICAgICAgICBzZXJ2ZXJpbmZvLmN1ck1zZy5faGVhZF9jaGVja0NvZGUgPSBQcm90b2NvbE1lc3NhZ2UuZGVjb2RlQnl0ZShzZXJ2ZXJpbmZvLl9tc2cpO1xuICAgICAgICAgICAgc2VydmVyaW5mby5fZmxhZ19yZWNlaXZlX3N0ZXAgPSAwO1xuXG4gICAgICAgICAgICBpZiAoc2VydmVyaW5mby5jdXJNc2cuX2hlYWRfdmVyc2lvbiAhPSBQcm90b2NvbEl0ZW0uU09DS0VUX1ZFUikge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi6Kej56CB5aSx6LSl77yI5byA5aeL5qCH5b+X6ZSZ6K+v77yJ77yM5a6i5oi356uv5YWz6Zet6L+e5o6l77yBXCIpO1xuICAgICAgICAgICAgICAgIHJldHVybiAtMTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChzZXJ2ZXJpbmZvLl9mbGFnX3JlY2VpdmVfc3RlcCA8PSAyKSB7XG4gICAgICAgICAgICBpZiAoUHJvdG9jb2xNZXNzYWdlLkdldEF2YWlsYWJsZShzZXJ2ZXJpbmZvLl9tc2cpIDwgMikge1xuICAgICAgICAgICAgICAgIHNlcnZlcmluZm8uX2ZsYWdfcmVjZWl2ZV9zdGVwID0gMjtcbiAgICAgICAgICAgICAgICByZXR1cm4gMDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgc2VydmVyaW5mby5jdXJNc2cuX2hlYWRfbXNnTGVuID0gUHJvdG9jb2xNZXNzYWdlLmRlY29kZVNob3J0KHNlcnZlcmluZm8uX21zZyk7XG4gICAgICAgICAgICBzZXJ2ZXJpbmZvLl9mbGFnX3JlY2VpdmVfc3RlcCA9IDA7XG5cbiAgICAgICAgICAgIHNlcnZlcmluZm8uX21zZy5fcmVtYWluTGVuID0gc2VydmVyaW5mby5jdXJNc2cuX2hlYWRfbXNnTGVuIC0gNDtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChzZXJ2ZXJpbmZvLl9mbGFnX3JlY2VpdmVfc3RlcCA8PSAzKSB7XG4gICAgICAgICAgICBpZiAoUHJvdG9jb2xNZXNzYWdlLkdldEF2YWlsYWJsZShzZXJ2ZXJpbmZvLl9tc2cpIDwgc2VydmVyaW5mby5fbXNnLl9yZW1haW5MZW4pIHtcbiAgICAgICAgICAgICAgICBzZXJ2ZXJpbmZvLl9tc2cuX3JlbWFpbkxlbiAtPSBQcm90b2NvbE1lc3NhZ2UuR2V0QXZhaWxhYmxlKHNlcnZlcmluZm8uX21zZyk7XG4gICAgICAgICAgICAgICAgc2VydmVyaW5mby5fZmxhZ19yZWNlaXZlX3N0ZXAgPSAzO1xuICAgICAgICAgICAgICAgIHJldHVybiAwO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc2VydmVyaW5mby5fZmxhZ19yZWNlaXZlX3N0ZXAgPSAwO1xuICAgICAgICB9XG5cbiAgICAgICAgc2VydmVyaW5mby5jdXJNc2cuX2hlYWRfbWFpbkNtZElEID0gUHJvdG9jb2xNZXNzYWdlLmRlY29kZVNob3J0KHNlcnZlcmluZm8uX21zZyk7XG4gICAgICAgIHNlcnZlcmluZm8uY3VyTXNnLl9oZWFkX3N1YkNtZElEID0gUHJvdG9jb2xNZXNzYWdlLmRlY29kZVNob3J0KHNlcnZlcmluZm8uX21zZyk7XG5cbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCAxMzsgaSsrKSB7XG4gICAgICAgICAgICBQcm90b2NvbE1lc3NhZ2UuZGVjb2RlQnl0ZShzZXJ2ZXJpbmZvLl9tc2cpO1xuICAgICAgICB9XG4gICAgICAgIHNlcnZlcmluZm8uY3VyTXNnLl9yZWNlaXZlX3NlcSA9IFByb3RvY29sTWVzc2FnZS5kZWNvZGVJbnQoc2VydmVyaW5mby5fbXNnKTtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCA0OyBpKyspIHtcbiAgICAgICAgICAgIFByb3RvY29sTWVzc2FnZS5kZWNvZGVCeXRlKHNlcnZlcmluZm8uX21zZyk7XG4gICAgICAgIH1cblxuICAgICAgICB2YXIgY2hlY2tDb2RlID0gMDtcbiAgICAgICAgZm9yICh2YXIgayA9IDI5OyBrIDwgc2VydmVyaW5mby5jdXJNc2cuX2hlYWRfbXNnTGVuOyBrKyspIHtcbiAgICAgICAgICAgIHZhciB2YWwgPSBQcm90b2NvbEl0ZW0uUmVjdkJ5dGVNYXBbc2VydmVyaW5mby5fbXNnLmRhdGFfdmlldy5nZXRVaW50OChrKV07XG4gICAgICAgICAgICBzZXJ2ZXJpbmZvLl9tc2cuZGF0YV92aWV3LnNldFVpbnQ4KGssIHZhbCk7XG5cbiAgICAgICAgICAgIGNoZWNrQ29kZSArPSB2YWw7XG4gICAgICAgIH1cbiAgICAgICAgY2hlY2tDb2RlICY9IDB4MDAwMDAwRkY7XG4gICAgICAgIGlmIChjaGVja0NvZGUgIT0gc2VydmVyaW5mby5jdXJNc2cuX2hlYWRfY2hlY2tDb2RlKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIuino+eggeWksei0pe+8jOagoemqjOeggemUmeivr++8gVwiKTtcbiAgICAgICAgICAgIHJldHVybiAtMTtcbiAgICAgICAgfVxuXG4gICAgICAgIHdoaWxlIChzZXJ2ZXJpbmZvLl9tc2cuZGF0YV9vZmZzZXQgPCBzZXJ2ZXJpbmZvLmN1ck1zZy5faGVhZF9tc2dMZW4gLSAxKSB7XG4gICAgICAgICAgICB2YXIgaXRlbSA9IG5ldyBQcm90b2NvbEl0ZW0oKTtcbiAgICAgICAgICAgIGl0ZW0uX2RhdGF0eXBlID0gUHJvdG9jb2xNZXNzYWdlLmRlY29kZUJ5dGUoc2VydmVyaW5mby5fbXNnKTtcblxuICAgICAgICAgICAgc3dpdGNoIChpdGVtLl9kYXRhdHlwZSkge1xuICAgICAgICAgICAgICAgIGNhc2UgUHJvdG9jb2xJdGVtLkRBVEFUWVBFX0JZVEU6XG4gICAgICAgICAgICAgICAgICAgIGl0ZW0uX2ludF92YWx1ZSA9IFByb3RvY29sTWVzc2FnZS5kZWNvZGVCeXRlKHNlcnZlcmluZm8uX21zZyk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgUHJvdG9jb2xJdGVtLkRBVEFUWVBFX1NIT1JUOlxuICAgICAgICAgICAgICAgICAgICBpdGVtLl9pbnRfdmFsdWUgPSBQcm90b2NvbE1lc3NhZ2UuZGVjb2RlU2hvcnQoc2VydmVyaW5mby5fbXNnKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSBQcm90b2NvbEl0ZW0uREFUQVRZUEVfSU5UOlxuICAgICAgICAgICAgICAgICAgICBpdGVtLl9pbnRfdmFsdWUgPSBQcm90b2NvbE1lc3NhZ2UuZGVjb2RlSW50KHNlcnZlcmluZm8uX21zZyk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgUHJvdG9jb2xJdGVtLkRBVEFUWVBFX1NUUklORzpcbiAgICAgICAgICAgICAgICAgICAgdmFyIGxlbiA9IFByb3RvY29sTWVzc2FnZS5kZWNvZGVTaG9ydChzZXJ2ZXJpbmZvLl9tc2cpO1xuICAgICAgICAgICAgICAgICAgICBpZiAobGVuID4gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHBzelZhbCA9IG5ldyBVaW50OEFycmF5KGxlbik7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGxlbjsgaSsrKSBwc3pWYWxbaV0gPSBQcm90b2NvbE1lc3NhZ2UuZGVjb2RlQnl0ZShzZXJ2ZXJpbmZvLl9tc2cpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5fc3RyX3ZhbHVlID0gUHJvdG9jb2xNZXNzYWdlLlV0ZjhBcnJheVRvU3RyKHBzelZhbCk7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpdGVtLl9zdHJfdmFsdWUgPSBcIlwiO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgUHJvdG9jb2xJdGVtLkRBVEFUWVBFX1ZFQ1RPUjpcbiAgICAgICAgICAgICAgICAgICAgaXRlbS5fdmVjdF92YWx1ZSA9IHJlY3Vyc2lvbl9kZWNvZGVfdmVjdG9yKHNlcnZlcmluZm8uX21zZyk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi6Kej56CB5aSx6LSl77yI5byC5bi477yJ77yM5a6i5oi356uv5YWz6Zet6L+e5o6l77yBXCIpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gLTE7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHNlcnZlcmluZm8uY3VyTXNnLl9ib2R5X21zZy5wdXNoKGl0ZW0pO1xuICAgICAgICB9XG5cbiAgICAgICAgdmFyIHN0ckNtZCA9IFwiW1wiICsgc2VydmVyaW5mby5jdXJNc2cuX2hlYWRfbWFpbkNtZElELnRvU3RyaW5nKDE2KSArIFwiOlwiICsgc2VydmVyaW5mby5jdXJNc2cuX2hlYWRfc3ViQ21kSUQudG9TdHJpbmcoMTYpICsgXCJdXCI7XG4gICAgICAgIGlmIChiTG9nRmxhZykgY29uc29sZS5sb2coXCI9PT09PT09PT09PT09PT09PT09PT09PT09PiBSRUNFSVZFIE1FU1NBR0UsIFRZUEVcIiArIHN0ckNtZCArIFwiLCBTRVFbXCIgKyBzZXJ2ZXJpbmZvLmN1ck1zZy5fcmVjZWl2ZV9zZXEgKyBcIl1cIik7XG4gICAgICAgIHNlcnZlcmluZm8uX21zZy5kYXRhX2xlbmd0aCAtPSBzZXJ2ZXJpbmZvLmN1ck1zZy5faGVhZF9tc2dMZW47XG4gICAgICAgIHNlcnZlcmluZm8uX21zZy5kYXRhX29mZnNldCA9IDA7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgc2VydmVyaW5mby5fbXNnLmRhdGFfbGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIHNlcnZlcmluZm8uX21zZy5kYXRhX2J1ZmZlcltpXSA9IHNlcnZlcmluZm8uX21zZy5kYXRhX2J1ZmZlcltzZXJ2ZXJpbmZvLmN1ck1zZy5faGVhZF9tc2dMZW4gKyBpXTtcbiAgICAgICAgfVxuICAgICAgICB2YXIgYWRqdXN0TGVuID0gc2VydmVyaW5mby5fbXNnLmRhdGFfbGVuZ3RoIDwgUHJvdG9jb2xJdGVtLkJVRkZFUl9SRUNWID8gUHJvdG9jb2xJdGVtLkJVRkZFUl9SRUNWIDogc2VydmVyaW5mby5fbXNnLmRhdGFfbGVuZ3RoO1xuICAgICAgICBpZiAoc2VydmVyaW5mby5fbXNnLmRhdGFfYnVmZmVyLmJ5dGVMZW5ndGggIT0gYWRqdXN0TGVuKSB7XG4gICAgICAgICAgICB2YXIgZGF0YVRtcCA9IG5ldyBVaW50OEFycmF5KHNlcnZlcmluZm8uX21zZy5kYXRhX2xlbmd0aCk7XG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHNlcnZlcmluZm8uX21zZy5kYXRhX2xlbmd0aDsgaSsrKSBkYXRhVG1wW2ldID0gc2VydmVyaW5mby5fbXNnLmRhdGFfdmlldy5nZXRVaW50OChpKTtcbiAgICAgICAgICAgIHNlcnZlcmluZm8uX21zZy5kYXRhX2J1ZmZlciA9IG5ldyBBcnJheUJ1ZmZlcihhZGp1c3RMZW4pO1xuICAgICAgICAgICAgc2VydmVyaW5mby5fbXNnLmRhdGFfdmlldyA9IG5ldyBEYXRhVmlldyhzZXJ2ZXJpbmZvLl9tc2cuZGF0YV9idWZmZXIpO1xuICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBzZXJ2ZXJpbmZvLl9tc2cuZGF0YV9sZW5ndGg7IGkrKykgc2VydmVyaW5mby5fbXNnLmRhdGFfdmlldy5zZXRVaW50OChpLCBkYXRhVG1wW2ldKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChzZXJ2ZXJpbmZvLmN1ck1zZy5fcmVjZWl2ZV9zZXEgPT0gMCkge1xuICAgICAgICAgICAgbWVzc2FnZUhhbmRsZXIoc2VydmVyaW5mby5jdXJNc2cuX2hlYWRfbWFpbkNtZElELCBzZXJ2ZXJpbmZvLmN1ck1zZy5faGVhZF9zdWJDbWRJRCwgc2VydmVyaW5mby5jdXJNc2cuX2JvZHlfbXNnKTtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHNlcnZlcmluZm8uY3VyTXNnLl9yZWNlaXZlX3NlcSA8IHNlcnZlcmluZm8ubkN1clJlY2VpdmVTZXEgKyAxKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIj09PT1bRkFUQUwgRVJST1JdPT09PT4gUkVDRUlWRSBNRVNTQUdFLCBUWVBFXCIgKyBzdHJDbWQgKyBcIiwgU0VRW1wiICsgc2VydmVyaW5mby5jdXJNc2cuX3JlY2VpdmVfc2VxICsgXCJdXCIpO1xuICAgICAgICAgICAgcmV0dXJuIC0xO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdmFyIHggPSAwO1xuICAgICAgICAgICAgZm9yICh4ID0gMDsgeCA8IHNlcnZlcmluZm8udmVjdE1zZ1F1ZXVlLmxlbmd0aDsgeCsrKSB7XG4gICAgICAgICAgICAgICAgaWYgKHNlcnZlcmluZm8udmVjdE1zZ1F1ZXVlW3hdLl9yZWNlaXZlX3NlcSA9PSBzZXJ2ZXJpbmZvLmN1ck1zZy5fcmVjZWl2ZV9zZXEpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8g6YeN5aSN5o6l5pS255qE5raI5oGv5piv5ZCm6ICD6JmR57un57utIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIj09PT1bRkFUQUwgRVJST1JdPT09PT4gUkVDRUlWRSBNRVNTQUdFLCBUWVBFXCIgKyBzdHJDbWQgKyBcIiwgU0VRW1wiICsgc2VydmVyaW5mby5jdXJNc2cuX3JlY2VpdmVfc2VxICsgXCJdXCIpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gLTE7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChzZXJ2ZXJpbmZvLnZlY3RNc2dRdWV1ZVt4XS5fcmVjZWl2ZV9zZXEgPiBzZXJ2ZXJpbmZvLmN1ck1zZy5fcmVjZWl2ZV9zZXEpIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHggPT0gc2VydmVyaW5mby52ZWN0TXNnUXVldWUubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgc2VydmVyaW5mby52ZWN0TXNnUXVldWUucHVzaChzZXJ2ZXJpbmZvLmN1ck1zZyk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHNlcnZlcmluZm8udmVjdE1zZ1F1ZXVlLnNwbGljZSh4LCAwLCBzZXJ2ZXJpbmZvLmN1ck1zZyk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGZvciAoeCA9IDA7IHggPCBzZXJ2ZXJpbmZvLnZlY3RNc2dRdWV1ZS5sZW5ndGg7IHgrKykge1xuICAgICAgICAgICAgICAgIHZhciBtc2dJdGVtID0gc2VydmVyaW5mby52ZWN0TXNnUXVldWVbeF07XG4gICAgICAgICAgICAgICAgaWYgKG1zZ0l0ZW0uX3JlY2VpdmVfc2VxID09IHNlcnZlcmluZm8ubkN1clJlY2VpdmVTZXEgKyAxKSB7XG4gICAgICAgICAgICAgICAgICAgIHNlcnZlcmluZm8ubkN1clJlY2VpdmVTZXEgPSBzZXJ2ZXJpbmZvLm5DdXJSZWNlaXZlU2VxICsgMTtcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZUhhbmRsZXIobXNnSXRlbS5faGVhZF9tYWluQ21kSUQsIG1zZ0l0ZW0uX2hlYWRfc3ViQ21kSUQsIG1zZ0l0ZW0uX2JvZHlfbXNnKTtcbiAgICAgICAgICAgICAgICB9IGVsc2UgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBzZXJ2ZXJpbmZvLnZlY3RNc2dRdWV1ZS5zcGxpY2UoMCwgeCk7XG5cbiAgICAgICAgICAgIGlmIChzZXJ2ZXJpbmZvLnZlY3RNc2dRdWV1ZS5sZW5ndGggPT0gMCkgc2VydmVyaW5mby53YWl0VGltZXMgPSAwO2Vsc2Uge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiPT09PVtFUlJPUl09PT09PiBSRUNFSVZFIE1FU1NBR0UsIFRZUEVcIiArIHN0ckNtZCArIFwiLCBTRVFbXCIgKyBzZXJ2ZXJpbmZvLmN1ck1zZy5fcmVjZWl2ZV9zZXEgKyBcIl0sIHZlY3QgbGVuZ3RoW1wiICsgc2VydmVyaW5mby52ZWN0TXNnUXVldWUubGVuZ3RoICsgXCJdXCIpO1xuICAgICAgICAgICAgICAgIGlmIChzZXJ2ZXJpbmZvLndhaXRUaW1lcyA+IDUpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCI9PT09W0ZBVEFMIEVSUk9SLCB0aW1lb3V0XT09PT0+IFJFQ0VJVkUgTUVTU0FHRSwgVFlQRVwiICsgc3RyQ21kICsgXCIsIFNFUVtcIiArIHNlcnZlcmluZm8uY3VyTXNnLl9yZWNlaXZlX3NlcSArIFwiXSwgdmVjdCBsZW5ndGhbXCIgKyBzZXJ2ZXJpbmZvLnZlY3RNc2dRdWV1ZS5sZW5ndGggKyBcIl1cIik7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAtMTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoc2VydmVyaW5mby52ZWN0TXNnUXVldWUubGVuZ3RoID4gMTAwKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCI9PT09W0ZBVEFMIEVSUk9SXT09PT0+IFJFQ0VJVkUgTUVTU0FHRSwgVFlQRVwiICsgc3RyQ21kICsgXCIsIFNFUVtcIiArIHNlcnZlcmluZm8uY3VyTXNnLl9yZWNlaXZlX3NlcSArIFwiXSwgdmVjdCBsZW5ndGhbXCIgKyBzZXJ2ZXJpbmZvLnZlY3RNc2dRdWV1ZS5sZW5ndGggKyBcIl1cIik7XG4gICAgICAgICAgICAgICAgcmV0dXJuIC0xO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIDA7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gVVNvY2tldDtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzYxYTkxQ0pjTnRFQXFoanNaSGtNSnZPJywgJ1V0aWxzJyk7XG4vLyBHbG9iYWwvcWlzdUxpYi9iYXNlL1V0aWxzLmpzXG5cbnZhciBtZDUgPSByZXF1aXJlKFwibWQ1XCIpO1xuXG52YXIgVXRpbHMgPSB7XG4gICAgU3dhcEFycmF5SXRlbXM6IGZ1bmN0aW9uIFN3YXBBcnJheUl0ZW1zKGFyciwgaW5kZXgxLCBpbmRleDIpIHtcbiAgICAgICAgYXJyW2luZGV4MV0gPSBhcnIuc3BsaWNlKGluZGV4MiwgMSwgYXJyW2luZGV4MV0pWzBdO1xuICAgICAgICByZXR1cm4gYXJyO1xuICAgIH0sXG5cbiAgICBtZDVFbmNyeXB0OiBmdW5jdGlvbiBtZDVFbmNyeXB0KHZhbCkge1xuICAgICAgICByZXR1cm4gbWQ1Lm1kNSh2YWwpO1xuICAgIH0sXG5cbiAgICAvLyDojrflj5bmlbDlrZflrZfkuLLvvIzmr5TlpoIgMTIzNDU2NyA9PiAxMjMuNOS4h1xuICAgIC8vIOi+k+WFpeWPguaVsOW6lOS4uuato+aVtOaVsFxuICAgIEdldE51bWJlclN0cmluZzogZnVuY3Rpb24gR2V0TnVtYmVyU3RyaW5nKHZhbCkge1xuICAgICAgICBpZiAodmFsIDwgMTAwMDApIHtcbiAgICAgICAgICAgIHJldHVybiB2YWwudG9TdHJpbmcoKTtcbiAgICAgICAgfSBlbHNlIGlmICh2YWwgPj0gMTAwMDAgJiYgdmFsIDwgMTAwMDAwMDAwKSB7XG4gICAgICAgICAgICB2YWwgPSB2YWwgLyAxMDAwMDtcbiAgICAgICAgICAgIHZhbCA9IHZhbC50b0ZpeGVkKDEpO1xuICAgICAgICAgICAgcmV0dXJuIHZhbC50b1N0cmluZygpICsgXCLkuIdcIjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHZhbCA9IHZhbCAvIDEwMDAwO1xuICAgICAgICAgICAgdmFsID0gdmFsIC8gMTAwMDA7XG4gICAgICAgICAgICB2YWwgPSB2YWwudG9GaXhlZCgxKTtcbiAgICAgICAgICAgIHJldHVybiB2YWwudG9TdHJpbmcoKSArIFwi5Lq/XCI7XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgR2V0SGV4U3RyaW5nOiBmdW5jdGlvbiBHZXRIZXhTdHJpbmcodmFsKSB7XG4gICAgICAgIHZhciB0ZW1wTmFtZSA9IHZhbC50b1N0cmluZygxNik7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgODsgaSsrKSB7XG4gICAgICAgICAgICBpZiAodGVtcE5hbWUubGVuZ3RoID49IDgpIGJyZWFrO1xuICAgICAgICAgICAgdGVtcE5hbWUgPSBcIjBcIiArIHRlbXBOYW1lO1xuICAgICAgICB9XG4gICAgICAgIHRlbXBOYW1lID0gXCIweFwiICsgdGVtcE5hbWU7XG4gICAgICAgIHJldHVybiB0ZW1wTmFtZTtcbiAgICB9LFxuICAgIENhbGNBbmdsZTogZnVuY3Rpb24gQ2FsY0FuZ2xlKHN0YXJ0LCBlbmQpIHtcbiAgICAgICAgdmFyIGRpZmZfeCA9IGVuZC54IC0gc3RhcnQueDtcbiAgICAgICAgdmFyIGRpZmZfeSA9IGVuZC55IC0gc3RhcnQueTtcbiAgICAgICAgaWYgKGVuZC54ID09PSBzdGFydC54KSB7XG4gICAgICAgICAgICBpZiAoZGlmZl95ID49IDApIHJldHVybiAwO2Vsc2UgcmV0dXJuIDE4MDtcbiAgICAgICAgfSBlbHNlIGlmIChlbmQueSA9PT0gc3RhcnQueSkge1xuICAgICAgICAgICAgaWYgKGRpZmZfeCA+PSAwKSByZXR1cm4gOTA7ZWxzZSByZXR1cm4gMjcwO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgaWYgKGRpZmZfeCA+IDAgJiYgZGlmZl95ID4gMCkge1xuICAgICAgICAgICAgICAgIHJldHVybiAzNjAgKiBNYXRoLmF0YW4oZGlmZl94IC8gZGlmZl95KSAvICgyICogTWF0aC5QSSk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKGRpZmZfeCA8IDAgJiYgZGlmZl95IDwgMCkge1xuICAgICAgICAgICAgICAgIHJldHVybiAzNjAgKiBNYXRoLmF0YW4oZGlmZl94IC8gZGlmZl95KSAvICgyICogTWF0aC5QSSkgLSAxODA7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKGRpZmZfeCA+IDAgJiYgZGlmZl95IDwgMCkge1xuICAgICAgICAgICAgICAgIHJldHVybiAzNjAgKiBNYXRoLmF0YW4oZGlmZl94IC8gZGlmZl95KSAvICgyICogTWF0aC5QSSkgLSAxODA7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKGRpZmZfeCA8IDAgJiYgZGlmZl95ID4gMCkge1xuICAgICAgICAgICAgICAgIHJldHVybiAzNjAgKiBNYXRoLmF0YW4oZGlmZl94IC8gZGlmZl95KSAvICgyICogTWF0aC5QSSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHJldHVybiAwO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufTtcblxubW9kdWxlLmV4cG9ydHMgPSBVdGlscztcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzVlZGNhUUJzQVpDcUlOSGIzd2IxdHJpJywgJ1lpbmdzYW56aGFuZ0NvbnN0RGVmJyk7XG4vLyByZXNvdXJjZXMvR2FtZXMvWWluZ3NhbnpoYW5nL3NyYy9ZaW5nc2FuemhhbmdDb25zdERlZi5qc1xuXG52YXIgQ09OTkVDVF9DQUxMQkFDS19TVEFUVVMgPSBjYy5FbnVtKHtcbiAgICAvLz09PT09PT09PT09PT09PT09PT3jgJDkuLvlkb3ku6TjgJE9PT09PT09PT09PT09PT09PT09PT09XG4gICAgTUlBTl9MT0dPTjogMHgwMDAxLFxuICAgIE1JQU5fR1VJREU6IDB4MDAwMixcbiAgICBNSUFOX0hPTUU6IDB4MDAwMyxcblxuICAgIC8vPT09PT09PT09PT09PT09PT09PeOAkOW8leWvvOWcuuaZr+OAkT09PT09PT09PT09PT09PT09PT09ICBcbiAgICBHVUlERV9TRVRfQ0xJRU5UX0RBVEE6IDBYMDAwMjAwMDEsIC8vIOS/ruaUueS/oeaBr1xuXG4gICAgLy89PT09PT09PT09PT09PT09PT09PeOAkOS4u+WcuuaZr+OAkT09PT09PT09PT09PT09PT09PT09PSAgXG4gICAgSE9NRV9FTlRFUl9ST09NOiAweDAwMDMwMDAxLCAvL+i/m+WFpeaIv+mXtFxuXG4gICAgSE9NRV9MRUFWRV9URUFNOiAweDAwMDMwMDAyLCAvL+emu+W8gOmYn+S8jVxuXG4gICAgLy89PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBcbiAgICBTVEFUVVNfSU5JVDogMCB9KTtcblxuLy8g5Yid5aeL5YyW77yM5peg5Yqo5L2cXG5cbnZhciBDQVJEU19UWVBFID0gY2MuRW51bSh7XG4gICAgTk9ORTogMCwgLy8g5LiN56ym5ZCI6KeE5YiZXG4gICAgVFlQRV9FUl9TQU5fV1U6IDEsIC8vIDEgMjM1XG4gICAgVFlQRV9EYW5fWkhBTkc6IDIsIC8vIDIg5Y2V5bygXG4gICAgVFlQRV9EVUlfWkk6IDMsIC8vIDMg5a+55a2QXG4gICAgVFlQRV9TSFVOX1pJOiA0LCAvLyA0IOmhuuWtkFxuICAgIFRZUEVfVE9OR19IVUE6IDUsIC8vIDUg5ZCM6IqxXG4gICAgVFlQRV9UT05HX0hVQV9TSFVOOiA2LCAvLyA2IOWQjOiKsemhulxuICAgIFRZUEVfQkFPX1pJOiA3IH0pO1xuLy8gNyDosbnlrZBcbnZhciBQTEFZRVJfT1BFUkFUSU9OX1RZUEUgPSB7XG4gICAgT1BFUkFUSU9OX0RJU0NBUkQ6IDEsXG4gICAgT1BFUkFUSU9OX0xPT0tDQVJEOiAyLFxuICAgIE9QRVJBVElPTl9MT1NFOiAzXG59O1xudmFyIEZJR0hUX1JFU1VMVCA9IHtcbiAgICBMT1NFOiAxLFxuICAgIFdJTjogMlxufTtcbnZhciBGSUdIVF9TVEFUVVMgPSBjYy5FbnVtKHtcbiAgICBJTklUOiAwLFxuICAgIEJFR0lOOiAxLFxuICAgIFdBSVRfQkVUOiAyLFxuICAgIEZJR0hUSU5HOiAzLFxuICAgIEVORDogNCxcblxuICAgIENfUkVBRFlfQkVHSU46IDEwMSxcbiAgICBDX0NBTkNFTF9CRUdJTjogMTAyLFxuXG4gICAgQ19CRUdJTjogMTAzLFxuXG4gICAgQ19CRUdJTl9TRU5EX0NBUkQ6IDEwNCwgLy8g5Y+R5LiJ5byg54mMIDEwNCB+IDEwNlxuXG4gICAgQ19CRUdJTl9TRU5EX1JFQURZOiAxMDgsIC8vIOWPkeWujOeJjFxuXG4gICAgQ19CRVRfU1RBUlQ6IDExMCxcblxuICAgIENfRU5EOiAxMTUsIC8vIOaUtuWIsOaImOaWl+aImOaWl+e7k+adn+a2iOaBr+eahOaXtuWAmeiuvue9ruS4uuivpeeKtuaAge+8iOW8gOeJjOOAgeW8ueeql+OAgemjnumSseOAgemjmOmSse+8iVxuXG4gICAgQ19FTkRfUDE6IDEyMSwgLy8g5pKt5pS+5by556qX5YmNXG4gICAgQ19FTkRfUDI6IDEyMiwgLy8g5by556qX5pKt5pS+57uT5p2f77yM57Sn5o6l552A5pKt5pS+6aOY6ZKxXG4gICAgQ19FTkRfRklOSVNIOiAxMjNcbn0pO1xuXG52YXIgQ09JTl9UWVBFID0gY2MuRW51bSh7XG4gICAgZGlhbW9uZDogMCwgLy/pkrvnn7NcbiAgICBnb2xkOiAxIC8v6YeR5biBXG59KTtcblxudmFyIEdBTUVfV0FJVF9USU1FID0ge1xuICAgIEdSQUJfQkFOS0VSX1dBSVRfVElNRTogMTAsXG4gICAgRklSU1RfT1VUX0NBUkRfV0FJVF9USU1FOiAyNSxcbiAgICBPVVRfQ0FSRF9XQUlUX1RJTUU6IDI1LFxuICAgIE9VVF9DQVJEX09OTFlfUEFTRUVfV0FJVF9USU1FOiAxMCxcbiAgICBPVVRfQ0FSRF9MRVNTX09OTFlfUEFTRUVfV0FJVF9USU1FOiAzLFxuICAgIFJPQ0tFVF9XQUlUX1RJTUU6IDMsXG4gICAgUkVBRFlfV0FJVF9USU1FOiAzNVxufTtcbnZhciBDQVJEX1NUQVRVUyA9IGNjLkVudW0oe1xuICAgIE9QRU5fQ0FSRDogMSxcbiAgICBEQVJEX0NBUkQ6IDJcbn0pO1xudmFyIE1FU1NBR0UgPSB7XG4gICAgQ01EX01BSU5fWWluZ1NhblpoYW5nOiAweDgwMDEsXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICBCRVRfUkVROiAweDAwMDEsXG4gICAgQkVUX1NVQ0NFU1M6IDB4MDAwMixcbiAgICBCRVRfRkFJTEVEOiAweDAwMDMsXG4gICAgQkVUX05PVElGWTogMHgwMDA0LFxuXG4gICAgRk9MTE9XX0JFVF9SRVE6IDB4MDAwNSxcbiAgICBGT0xMT1dfQkVUX1NVQ0NFU1M6IDB4MDAwNixcbiAgICBGT0xMT1dfQkVUX0ZBSUxFRDogMHgwMDA3LFxuICAgIEZPTExPV19CRVRfTk9USUZZOiAweDAwMDgsXG5cbiAgICBBRERfQkVUX1JFUTogMHgwMDA5LFxuICAgIEFERF9CRVRfU1VDQ0VTUzogMHgwMDAxMCxcbiAgICBBRERfQkVUX0ZBSUxFRDogMHgwMDAxMSxcbiAgICBBRERfQkVUX05PVElGWTogMHgwMDAxMixcblxuICAgIExPT0tfQ0FSRF9SRVE6IDB4MDAwMTMsXG4gICAgTE9PS19DQVJEX1NVQ0NFU1M6IDB4MDAwMTQsXG4gICAgTE9PS19DQVJEX0ZBSUxFRDogMHgwMDAxNSxcbiAgICBMT09LX0NBUkRfTk9USUZZOiAweDAwMDE2LFxuXG4gICAgRElTQ0FSRF9SRVE6IDB4MDAwMTcsXG4gICAgRElTQ0FSRF9TVUNDRVNTOiAweDAwMDE4LFxuICAgIERJU0NBUkRfRkFJTEVEOiAweDAwMDE5LFxuICAgIERJU0NBUkRfTk9USUZZOiAweDAwMDIwLFxuXG4gICAgQ09NUEFSRV9DQVJEX1JFUTogMHgwMDAyMSxcbiAgICBDT01QQVJFX0NBUkRfU1VDQ0VTUzogMHgwMDAyMixcbiAgICBDT01QQVJFX0NBUkRfRkFJTEVEOiAweDAwMDIzLFxuICAgIENPTVBBUkVfQ0FSRF9OT1RJRlk6IDB4MDAwMjRcbn07XG5cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxubW9kdWxlLmV4cG9ydHMgPSB7XG4gICAgUExBWUVSX09QRVJBVElPTl9UWVBFOiBQTEFZRVJfT1BFUkFUSU9OX1RZUEUsXG4gICAgQ09OTkVDVF9DQUxMQkFDS19TVEFUVVM6IENPTk5FQ1RfQ0FMTEJBQ0tfU1RBVFVTLFxuICAgIE1FU1NBR0U6IE1FU1NBR0UsXG4gICAgQ09JTl9UWVBFOiBDT0lOX1RZUEUsXG4gICAgRklHSFRfU1RBVFVTOiBGSUdIVF9TVEFUVVMsXG4gICAgR0FNRV9XQUlUX1RJTUU6IEdBTUVfV0FJVF9USU1FLFxuICAgIENBUkRfU1RBVFVTOiBDQVJEX1NUQVRVUyxcbiAgICBDQVJEU19UWVBFOiBDQVJEU19UWVBFXG59O1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnNjYyYTNrTWVoSkdiNnBrSXhVc2RqemknLCAnWWluZ3NhbnpoYW5nR2FtZUNvbnRyb2xsZXInKTtcbi8vIHJlc291cmNlcy9HYW1lcy9ZaW5nc2Fuemhhbmcvc3JjL1lpbmdzYW56aGFuZ0dhbWVDb250cm9sbGVyLmpzXG5cbnZhciBjb25zdERlZiA9IHJlcXVpcmUoXCJDb25zdERlZlwiKTtcbnZhciBnYW1lQ29uc3REZWYgPSByZXF1aXJlKFwiWWluZ3NhbnpoYW5nQ29uc3REZWZcIik7XG52YXIgUHJvdG9jb2xNZXNzYWdlID0gcmVxdWlyZShcIlByb3RvY29sTWVzc2FnZVwiKTtcbnZhciBIaW50TWFuYWdlciA9IHJlcXVpcmUoXCJIaW50TWFuYWdlclwiKTtcbnZhciBHbG9iYWxNYW5hZ2VyID0gcmVxdWlyZShcIkdsb2JhbE1hbmFnZXJcIik7XG52YXIgR2FtZU1lc3NhZ2UgPSByZXF1aXJlKFwiWWluZ3NhbnpoYW5nR2FtZU1lc3NhZ2VcIik7XG5cbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICBnYW1lRGF0YTogcmVxdWlyZShcIllpbmdzYW56aGFuZ0dhbWVEYXRhXCIpXG5cbiAgICB9LFxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge30sXG4gICAgZ2FtZVJlZ2lzdGVyTWVzc2FnZTogZnVuY3Rpb24gZ2FtZVJlZ2lzdGVyTWVzc2FnZSgpIHtcbiAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5SZWdNc2dIYW5kbGVyKGNvbnN0RGVmLk1FU1NBR0UuQ01EX01BSU5fUExBVEZPUk0sIGNvbnN0RGVmLk1FU1NBR0UuRU5URVJfUk9PTV9TVUNDRVNTLCBHYW1lTWVzc2FnZS5oYW5kbGVyX0VOVEVSX1JPT01fU1VDQ0VTUyk7XG4gICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuUmVnTXNnSGFuZGxlcihjb25zdERlZi5NRVNTQUdFLkNNRF9NQUlOX1BMQVRGT1JNLCBjb25zdERlZi5NRVNTQUdFLkVOVEVSX1JPT01fRkFJTEVELCBHYW1lTWVzc2FnZS5oYW5kbGVyX0VOVEVSX1JPT01fRkFJTEVEKTtcblxuICAgICAgICBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLlJlZ01zZ0hhbmRsZXIoY29uc3REZWYuTUVTU0FHRS5DTURfTUFJTl9QTEFURk9STSwgY29uc3REZWYuTUVTU0FHRS5QTEFZRVJfRU5URVJfUk9PTV9OT1RJRlksIEdhbWVNZXNzYWdlLmhhbmRsZXJfUExBWUVSX0VOVEVSX1JPT01fTk9USUZZKTtcbiAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5SZWdNc2dIYW5kbGVyKGNvbnN0RGVmLk1FU1NBR0UuQ01EX01BSU5fUExBVEZPUk0sIGNvbnN0RGVmLk1FU1NBR0UuUExBWUVSX0xFQVZFX1JPT01fTk9USUZZLCBHYW1lTWVzc2FnZS5oYW5kbGVyX1BMQVlFUl9MRUFWRV9ST09NX05PVElGWSk7XG5cbiAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5SZWdNc2dIYW5kbGVyKGNvbnN0RGVmLk1FU1NBR0UuQ01EX01BSU5fUExBVEZPUk0sIGNvbnN0RGVmLk1FU1NBR0UuR0VUX0dBTUVfSU5GT19TVUNDRVNTLCBHYW1lTWVzc2FnZS5oYW5kbGVyX0dFVF9HQU1FX0lORk9fU1VDQ0VTUyk7XG4gICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuUmVnTXNnSGFuZGxlcihjb25zdERlZi5NRVNTQUdFLkNNRF9NQUlOX1BMQVRGT1JNLCBjb25zdERlZi5NRVNTQUdFLkdFVF9HQU1FX0lORk9fRkFJTEVELCBHYW1lTWVzc2FnZS5oYW5kbGVyX0dFVF9HQU1FX0lORk9fRkFJTEVEKTtcblxuICAgICAgICBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLlJlZ01zZ0hhbmRsZXIoY29uc3REZWYuTUVTU0FHRS5DTURfTUFJTl9QTEFURk9STSwgY29uc3REZWYuTUVTU0FHRS5HRVRfUExBWUVSU19CQVNFX0lORk9fU1VDQ0VTUywgR2FtZU1lc3NhZ2UuaGFuZGxlcl9HRVRfUExBWUVSU19CQVNFX0lORk9fU1VDQ0VTUyk7XG4gICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuUmVnTXNnSGFuZGxlcihjb25zdERlZi5NRVNTQUdFLkNNRF9NQUlOX1BMQVRGT1JNLCBjb25zdERlZi5NRVNTQUdFLkdFVF9QTEFZRVJTX0JBU0VfSU5GT19GQUlMRUQsIEdhbWVNZXNzYWdlLmhhbmRsZXJfR0VUX1BMQVlFUlNfQkFTRV9JTkZPX0ZBSUxFRCk7XG5cbiAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5SZWdNc2dIYW5kbGVyKGNvbnN0RGVmLk1FU1NBR0UuQ01EX01BSU5fUExBVEZPUk0sIGNvbnN0RGVmLk1FU1NBR0UuQkFMQU5DRV9OT1RJRlksIEdhbWVNZXNzYWdlLmhhbmRsZXJfQkFMQU5DRV9OT1RJRlkpO1xuXG4gICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuUmVnTXNnSGFuZGxlcihjb25zdERlZi5NRVNTQUdFLkNNRF9NQUlOX0dBTUUsIGNvbnN0RGVmLk1FU1NBR0UuTEVBVkVfVEVBTV9OT1RJRlksIEdhbWVNZXNzYWdlLmhhbmRsZXJfTEVBVkVfVEVBTV9OT1RJRlkpO1xuICAgICAgICBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLlJlZ01zZ0hhbmRsZXIoY29uc3REZWYuTUVTU0FHRS5DTURfTUFJTl9HQU1FLCBjb25zdERlZi5NRVNTQUdFLlRFQU1fQUxMX1JFQURZX05PVElGWSwgR2FtZU1lc3NhZ2UuaGFuZGxlcl9URUFNX0FMTF9SRUFEWV9OT1RJRlkpO1xuICAgICAgICBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLlJlZ01zZ0hhbmRsZXIoY29uc3REZWYuTUVTU0FHRS5DTURfTUFJTl9HQU1FLCBjb25zdERlZi5NRVNTQUdFLlRFQU1fQUxMX1JFQURZX1NVQ0NFU1MsIEdhbWVNZXNzYWdlLmhhbmRsZXJfVEVBTV9BTExfUkVBRFlfU1VDQ0VTUyk7XG4gICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuUmVnTXNnSGFuZGxlcihjb25zdERlZi5NRVNTQUdFLkNNRF9NQUlOX0dBTUUsIGNvbnN0RGVmLk1FU1NBR0UuVEVBTV9BTExfUkVBRFlfRkFJTEVELCBHYW1lTWVzc2FnZS5oYW5kbGVyX1RFQU1fQUxMX1JFQURZX0ZBSUxFRCk7XG4gICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuUmVnTXNnSGFuZGxlcihjb25zdERlZi5NRVNTQUdFLkNNRF9NQUlOX0dBTUUsIGNvbnN0RGVmLk1FU1NBR0UuRU5URVJfQkFUVExFX05PVElGWSwgR2FtZU1lc3NhZ2UuaGFuZGxlcl9FTlRFUl9CQVRUTEVfTk9USUZZKTtcbiAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5SZWdNc2dIYW5kbGVyKGNvbnN0RGVmLk1FU1NBR0UuQ01EX01BSU5fR0FNRSwgY29uc3REZWYuTUVTU0FHRS5FTlRFUl9CQVRUTEVfU1VDQ0VTUywgR2FtZU1lc3NhZ2UuaGFuZGxlcl9FTlRFUl9CQVRUTEVfU1VDQ0VTUyk7XG4gICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuUmVnTXNnSGFuZGxlcihjb25zdERlZi5NRVNTQUdFLkNNRF9NQUlOX0dBTUUsIGNvbnN0RGVmLk1FU1NBR0UuRU5URVJfQkFUVExFX0ZBSUxFRCwgR2FtZU1lc3NhZ2UuaGFuZGxlcl9FTlRFUl9CQVRUTEVfRkFJTEVEKTtcbiAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5SZWdNc2dIYW5kbGVyKGNvbnN0RGVmLk1FU1NBR0UuQ01EX01BSU5fR0FNRSwgY29uc3REZWYuTUVTU0FHRS5GSUdIVF9SRUFEWV9TVUNDRVNTLCBHYW1lTWVzc2FnZS5oYW5kbGVyX0ZJR0hUX1JFQURZX1NVQ0NFU1MpO1xuICAgICAgICBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLlJlZ01zZ0hhbmRsZXIoY29uc3REZWYuTUVTU0FHRS5DTURfTUFJTl9HQU1FLCBjb25zdERlZi5NRVNTQUdFLkZJR0hUX1JFQURZX0ZBSUxFRCwgR2FtZU1lc3NhZ2UuaGFuZGxlcl9GSUdIVF9SRUFEWV9GQUlMRUQpO1xuICAgICAgICBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLlJlZ01zZ0hhbmRsZXIoY29uc3REZWYuTUVTU0FHRS5DTURfTUFJTl9HQU1FLCBjb25zdERlZi5NRVNTQUdFLkZJR0hUX1JFQURZX05PVElGWSwgR2FtZU1lc3NhZ2UuaGFuZGxlcl9GSUdIVF9SRUFEWV9OT1RJRlkpO1xuICAgICAgICBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLlJlZ01zZ0hhbmRsZXIoY29uc3REZWYuTUVTU0FHRS5DTURfTUFJTl9HQU1FLCBjb25zdERlZi5NRVNTQUdFLlNDRU5FX1JFQURZX05PVElGWSwgR2FtZU1lc3NhZ2UuaGFuZGxlcl9TQ0VORV9SRUFEWV9OT1RJRlkpO1xuICAgICAgICBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLlJlZ01zZ0hhbmRsZXIoY29uc3REZWYuTUVTU0FHRS5DTURfTUFJTl9HQU1FLCBjb25zdERlZi5NRVNTQUdFLlNDRU5FX1JFQURZX1NVQ0NFU1MsIEdhbWVNZXNzYWdlLmhhbmRsZXJfU0NFTkVfUkVBRFlfU1VDQ0VTUyk7XG4gICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuUmVnTXNnSGFuZGxlcihjb25zdERlZi5NRVNTQUdFLkNNRF9NQUlOX0dBTUUsIGNvbnN0RGVmLk1FU1NBR0UuU0NFTkVfUkVBRFlfRkFJTEVELCBHYW1lTWVzc2FnZS5oYW5kbGVyX1NDRU5FX1JFQURZX0ZBSUxFRCk7XG4gICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuUmVnTXNnSGFuZGxlcihjb25zdERlZi5NRVNTQUdFLkNNRF9NQUlOX0dBTUUsIGNvbnN0RGVmLk1FU1NBR0UuRklHSFRfQkVHSU5fTk9USUZZLCBHYW1lTWVzc2FnZS5oYW5kbGVyX0ZJR0hUX0JFR0lOX05PVElGWSk7XG4gICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuUmVnTXNnSGFuZGxlcihjb25zdERlZi5NRVNTQUdFLkNNRF9NQUlOX0dBTUUsIGNvbnN0RGVmLk1FU1NBR0UuRklHSFRfRU5EX05PVElGWSwgR2FtZU1lc3NhZ2UuaGFuZGxlcl9GSUdIVF9FTkRfTk9USUZZKTtcbiAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5SZWdNc2dIYW5kbGVyKGNvbnN0RGVmLk1FU1NBR0UuQ01EX01BSU5fR0FNRSwgY29uc3REZWYuTUVTU0FHRS5HRVRfVEVBTV9NRU1CRVJTX1NVQ0NFU1MsIEdhbWVNZXNzYWdlLmhhbmRsZXJfR0VUX1RFQU1fTUVNQkVSU19TVUNDRVNTKTtcbiAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5SZWdNc2dIYW5kbGVyKGNvbnN0RGVmLk1FU1NBR0UuQ01EX01BSU5fR0FNRSwgY29uc3REZWYuTUVTU0FHRS5HRVRfVEVBTV9NRU1CRVJTX0ZBSUxFRCwgR2FtZU1lc3NhZ2UuaGFuZGxlcl9HRVRfVEVBTV9NRU1CRVJTX0ZBSUxFRCk7XG4gICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuUmVnTXNnSGFuZGxlcihjb25zdERlZi5NRVNTQUdFLkNNRF9NQUlOX0dBTUUsIGNvbnN0RGVmLk1FU1NBR0UuR0VUX01BVENIX0RBVEFfTk9USUZZLCBHYW1lTWVzc2FnZS5oYW5kbGVyX0dFVF9NQVRDSF9EQVRBX05PVElGWSk7XG4gICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuUmVnTXNnSGFuZGxlcihjb25zdERlZi5NRVNTQUdFLkNNRF9NQUlOX0dBTUUsIGNvbnN0RGVmLk1FU1NBR0UuR0VUX01BVENIX0NVUl9DT1VOVF9TVUNDRVNTLCBHYW1lTWVzc2FnZS5oYW5kbGVyX0dFVF9NQVRDSF9DVVJfQ09VTlRfU1VDQ0VTUyk7XG4gICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuUmVnTXNnSGFuZGxlcihjb25zdERlZi5NRVNTQUdFLkNNRF9NQUlOX0dBTUUsIGNvbnN0RGVmLk1FU1NBR0UuR0VUX01BVENIX0NVUl9DT1VOVF9GQUlMRUQsIEdhbWVNZXNzYWdlLmhhbmRsZXJfR0VUX01BVENIX0NVUl9DT1VOVF9GQUlMRUQpO1xuXG4gICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuUmVnTXNnSGFuZGxlcihnYW1lQ29uc3REZWYuTUVTU0FHRS5DTURfTUFJTl9ZaW5nU2FuWmhhbmcsIGdhbWVDb25zdERlZi5NRVNTQUdFLkJFVF9TVUNDRVNTLCBHYW1lTWVzc2FnZS5oYW5kbGVyX0JFVF9TVUNDRVNTKTtcbiAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5SZWdNc2dIYW5kbGVyKGdhbWVDb25zdERlZi5NRVNTQUdFLkNNRF9NQUlOX1lpbmdTYW5aaGFuZywgZ2FtZUNvbnN0RGVmLk1FU1NBR0UuQkVUX0ZBSUxFRCwgR2FtZU1lc3NhZ2UuaGFuZGxlcl9CRVRfRkFJTEVEKTtcbiAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5SZWdNc2dIYW5kbGVyKGdhbWVDb25zdERlZi5NRVNTQUdFLkNNRF9NQUlOX1lpbmdTYW5aaGFuZywgZ2FtZUNvbnN0RGVmLk1FU1NBR0UuQkVUX05PVElGWSwgR2FtZU1lc3NhZ2UuaGFuZGxlcl9CRVRfTk9USUZZKTtcblxuICAgICAgICBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLlJlZ01zZ0hhbmRsZXIoZ2FtZUNvbnN0RGVmLk1FU1NBR0UuQ01EX01BSU5fWWluZ1NhblpoYW5nLCBnYW1lQ29uc3REZWYuTUVTU0FHRS5GT0xMT1dfQkVUX1NVQ0NFU1MsIEdhbWVNZXNzYWdlLmhhbmRsZXJfRk9MTE9XX0JFVF9TVUNDRVNTKTtcbiAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5SZWdNc2dIYW5kbGVyKGdhbWVDb25zdERlZi5NRVNTQUdFLkNNRF9NQUlOX1lpbmdTYW5aaGFuZywgZ2FtZUNvbnN0RGVmLk1FU1NBR0UuRk9MTE9XX0JFVF9OT1RJRlksIEdhbWVNZXNzYWdlLmhhbmRsZXJfRk9MTE9XX0JFVF9OT1RJRlkpO1xuICAgICAgICBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLlJlZ01zZ0hhbmRsZXIoZ2FtZUNvbnN0RGVmLk1FU1NBR0UuQ01EX01BSU5fWWluZ1NhblpoYW5nLCBnYW1lQ29uc3REZWYuTUVTU0FHRS5GT0xMT1dfQkVUX0ZBSUxFRCwgR2FtZU1lc3NhZ2UuaGFuZGxlcl9GT0xMT1dfQkVUX0ZBSUxFRCk7XG5cbiAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5SZWdNc2dIYW5kbGVyKGdhbWVDb25zdERlZi5NRVNTQUdFLkNNRF9NQUlOX1lpbmdTYW5aaGFuZywgZ2FtZUNvbnN0RGVmLk1FU1NBR0UuQUREX0JFVF9TVUNDRVNTLCBHYW1lTWVzc2FnZS5oYW5kbGVyX0FERF9CRVRfU1VDQ0VTUyk7XG4gICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuUmVnTXNnSGFuZGxlcihnYW1lQ29uc3REZWYuTUVTU0FHRS5DTURfTUFJTl9ZaW5nU2FuWmhhbmcsIGdhbWVDb25zdERlZi5NRVNTQUdFLkFERF9CRVRfRkFJTEVELCBHYW1lTWVzc2FnZS5oYW5kbGVyX0FERF9CRVRfRkFJTEVEKTtcbiAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5SZWdNc2dIYW5kbGVyKGdhbWVDb25zdERlZi5NRVNTQUdFLkNNRF9NQUlOX1lpbmdTYW5aaGFuZywgZ2FtZUNvbnN0RGVmLk1FU1NBR0UuQUREX0JFVF9OT1RJRlksIEdhbWVNZXNzYWdlLmhhbmRsZXJfQUREX0JFVF9OT1RJRlkpO1xuXG4gICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuUmVnTXNnSGFuZGxlcihnYW1lQ29uc3REZWYuTUVTU0FHRS5DTURfTUFJTl9ZaW5nU2FuWmhhbmcsIGdhbWVDb25zdERlZi5NRVNTQUdFLkxPT0tfQ0FSRF9TVUNDRVNTLCBHYW1lTWVzc2FnZS5oYW5kbGVyX0xPT0tfQ0FSRF9TVUNDRVNTKTtcbiAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5SZWdNc2dIYW5kbGVyKGdhbWVDb25zdERlZi5NRVNTQUdFLkNNRF9NQUlOX1lpbmdTYW5aaGFuZywgZ2FtZUNvbnN0RGVmLk1FU1NBR0UuTE9PS19DQVJEX05PVElGWSwgR2FtZU1lc3NhZ2UuaGFuZGxlcl9MT09LX0NBUkRfTk9USUZZKTtcbiAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5SZWdNc2dIYW5kbGVyKGdhbWVDb25zdERlZi5NRVNTQUdFLkNNRF9NQUlOX1lpbmdTYW5aaGFuZywgZ2FtZUNvbnN0RGVmLk1FU1NBR0UuTE9PS19DQVJEX0ZBSUxFRCwgR2FtZU1lc3NhZ2UuaGFuZGxlcl9MT09LX0NBUkRfRkFJTEVEKTtcblxuICAgICAgICBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLlJlZ01zZ0hhbmRsZXIoZ2FtZUNvbnN0RGVmLk1FU1NBR0UuQ01EX01BSU5fWWluZ1NhblpoYW5nLCBnYW1lQ29uc3REZWYuTUVTU0FHRS5ESVNDQVJEX1NVQ0NFU1MsIEdhbWVNZXNzYWdlLmhhbmRsZXJfRElTQ0FSRF9TVUNDRVNTKTtcbiAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5SZWdNc2dIYW5kbGVyKGdhbWVDb25zdERlZi5NRVNTQUdFLkNNRF9NQUlOX1lpbmdTYW5aaGFuZywgZ2FtZUNvbnN0RGVmLk1FU1NBR0UuRElTQ0FSRF9GQUlMRUQsIEdhbWVNZXNzYWdlLmhhbmRsZXJfRElTQ0FSRF9GQUlMRUQpO1xuICAgICAgICBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLlJlZ01zZ0hhbmRsZXIoZ2FtZUNvbnN0RGVmLk1FU1NBR0UuQ01EX01BSU5fWWluZ1NhblpoYW5nLCBnYW1lQ29uc3REZWYuTUVTU0FHRS5ESVNDQVJEX05PVElGWSwgR2FtZU1lc3NhZ2UuaGFuZGxlcl9ESVNDQVJEX05PVElGWSk7XG5cbiAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5SZWdNc2dIYW5kbGVyKGdhbWVDb25zdERlZi5NRVNTQUdFLkNNRF9NQUlOX1lpbmdTYW5aaGFuZywgZ2FtZUNvbnN0RGVmLk1FU1NBR0UuQ09NUEFSRV9DQVJEX1NVQ0NFU1MsIEdhbWVNZXNzYWdlLmhhbmRsZXJfQ09NUEFSRV9DQVJEX1NVQ0NFU1MpO1xuICAgICAgICBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLlJlZ01zZ0hhbmRsZXIoZ2FtZUNvbnN0RGVmLk1FU1NBR0UuQ01EX01BSU5fWWluZ1NhblpoYW5nLCBnYW1lQ29uc3REZWYuTUVTU0FHRS5DT01QQVJFX0NBUkRfRkFJTEVELCBHYW1lTWVzc2FnZS5oYW5kbGVyX0NPTVBBUkVfQ0FSRF9GQUlMRUQpO1xuICAgICAgICBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLlJlZ01zZ0hhbmRsZXIoZ2FtZUNvbnN0RGVmLk1FU1NBR0UuQ01EX01BSU5fWWluZ1NhblpoYW5nLCBnYW1lQ29uc3REZWYuTUVTU0FHRS5DT01QQVJFX0NBUkRfTk9USUZZLCBHYW1lTWVzc2FnZS5oYW5kbGVyX0NPTVBBUkVfQ0FSRF9OT1RJRlkpO1xuICAgIH0sXG5cbiAgICBSZWZyZXNoUGxheWVyRGF0YTogZnVuY3Rpb24gUmVmcmVzaFBsYXllckRhdGEodHlwZSkge1xuICAgICAgICBjYy5sb2coXCJ0eXBlXCIsIHR5cGUpO1xuICAgIH0sXG4gICAgU2VuZE1zZzogZnVuY3Rpb24gU2VuZE1zZyhzdGF0dXMpIHtcbiAgICAgICAgdmFyIGdhbWVEYXRhID0gR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5HZXRHYW1lRGF0YShHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLnNlbGZEYXRhLm5DdXJHYW1lSUQpO1xuICAgICAgICBzd2l0Y2ggKHN0YXR1cykge1xuICAgICAgICAgICAgY2FzZSBjb25zdERlZi5DT05ORUNUX0NBTExCQUNLX1NUQVRVUy5MT0dPTl9HRVRfR0FNRV9JTkZPOlxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIF9tc2cgPSBuZXcgUHJvdG9jb2xNZXNzYWdlKGNvbnN0RGVmLk1FU1NBR0UuQ01EX01BSU5fUExBVEZPUk0sIGNvbnN0RGVmLk1FU1NBR0UuR0VUX0dBTUVfSU5GT19SRVEsIGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgICAgUHJvdG9jb2xNZXNzYWdlLkFkZFZlY3RJdGVtSW50KF9tc2cuX2JvZHlfbXNnLCBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLnNlbGZEYXRhLm5BY2NvdW50SUQpO1xuICAgICAgICAgICAgICAgICAgICBQcm90b2NvbE1lc3NhZ2UuQWRkVmVjdEl0ZW1JbnQoX21zZy5fYm9keV9tc2csIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2Uuc2VsZkRhdGEubkN1ckdhbWVJRCk7XG4gICAgICAgICAgICAgICAgICAgIFByb3RvY29sTWVzc2FnZS5BZGRWZWN0SXRlbUludChfbXNnLl9ib2R5X21zZywgMCk7XG4gICAgICAgICAgICAgICAgICAgIFByb3RvY29sTWVzc2FnZS5BZGRWZWN0SXRlbUludChfbXNnLl9ib2R5X21zZywgMCk7XG4gICAgICAgICAgICAgICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuU2VuZExvZ29uTXNnKF9tc2cpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlIGNvbnN0RGVmLkNPTk5FQ1RfQ0FMTEJBQ0tfU1RBVFVTLkxPR09OX0dFVF9QTEFZRVJTX0JBU0VfSU5GTzpcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGNjLmxvZyhcIkxPR09OX0dFVF9QTEFZRVJTX0JBU0VfSU5GT1wiKTtcbiAgICAgICAgICAgICAgICAgICAgdmFyIF9tc2cyID0gbmV3IFByb3RvY29sTWVzc2FnZShjb25zdERlZi5NRVNTQUdFLkNNRF9NQUlOX1BMQVRGT1JNLCBjb25zdERlZi5NRVNTQUdFLkdFVF9QTEFZRVJTX0JBU0VfSU5GT19SRVEsIGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgICAgUHJvdG9jb2xNZXNzYWdlLkFkZFZlY3RJdGVtSW50KF9tc2cyLl9ib2R5X21zZywgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5zZWxmRGF0YS5uQWNjb3VudElEKTtcbiAgICAgICAgICAgICAgICAgICAgUHJvdG9jb2xNZXNzYWdlLkFkZFZlY3RJdGVtSW50KF9tc2cyLl9ib2R5X21zZywgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5zZWxmRGF0YS5uQ3VyR2FtZUlEKTtcblxuICAgICAgICAgICAgICAgICAgICB2YXIgdmVjdEluZGV4ID0gX21zZzIuX2JvZHlfbXNnLmxlbmd0aDtcbiAgICAgICAgICAgICAgICAgICAgUHJvdG9jb2xNZXNzYWdlLkFkZFZlY3RJdGVtVmVjdChfbXNnMi5fYm9keV9tc2cpO1xuICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGdhbWVEYXRhLnZlY3RUZWFtTGlzdC5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGdhbWVEYXRhLnZlY3RUZWFtTGlzdFtpXS5uQWNjb3VudElEID4gMCAmJiBnYW1lRGF0YS52ZWN0VGVhbUxpc3RbaV0ubmljayA9PSBcIlwiKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUHJvdG9jb2xNZXNzYWdlLkFkZFZlY3RJdGVtSW50KF9tc2cyLl9ib2R5X21zZ1t2ZWN0SW5kZXhdLl92ZWN0X3ZhbHVlLCBnYW1lRGF0YS52ZWN0VGVhbUxpc3RbaV0ubkFjY291bnRJRCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5TZW5kTG9nb25Nc2coX21zZzIpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgICAgICAgIGNhc2UgZ2FtZUNvbnN0RGVmLkNPTk5FQ1RfQ0FMTEJBQ0tfU1RBVFVTLkhPTUVfRU5URVJfUk9PTTpcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBtc2cgPSBuZXcgUHJvdG9jb2xNZXNzYWdlKGNvbnN0RGVmLk1FU1NBR0UuQ01EX01BSU5fUExBVEZPUk0sIGNvbnN0RGVmLk1FU1NBR0UuRU5URVJfUk9PTV9SRVEsIGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgICAgUHJvdG9jb2xNZXNzYWdlLkFkZFZlY3RJdGVtSW50KG1zZy5fYm9keV9tc2csIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2Uuc2VsZkRhdGEubkFjY291bnRJRCk7XG4gICAgICAgICAgICAgICAgICAgIFByb3RvY29sTWVzc2FnZS5BZGRWZWN0SXRlbUludChtc2cuX2JvZHlfbXNnLCBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLnNlbGZEYXRhLm5Mb2dvblRTKTtcbiAgICAgICAgICAgICAgICAgICAgUHJvdG9jb2xNZXNzYWdlLkFkZFZlY3RJdGVtSW50KG1zZy5fYm9keV9tc2csIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2Uuc2VsZkRhdGEubkxvZ29uUmFuZCk7XG4gICAgICAgICAgICAgICAgICAgIFByb3RvY29sTWVzc2FnZS5BZGRWZWN0SXRlbVN0cmluZyhtc2cuX2JvZHlfbXNnLCBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLnNlbGZEYXRhLnNMb2dvbktleSk7XG4gICAgICAgICAgICAgICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuU2VuZEdhbWVNc2cobXNnKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSBnYW1lQ29uc3REZWYuQ09OTkVDVF9DQUxMQkFDS19TVEFUVVMuSE9NRV9MRUFWRV9URUFNOlxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIF9tc2czID0gbmV3IFByb3RvY29sTWVzc2FnZShjb25zdERlZi5NRVNTQUdFLkNNRF9NQUlOX0dBTUUsIGNvbnN0RGVmLk1FU1NBR0UuTEVBVkVfVEVBTV9SRVEsIGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5TZW5kR2FtZU1zZyhfbXNnMyk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn0pO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnNzZkNTZNSlc5ZExrWnVDOWRpazcxRWgnLCAnWWluZ3NhbnpoYW5nR2FtZURhdGEnKTtcbi8vIHJlc291cmNlcy9HYW1lcy9ZaW5nc2Fuemhhbmcvc3JjL1lpbmdzYW56aGFuZ0dhbWVEYXRhLmpzXG5cbnZhciBjb25zdERlZiA9IHJlcXVpcmUoXCJDb25zdERlZlwiKTtcbnZhciBQcm90b2NvbE1lc3NhZ2UgPSByZXF1aXJlKFwiUHJvdG9jb2xNZXNzYWdlXCIpO1xudmFyIEdsb2JhbE1hbmFnZXIgPSByZXF1aXJlKFwiR2xvYmFsTWFuYWdlclwiKTtcbnZhciBnYW1lQ29uc3REZWYgPSByZXF1aXJlKFwiWWluZ3NhbnpoYW5nQ29uc3REZWZcIik7XG5cbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuXG4gICAgICAgIGluc3RhbmNlR2xvYmFsOiBudWxsLFxuXG4gICAgICAgIG5HYW1lSUQ6IDEsXG4gICAgICAgIHJvb21zOiBbXSwgLy9pdGVtPXtuUm9vbUlEL29uTGluZUNvdW50fSxcbiAgICAgICAgLy8gLS0tLS0tLVvpmJ/kvI1dLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAgIG5UZWFtSUQ6IDAsXG4gICAgICAgIG5PcGVuTW9kZTogMCxcblxuICAgICAgICAvLyAtLS0tLS0tW+aImOaWl10tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgICAgbkJhdHRsZUlEOiAwLFxuICAgICAgICBuQmF0dGxlU3RhdHVzOiAwLCAvLzAg5Yid5aeL5YyWICAg5oiY5paX57uT5p2fICAgICAgMSDmiJjmlpfkuK1cbiAgICAgICAgbkJhdHRsZVN0YXR1c1RTOiAwLCAvL+aImOaWl+eKtuaAgeaXtumXtFxuXG4gICAgICAgIG5DbGllbnRTdGF0dXM6IDAsXG5cbiAgICAgICAgbkxlYXZlUm9vbUZsYWc6IDAsIC8vIDAg6KGo56S65Li75Yqo56a75byAICAxIOihqOekuuaIv+mXtOino+aVo1xuXG4gICAgICAgIC8vIC0tIOWPguaImOWkmuaWuemYn+S8jUlE5YiX6KGoXG4gICAgICAgIC8vIHZlY3RUZWFtTGlzdFxuICAgICAgICB2ZWN0VGVhbUxpc3Q6IFtdLCAvLyDlvZPliY3miJjmlpfpmJ/kvI0gaXRlbSA9IHtuVGVhbUlEfSAgICAgXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgPSB7bkNhcmRUeXBlfSAgIC8vIOeJjOexu+Wei1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgID0ge25Mb29rRmxhZ30gICAvLyDmmK/lkKbnnIvniYxcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICA9IHtuR2l2ZXVwRmxhZ30gICAvL+aYr+WQpuW8g+eJjFxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgID0ge25Ub3RhbE1vbmV5fSAgIC8v5oC76ZKx5pWwXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgPSB7cHVrZVswLDEsM119ICAgICAgLy/niYxcbiAgICAgICAgcHVrZTogW10sIC8v546p5a6255qE5b2T5YmN54mM77yMXG4gICAgICAgIG5BY2NvdW50SUQ6IDAsXG4gICAgICAgIG5CYXR0bGVJRDogMCxcbiAgICAgICAgbkxvZ2ljU3RhdHVzOiAwLCAvL+eKtuaAgVxuICAgICAgICBuTG9naWNUUzogMCwgLy8g5b2T5YmN54q25oCB5pe26Ze05oizXG4gICAgICAgIG5DdXJTaXQ6IDAsIC8vIOW9k+WJjeW6hOW6p+S9jeWPt1xuICAgICAgICBuQ3VyUmF0ZTogMCwgLy8g5b2T5YmN5bqV5rOoXG5cbiAgICAgICAgLy8tLS0tLS0tW+aIv+mXtCBnYW1lU2VydmVyXS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgICAgblJvb21JRDogMCxcbiAgICAgICAgLy8gLS0tLS0tLVtHQU1F55u45YWz5pWw5o2uXS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgICBuRmRpYW1vbmRIOiAwLFxuICAgICAgICBuRmRpYW1vbmRMOiAwLFxuICAgICAgICBuRmNvaW5IOiAwLFxuICAgICAgICBuRmNvaW5MOiAwLFxuICAgICAgICBuRmJlZ2lubmVyX2ZsYWc6IDEsXG5cbiAgICAgICAgLy8gLS0tLS0tLVvmr5TotZvnm7jlhbPmlbDmja5dLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAgIC8vIGhhc2hNYXRjaERhdGE6e30sICAgIC8vIGtleT1tYXRjaFRTICBkYXRhPXt9XG5cbiAgICAgICAgLy8gaGFzaE1hdGNoRGF0YVt0c10gPSB7fVxuXG4gICAgICAgIG5NYXRjaEN1clNpZ25Db3VudDogMCwgLy8g5q+U6LWb5b2T5YmN5oql5ZCN5Lq65pWwXG4gICAgICAgIG5NYXRjaFRTOiAwLCAvLyDmr5TotZvlvIDlp4vml7bpl7RcbiAgICAgICAgbk1hdGNoRmxhZzogMCxcbiAgICAgICAgbk1hdGNoU3RhdHVzOiAwLFxuICAgICAgICBuTWF0Y2hTdGF0dXNUUzogMCxcbiAgICAgICAgbk1hdGNoUmVtYWluQ291bnQ6IDAsXG4gICAgICAgIG5NYXRjaFJhbms6IDBcblxuICAgIH0sXG4gICAgLy8tLS0tLS0tLS0tLS0tLS1b5Li05pe25Y+Y6YePXS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7fSxcbiAgICAvLyAtLSDojrflj5boh6rlt7HnmoTluqfkvY3vvIzku44x5byA5aeL77ybMOihqOekuuS4jeWcqOaIv+mXtFxuICAgIEdldFNlbGZTaXQ6IGZ1bmN0aW9uIEdldFNlbGZTaXQoKSB7XG4gICAgICAgIGlmICh0aGlzLm5UZWFtSUQgPT09IDApIHJldHVybiAwO1xuICAgICAgICB2YXIgc2VsZkluZGV4ID0gMDtcbiAgICAgICAgZm9yIChzZWxmSW5kZXggPSAwOyBzZWxmSW5kZXggPCB0aGlzLnZlY3RUZWFtTGlzdC5sZW5ndGg7IHNlbGZJbmRleCsrKSB7XG4gICAgICAgICAgICBpZiAodGhpcy52ZWN0VGVhbUxpc3Rbc2VsZkluZGV4XS5uVGVhbUlEID09IHRoaXMublRlYW1JRCkgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHNlbGZJbmRleCA9PSB0aGlzLnZlY3RUZWFtTGlzdC5sZW5ndGgpIHJldHVybiAwO1xuICAgICAgICByZXR1cm4gc2VsZkluZGV4ICsgMTtcbiAgICB9LFxuICAgIENsZWFyT25lUGxheWVyRGF0YTogZnVuY3Rpb24gQ2xlYXJPbmVQbGF5ZXJEYXRhKHBvcykge1xuICAgICAgICB2YXIgaXRlbSA9IHRoaXMudmVjdFRlYW1MaXN0W3Bvc107XG4gICAgICAgIGl0ZW0ublRlYW1JRCA9IDA7XG4gICAgICAgIGl0ZW0ubkNhcmRUeXBlID0gLTE7IC8vIC0x6KGo56S65bCa5pyq5oqi5bqE77yMMOihqOekuuS4jeaKou+8jDF+NOihqOekuuaKouW6hOWAjeaVsFxuICAgICAgICBpdGVtLm5Mb29rRmxhZyA9IDA7XG4gICAgICAgIGl0ZW0ubkdpdmV1cEZsYWcgPSAyNTU7XG4gICAgICAgIGl0ZW0ucHVrZSA9IFtdO1xuICAgICAgICBpdGVtLnB1a2UucHVzaCgwKTtcbiAgICAgICAgaXRlbS5wdWtlLnB1c2goMCk7XG4gICAgICAgIGl0ZW0ucHVrZS5wdXNoKDApO1xuICAgICAgICBpdGVtLm5SZXN1bHQgPSAwO1xuICAgICAgICBpdGVtLm5Ub3RhbE1vbmV5ID0gMDtcbiAgICAgICAgaXRlbS5uQWNjb3VudElEID0gMDtcbiAgICAgICAgaXRlbS5uU2l0ID0gMDtcbiAgICAgICAgaXRlbS5uaWNrID0gXCJcIjtcbiAgICAgICAgaXRlbS5zZXggPSAwO1xuICAgICAgICBpdGVtLmhlYWQgPSAwO1xuICAgICAgICBpdGVtLmN1c3RvbUhlYWQgPSBudWxsO1xuICAgICAgICBpdGVtLmNvaW5IID0gMDtcbiAgICAgICAgaXRlbS5jb2luTCA9IDA7XG4gICAgICAgIGl0ZW0uaXNPZmZsaW5lID0gMDtcbiAgICB9LFxuICAgIENsZWFyQmF0dGxlRGF0YTogZnVuY3Rpb24gQ2xlYXJCYXR0bGVEYXRhKGJTdGF5SW5HYW1lKSB7XG4gICAgICAgIGlmIChiU3RheUluR2FtZSAhPT0gdHJ1ZSkgYlN0YXlJbkdhbWUgPSBmYWxzZTtcblxuICAgICAgICB0aGlzLm5DdXJCYW5rZXIgPSAwO1xuXG4gICAgICAgIGlmIChiU3RheUluR2FtZSA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCA1OyBpKyspIHtcbiAgICAgICAgICAgICAgICB2YXIgaXRlbSA9IHRoaXMudmVjdFRlYW1MaXN0W2ldO1xuICAgICAgICAgICAgICAgIGl0ZW0ublRlYW1JRCA9IDA7XG4gICAgICAgICAgICAgICAgaXRlbS5uQ2FyZFR5cGUgPSAwO1xuICAgICAgICAgICAgICAgIGl0ZW0ubkxvb2tGbGFnID0gMDtcbiAgICAgICAgICAgICAgICBpdGVtLm5HaXZldXBGbGFnID0gMDtcbiAgICAgICAgICAgICAgICBpdGVtLm5Ub3RhbE1vbmV5ID0gMDtcbiAgICAgICAgICAgICAgICBpdGVtLm5BY2NvdW50SUQgPSAwO1xuICAgICAgICAgICAgICAgIGl0ZW0ublNpdCA9IDA7XG4gICAgICAgICAgICAgICAgaXRlbS5wdWtlID0gW107XG4gICAgICAgICAgICAgICAgaXRlbS5wdWtlLnB1c2goMCk7XG4gICAgICAgICAgICAgICAgaXRlbS5wdWtlLnB1c2goMCk7XG4gICAgICAgICAgICAgICAgaXRlbS5wdWtlLnB1c2goMCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLm5DbGllbnRTdGF0dXMgPSAwO1xuICAgICAgICAgICAgdGhpcy5DbGllbnRTdGF0dXNQYXJhbSA9IFtdO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5uQmF0dGxlSUQgPSAwO1xuICAgICAgICAgICAgdGhpcy5uQmF0dGxlU3RhdHVzID0gMDtcbiAgICAgICAgICAgIHRoaXMubkJhdHRsZVN0YXR1c1RTID0gMDtcblxuICAgICAgICAgICAgdGhpcy52ZWN0VGVhbUxpc3QgPSBbXTtcbiAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgNTsgaSsrKSB7XG4gICAgICAgICAgICAgICAgdmFyIGl0ZW0gPSB7fTtcbiAgICAgICAgICAgICAgICBpdGVtLm5UZWFtSUQgPSAwO1xuICAgICAgICAgICAgICAgIGl0ZW0ubkNhcmRUeXBlID0gMDtcbiAgICAgICAgICAgICAgICBpdGVtLm5Mb29rRmxhZyA9IDA7XG4gICAgICAgICAgICAgICAgaXRlbS5uR2l2ZXVwRmxhZyA9IDA7XG4gICAgICAgICAgICAgICAgaXRlbS5uVG90YWxNb25leSA9IDA7XG4gICAgICAgICAgICAgICAgaXRlbS5uQWNjb3VudElEID0gMDtcbiAgICAgICAgICAgICAgICBpdGVtLnB1a2UgPSBbXTtcbiAgICAgICAgICAgICAgICBpdGVtLnB1a2UucHVzaCgwKTtcbiAgICAgICAgICAgICAgICBpdGVtLnB1a2UucHVzaCgwKTtcbiAgICAgICAgICAgICAgICBpdGVtLnB1a2UucHVzaCgwKTtcbiAgICAgICAgICAgICAgICBpdGVtLm5SZXN1bHQgPSAwO1xuICAgICAgICAgICAgICAgIGl0ZW0ubkFjY291bnRJRCA9IDA7XG4gICAgICAgICAgICAgICAgaXRlbS5uaWNrID0gXCJcIjtcbiAgICAgICAgICAgICAgICBpdGVtLnNleCA9IDA7XG4gICAgICAgICAgICAgICAgaXRlbS5oZWFkID0gMDtcbiAgICAgICAgICAgICAgICBpdGVtLmN1c3RvbUhlYWQgPSBudWxsO1xuICAgICAgICAgICAgICAgIGl0ZW0uY29pbkggPSAwO1xuICAgICAgICAgICAgICAgIGl0ZW0uY29pbkwgPSAwO1xuICAgICAgICAgICAgICAgIHRoaXMudmVjdFRlYW1MaXN0LnB1c2goaXRlbSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLm5DbGllbnRTdGF0dXMgPSAwO1xuICAgICAgICAgICAgdGhpcy5DbGllbnRTdGF0dXNQYXJhbSA9IFtdO1xuICAgICAgICB9XG4gICAgfSxcblxuICAgIEluaXRCYXR0bGVEYXRhOiBmdW5jdGlvbiBJbml0QmF0dGxlRGF0YShib2R5TXNnKSB7XG4gICAgICAgIHZhciBpbmRleCA9IDA7XG4gICAgICAgIHRoaXMubkFjY291bnRJRCA9IGJvZHlNc2dbaW5kZXgrK10uX2ludF92YWx1ZTtcbiAgICAgICAgdGhpcy5uQmF0dGxlSUQgPSBib2R5TXNnW2luZGV4KytdLl9pbnRfdmFsdWU7XG4gICAgICAgIHRoaXMubkxvZ2ljU3RhdHVzID0gYm9keU1zZ1tpbmRleCsrXS5faW50X3ZhbHVlO1xuICAgICAgICB0aGlzLm5Mb2dpY1RTID0gYm9keU1zZ1tpbmRleCsrXS5faW50X3ZhbHVlO1xuXG4gICAgICAgIHRoaXMubkN1clNpdCA9IGJvZHlNc2dbaW5kZXgrK10uX2ludF92YWx1ZTtcbiAgICAgICAgdGhpcy5uQ3VyUmF0ZSA9IGJvZHlNc2dbaW5kZXgrK10uX2ludF92YWx1ZTtcblxuICAgICAgICB2YXIgdmVjdExpc3QgPSBib2R5TXNnW2luZGV4KytdLl92ZWN0X3ZhbHVlO1xuICAgICAgICB2YXIgaXRlbUNvdW50ID0gODtcbiAgICAgICAgdmFyIGNvdW50ID0gdmVjdExpc3QubGVuZ3RoIC8gaXRlbUNvdW50O1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGNvdW50OyBpKyspIHtcbiAgICAgICAgICAgIHZhciBpbmRleDEgPSAwO1xuICAgICAgICAgICAgdmFyIGl0ZW0gPSB0aGlzLnZlY3RUZWFtTGlzdFtpXTtcbiAgICAgICAgICAgIGl0ZW0ublRlYW1JRCA9IHZlY3RMaXN0W2kgKiBpdGVtQ291bnQgKyBpbmRleDErK10uX2ludF92YWx1ZTtcbiAgICAgICAgICAgIGl0ZW0ubkNhcmRUeXBlID0gdmVjdExpc3RbaSAqIGl0ZW1Db3VudCArIGluZGV4MSsrXS5faW50X3ZhbHVlIC0gMTtcbiAgICAgICAgICAgIGl0ZW0ubkxvb2tGbGFnID0gdmVjdExpc3RbaSAqIGl0ZW1Db3VudCArIGluZGV4MSsrXS5faW50X3ZhbHVlO1xuICAgICAgICAgICAgaXRlbS5uR2l2ZXVwRmxhZyA9IHZlY3RMaXN0W2kgKiBpdGVtQ291bnQgKyBpbmRleDErK10uX2ludF92YWx1ZTtcbiAgICAgICAgICAgIGl0ZW0ublRvdGFsTW9uZXkgPSB2ZWN0TGlzdFtpICogaXRlbUNvdW50ICsgaW5kZXgxKytdLl9pbnRfdmFsdWU7XG4gICAgICAgICAgICBpdGVtLnB1a2VbMF0gPSB2ZWN0TGlzdFtpICogaXRlbUNvdW50ICsgaW5kZXgxKytdLl9pbnRfdmFsdWU7XG4gICAgICAgICAgICBpdGVtLnB1a2VbMV0gPSB2ZWN0TGlzdFtpICogaXRlbUNvdW50ICsgaW5kZXgxKytdLl9pbnRfdmFsdWU7XG4gICAgICAgICAgICBpdGVtLnB1a2VbMl0gPSB2ZWN0TGlzdFtpICogaXRlbUNvdW50ICsgaW5kZXgxKytdLl9pbnRfdmFsdWU7XG4gICAgICAgIH1cblxuICAgICAgICAvL+iOt+WPlumYn+S8jeaIkOWRmOi0puWPt0lEXG4gICAgICAgIHZhciBtc2cgPSBuZXcgUHJvdG9jb2xNZXNzYWdlKGNvbnN0RGVmLk1FU1NBR0UuQ01EX01BSU5fR0FNRSwgY29uc3REZWYuTUVTU0FHRS5HRVRfVEVBTV9NRU1CRVJTX1JFUSwgZmFsc2UpO1xuICAgICAgICB2YXIgdmVjdEluZGV4ID0gMDtcbiAgICAgICAgUHJvdG9jb2xNZXNzYWdlLkFkZFZlY3RJdGVtVmVjdChtc2cuX2JvZHlfbXNnKTtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB0aGlzLnZlY3RUZWFtTGlzdC5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgaWYgKHRoaXMudmVjdFRlYW1MaXN0W2ldLm5UZWFtSUQgPiAwKSB7XG4gICAgICAgICAgICAgICAgUHJvdG9jb2xNZXNzYWdlLkFkZFZlY3RJdGVtSW50KG1zZy5fYm9keV9tc2dbdmVjdEluZGV4XS5fdmVjdF92YWx1ZSwgdGhpcy52ZWN0VGVhbUxpc3RbaV0ublRlYW1JRCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5Tb2NrZXRNYW5hZ2VyLlNlbmRNZXNzYWdlKGNvbnN0RGVmLlNFUlZFUl9VUkwuZ2FtZSwgbXNnKTtcbiAgICB9LFxuICAgIENsZWFyTWF0Y2hEYXRhOiBmdW5jdGlvbiBDbGVhck1hdGNoRGF0YSgpIHtcbiAgICAgICAgdGhpcy5uTWF0Y2hDdXJTaWduQ291bnQgPSAwO1xuICAgICAgICB0aGlzLm5NYXRjaFRTID0gMDtcbiAgICAgICAgdGhpcy5uTWF0Y2hGbGFnID0gMDtcbiAgICAgICAgdGhpcy5uTWF0Y2hTdGF0dXMgPSAwO1xuICAgICAgICB0aGlzLm5NYXRjaFN0YXR1c1RTID0gMDtcbiAgICAgICAgdGhpcy5uTWF0Y2hSZW1haW5Db3VudCA9IDA7XG4gICAgICAgIHRoaXMubk1hdGNoUmFuayA9IDA7XG4gICAgfSxcbiAgICBSZWZyZXNoRGF0YTogZnVuY3Rpb24gUmVmcmVzaERhdGEobkRhdGFUeXBlKSB7XG4gICAgICAgIGlmIChuRGF0YVR5cGUgPT09IG51bGwpIG5EYXRhVHlwZSA9IDA7XG4gICAgICAgIGlmICh0eXBlb2YgbkRhdGFUeXBlID09IFwidW5kZWZpbmVkXCIpIG5EYXRhVHlwZSA9IDA7XG5cbiAgICAgICAgdmFyIGN1clNjZW5lID0gY2MuZGlyZWN0b3IuZ2V0U2NlbmUoKTtcbiAgICAgICAgdmFyIENhbnZhcyA9IGN1clNjZW5lLmdldENoaWxkQnlOYW1lKFwiQ2FudmFzXCIpO1xuICAgICAgICB2YXIgV2FyVUkgPSBDYW52YXMuZ2V0Q29tcG9uZW50KFwiWWluZ3NhbnpoYW5nX1dhclVJXCIpO1xuICAgICAgICBpZiAoV2FyVUkpIHtcbiAgICAgICAgICAgIGlmIChuRGF0YVR5cGUgPT0gMCkgV2FyVUkuUmVmcmVzaFVJKCk7ZWxzZSBpZiAobkRhdGFUeXBlID09IDEpIFdhclVJLlJlZnJlc2hFbmRVSSgpO1xuICAgICAgICB9XG4gICAgfSxcbiAgICBSZWZyZXNoUGxheWVyRGF0YTogZnVuY3Rpb24gUmVmcmVzaFBsYXllckRhdGEobkRhdGFUeXBlKSB7XG4gICAgICAgIC8vIC0tIDAgOiDlhajpg6jliLfmlrBcbiAgICAgICAgLy8gLS0gMSA6IOWPquWIt+aWsOeOqeWutuWfuuacrOaVsOaNrlxuICAgICAgICAvLyAtLSAyIDog5LiN5Yi35paw54mM55qE5pWw55uuXG4gICAgICAgIC8vIC0tIDMgOiDkuI3liLfmlrDniYxcblxuICAgICAgICBpZiAobkRhdGFUeXBlID09PSBudWxsKSBuRGF0YVR5cGUgPSAwO1xuICAgICAgICBpZiAodHlwZW9mIG5EYXRhVHlwZSA9PSBcInVuZGVmaW5lZFwiKSBuRGF0YVR5cGUgPSAwO1xuXG4gICAgICAgIHZhciBjdXJTY2VuZSA9IGNjLmRpcmVjdG9yLmdldFNjZW5lKCk7XG4gICAgICAgIHZhciBDYW52YXMgPSBjdXJTY2VuZS5nZXRDaGlsZEJ5TmFtZShcIkNhbnZhc1wiKTtcbiAgICAgICAgdmFyIFdhclVJID0gQ2FudmFzLmdldENvbXBvbmVudChcIllpbmdzYW56aGFuZ19XYXJVSVwiKTtcbiAgICAgICAgaWYgKFdhclVJKSB7XG4gICAgICAgICAgICBXYXJVSS5SZWZyZXNoUGxheWVyRGF0YShuRGF0YVR5cGUpO1xuICAgICAgICB9XG4gICAgfSxcblxuICAgIFJlZnJlc2hHYW1lV2FpdDogZnVuY3Rpb24gUmVmcmVzaEdhbWVXYWl0KCkge1xuICAgICAgICB2YXIgY3VyU2NlbmUgPSBjYy5kaXJlY3Rvci5nZXRTY2VuZSgpO1xuICAgICAgICB2YXIgQ2FudmFzID0gY3VyU2NlbmUuZ2V0Q2hpbGRCeU5hbWUoXCJDYW52YXNcIik7XG4gICAgICAgIHZhciBtYXRjaFdhaXRQYW5lbCA9IENhbnZhcy5nZXRDaGlsZEJ5TmFtZShcIndhaXRQYW5lbFwiKTtcbiAgICAgICAgaWYgKG1hdGNoV2FpdFBhbmVsKSB7XG4gICAgICAgICAgICBtYXRjaFdhaXRQYW5lbC5nZXRDb21wb25lbnQoXCJ3YWl0XCIpLlJlZnJlc2hVSSgpO1xuICAgICAgICB9XG4gICAgfSxcblxuICAgIGluaXRDdXJHYW1lUmVtYWluQ291bnQ6IGZ1bmN0aW9uIGluaXRDdXJHYW1lUmVtYWluQ291bnQoKSAvLyDorqHnrpflvZPliY3ov5nlsYDmr5TotZvkurrmlbAgICAg5LiN6ZyA6KaB6ICD6JmR5omT56uL5Ye65bGAXG4gICAge1xuICAgICAgICB2YXIgY3VyTm9kZUJhc2VJbmZvID0gdGhpcy5nZXRDdXJOb2RlQmFzZUluZm8oKTtcbiAgICAgICAgc3dpdGNoICh0aGlzLm5NYXRjaFN0YXR1cykge1xuICAgICAgICAgICAgY2FzZSBjb25zdERlZi5NQVRDSF9TVEFUVVMuSU5JVDpcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMubk1hdGNoUmVtYWluQ291bnQgPSB0aGlzLm5NYXRjaEN1clNpZ25Db3VudDtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSBjb25zdERlZi5NQVRDSF9TVEFUVVMuUEhBU0VfMV9CRUdJTjpcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChjdXJOb2RlQmFzZUluZm8uRnBoYXNlXzFfbW9kZSA9PSBjb25zdERlZi5NQVRDSF9NT0RFLkZJWEVEX1JPVU5EKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgcm91bmRzID0gY3VyTm9kZUJhc2VJbmZvLkZwaGFzZV8xX3BhcmFtMy5zdWJzdHIoMCwgY3VyTm9kZUJhc2VJbmZvLkZwaGFzZV8xX3BhcmFtMy5sZW5ndGggLSAxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBwZXJSb3VuZFBlcnNvbkFyciA9IHJvdW5kcy5zcGxpdChcIjtcIik7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5uTWF0Y2hSZW1haW5Db3VudCA9PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5uTWF0Y2hSZW1haW5Db3VudCA9IHBlclJvdW5kUGVyc29uQXJyWzBdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMTsgaSA8IHBlclJvdW5kUGVyc29uQXJyLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHBlclJvdW5kUGVyc29uQXJyW2kgLSAxXSA9PSB0aGlzLm5NYXRjaFJlbWFpbkNvdW50KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubk1hdGNoUmVtYWluQ291bnQgPSBwZXJSb3VuZFBlcnNvbkFycltpXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKGN1ck5vZGVCYXNlSW5mby5GcGhhc2VfMV9tb2RlID09IGNvbnN0RGVmLk1BVENIX01PREUuT1VUX0FUX09OQ0UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLm5NYXRjaFJlbWFpbkNvdW50ID09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm5NYXRjaFJlbWFpbkNvdW50ID0gdGhpcy5uTWF0Y2hDdXJTaWduQ291bnQ7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSBjb25zdERlZi5NQVRDSF9TVEFUVVMuUEhBU0VfMl9CRUdJTjpcbiAgICAgICAgICAgICAgICB7XG5cbiAgICAgICAgICAgICAgICAgICAgaWYgKGN1ck5vZGVCYXNlSW5mby5GcGhhc2VfMl9tb2RlID09IGNvbnN0RGVmLk1BVENIX01PREUuRklYRURfUk9VTkQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciByb3VuZHMgPSBjdXJOb2RlQmFzZUluZm8uRnBoYXNlXzJfcGFyYW0zLnN1YnN0cigwLCBjdXJOb2RlQmFzZUluZm8uRnBoYXNlXzJfcGFyYW0zLmxlbmd0aCAtIDEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHBlclJvdW5kUGVyc29uQXJyID0gcm91bmRzLnNwbGl0KFwiO1wiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgcGVyUm91bmRQZXJzb25BcnIubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocGVyUm91bmRQZXJzb25BcnJbaSAtIDFdID09IHRoaXMubk1hdGNoUmVtYWluQ291bnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5uTWF0Y2hSZW1haW5Db3VudCA9IHBlclJvdW5kUGVyc29uQXJyW2ldO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoY3VyTm9kZUJhc2VJbmZvLkZwaGFzZV8yX21vZGUgPT0gY29uc3REZWYuTUFUQ0hfTU9ERS5PVVRfQVRfT05DRSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMubk1hdGNoUmVtYWluQ291bnQgPT0gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubk1hdGNoUmVtYWluQ291bnQgPSB0aGlzLm5NYXRjaEN1clNpZ25Db3VudDtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9LFxuICAgIGdldEN1ck5vZGVCYXNlSW5mbzogZnVuY3Rpb24gZ2V0Q3VyTm9kZUJhc2VJbmZvKCkge1xuICAgICAgICB2YXIgZ2FtZURhdGEgPSBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLkdldEdhbWVEYXRhKEdsb2JhbE1hbmFnZXIuaW5zdGFuY2Uuc2VsZkRhdGEubkN1ckdhbWVJRCk7XG4gICAgICAgIHZhciByb29tQXJlYSA9IEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuY29uZkRhdGEuZ2V0Um9vbUFyZWEoR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5zZWxmRGF0YS5uQ3VyR2FtZUlELCAyKTsgLy8gMuihqOekuuavlOi1m1xuICAgICAgICB2YXIgbm9kZUJhc2VpbmZvcyA9IEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuY29uZkRhdGEuZ2V0R2FtZU5vZGUocm9vbUFyZWEuRmFyZWFfaWQpO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IG5vZGVCYXNlaW5mb3MubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIHZhciByb29tID0gR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5jb25mRGF0YS5nZXRHYW1lUm9vbShub2RlQmFzZWluZm9zW2ldLkZub2RlX2lkKTtcbiAgICAgICAgICAgIGlmIChyb29tLkZyb29tX2lkID09IGdhbWVEYXRhLm5Sb29tSUQpIHtcbiAgICAgICAgICAgICAgICB2YXIgY3VyTm9kZUJhc2VJbmZvID0gbm9kZUJhc2VpbmZvc1tpXTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gY3VyTm9kZUJhc2VJbmZvO1xuICAgIH0sXG4gICAgLy8g5LuO5aSn5Yiw5bCP5o6S5bqPXG4gICAgT3JkZXJQdWtlOiBmdW5jdGlvbiBPcmRlclB1a2UoYXJyKSB7XG4gICAgICAgIHZhciB0ZW1wQXJyID0gW107XG4gICAgICAgIC8vIOWkp+eOi1xuICAgICAgICBmb3IgKHZhciB0ID0gMDsgdCA8IGFyci5sZW5ndGg7IHQrKykge1xuICAgICAgICAgICAgdmFyIGNhcmRWYWx1ZSA9IGFyclt0XTtcbiAgICAgICAgICAgIGlmIChjYXJkVmFsdWUgPT0gOTUpIHtcbiAgICAgICAgICAgICAgICB0ZW1wQXJyLnB1c2goY2FyZFZhbHVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAvLyDlsI/njotcbiAgICAgICAgZm9yICh2YXIgdCA9IDA7IHQgPCBhcnIubGVuZ3RoOyB0KyspIHtcbiAgICAgICAgICAgIHZhciBjYXJkVmFsdWUgPSBhcnJbdF07XG4gICAgICAgICAgICBpZiAoY2FyZFZhbHVlID09IDk0KSB7XG4gICAgICAgICAgICAgICAgdGVtcEFyci5wdXNoKGNhcmRWYWx1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyAx44CBMlxuICAgICAgICBmb3IgKHZhciBpID0gMjsgaSA+IDA7IGktLSkge1xuICAgICAgICAgICAgZm9yICh2YXIgdCA9IDA7IHQgPCBhcnIubGVuZ3RoOyB0KyspIHtcbiAgICAgICAgICAgICAgICB2YXIgY2FyZFZhbHVlID0gYXJyW3RdO1xuICAgICAgICAgICAgICAgIHZhciBMb3dWYWx1ZSA9IGNhcmRWYWx1ZSAmIDB4MGY7XG4gICAgICAgICAgICAgICAgaWYgKExvd1ZhbHVlID09IGkpIHtcbiAgICAgICAgICAgICAgICAgICAgdGVtcEFyci5wdXNoKGNhcmRWYWx1ZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC8vIDMtUVxuICAgICAgICBmb3IgKHZhciBpID0gMTM7IGkgPiAyOyBpLS0pIHtcbiAgICAgICAgICAgIGZvciAodmFyIHQgPSAwOyB0IDwgYXJyLmxlbmd0aDsgdCsrKSB7XG4gICAgICAgICAgICAgICAgdmFyIGNhcmRWYWx1ZSA9IGFyclt0XTtcbiAgICAgICAgICAgICAgICB2YXIgTG93VmFsdWUgPSBjYXJkVmFsdWUgJiAweDBmO1xuICAgICAgICAgICAgICAgIGlmIChMb3dWYWx1ZSA9PSBpKSB7XG4gICAgICAgICAgICAgICAgICAgIHRlbXBBcnIucHVzaChjYXJkVmFsdWUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGVtcEFycjtcbiAgICB9LFxuICAgIEdldENhcmRWYWw6IGZ1bmN0aW9uIEdldENhcmRWYWwoY2FyZCkge1xuICAgICAgICByZXR1cm4gY2FyZCAmIDB4MEY7XG4gICAgfSxcblxuICAgIEdldENhcmRDb21tb25WYWw6IGZ1bmN0aW9uIEdldENhcmRDb21tb25WYWwoY2FyZCkge1xuICAgICAgICBpZiAoY2FyZCA9PSAwKSByZXR1cm4gMDtcbiAgICAgICAgdmFyIHZhbCA9IHRoaXMuR2V0Q2FyZFZhbChjYXJkKTtcbiAgICAgICAgaWYgKHZhbCA8PSAyKSB2YWwgKz0gMTE7ZWxzZSBpZiAodmFsIDw9IDEzKSB2YWwgLT0gMjtcbiAgICAgICAgcmV0dXJuIHZhbDtcbiAgICB9LFxuXG4gICAgLy8g5Ye654mM6KeE5YiZ5qOA5p+lXG4gICAgQ2hlY2tDYXJkc1ZhbGlkOiBmdW5jdGlvbiBDaGVja0NhcmRzVmFsaWQoY2FyZHMpIHtcbiAgICAgICAgdmFyIGNvdW50ID0gY2FyZHMubGVuZ3RoO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGNvdW50OyBpKyspIHtcbiAgICAgICAgICAgIGlmIChjYXJkc1tpXSA8IDB4MTEpIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgaWYgKGNhcmRzW2ldID4gMHgxRCAmJiBjYXJkc1tpXSA8IDB4MjEpIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgaWYgKGNhcmRzW2ldID4gMHgyRCAmJiBjYXJkc1tpXSA8IDB4MzEpIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgaWYgKGNhcmRzW2ldID4gMHgzRCAmJiBjYXJkc1tpXSA8IDB4NDEpIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgaWYgKGNhcmRzW2ldID4gMHg0RCAmJiBjYXJkc1tpXSA8IDB4NUUpIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgaWYgKGNhcmRzW2ldID4gMHg1RikgcmV0dXJuIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLk5PTkU7XG4gICAgICAgIH1cblxuICAgICAgICB2YXIgbmV3Q2FyZHMgPSB0aGlzLk9yZGVyUHVrZShjYXJkcyk7XG5cbiAgICAgICAgaWYgKGNvdW50ID09IDApIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICBpZiAoY291bnQgPT0gMSkgcmV0dXJuIChnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5UWVBFX1ggPDwgMTYpICsgbmV3Q2FyZHNbMF07XG4gICAgICAgIGlmIChjb3VudCA9PSAyKSB7XG4gICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzBdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMV0pKSByZXR1cm4gKGdhbWVDb25zdERlZi5DQVJEU19UWVBFLlRZUEVfWFggPDwgMTYpICsgbmV3Q2FyZHNbMF07ZWxzZSBpZiAobmV3Q2FyZHNbMF0gPT0gMHg1RiAmJiBuZXdDYXJkc1sxXSA9PSAweDVFKSByZXR1cm4gZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuUk9DS0VUIDw8IDE2O2Vsc2UgcmV0dXJuIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLk5PTkU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNvdW50ID09IDMpIHtcbiAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMF0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzFdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMl0pKSByZXR1cm4gKGdhbWVDb25zdERlZi5DQVJEU19UWVBFLlRZUEVfWFhYIDw8IDE2KSArIG5ld0NhcmRzWzBdO2Vsc2UgcmV0dXJuIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLk5PTkU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNvdW50ID09IDQpIHtcbiAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMF0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzFdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMl0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1syXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzNdKSkgcmV0dXJuIChnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5CT01CIDw8IDE2KSArIG5ld0NhcmRzWzBdO2Vsc2Uge1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMF0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzFdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMl0pKSByZXR1cm4gKGdhbWVDb25zdERlZi5DQVJEU19UWVBFLlBMQU5FX1NfMSA8PCAxNikgKyBuZXdDYXJkc1sxXTtlbHNlIGlmICh0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMV0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1syXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzJdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbM10pKSByZXR1cm4gKGdhbWVDb25zdERlZi5DQVJEU19UWVBFLlBMQU5FX1NfMSA8PCAxNikgKyBuZXdDYXJkc1syXTtlbHNlIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGNvdW50ID09IDUpIHtcbiAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMF0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzFdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMl0pKSB7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1szXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzRdKSkgcmV0dXJuIChnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5QTEFORV9CXzEgPDwgMTYpICsgbmV3Q2FyZHNbMF07ZWxzZSByZXR1cm4gZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTk9ORTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAodGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzJdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbM10pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1szXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzRdKSkge1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMF0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxXSkpIHJldHVybiAoZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuUExBTkVfQl8xIDw8IDE2KSArIG5ld0NhcmRzWzJdO2Vsc2UgcmV0dXJuIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLk5PTkU7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMF0pID49IDEzKSByZXR1cm4gZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTk9ORTtcblxuICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1sxXSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1sxXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzJdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGNhcmRzWzJdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwoY2FyZHNbM10pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwoY2FyZHNbM10pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s0XSkgKyAxKSByZXR1cm4gKGdhbWVDb25zdERlZi5DQVJEU19UWVBFLlNIVU5aSV81IDw8IDE2KSArIG5ld0NhcmRzWzRdO2Vsc2UgcmV0dXJuIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLk5PTkU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoY291bnQgPT0gNikge1xuICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1swXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzFdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMV0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1syXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzJdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbM10pKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIChnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5TSElQX1MgPDwgMTYpICsgbmV3Q2FyZHNbMF07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzFdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMl0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1syXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzNdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbM10pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s0XSkpIHJldHVybiAoZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuU0hJUF9TIDw8IDE2KSArIG5ld0NhcmRzWzFdO1xuICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1syXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzNdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbM10pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s0XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzRdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNV0pKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIChnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5TSElQX1MgPDwgMTYpICsgbmV3Q2FyZHNbMl07XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMF0pID49IDEzKSByZXR1cm4gZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTk9ORTtcblxuICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1swXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzFdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMV0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1syXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzNdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNF0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s0XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzVdKSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMl0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1szXSkgKyAxKSByZXR1cm4gKGdhbWVDb25zdERlZi5DQVJEU19UWVBFLkxJQU5fU0hVTl8yIDw8IDE2KSArIG5ld0NhcmRzWzNdO1xuXG4gICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzBdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMV0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1syXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzNdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNF0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s1XSkgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzFdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMl0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbM10pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s0XSkgKyAxKSByZXR1cm4gKGdhbWVDb25zdERlZi5DQVJEU19UWVBFLkxJQU5fRFVJXzMgPDwgMTYpICsgbmV3Q2FyZHNbNV07XG5cbiAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1sxXSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1sxXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzJdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzJdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbM10pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbM10pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s0XSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s0XSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzVdKSArIDEpIHJldHVybiAoZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuU0hVTlpJXzYgPDwgMTYpICsgbmV3Q2FyZHNbNV07ZWxzZSByZXR1cm4gZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTk9ORTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChjb3VudCA9PSA3KSB7XG4gICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzBdKSA+PSAxMykgcmV0dXJuIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLk5PTkU7XG4gICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzBdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMV0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMV0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1syXSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1syXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzNdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzNdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbNF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbNF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s1XSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s1XSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzZdKSArIDEpIHJldHVybiAoZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuU0hVTlpJXzcgPDwgMTYpICsgbmV3Q2FyZHNbNl07ZWxzZSByZXR1cm4gZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTk9ORTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChjb3VudCA9PSA4KSB7XG4gICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzBdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMV0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzJdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMl0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1szXSkpIHtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzRdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNV0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s1XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzZdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNl0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s3XSkpIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNF0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s1XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzZdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbN10pKSByZXR1cm4gKGdhbWVDb25zdERlZi5DQVJEU19UWVBFLlNISVBfQiA8PCAxNikgKyBuZXdDYXJkc1swXTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTk9ORTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1syXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzNdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbM10pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s0XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzRdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNV0pKSB7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1swXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzFdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNl0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s3XSkpIHJldHVybiAoZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuU0hJUF9CIDw8IDE2KSArIG5ld0NhcmRzWzJdO1xuICAgICAgICAgICAgICAgIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s0XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzVdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNV0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s2XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzZdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbN10pKSB7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1swXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzFdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMl0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1szXSkpIHJldHVybiAoZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuU0hJUF9CIDw8IDE2KSArIG5ld0NhcmRzWzRdO1xuICAgICAgICAgICAgICAgIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzBdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMV0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzJdKSkge1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbM10pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s0XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzRdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNV0pKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMF0pID49IDEzKSByZXR1cm4gZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTk9ORTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s1XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzZdKSkgcmV0dXJuIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLk5PTkU7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMl0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1szXSkgKyAxKSByZXR1cm4gKGdhbWVDb25zdERlZi5DQVJEU19UWVBFLlBMQU5FX1NfMiA8PCAxNikgKyBuZXdDYXJkc1szXTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLk5PTkU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzJdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMl0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1szXSkpIHtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzBdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMV0pKSByZXR1cm4gZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTk9ORTtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzRdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNV0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s1XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzZdKSkge1xuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzFdKSA+PSAxMykgcmV0dXJuIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLk5PTkU7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNl0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s3XSkpIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzNdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbNF0pICsgMSkgcmV0dXJuIChnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5QTEFORV9TXzIgPDwgMTYpICsgbmV3Q2FyZHNbNF07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTk9ORTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1syXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzNdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbM10pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s0XSkpIHtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzVdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNl0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s2XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzddKSkge1xuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzJdKSA+PSAxMykgcmV0dXJuIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLk5PTkU7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMV0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1syXSkpIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzRdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbNV0pICsgMSkgcmV0dXJuIChnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5QTEFORV9TXzIgPDwgMTYpICsgbmV3Q2FyZHNbNV07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTk9ORTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1swXSkgPj0gMTMpIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1swXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzFdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMl0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1szXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzRdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNV0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s2XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzddKSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMV0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1syXSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1szXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzRdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzVdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbNl0pICsgMSkgcmV0dXJuIChnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5MSUFOX0RVSV80IDw8IDE2KSArIG5ld0NhcmRzWzZdO1xuXG4gICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzBdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMV0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMV0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1syXSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1syXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzNdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzNdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbNF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbNF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s1XSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s1XSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzZdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzZdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbN10pICsgMSkgcmV0dXJuIChnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5TSFVOWklfOCA8PCAxNikgKyBuZXdDYXJkc1s3XTtcbiAgICAgICAgICAgIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICB9XG4gICAgICAgIGlmIChjb3VudCA9PSA5KSB7XG4gICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzBdKSA+PSAxMykgcmV0dXJuIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLk5PTkU7XG5cbiAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMF0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzFdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMl0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1szXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzRdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNF0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s1XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzZdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbN10pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s3XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzhdKSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMl0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1szXSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s1XSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzZdKSArIDEpIHJldHVybiAoZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTElBTl9TSFVOXzMgPDwgMTYpICsgbmV3Q2FyZHNbNl07XG5cbiAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1sxXSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1sxXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzJdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzJdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbM10pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbM10pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s0XSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s0XSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzVdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzVdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbNl0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbNl0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s3XSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s3XSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzhdKSArIDEpIHJldHVybiAoZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuU0hVTlpJXzkgPDwgMTYpICsgbmV3Q2FyZHNbOF07XG5cbiAgICAgICAgICAgIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGNvdW50ID09IDEwKSB7XG4gICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzBdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMV0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzJdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbM10pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s0XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzRdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNV0pKSB7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1swXSkgPj0gMTMpIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMl0pICE9IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1szXSkgKyAxKSByZXR1cm4gZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTk9ORTtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzZdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbN10pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s4XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzldKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbOF0pICE9IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s3XSkpIHJldHVybiAoZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuUExBTkVfQl8yIDw8IDE2KSArIG5ld0NhcmRzWzNdO1xuICAgICAgICAgICAgICAgIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzJdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbM10pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1szXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzRdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNV0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s2XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzZdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbN10pKSB7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s0XSkgIT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzVdKSArIDEpIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMF0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzhdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbOV0pKSByZXR1cm4gKGdhbWVDb25zdERlZi5DQVJEU19UWVBFLlBMQU5FX0JfMiA8PCAxNikgKyBjYXJkc1s2XTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTk9ORTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s0XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzVdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNV0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s2XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzddKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbOF0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s4XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzldKSkge1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbNl0pICE9IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s3XSkgKyAxKSByZXR1cm4gZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTk9ORTtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzBdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMV0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1syXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzNdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMV0pICE9IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1syXSkpIHJldHVybiAoZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuUExBTkVfQl8yIDw8IDE2KSArIG5ld0NhcmRzWzddO1xuICAgICAgICAgICAgICAgIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzBdKSA+PSAxMykgcmV0dXJuIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLk5PTkU7XG5cbiAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMF0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzJdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbM10pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s0XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzVdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNl0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s3XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzhdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbOV0pICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1sxXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzJdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzNdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbNF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbNV0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s2XSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s3XSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzhdKSArIDEpIHJldHVybiAoZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTElBTl9EVUlfNSA8PCAxNikgKyBuZXdDYXJkc1s4XTtcblxuICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1swXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzFdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzFdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMl0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMl0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1szXSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1szXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzRdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzRdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbNV0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbNV0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s2XSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s2XSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzddKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzddKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbOF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbOF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s5XSkgKyAxKSByZXR1cm4gKGdhbWVDb25zdERlZi5DQVJEU19UWVBFLlNIVU5aSV8xMCA8PCAxNikgKyBuZXdDYXJkc1s5XTtcbiAgICAgICAgICAgIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGNvdW50ID09IDExKSB7XG4gICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzBdKSA+PSAxMykgcmV0dXJuIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLk5PTkU7XG4gICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzBdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMV0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMV0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1syXSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1syXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzNdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzNdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbNF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbNF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s1XSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s1XSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzZdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzZdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbN10pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbN10pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s4XSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s4XSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzldKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzldKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMTBdKSArIDEpIHJldHVybiAoZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuU0hVTlpJXzExIDw8IDE2KSArIG5ld0NhcmRzWzEwXTtcbiAgICAgICAgICAgIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGNvdW50ID09IDEyKSB7XG4gICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzBdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMV0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzJdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbM10pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s0XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzRdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNV0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s2XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzddKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbN10pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s4XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzldKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbOV0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxMF0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxMV0pKSB7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1syXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzNdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzVdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbNl0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbOF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s5XSkgKyAxKSByZXR1cm4gKGdhbWVDb25zdERlZi5DQVJEU19UWVBFLkxJQU5fU0hVTl80IDw8IDE2KSArIG5ld0NhcmRzWzldO1xuICAgICAgICAgICAgICAgIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzBdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMV0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzJdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbM10pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s0XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzRdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNV0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s2XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzddKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbN10pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s4XSkpIHtcbiAgICAgICAgICAgICAgICAvLyBpZiAoKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s5XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEwXSkpIHx8ICh0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTBdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTFdKSkpIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgICAgIC8vIGlmICh0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbOV0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s4XSkpIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMl0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1szXSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s1XSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzZdKSArIDEpIHJldHVybiAoZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuUExBTkVfU18zIDw8IDE2KSArIG5ld0NhcmRzWzZdO1xuICAgICAgICAgICAgICAgIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzldKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTBdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTBdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTFdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbM10pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s0XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzRdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNV0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s2XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzddKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbN10pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s4XSkpIHtcbiAgICAgICAgICAgICAgICAvLyBpZiAoKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1swXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzFdKSkgfHwgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzJdKSkpIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgICAgIC8vIGlmICh0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMl0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1szXSkpIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbNV0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s2XSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s4XSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzldKSArIDEpIHJldHVybiAoZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuUExBTkVfU18zIDw8IDE2KSArIGNhcmRzWzldO1xuICAgICAgICAgICAgICAgIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzFdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMl0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1syXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzNdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNF0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s1XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzVdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNl0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s3XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzhdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbOF0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s5XSkpIHtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEwXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzExXSkpIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMF0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxXSkpIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbOV0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxMF0pKSByZXR1cm4gZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTk9ORTtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzNdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbNF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbNl0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s3XSkgKyAxKSByZXR1cm4gKGdhbWVDb25zdERlZi5DQVJEU19UWVBFLlBMQU5FX1NfMyA8PCAxNikgKyBuZXdDYXJkc1s3XTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTk9ORTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1syXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzNdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbM10pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s0XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzVdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNl0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s2XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzddKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbOF0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s5XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzldKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTBdKSkge1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMF0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxXSkpIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMl0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxXSkpIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTBdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTFdKSkgcmV0dXJuIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLk5PTkU7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s0XSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzVdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzddKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbOF0pICsgMSkgcmV0dXJuIChnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5QTEFORV9TXzMgPDwgMTYpICsgbmV3Q2FyZHNbOF07XG4gICAgICAgICAgICAgICAgcmV0dXJuIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLk5PTkU7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMF0pID49IDEzKSByZXR1cm4gZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTk9ORTtcblxuICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1swXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzFdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMl0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1szXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEwXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzExXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzRdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNV0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s2XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzddKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbOF0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s5XSkgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzFdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMl0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbM10pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s0XSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s1XSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzZdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzddKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbOF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbOV0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1sxMF0pICsgMSkgcmV0dXJuIChnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5MSUFOX0RVSV82IDw8IDE2KSArIG5ld0NhcmRzWzEwXTtcblxuICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1swXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzFdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzFdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMl0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMl0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1szXSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1szXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzRdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzRdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbNV0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbNV0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s2XSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s2XSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzddKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzddKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbOF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbOF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s5XSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s5XSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzEwXSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1sxMF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1sxMV0pICsgMSkgcmV0dXJuIChnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5TSFVOWklfMTIgPDwgMTYpICsgbmV3Q2FyZHNbMTFdO1xuICAgICAgICAgICAgcmV0dXJuIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLk5PTkU7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoY291bnQgPT0gMTQpIHtcbiAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMF0pID49IDEzKSByZXR1cm4gZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTk9ORTtcblxuICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1swXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzFdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMl0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1szXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEwXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzExXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzRdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNV0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s2XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzddKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbOF0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s5XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEyXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEzXSkgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzFdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMl0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbM10pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s0XSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s1XSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzZdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzddKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbOF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbOV0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1sxMF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMTFdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMTJdKSArIDEpIHJldHVybiAoZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTElBTl9EVUlfNyA8PCAxNikgKyBuZXdDYXJkc1sxMl07XG4gICAgICAgICAgICByZXR1cm4gZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTk9ORTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChjb3VudCA9PSAxNSkge1xuICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1swXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzFdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMV0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1syXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzNdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNF0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s0XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzVdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNl0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s3XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzddKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbOF0pKSB7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s5XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEwXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzExXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEyXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEzXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzE0XSkpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1syXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzNdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzVdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbNl0pICsgMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxMF0pICE9IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxMV0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxMl0pICE9IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxM10pKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5QTEFORV9CXzMgPDwgMTYpICsgbmV3Q2FyZHNbNl07XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLk5PTkU7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMl0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1szXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzNdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNF0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s1XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzZdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNl0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s4XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzhdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbOV0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s5XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEwXSkpIHtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzBdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMV0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxMV0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxMl0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxM10pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxNF0pKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbNF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s1XSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s3XSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzhdKSArIDEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTJdKSAhPSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTNdKSkgcmV0dXJuIChnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5QTEFORV9CXzMgPDwgMTYpICsgbmV3Q2FyZHNbOF07XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLk5PTkU7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNF0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s1XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzVdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNl0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s3XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzhdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbOF0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s5XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEwXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzExXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzExXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEyXSkpIHtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzBdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMV0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1syXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzNdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTNdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTRdKSkge1xuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzZdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbN10pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbOV0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1sxMF0pICsgMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxXSkgIT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzJdKSkgcmV0dXJuIChnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5QTEFORV9CXzMgPDwgMTYpICsgY2FyZHNbMTBdO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzZdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbN10pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s3XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzhdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbOV0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxMF0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxMF0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxMV0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxMl0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxM10pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxM10pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxNF0pKSB7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1swXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzFdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMl0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1szXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzRdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNV0pKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbOF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s5XSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1sxMV0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1sxMl0pICsgMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxXSkgIT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzJdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbM10pICE9IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s0XSkpIHJldHVybiAoZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuUExBTkVfQl8zIDw8IDE2KSArIG5ld0NhcmRzWzEyXTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTk9ORTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1swXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzFdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMV0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1syXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzNdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNF0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s0XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzVdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNl0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s3XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzddKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbOF0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s5XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEwXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEwXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzExXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEyXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEzXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEzXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzE0XSkpIHtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzJdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbM10pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbNV0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s2XSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s4XSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzldKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzExXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzEyXSkgKyAxKSByZXR1cm4gKGdhbWVDb25zdERlZi5DQVJEU19UWVBFLkxJQU5fU0hVTl81IDw8IDE2KSArIG5ld0NhcmRzWzEyXTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTk9ORTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGNvdW50ID09IDE2KSB7XG4gICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzBdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMV0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzJdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbM10pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s0XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzRdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNV0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s2XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzddKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbN10pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s4XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzldKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTBdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTBdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTFdKSkge1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTJdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTNdKSB8fCB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTNdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTRdKSB8fCB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTRdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTVdKSkgcmV0dXJuIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLk5PTkU7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxMl0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxMV0pKSByZXR1cm4gZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTk9ORTtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzJdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbM10pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbNV0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s2XSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s4XSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzldKSArIDEpIHJldHVybiAoZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuUExBTkVfU180IDw8IDE2KSArIG5ld0NhcmRzWzldO1xuICAgICAgICAgICAgICAgIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzFdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMl0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1syXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzNdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNF0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s1XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzVdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNl0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s3XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzhdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbOF0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s5XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEwXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzExXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzExXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEyXSkpIHtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEzXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzE0XSkgfHwgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzE0XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzE1XSkpIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTJdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTNdKSkgcmV0dXJuIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLk5PTkU7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1swXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzFdKSkgcmV0dXJuIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLk5PTkU7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1szXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzRdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzZdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbN10pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbOV0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1sxMF0pICsgMSkgcmV0dXJuIChnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5QTEFORV9TXzQgPDwgMTYpICsgbmV3Q2FyZHNbMTBdO1xuICAgICAgICAgICAgICAgIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzJdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbM10pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1szXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzRdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNV0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s2XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzZdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbN10pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s4XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzldKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbOV0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxMF0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxMV0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxMl0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxMl0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxM10pKSB7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1swXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzFdKSB8fCB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTRdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTVdKSkgcmV0dXJuIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLk5PTkU7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzJdKSkgcmV0dXJuIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLk5PTkU7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxM10pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxNF0pKSByZXR1cm4gZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTk9ORTtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzRdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbNV0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbN10pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s4XSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1sxMF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1sxMV0pICsgMSkgcmV0dXJuIChnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5QTEFORV9TXzQgPDwgMTYpICsgbmV3Q2FyZHNbMTFdO1xuICAgICAgICAgICAgICAgIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzNdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNF0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s0XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzVdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNl0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s3XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzddKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbOF0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s5XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEwXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEwXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzExXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEyXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEzXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEzXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzE0XSkpIHtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzBdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMV0pIHx8IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzJdKSkgcmV0dXJuIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLk5PTkU7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1syXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzNdKSkgcmV0dXJuIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLk5PTkU7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxNF0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxNV0pKSByZXR1cm4gZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTk9ORTtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzVdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbNl0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbOF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s5XSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1sxMV0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1sxMl0pICsgMSkgcmV0dXJuIChnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5QTEFORV9TXzQgPDwgMTYpICsgbmV3Q2FyZHNbMTJdO1xuICAgICAgICAgICAgICAgIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzRdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNV0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s1XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzZdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbN10pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s4XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzhdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbOV0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxMF0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxMV0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxMV0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxMl0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxM10pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxNF0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxNF0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxNV0pKSB7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1szXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzRdKSkgcmV0dXJuIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLk5PTkU7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1swXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzFdKSB8fCB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMV0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1syXSkgfHwgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzJdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbM10pKSByZXR1cm4gZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTk9ORTtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzZdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbN10pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbOV0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1sxMF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMTJdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMTNdKSArIDEpIHJldHVybiAoZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuUExBTkVfU180IDw8IDE2KSArIG5ld0NhcmRzWzEzXTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTk9ORTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1swXSkgPj0gMTMpIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1swXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzFdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMl0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1szXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEwXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzExXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzRdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNV0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s2XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzddKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbOF0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s5XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEyXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEzXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzE0XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzE1XSkgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzFdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMl0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbM10pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s0XSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s1XSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzZdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzddKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbOF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbOV0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1sxMF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMTFdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMTJdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzEzXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzE0XSkgKyAxKSByZXR1cm4gKGdhbWVDb25zdERlZi5DQVJEU19UWVBFLkxJQU5fRFVJXzggPDwgMTYpICsgbmV3Q2FyZHNbMTRdO1xuICAgICAgICAgICAgcmV0dXJuIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLk5PTkU7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoY291bnQgPT0gMTgpIHtcbiAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMF0pID49IDEzKSByZXR1cm4gZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTk9ORTtcblxuICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1swXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzFdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMV0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1syXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzNdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNF0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s0XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzVdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNl0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s3XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzddKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbOF0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s5XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEwXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEwXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzExXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEyXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEzXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzEzXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzE0XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzE1XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzE2XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzE2XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzE3XSkpIHtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzJdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbM10pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbNV0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s2XSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s4XSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzldKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzExXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzEyXSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1sxNF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1sxNV0pICsgMSkgcmV0dXJuIChnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5MSUFOX1NIVU5fNiA8PCAxNikgKyBuZXdDYXJkc1sxNV07XG4gICAgICAgICAgICAgICAgcmV0dXJuIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLk5PTkU7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMF0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxXSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzJdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbM10pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxMF0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxMV0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s0XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzVdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNl0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s3XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzhdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbOV0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxMl0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxM10pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxNF0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxNV0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxNl0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1sxN10pICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1sxXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzJdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzNdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbNF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbNV0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s2XSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s3XSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzhdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzldKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMTBdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzExXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzEyXSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1sxM10pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1sxNF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMTVdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMTZdKSArIDEpIHJldHVybiAoZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTElBTl9EVUlfOSA8PCAxNikgKyBuZXdDYXJkc1sxNl07XG5cbiAgICAgICAgICAgIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGNvdW50ID09IDIwKSB7XG4gICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzBdKSA+PSAxMykgcmV0dXJuIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLk5PTkU7XG4gICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzBdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMV0pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1syXSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzNdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTBdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTFdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbNF0pID09IHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s1XSkgJiYgdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzZdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbN10pICYmIHRoaXMuR2V0Q2FyZFZhbChuZXdDYXJkc1s4XSkgPT0gdGhpcy5HZXRDYXJkVmFsKG5ld0NhcmRzWzldKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTJdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTNdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTRdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTVdKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTZdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTddKSAmJiB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMThdKSA9PSB0aGlzLkdldENhcmRWYWwobmV3Q2FyZHNbMTldKSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMV0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1syXSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1szXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzRdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzVdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbNl0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbN10pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s4XSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1s5XSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzEwXSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1sxMV0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1sxMl0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMTNdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwobmV3Q2FyZHNbMTRdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzE1XSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5ld0NhcmRzWzE2XSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1sxN10pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChuZXdDYXJkc1sxOF0pICsgMSkgcmV0dXJuIChnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5MSUFOX0RVSV8xMCA8PCAxNikgKyBuZXdDYXJkc1sxOF07XG5cbiAgICAgICAgICAgIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5OT05FO1xuICAgIH0sXG5cbiAgICBDYXJkc0NvbXBhcmU6IGZ1bmN0aW9uIENhcmRzQ29tcGFyZShwdWtlMSwgcHVrZTIpIHtcbiAgICAgICAgdmFyIG5UeXBlVmFsMSA9IHRoaXMuQ2hlY2tDYXJkc1ZhbGlkKHB1a2UxKTtcbiAgICAgICAgdmFyIG5UeXBlVmFsMiA9IHRoaXMuQ2hlY2tDYXJkc1ZhbGlkKHB1a2UyKTtcbiAgICAgICAgdmFyIG5UeXBlMSA9IG5UeXBlVmFsMSA+PiAxNjtcbiAgICAgICAgdmFyIG5UeXBlMiA9IG5UeXBlVmFsMiA+PiAxNjtcbiAgICAgICAgdmFyIG5WYWwxID0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKG5UeXBlVmFsMSAmIDB4RkYpO1xuICAgICAgICB2YXIgblZhbDIgPSB0aGlzLkdldENhcmRDb21tb25WYWwoblR5cGVWYWwyICYgMHhGRik7XG5cbiAgICAgICAgaWYgKG5UeXBlMSA9PSBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5ST0NLRVQpIHJldHVybiAxO1xuICAgICAgICBpZiAoblR5cGUyID09IGdhbWVDb25zdERlZi5DQVJEU19UWVBFLlJPQ0tFVCkgcmV0dXJuIC0xO1xuXG4gICAgICAgIGlmIChuVHlwZTEgPT0gZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuQk9NQiAmJiBuVHlwZTIgIT0gZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuQk9NQikgcmV0dXJuIDE7XG4gICAgICAgIGlmIChuVHlwZTEgIT0gZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuQk9NQiAmJiBuVHlwZTIgPT0gZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuQk9NQikgcmV0dXJuIC0xO1xuXG4gICAgICAgIGlmIChuVHlwZTEgIT0gblR5cGUyKSByZXR1cm4gMTtcblxuICAgICAgICBpZiAoblZhbDEgPiBuVmFsMikgcmV0dXJuIDE7XG4gICAgICAgIGlmIChuVmFsMSA8IG5WYWwyKSByZXR1cm4gLTE7XG5cbiAgICAgICAgcmV0dXJuIDA7XG4gICAgfSxcbiAgICBCZWF0Q2FyZHNDb2JtYmlsZXM6IGZ1bmN0aW9uIEJlYXRDYXJkc0NvYm1iaWxlcyhwdWtlMSwgcHVrZTIpIC8vIHB1a2UxIOW9k+WJjeWHuueahOeJjCAgICBwdWtlMiDmiYvkuK3miYDmnInniYxcbiAgICB7XG4gICAgICAgIGlmIChwdWtlMi5sZW5ndGggPT0gMCkgcmV0dXJuIDA7XG4gICAgICAgIHZhciBuVHlwZVZhbCA9IHRoaXMuQ2hlY2tDYXJkc1ZhbGlkKHB1a2UxKTtcbiAgICAgICAgdmFyIG5UeXBlID0gblR5cGVWYWwgPj4gMTY7XG5cbiAgICAgICAgdmFyIGNhbkJlYXRBcnIgPSBbXTtcbiAgICAgICAgaWYgKG5UeXBlID09IGdhbWVDb25zdERlZi5DQVJEU19UWVBFLlJPQ0tFVCkgcmV0dXJuIGNhbkJlYXRBcnI7XG5cbiAgICAgICAgdmFyIHB1a2UgPSB0aGlzLk9yZGVyUHVrZShwdWtlMik7XG4gICAgICAgIHZhciBjb21iaWxlcyA9IHRoaXMuR2V0Q2FyZHNDb21iaWxlKHB1a2UsIG5UeXBlKTtcblxuICAgICAgICBmb3IgKHZhciBpID0gY29tYmlsZXMubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcbiAgICAgICAgICAgIGlmICh0aGlzLkNhcmRzQ29tcGFyZShjb21iaWxlc1tpXSwgcHVrZTEpID09IDEpIHtcbiAgICAgICAgICAgICAgICBjYW5CZWF0QXJyLnB1c2goY29tYmlsZXNbaV0pO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoblR5cGUgIT0gZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuQk9NQikge1xuICAgICAgICAgICAgdmFyIGJvbWJDb21iaWxlcyA9IHRoaXMuR2V0Q2FyZHNDb21iaWxlKHB1a2UsIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLkJPTUIpO1xuICAgICAgICAgICAgZm9yICh2YXIgaiA9IDA7IGogPCBib21iQ29tYmlsZXMubGVuZ3RoOyBqKyspIHtcbiAgICAgICAgICAgICAgICBjYW5CZWF0QXJyLnB1c2goYm9tYkNvbWJpbGVzW2pdKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB2YXIgcm9ja2V0Q29tYmlsZXMgPSB0aGlzLkdldENhcmRzQ29tYmlsZShwdWtlLCBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5ST0NLRVQpO1xuICAgICAgICBpZiAocm9ja2V0Q29tYmlsZXMubGVuZ3RoID4gMCkgY2FuQmVhdEFyci5wdXNoKHJvY2tldENvbWJpbGVzWzBdKTtcbiAgICAgICAgcmV0dXJuIGNhbkJlYXRBcnI7XG4gICAgfSxcblxuICAgIEdldENhcmRzVHlwZVhYOiBmdW5jdGlvbiBHZXRDYXJkc1R5cGVYWChwdWtlKSB7XG4gICAgICAgIHZhciBhbGxYWCA9IFtdO1xuICAgICAgICBpZiAocHVrZS5sZW5ndGggPCAyKSByZXR1cm4gYWxsWFg7XG5cbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBwdWtlLmxlbmd0aCAtIDE7IGkrKykge1xuICAgICAgICAgICAgaWYgKGkgPiAwICYmIHRoaXMuR2V0Q2FyZFZhbChwdWtlW2kgLSAxXSkgPT0gdGhpcy5HZXRDYXJkVmFsKHB1a2VbaV0pKSBjb250aW51ZTtcbiAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwocHVrZVtpXSkgPT0gdGhpcy5HZXRDYXJkVmFsKHB1a2VbaSArIDFdKSkge1xuICAgICAgICAgICAgICAgIHZhciBpdGVtID0gW107XG4gICAgICAgICAgICAgICAgaXRlbS5wdXNoKHB1a2VbaV0pO1xuICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChwdWtlW2kgKyAxXSk7XG4gICAgICAgICAgICAgICAgYWxsWFgucHVzaChpdGVtKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYWxsWFg7XG4gICAgfSxcbiAgICBHZXRDYXJkc1R5cGVYWFg6IGZ1bmN0aW9uIEdldENhcmRzVHlwZVhYWChwdWtlKSB7XG4gICAgICAgIHZhciBhbGxYWFggPSBbXTtcbiAgICAgICAgaWYgKHB1a2UubGVuZ3RoIDwgMykgcmV0dXJuIGFsbFhYWDtcblxuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHB1a2UubGVuZ3RoIC0gMjsgaSsrKSB7XG4gICAgICAgICAgICBpZiAoaSA+IDAgJiYgdGhpcy5HZXRDYXJkVmFsKHB1a2VbaSAtIDFdKSA9PSB0aGlzLkdldENhcmRWYWwocHVrZVtpXSkpIGNvbnRpbnVlO1xuICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChwdWtlW2ldKSA9PSB0aGlzLkdldENhcmRWYWwocHVrZVtpICsgMl0pKSB7XG4gICAgICAgICAgICAgICAgdmFyIGl0ZW0gPSBbXTtcbiAgICAgICAgICAgICAgICBpdGVtLnB1c2gocHVrZVtpXSk7XG4gICAgICAgICAgICAgICAgaXRlbS5wdXNoKHB1a2VbaSArIDFdKTtcbiAgICAgICAgICAgICAgICBpdGVtLnB1c2gocHVrZVtpICsgMl0pO1xuICAgICAgICAgICAgICAgIGFsbFhYWC5wdXNoKGl0ZW0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBhbGxYWFg7XG4gICAgfSxcbiAgICBHZXRDYXJkc0NvbWJpbGU6IGZ1bmN0aW9uIEdldENhcmRzQ29tYmlsZShwdWtlLCB0eXBlKSB7XG4gICAgICAgIHZhciBwdWtlQ29tYmlsZSA9IFtdO1xuICAgICAgICBzd2l0Y2ggKHR5cGUpIHtcbiAgICAgICAgICAgIGNhc2UgZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuVFlQRV9YOlxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgayBpbiBwdWtlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgaXRlbSA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKHB1a2Vba10pO1xuICAgICAgICAgICAgICAgICAgICAgICAgcHVrZUNvbWJpbGUucHVzaChpdGVtKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLlRZUEVfWFg6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBpZiAocHVrZS5sZW5ndGggPCAyKSBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgcHVrZUNvbWJpbGUgPSB0aGlzLkdldENhcmRzVHlwZVhYKHB1a2UpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGNhc2UgZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuVFlQRV9YWFg6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBpZiAocHVrZS5sZW5ndGggPCAzKSBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgcHVrZUNvbWJpbGUgPSB0aGlzLkdldENhcmRzVHlwZVhYWChwdWtlKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5MSUFOX0RVSV8zOlxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHB1a2UubGVuZ3RoIDwgNikgYnJlYWs7XG5cbiAgICAgICAgICAgICAgICAgICAgdmFyIGFsbFhYID0gdGhpcy5HZXRDYXJkc1R5cGVYWChwdWtlKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGFsbFhYLmxlbmd0aCA8IDMpIGJyZWFrO1xuXG4gICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgYWxsWFgubGVuZ3RoIC0gMjsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYW2ldWzBdKSA+PSAxMykgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYW2ldWzBdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaSArIDFdWzBdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYW2kgKyAxXVswXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYW2kgKyAyXVswXSkgKyAxKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGl0ZW0gPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaV1bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFtpXVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2kgKyAxXVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2kgKyAxXVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2kgKyAyXVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2kgKyAyXVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHVrZUNvbWJpbGUucHVzaChpdGVtKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLkxJQU5fRFVJXzQ6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBpZiAocHVrZS5sZW5ndGggPCA4KSBicmVhaztcblxuICAgICAgICAgICAgICAgICAgICB2YXIgYWxsWFggPSB0aGlzLkdldENhcmRzVHlwZVhYKHB1a2UpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoYWxsWFgubGVuZ3RoIDwgNCkgYnJlYWs7XG5cbiAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBhbGxYWC5sZW5ndGggLSAzOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaV1bMF0pID49IDEzKSBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaV1bMF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFtpICsgMV1bMF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaSArIDFdWzBdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaSArIDJdWzBdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYW2kgKyAyXVswXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYW2kgKyAzXVswXSkgKyAxKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGl0ZW0gPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaV1bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFtpXVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2kgKyAxXVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2kgKyAxXVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2kgKyAyXVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2kgKyAyXVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2kgKyAzXVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2kgKyAzXVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHVrZUNvbWJpbGUucHVzaChpdGVtKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLkxJQU5fRFVJXzU6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBpZiAocHVrZS5sZW5ndGggPCAxMCkgYnJlYWs7XG5cbiAgICAgICAgICAgICAgICAgICAgdmFyIGFsbFhYID0gdGhpcy5HZXRDYXJkc1R5cGVYWChwdWtlKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGFsbFhYLmxlbmd0aCA8IDUpIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGFsbFhYLmxlbmd0aCAtIDQ7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFtpXVswXSkgPj0gMTMpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFtpXVswXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYW2kgKyAxXVswXSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFtpICsgMV1bMF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFtpICsgMl1bMF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaSArIDJdWzBdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaSArIDNdWzBdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYW2kgKyAzXVswXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYW2kgKyA0XVswXSkgKyAxKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGl0ZW0gPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaV1bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFtpXVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2kgKyAxXVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2kgKyAxXVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2kgKyAyXVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2kgKyAyXVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2kgKyAzXVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2kgKyAzXVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2kgKyA0XVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2kgKyA0XVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHVrZUNvbWJpbGUucHVzaChpdGVtKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLkxJQU5fRFVJXzY6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBpZiAocHVrZS5sZW5ndGggPCAxMikgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIHZhciBhbGxYWCA9IHRoaXMuR2V0Q2FyZHNUeXBlWFgocHVrZSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChhbGxYWC5sZW5ndGggPCA2KSBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBhbGxYWC5sZW5ndGggLSA1OyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaV1bMF0pID49IDEzKSBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaV1bMF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFtpICsgMV1bMF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaSArIDFdWzBdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaSArIDJdWzBdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYW2kgKyAyXVswXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYW2kgKyAzXVswXSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFtpICsgM11bMF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFtpICsgNF1bMF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaSArIDRdWzBdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaSArIDVdWzBdKSArIDEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgaXRlbSA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFtpXVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2ldWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDFdWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDFdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDJdWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDJdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDNdWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDNdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDRdWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDRdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDVdWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDVdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwdWtlQ29tYmlsZS5wdXNoKGl0ZW0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhc2UgZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTElBTl9EVUlfNzpcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChwdWtlLmxlbmd0aCA8IDE0KSBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgdmFyIGFsbFhYID0gdGhpcy5HZXRDYXJkc1R5cGVYWChwdWtlKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGFsbFhYLmxlbmd0aCA8IDcpIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGFsbFhYLmxlbmd0aCAtIDY7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFtpXVswXSkgPj0gMTMpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFtpXVswXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYW2kgKyAxXVswXSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFtpICsgMV1bMF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFtpICsgMl1bMF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaSArIDJdWzBdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaSArIDNdWzBdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYW2kgKyAzXVswXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYW2kgKyA0XVswXSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFtpICsgNF1bMF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFtpICsgNV1bMF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaSArIDVdWzBdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaSArIDZdWzBdKSArIDEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgaXRlbSA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFtpXVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2ldWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDFdWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDFdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDJdWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDJdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDNdWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDNdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDRdWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDRdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDVdWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDVdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDZdWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDZdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwdWtlQ29tYmlsZS5wdXNoKGl0ZW0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhc2UgZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTElBTl9EVUlfODpcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChwdWtlLmxlbmd0aCA8IDE2KSBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgdmFyIGFsbFhYID0gdGhpcy5HZXRDYXJkc1R5cGVYWChwdWtlKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGFsbFhYLmxlbmd0aCA8IDgpIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGFsbFhYLmxlbmd0aCAtIDc7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFtpXVswXSkgPj0gMTMpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFtpXVswXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYW2kgKyAxXVswXSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFtpICsgMV1bMF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFtpICsgMl1bMF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaSArIDJdWzBdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaSArIDNdWzBdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYW2kgKyAzXVswXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYW2kgKyA0XVswXSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFtpICsgNF1bMF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFtpICsgNV1bMF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaSArIDVdWzBdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaSArIDZdWzBdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYW2kgKyA2XVswXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYW2kgKyA3XVswXSkgKyAxKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGl0ZW0gPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaV1bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFtpXVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2kgKyAxXVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2kgKyAxXVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2kgKyAyXVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2kgKyAyXVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2kgKyAzXVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2kgKyAzXVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2kgKyA0XVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2kgKyA0XVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2kgKyA1XVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2kgKyA1XVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2kgKyA2XVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2kgKyA2XVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2kgKyA3XVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2kgKyA3XVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHVrZUNvbWJpbGUucHVzaChpdGVtKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLkxJQU5fRFVJXzk6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBpZiAocHVrZS5sZW5ndGggPCAxOCkgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIHZhciBhbGxYWCA9IHRoaXMuR2V0Q2FyZHNUeXBlWFgocHVrZSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChhbGxYWC5sZW5ndGggPCA5KSBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBhbGxYWC5sZW5ndGggLSA4OyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaV1bMF0pID49IDEzKSBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaV1bMF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFtpICsgMV1bMF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaSArIDFdWzBdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaSArIDJdWzBdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYW2kgKyAyXVswXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYW2kgKyAzXVswXSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFtpICsgM11bMF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFtpICsgNF1bMF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaSArIDRdWzBdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaSArIDVdWzBdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYW2kgKyA1XVswXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYW2kgKyA2XVswXSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFtpICsgNl1bMF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFtpICsgN11bMF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaSArIDddWzBdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaSArIDhdWzBdKSArIDEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgaXRlbSA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFtpXVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2ldWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDFdWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDFdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDJdWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDJdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDNdWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDNdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDRdWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDRdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDVdWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDVdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDZdWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDZdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDddWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDddWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDhdWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaSArIDhdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwdWtlQ29tYmlsZS5wdXNoKGl0ZW0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhc2UgZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTElBTl9EVUlfMTA6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBpZiAocHVrZS5sZW5ndGggPCAyMCkgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIHZhciBhbGxYWCA9IHRoaXMuR2V0Q2FyZHNUeXBlWFgocHVrZSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChhbGxYWC5sZW5ndGggPCAxMCkgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgYWxsWFgubGVuZ3RoIC0gOTsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYW2ldWzBdKSA+PSAxMykgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYW2ldWzBdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaSArIDFdWzBdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYW2kgKyAxXVswXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYW2kgKyAyXVswXSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFtpICsgMl1bMF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFtpICsgM11bMF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaSArIDNdWzBdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaSArIDRdWzBdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYW2kgKyA0XVswXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYW2kgKyA1XVswXSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFtpICsgNV1bMF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFtpICsgNl1bMF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaSArIDZdWzBdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhbaSArIDddWzBdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYW2kgKyA3XVswXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYW2kgKyA4XVswXSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFtpICsgOF1bMF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFtpICsgOV1bMF0pICsgMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBpdGVtID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2ldWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbaV1bMV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFtpICsgMV1bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFtpICsgMV1bMV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFtpICsgMl1bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFtpICsgMl1bMV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFtpICsgM11bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFtpICsgM11bMV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFtpICsgNF1bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFtpICsgNF1bMV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFtpICsgNV1bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFtpICsgNV1bMV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFtpICsgNl1bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFtpICsgNl1bMV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFtpICsgN11bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFtpICsgN11bMV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFtpICsgOF1bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFtpICsgOF1bMV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFtpICsgOV1bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFtpICsgOV1bMV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHB1a2VDb21iaWxlLnB1c2goaXRlbSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5MSUFOX1NIVU5fMjpcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChwdWtlLmxlbmd0aCA8IDYpIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICB2YXIgYWxsWFhYID0gdGhpcy5HZXRDYXJkc1R5cGVYWFgocHVrZSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChhbGxYWFgubGVuZ3RoIDwgMikgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgYWxsWFhYLmxlbmd0aCAtIDE7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFhbaV1bMF0pID49IDEzKSBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhYW2ldWzBdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhYW2kgKyAxXVswXSkgKyAxKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGl0ZW0gPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2ldWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2ldWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2ldWzJdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2kgKyAxXVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgMV1bMV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDFdWzJdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwdWtlQ29tYmlsZS5wdXNoKGl0ZW0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhc2UgZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTElBTl9TSFVOXzM6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBpZiAocHVrZS5sZW5ndGggPCA5KSBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgdmFyIGFsbFhYWCA9IHRoaXMuR2V0Q2FyZHNUeXBlWFhYKHB1a2UpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoYWxsWFhYLmxlbmd0aCA8IDMpIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGFsbFhYWC5sZW5ndGggLSAyOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhYW2ldWzBdKSA+PSAxMykgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYWFtpXVswXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYWFtpICsgMV1bMF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhYW2kgKyAxXVswXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYWFtpICsgMl1bMF0pICsgMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBpdGVtID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpXVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpXVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpXVsyXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgMV1bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDFdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2kgKyAxXVsyXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgMl1bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDJdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2kgKyAyXVsyXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHVrZUNvbWJpbGUucHVzaChpdGVtKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLkxJQU5fU0hVTl80OlxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHB1a2UubGVuZ3RoIDwgMTIpIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICB2YXIgYWxsWFhYID0gdGhpcy5HZXRDYXJkc1R5cGVYWFgocHVrZSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChhbGxYWFgubGVuZ3RoIDwgNCkgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgYWxsWFhYLmxlbmd0aCAtIDM7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFhbaV1bMF0pID49IDEzKSBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhYW2ldWzBdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhYW2kgKyAxXVswXSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFhbaSArIDFdWzBdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhYW2kgKyAyXVswXSkgKyAxICYmIHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFhbaSArIDJdWzBdKSA9PSB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhYW2kgKyAzXVswXSkgKyAxKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGl0ZW0gPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2ldWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2ldWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2ldWzJdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2kgKyAxXVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgMV1bMV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDFdWzJdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2kgKyAyXVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgMl1bMV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDJdWzJdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2kgKyAzXVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgM11bMV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDNdWzJdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwdWtlQ29tYmlsZS5wdXNoKGl0ZW0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhc2UgZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuTElBTl9TSFVOXzU6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBpZiAocHVrZS5sZW5ndGggPCAxNSkgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIHZhciBhbGxYWFggPSB0aGlzLkdldENhcmRzVHlwZVhYWChwdWtlKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGFsbFhYWC5sZW5ndGggPCA0KSBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBhbGxYWFgubGVuZ3RoIC0gNDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYWFtpXVswXSkgPj0gMTMpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFhbaV1bMF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFhbaSArIDFdWzBdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYWFtpICsgMV1bMF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFhbaSArIDJdWzBdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYWFtpICsgMl1bMF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFhbaSArIDNdWzBdKSArIDEgJiYgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYWFtpICsgM11bMF0pID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFhbaSArIDRdWzBdKSArIDEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgaXRlbSA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaV1bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaV1bMV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaV1bMl0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDFdWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2kgKyAxXVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgMV1bMl0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDJdWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2kgKyAyXVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgMl1bMl0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDNdWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2kgKyAzXVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgM11bMl0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDRdWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2kgKyA0XVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgNF1bMl0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHB1a2VDb21iaWxlLnB1c2goaXRlbSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5MSUFOX1NIVU5fNjpcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChwdWtlLmxlbmd0aCA8IDE4KSBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgdmFyIGFsbFhYWCA9IHRoaXMuR2V0Q2FyZHNUeXBlWFhYKHB1a2UpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoYWxsWFhYLmxlbmd0aCA8IDUpIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGFsbFhYWC5sZW5ndGggLSA1OyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhYW2ldWzBdKSA+PSAxMykgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYWFtpXVswXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYWFtpICsgMV1bMF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhYW2kgKyAxXVswXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYWFtpICsgMl1bMF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhYW2kgKyAyXVswXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYWFtpICsgM11bMF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhYW2kgKyAzXVswXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYWFtpICsgNF1bMF0pICsgMSAmJiB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhYW2kgKyA0XVswXSkgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYWFtpICsgNV1bMF0pICsgMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBpdGVtID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpXVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpXVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpXVsyXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgMV1bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDFdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2kgKyAxXVsyXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgMl1bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDJdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2kgKyAyXVsyXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgM11bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDNdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2kgKyAzXVsyXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgNF1bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDRdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2kgKyA0XVsyXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgNV1bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDVdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2kgKyA1XVsyXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHVrZUNvbWJpbGUucHVzaChpdGVtKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGNhc2UgZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuUExBTkVfU18xOlxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHB1a2UubGVuZ3RoIDwgNCkgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIHZhciBhbGxYWFggPSB0aGlzLkdldENhcmRzVHlwZVhYWChwdWtlKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGFsbFhYWC5sZW5ndGggPCAxKSBicmVhaztcblxuICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGFsbFhYWC5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaiA9IDA7IGogPCBwdWtlLmxlbmd0aDsgaisrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChwdWtlW2pdKSA9PSB0aGlzLkdldENhcmRWYWwoYWxsWFhYW2ldWzBdKSkgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGl0ZW0gPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2ldWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2ldWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2ldWzJdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2gocHVrZVtqXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHVrZUNvbWJpbGUucHVzaChpdGVtKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLlBMQU5FX1NfMjpcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChwdWtlLmxlbmd0aCA8IDgpIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICB2YXIgYWxsWFhYID0gdGhpcy5HZXRDYXJkc1R5cGVYWFgocHVrZSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChhbGxYWFgubGVuZ3RoIDwgMikgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgYWxsWFhYLmxlbmd0aCAtIDE7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFhbaV1bMF0pID49IDEzKSBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhYW2ldWzBdKSAhPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYWFtpICsgMV1bMF0pICsgMSkgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBqID0gMDsgaiA8IHB1a2UubGVuZ3RoOyBqKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKHB1a2Vbal0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFhbaV1bMF0pIHx8IHRoaXMuR2V0Q2FyZFZhbChwdWtlW2pdKSA9PSB0aGlzLkdldENhcmRWYWwoYWxsWFhYW2kgKyAxXVswXSkpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIF9rID0gMDsgX2sgPCBwdWtlLmxlbmd0aDsgX2srKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKHB1a2VbX2tdKSA9PSB0aGlzLkdldENhcmRWYWwoYWxsWFhYW2ldWzBdKSB8fCB0aGlzLkdldENhcmRWYWwocHVrZVtfa10pICE9IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFhbaSArIDFdWzBdKSB8fCB0aGlzLkdldENhcmRWYWwocHVrZVtfa10pID09IHRoaXMuR2V0Q2FyZFZhbChwdWtlW2pdKSkgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBpdGVtID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaV1bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2ldWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpXVsyXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDFdWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgMV1bMV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2kgKyAxXVsyXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChwdWtlW2pdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKHB1a2VbX2tdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHVrZUNvbWJpbGUucHVzaChpdGVtKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5QTEFORV9TXzM6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBpZiAocHVrZS5sZW5ndGggPCAxMikgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIHZhciBhbGxYWFggPSB0aGlzLkdldENhcmRzVHlwZVhYWChwdWtlKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGFsbFhYWC5sZW5ndGggPCAzKSBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBhbGxYWFgubGVuZ3RoIC0gMjsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYWFtpXVswXSkgPj0gMTMpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFhbaV1bMF0pICE9PSB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhYW2kgKyAxXVswXSkgKyAxIHx8IHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFhbaSArIDFdWzBdKSAhPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYWFtpICsgMl1bMF0pICsgMSkgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBqID0gMDsgaiA8IHB1a2UubGVuZ3RoOyBqKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKHB1a2Vbal0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFhbaV1bMF0pIHx8IHRoaXMuR2V0Q2FyZFZhbChwdWtlW2pdKSA9PSB0aGlzLkdldENhcmRWYWwoYWxsWFhYW2kgKyAxXVswXSkgfHwgdGhpcy5HZXRDYXJkVmFsKHB1a2Vbal0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFhbaSArIDJdWzBdKSkgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgX2syID0gMDsgX2syIDwgcHVrZS5sZW5ndGg7IF9rMisrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwocHVrZVtfazJdKSA9PSB0aGlzLkdldENhcmRWYWwoYWxsWFhYW2ldWzBdKSB8fCB0aGlzLkdldENhcmRWYWwocHVrZVtfazJdKSA9PSB0aGlzLkdldENhcmRWYWwoYWxsWFhYW2kgKyAxXVswXSkgfHwgdGhpcy5HZXRDYXJkVmFsKHB1a2VbX2syXSkgPT0gdGhpcy5HZXRDYXJkVmFsKGFsbFhYWFtpICsgMl1bMF0pIHx8IHRoaXMuR2V0Q2FyZFZhbChwdWtlW2pdKSA9PSB0aGlzLkdldENhcmRWYWwocHVrZVtfazJdKSkgZm9yICh2YXIgbSA9IDA7IG0gPCBwdWtlLmxlbmd0aDsgbSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKHB1a2VbbV0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFhbaV1bMF0pIHx8IHRoaXMuR2V0Q2FyZFZhbChwdWtlW21dKSA9PSB0aGlzLkdldENhcmRWYWwoYWxsWFhYW2kgKyAxXVswXSkgfHwgdGhpcy5HZXRDYXJkVmFsKHB1a2VbbV0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFhbaSArIDJdWzBdKSB8fCB0aGlzLkdldENhcmRWYWwocHVrZVttXSkgPT0gdGhpcy5HZXRDYXJkVmFsKHB1a2VbX2syXSkgfHwgdGhpcy5HZXRDYXJkVmFsKHB1a2VbbV0pID09IHRoaXMuR2V0Q2FyZFZhbChwdWtlW2pdKSkgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgaXRlbSA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpXVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2ldWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaV1bMl0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgMV1bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgMV1bMV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgMV1bMl0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgMl1bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgMl1bMV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgMl1bMl0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKHB1a2Vbal0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKHB1a2VbX2syXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2gocHVrZVttXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwdWtlQ29tYmlsZS5wdXNoKGl0ZW0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhc2UgZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuUExBTkVfU180OlxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHB1a2UubGVuZ3RoIDwgMTYpIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICB2YXIgYWxsWFhYID0gdGhpcy5HZXRDYXJkc1R5cGVYWFgocHVrZSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChhbGxYWFgubGVuZ3RoIDwgNCkgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgYWxsWFhYLmxlbmd0aCAtIDM7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFhbaV1bMF0pID49IDEzKSBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhYW2ldWzBdKSAhPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYWFtpICsgMV1bMF0pICsgMSB8fCB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhYW2kgKyAxXVswXSkgIT09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFhbaSArIDJdWzBdKSArIDEgfHwgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYWFtpICsgMl1bMF0pICE9PSB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhYW2kgKyAzXVswXSkgKyAxKSBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGogPSAwOyBqIDwgcHVrZS5sZW5ndGg7IGorKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwocHVrZVtqXSkgPT0gdGhpcy5HZXRDYXJkVmFsKGFsbFhYWFtpXVswXSkgfHwgdGhpcy5HZXRDYXJkVmFsKHB1a2Vbal0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFhbaSArIDFdWzBdKSB8fCB0aGlzLkdldENhcmRWYWwocHVrZVtqXSkgPT0gdGhpcy5HZXRDYXJkVmFsKGFsbFhYWFtpICsgMl1bMF0pIHx8IHRoaXMuR2V0Q2FyZFZhbChwdWtlW2pdKSA9PSB0aGlzLkdldENhcmRWYWwoYWxsWFhYW2kgKyAzXVswXSkpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIF9rMyA9IDA7IF9rMyA8IHB1a2UubGVuZ3RoOyBfazMrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKHB1a2VbX2szXSkgPT0gdGhpcy5HZXRDYXJkVmFsKGFsbFhYWFtpXVswXSkgfHwgdGhpcy5HZXRDYXJkVmFsKHB1a2VbX2szXSkgPT0gdGhpcy5HZXRDYXJkVmFsKGFsbFhYWFtpICsgMV1bMF0pIHx8IHRoaXMuR2V0Q2FyZFZhbChwdWtlW19rM10pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFhbaSArIDJdWzBdKSB8fCB0aGlzLkdldENhcmRWYWwocHVrZVtfazNdKSA9PSB0aGlzLkdldENhcmRWYWwoYWxsWFhYW2kgKyAzXVswXSkgfHwgdGhpcy5HZXRDYXJkVmFsKHB1a2Vbal0pID09IHRoaXMuR2V0Q2FyZFZhbChwdWtlW19rM10pKSBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgbSA9IDA7IG0gPCBwdWtlLmxlbmd0aDsgbSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKHB1a2VbbV0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFhbaV1bMF0pIHx8IHRoaXMuR2V0Q2FyZFZhbChwdWtlW21dKSA9PSB0aGlzLkdldENhcmRWYWwoYWxsWFhYW2kgKyAxXVswXSkgfHwgdGhpcy5HZXRDYXJkVmFsKHB1a2VbbV0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFhbaSArIDJdWzBdKSB8fCB0aGlzLkdldENhcmRWYWwocHVrZVttXSkgPT0gdGhpcy5HZXRDYXJkVmFsKGFsbFhYWFtpICsgM11bMF0pIHx8IHRoaXMuR2V0Q2FyZFZhbChwdWtlW21dKSA9PSB0aGlzLkdldENhcmRWYWwocHVrZVtfazNdKSB8fCB0aGlzLkdldENhcmRWYWwocHVrZVttXSkgPT0gdGhpcy5HZXRDYXJkVmFsKHB1a2Vbal0pKSBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIG4gPSAwOyBuIDwgcHVrZS5sZW5ndGg7IG4rKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwocHVrZVtuXSkgPT0gdGhpcy5HZXRDYXJkVmFsKGFsbFhYWFtpXVswXSkgfHwgdGhpcy5HZXRDYXJkVmFsKHB1a2Vbbl0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFhbaSArIDFdWzBdKSB8fCB0aGlzLkdldENhcmRWYWwocHVrZVtuXSkgPT0gdGhpcy5HZXRDYXJkVmFsKGFsbFhYWFtpICsgMl1bMF0pIHx8IHRoaXMuR2V0Q2FyZFZhbChwdWtlW25dKSA9PSB0aGlzLkdldENhcmRWYWwoYWxsWFhYW2kgKyAzXVswXSkgfHwgdGhpcy5HZXRDYXJkVmFsKHB1a2Vbbl0pID09IHRoaXMuR2V0Q2FyZFZhbChwdWtlW21dKSB8fCB0aGlzLkdldENhcmRWYWwocHVrZVtuXSkgPT0gdGhpcy5HZXRDYXJkVmFsKHB1a2Vbal0pIHx8IHRoaXMuR2V0Q2FyZFZhbChwdWtlW25dKSA9PSB0aGlzLkdldENhcmRWYWwocHVrZVtfazNdKSkgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgaXRlbSA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2ldWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpXVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaV1bMl0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2kgKyAxXVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDFdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgMV1bMl0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2kgKyAyXVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDJdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgMl1bMl0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2kgKyAzXVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDNdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgM11bMl0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2gocHVrZVtqXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChwdWtlW19rM10pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2gocHVrZVttXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChwdWtlW25dKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHVrZUNvbWJpbGUucHVzaChpdGVtKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5QTEFORV9TXzU6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBpZiAocHVrZS5sZW5ndGggPCAyMCkgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIHZhciBhbGxYWFggPSB0aGlzLkdldENhcmRzVHlwZVhYWChwdWtlKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGFsbFhYWC5sZW5ndGggPCA1KSBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBhbGxYWFgubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhYW2ldWzBdKSA+PSAxMykgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYWFtpXVswXSkgIT09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFhbaSArIDFdWzBdKSArIDEgfHwgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYWFtpICsgMV1bMF0pICE9PSB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhYW2kgKyAyXVswXSkgKyAxIHx8IHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFhbaSArIDJdWzBdKSAhPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYWFtpICsgM11bMF0pICsgMSB8fCB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhYW2kgKyAzXVswXSkgIT09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFhbaSArIDRdWzBdKSArIDEpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaiA9IDA7IGogPCBwdWtlLmxlbmd0aDsgaisrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChwdWtlW2pdKSA9PSB0aGlzLkdldENhcmRWYWwoYWxsWFhYW2ldWzBdKSB8fCB0aGlzLkdldENhcmRWYWwocHVrZVtqXSkgPT0gdGhpcy5HZXRDYXJkVmFsKGFsbFhYWFtpICsgMV1bMF0pIHx8IHRoaXMuR2V0Q2FyZFZhbChwdWtlW2pdKSA9PSB0aGlzLkdldENhcmRWYWwoYWxsWFhYW2kgKyAyXVswXSkgfHwgdGhpcy5HZXRDYXJkVmFsKHB1a2Vbal0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFhbaSArIDNdWzBdKSB8fCB0aGlzLkdldENhcmRWYWwocHVrZVtqXSkgPT0gdGhpcy5HZXRDYXJkVmFsKGFsbFhYWFtpICsgNF1bMF0pKSBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBfazQgPSAwOyBfazQgPCBwdWtlLmxlbmd0aDsgX2s0KyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChwdWtlW19rNF0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFhbaV1bMF0pIHx8IHRoaXMuR2V0Q2FyZFZhbChwdWtlW19rNF0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFhbaSArIDFdWzBdKSB8fCB0aGlzLkdldENhcmRWYWwocHVrZVtfazRdKSA9PSB0aGlzLkdldENhcmRWYWwoYWxsWFhYW2kgKyAyXVswXSkgfHwgdGhpcy5HZXRDYXJkVmFsKHB1a2VbX2s0XSkgPT0gdGhpcy5HZXRDYXJkVmFsKGFsbFhYWFtpICsgM11bMF0pIHx8IHRoaXMuR2V0Q2FyZFZhbChwdWtlW19rNF0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFhbaSArIDRdWzBdKSB8fCB0aGlzLkdldENhcmRWYWwocHVrZVtqXSkgPT0gdGhpcy5HZXRDYXJkVmFsKHB1a2VbX2s0XSkpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBtID0gMDsgbSA8IHB1a2UubGVuZ3RoOyBtKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwocHVrZVttXSkgPT0gdGhpcy5HZXRDYXJkVmFsKGFsbFhYWFtpXVswXSkgfHwgdGhpcy5HZXRDYXJkVmFsKHB1a2VbbV0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFhbaSArIDFdWzBdKSB8fCB0aGlzLkdldENhcmRWYWwocHVrZVttXSkgPT0gdGhpcy5HZXRDYXJkVmFsKGFsbFhYWFtpICsgMl1bMF0pIHx8IHRoaXMuR2V0Q2FyZFZhbChwdWtlW21dKSA9PSB0aGlzLkdldENhcmRWYWwoYWxsWFhYW2kgKyAzXVswXSkgfHwgdGhpcy5HZXRDYXJkVmFsKHB1a2VbbV0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFhbaSArIDRdWzBdKSB8fCB0aGlzLkdldENhcmRWYWwocHVrZVttXSkgPT0gdGhpcy5HZXRDYXJkVmFsKHB1a2VbX2s0XSkgfHwgdGhpcy5HZXRDYXJkVmFsKHB1a2VbbV0pID09IHRoaXMuR2V0Q2FyZFZhbChwdWtlW2pdKSkgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBuID0gMDsgbiA8IHB1a2UubGVuZ3RoOyBuKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKHB1a2Vbbl0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFhbaV1bMF0pIHx8IHRoaXMuR2V0Q2FyZFZhbChwdWtlW25dKSA9PSB0aGlzLkdldENhcmRWYWwoYWxsWFhYW2kgKyAxXVswXSkgfHwgdGhpcy5HZXRDYXJkVmFsKHB1a2Vbbl0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFhbaSArIDJdWzBdKSB8fCB0aGlzLkdldENhcmRWYWwocHVrZVtuXSkgPT0gdGhpcy5HZXRDYXJkVmFsKGFsbFhYWFtpICsgM11bMF0pIHx8IHRoaXMuR2V0Q2FyZFZhbChwdWtlW25dKSA9PSB0aGlzLkdldENhcmRWYWwoYWxsWFhYW2kgKyA0XVswXSkgfHwgdGhpcy5HZXRDYXJkVmFsKHB1a2Vbbl0pID09IHRoaXMuR2V0Q2FyZFZhbChwdWtlW21dKSB8fCB0aGlzLkdldENhcmRWYWwocHVrZVtuXSkgPT0gdGhpcy5HZXRDYXJkVmFsKHB1a2Vbal0pIHx8IHRoaXMuR2V0Q2FyZFZhbChwdWtlW25dKSA9PSB0aGlzLkdldENhcmRWYWwocHVrZVtfazRdKSkgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgdCA9IDA7IHQgPCBwdWtlLmxlbmd0aDsgdCsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwocHVrZVt0XSkgPT0gdGhpcy5HZXRDYXJkVmFsKGFsbFhYWFtpXVswXSkgfHwgdGhpcy5HZXRDYXJkVmFsKHB1a2VbdF0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFhbaSArIDFdWzBdKSB8fCB0aGlzLkdldENhcmRWYWwocHVrZVt0XSkgPT0gdGhpcy5HZXRDYXJkVmFsKGFsbFhYWFtpICsgMl1bMF0pIHx8IHRoaXMuR2V0Q2FyZFZhbChwdWtlW3RdKSA9PSB0aGlzLkdldENhcmRWYWwoYWxsWFhYW2kgKyAzXVswXSkgfHwgdGhpcy5HZXRDYXJkVmFsKHB1a2VbdF0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFhbaSArIDRdWzBdKSB8fCB0aGlzLkdldENhcmRWYWwocHVrZVt0XSkgPT0gdGhpcy5HZXRDYXJkVmFsKHB1a2Vbal0pIHx8IHRoaXMuR2V0Q2FyZFZhbChwdWtlW3RdKSA9PSB0aGlzLkdldENhcmRWYWwocHVrZVtfazRdKSB8fCB0aGlzLkdldENhcmRWYWwocHVrZVt0XSkgPT0gdGhpcy5HZXRDYXJkVmFsKHB1a2VbbV0pIHx8IHRoaXMuR2V0Q2FyZFZhbChwdWtlW3RdKSA9PSB0aGlzLkdldENhcmRWYWwocHVrZVtuXSkpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgaXRlbSA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2ldWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpXVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaV1bMl0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2kgKyAxXVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDFdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgMV1bMl0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2kgKyAyXVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDJdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgMl1bMl0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2kgKyAzXVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDNdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgM11bMl0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2kgKyA0XVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDRdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgNF1bMl0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2gocHVrZVtqXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChwdWtlW19rNF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2gocHVrZVttXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChwdWtlW25dKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKHB1a2VbdF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwdWtlQ29tYmlsZS5wdXNoKGl0ZW0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLlBMQU5FX0JfMTpcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChwdWtlLmxlbmd0aCA8IDUpIGJyZWFrO1xuXG4gICAgICAgICAgICAgICAgICAgIHZhciBhbGxYWCA9IHRoaXMuR2V0Q2FyZHNUeXBlWFgocHVrZSk7XG4gICAgICAgICAgICAgICAgICAgIHZhciBhbGxYWFggPSB0aGlzLkdldENhcmRzVHlwZVhYWChwdWtlKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGFsbFhYLmxlbmd0aCA8IDIgfHwgYWxsWFhYLmxlbmd0aCA8IDEpIGJyZWFrO1xuXG4gICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgYWxsWFhYLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBqID0gMDsgaiA8IGFsbFhYLmxlbmd0aDsgaisrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChhbGxYWFtqXVswXSkgIT0gdGhpcy5HZXRDYXJkVmFsKGFsbFhYWFtpXVswXSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGl0ZW0gPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpXVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaV1bMV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2ldWzJdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2pdWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2pdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHVrZUNvbWJpbGUucHVzaChpdGVtKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5QTEFORV9CXzI6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBpZiAocHVrZS5sZW5ndGggPCAxMCkgYnJlYWs7XG5cbiAgICAgICAgICAgICAgICAgICAgdmFyIGFsbFhYID0gdGhpcy5HZXRDYXJkc1R5cGVYWChwdWtlKTtcbiAgICAgICAgICAgICAgICAgICAgdmFyIGFsbFhYWCA9IHRoaXMuR2V0Q2FyZHNUeXBlWFhYKHB1a2UpO1xuXG4gICAgICAgICAgICAgICAgICAgIGlmIChhbGxYWC5sZW5ndGggPCA0IHx8IGFsbFhYWC5sZW5ndGggPCAyKSBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBhbGxYWFgubGVuZ3RoIC0gMTsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYWFtpXVswXSkgPj0gMTMpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFhbaV1bMF0pICE9IHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFhbaSArIDFdWzBdKSArIDEpIGNvbnRpbnVlO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBqID0gMDsgaiA8IGFsbFhYLmxlbmd0aDsgaisrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChhbGxYWFtqXVswXSkgPT0gdGhpcy5HZXRDYXJkVmFsKGFsbFhYWFtpXVswXSkgfHwgdGhpcy5HZXRDYXJkVmFsKGFsbFhYW2pdWzBdKSA9PSB0aGlzLkdldENhcmRWYWwoYWxsWFhYW2kgKyAxXVswXSkpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIF9rNSA9IDA7IF9rNSA8IGFsbFhYLmxlbmd0aDsgX2s1KyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChhbGxYWFtfazVdWzBdKSA9PSB0aGlzLkdldENhcmRWYWwoYWxsWFhYW2ldWzBdKSB8fCB0aGlzLkdldENhcmRWYWwoYWxsWFhbX2s1XVswXSkgPT0gdGhpcy5HZXRDYXJkVmFsKGFsbFhYWFtpICsgMV1bMF0pIHx8IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFtfazVdWzBdKSA9PSB0aGlzLkdldENhcmRWYWwoYWxsWFhbal1bMF0pKSBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGl0ZW0gPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpXVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaV1bMV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2ldWzJdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgMV1bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2kgKyAxXVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDFdWzJdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtqXVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbal1bMV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW19rNV1bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW19rNV1bMV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwdWtlQ29tYmlsZS5wdXNoKGl0ZW0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLlBMQU5FX0JfMzpcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChwdWtlLmxlbmd0aCA8IDE1KSBicmVhaztcblxuICAgICAgICAgICAgICAgICAgICB2YXIgYWxsWFggPSB0aGlzLkdldENhcmRzVHlwZVhYKHB1a2UpO1xuICAgICAgICAgICAgICAgICAgICB2YXIgYWxsWFhYID0gdGhpcy5HZXRDYXJkc1R5cGVYWFgocHVrZSk7XG5cbiAgICAgICAgICAgICAgICAgICAgaWYgKGFsbFhYLmxlbmd0aCA8IDYgfHwgYWxsWFhYLmxlbmd0aCA8IDMpIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGFsbFhYWC5sZW5ndGggLSAyOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhYW2ldWzBdKSA+PSAxMykgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYWFtpXVswXSkgIT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYWFtpICsgMV1bMF0pICsgMSB8fCB0aGlzLkdldENhcmRDb21tb25WYWwoYWxsWFhYW2kgKyAxXVswXSkgIT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYWFtpICsgMl1bMF0pICsgMSkgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBqID0gMDsgaiA8IGFsbFhYLmxlbmd0aDsgaisrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChhbGxYWFtqXVswXSkgPT0gdGhpcy5HZXRDYXJkVmFsKGFsbFhYWFtpXVswXSkgfHwgdGhpcy5HZXRDYXJkVmFsKGFsbFhYW2pdWzBdKSA9PSB0aGlzLkdldENhcmRWYWwoYWxsWFhYW2kgKyAxXVswXSkgfHwgdGhpcy5HZXRDYXJkVmFsKGFsbFhYW2pdWzBdKSA9PSB0aGlzLkdldENhcmRWYWwoYWxsWFhYW2kgKyAyXVswXSkpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIF9rNiA9IDA7IF9rNiA8IGFsbFhYLmxlbmd0aDsgX2s2KyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChhbGxYWFtfazZdWzBdKSA9PSB0aGlzLkdldENhcmRWYWwoYWxsWFhYW2ldWzBdKSB8fCB0aGlzLkdldENhcmRWYWwoYWxsWFhbX2s2XVswXSkgPT0gdGhpcy5HZXRDYXJkVmFsKGFsbFhYWFtpICsgMV1bMF0pIHx8IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFtfazZdWzBdKSA9PSB0aGlzLkdldENhcmRWYWwoYWxsWFhYW2kgKyAyXVswXSkgfHwgdGhpcy5HZXRDYXJkVmFsKGFsbFhYW19rNl1bMF0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFtqXVswXSkpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciB0ID0gMDsgdCA8IGFsbFhYLmxlbmd0aDsgdCsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKGFsbFhYW3RdWzBdKSA9PSB0aGlzLkdldENhcmRWYWwoYWxsWFhYW2ldWzBdKSB8fCB0aGlzLkdldENhcmRWYWwoYWxsWFhbdF1bMF0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFhbaSArIDFdWzBdKSB8fCB0aGlzLkdldENhcmRWYWwoYWxsWFhbdF1bMF0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFhbaSArIDJdWzBdKSB8fCB0aGlzLkdldENhcmRWYWwoYWxsWFhbdF1bMF0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFtqXVswXSkgfHwgdGhpcy5HZXRDYXJkVmFsKGFsbFhYW3RdWzBdKSA9PSB0aGlzLkdldENhcmRWYWwoYWxsWFhbX2s2XVswXSkpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGl0ZW0gPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaV1bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpXVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2ldWzJdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDFdWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDFdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDFdWzJdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDJdWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDJdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDJdWzJdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbal1bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtqXVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW19rNl1bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtfazZdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbdF1bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFt0XVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwdWtlQ29tYmlsZS5wdXNoKGl0ZW0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5QTEFORV9CXzM6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBpZiAocHVrZS5sZW5ndGggPCAxOCkgYnJlYWs7XG5cbiAgICAgICAgICAgICAgICAgICAgdmFyIGFsbFhYID0gdGhpcy5HZXRDYXJkc1R5cGVYWChwdWtlKTtcbiAgICAgICAgICAgICAgICAgICAgdmFyIGFsbFhYWCA9IHRoaXMuR2V0Q2FyZHNUeXBlWFhYKHB1a2UpO1xuXG4gICAgICAgICAgICAgICAgICAgIGlmIChhbGxYWC5sZW5ndGggPCA4IHx8IGFsbFhYWC5sZW5ndGggPCA0KSBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBhbGxYWFgubGVuZ3RoIC0gMzsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYWFtpXVswXSkgPj0gMTMpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFhbaV1bMF0pICE9IHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFhbaSArIDFdWzBdKSArIDEgfHwgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYWFtpICsgMV1bMF0pICE9IHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFhbaSArIDJdWzBdKSArIDEgfHwgdGhpcy5HZXRDYXJkQ29tbW9uVmFsKGFsbFhYWFtpICsgMl1bMF0pICE9IHRoaXMuR2V0Q2FyZENvbW1vblZhbChhbGxYWFhbaSArIDNdWzBdKSArIDEpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaiA9IDA7IGogPCBhbGxYWC5sZW5ndGg7IGorKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwoYWxsWFhbal1bMF0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFhbaV1bMF0pIHx8IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFtqXVswXSkgPT0gdGhpcy5HZXRDYXJkVmFsKGFsbFhYWFtpICsgMV1bMF0pIHx8IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFtqXVswXSkgPT0gdGhpcy5HZXRDYXJkVmFsKGFsbFhYWFtpICsgMl1bMF0pIHx8IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFtqXVswXSkgPT0gdGhpcy5HZXRDYXJkVmFsKGFsbFhYWFtpICsgM11bMF0pKSBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBfazcgPSAwOyBfazcgPCBhbGxYWC5sZW5ndGg7IF9rNysrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwoYWxsWFhbX2s3XVswXSkgPT0gdGhpcy5HZXRDYXJkVmFsKGFsbFhYWFtpXVswXSkgfHwgdGhpcy5HZXRDYXJkVmFsKGFsbFhYW19rN11bMF0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFhbaSArIDFdWzBdKSB8fCB0aGlzLkdldENhcmRWYWwoYWxsWFhbX2s3XVswXSkgPT0gdGhpcy5HZXRDYXJkVmFsKGFsbFhYWFtpICsgMl1bMF0pIHx8IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFtfazddWzBdKSA9PSB0aGlzLkdldENhcmRWYWwoYWxsWFhYW2kgKyAzXVswXSkgfHwgdGhpcy5HZXRDYXJkVmFsKGFsbFhYW19rN11bMF0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFtqXVswXSkpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciB0ID0gMDsgdCA8IGFsbFhYLmxlbmd0aDsgdCsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKGFsbFhYW3RdWzBdKSA9PSB0aGlzLkdldENhcmRWYWwoYWxsWFhYW2ldWzBdKSB8fCB0aGlzLkdldENhcmRWYWwoYWxsWFhbdF1bMF0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFhbaSArIDFdWzBdKSB8fCB0aGlzLkdldENhcmRWYWwoYWxsWFhbdF1bMF0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFhbaSArIDJdWzBdKSB8fCB0aGlzLkdldENhcmRWYWwoYWxsWFhbdF1bMF0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFhbaSArIDNdWzBdKSB8fCB0aGlzLkdldENhcmRWYWwoYWxsWFhbdF1bMF0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFtqXVswXSkgfHwgdGhpcy5HZXRDYXJkVmFsKGFsbFhYW3RdWzBdKSA9PSB0aGlzLkdldENhcmRWYWwoYWxsWFhbX2s3XVswXSkpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgbSA9IDA7IG0gPCBhbGxYWC5sZW5ndGg7IG0rKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwoYWxsWFhbbV1bMF0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFhbaV1bMF0pIHx8IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFttXVswXSkgPT0gdGhpcy5HZXRDYXJkVmFsKGFsbFhYWFtpICsgMV1bMF0pIHx8IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFttXVswXSkgPT0gdGhpcy5HZXRDYXJkVmFsKGFsbFhYWFtpICsgMl1bMF0pIHx8IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFttXVswXSkgPT0gdGhpcy5HZXRDYXJkVmFsKGFsbFhYWFtpICsgM11bMF0pIHx8IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFttXVswXSkgPT0gdGhpcy5HZXRDYXJkVmFsKGFsbFhYW2pdWzBdKSB8fCB0aGlzLkdldENhcmRWYWwoYWxsWFhbbV1bMF0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFtfazddWzBdKSB8fCB0aGlzLkdldENhcmRWYWwoYWxsWFhbbV1bMF0pID09IHRoaXMuR2V0Q2FyZFZhbChhbGxYWFt0XVswXSkpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBpdGVtID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpXVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpXVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpXVsyXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgMV1bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDFdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2kgKyAxXVsyXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgMl1bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDJdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2kgKyAyXVsyXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtpICsgM11bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbaSArIDNdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW2kgKyAzXVsyXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtqXVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtqXVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYWFtfazddWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhYW19rN11bMV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbdF1bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbdF1bMV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbbV1bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChhbGxYWFhbbV1bMV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHB1a2VDb21iaWxlLnB1c2goaXRlbSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLlNIVU5aSV81OlxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHB1a2UubGVuZ3RoIDwgNSkgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgcHVrZS5sZW5ndGggLSA0OyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBmaXJzdFZhbCA9IHRoaXMuR2V0Q2FyZENvbW1vblZhbChwdWtlW2ldKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChmaXJzdFZhbCA+PSAxMykgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgaXNFeGlzdDEgPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGlzRXhpc3QyID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBpc0V4aXN0MyA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgaXNFeGlzdDQgPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGogPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgd2hpbGUgKGogPCBwdWtlLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChmaXJzdFZhbCA9PSB0aGlzLkdldENhcmRDb21tb25WYWwocHVrZVtqXSkgKyAxKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzRXhpc3QxID0gajtqKys7Y29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChmaXJzdFZhbCA9PSB0aGlzLkdldENhcmRDb21tb25WYWwocHVrZVtqXSkgKyAyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzRXhpc3QyID0gajtqKys7Y29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChmaXJzdFZhbCA9PSB0aGlzLkdldENhcmRDb21tb25WYWwocHVrZVtqXSkgKyAzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzRXhpc3QzID0gajtqKys7Y29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChmaXJzdFZhbCA9PSB0aGlzLkdldENhcmRDb21tb25WYWwocHVrZVtqXSkgKyA0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzRXhpc3Q0ID0gajtqKys7Y29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGorKztcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpc0V4aXN0MSA+IDAgJiYgaXNFeGlzdDIgPiAwICYmIGlzRXhpc3QzID4gMCAmJiBpc0V4aXN0NCA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgaXRlbSA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChwdWtlW2ldKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2gocHVrZVtpc0V4aXN0MV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChwdWtlW2lzRXhpc3QyXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKHB1a2VbaXNFeGlzdDNdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2gocHVrZVtpc0V4aXN0NF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHB1a2VDb21iaWxlLnB1c2goaXRlbSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5TSFVOWklfNjpcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChwdWtlLmxlbmd0aCA8IDYpIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHB1a2UubGVuZ3RoIC0gNTsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgZmlyc3RWYWwgPSB0aGlzLkdldENhcmRDb21tb25WYWwocHVrZVtpXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmlyc3RWYWwgPj0gMTMpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGlzRXhpc3QxID0gMDt2YXIgaXNFeGlzdDIgPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGlzRXhpc3QzID0gMDt2YXIgaXNFeGlzdDQgPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGlzRXhpc3Q1ID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBqID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHdoaWxlIChqIDwgcHVrZS5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmlyc3RWYWwgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKHB1a2Vbal0pICsgMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0V4aXN0MSA9IGo7aisrO2NvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmlyc3RWYWwgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKHB1a2Vbal0pICsgMikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0V4aXN0MiA9IGo7aisrO2NvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmlyc3RWYWwgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKHB1a2Vbal0pICsgMykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0V4aXN0MyA9IGo7aisrO2NvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmlyc3RWYWwgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKHB1a2Vbal0pICsgNCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0V4aXN0NCA9IGo7aisrO2NvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmlyc3RWYWwgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKHB1a2Vbal0pICsgNSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0V4aXN0NSA9IGo7aisrO2NvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBqKys7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaXNFeGlzdDEgPiAwICYmIGlzRXhpc3QyID4gMCAmJiBpc0V4aXN0MyA+IDAgJiYgaXNFeGlzdDQgPiAwICYmIGlzRXhpc3Q1ID4gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBpdGVtID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKHB1a2VbaV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChwdWtlW2lzRXhpc3QxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKHB1a2VbaXNFeGlzdDJdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2gocHVrZVtpc0V4aXN0M10pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChwdWtlW2lzRXhpc3Q0XSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKHB1a2VbaXNFeGlzdDVdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwdWtlQ29tYmlsZS5wdXNoKGl0ZW0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhc2UgZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuU0hVTlpJXzc6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBpZiAocHVrZS5sZW5ndGggPCA3KSBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBwdWtlLmxlbmd0aCAtIDY7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGZpcnN0VmFsID0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKHB1a2VbaV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGZpcnN0VmFsID49IDEzKSBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBpc0V4aXN0MSA9IDA7dmFyIGlzRXhpc3QyID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBpc0V4aXN0MyA9IDA7dmFyIGlzRXhpc3Q0ID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBpc0V4aXN0NSA9IDA7dmFyIGlzRXhpc3Q2ID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBqID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHdoaWxlIChqIDwgcHVrZS5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmlyc3RWYWwgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKHB1a2Vbal0pICsgMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0V4aXN0MSA9IGo7aisrO2NvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmlyc3RWYWwgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKHB1a2Vbal0pICsgMikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0V4aXN0MiA9IGo7aisrO2NvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmlyc3RWYWwgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKHB1a2Vbal0pICsgMykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0V4aXN0MyA9IGo7aisrO2NvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmlyc3RWYWwgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKHB1a2Vbal0pICsgNCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0V4aXN0NCA9IGo7aisrO2NvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmlyc3RWYWwgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKHB1a2Vbal0pICsgNSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0V4aXN0NSA9IGo7aisrO2NvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmlyc3RWYWwgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKHB1a2Vbal0pICsgNikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0V4aXN0NiA9IGo7aisrO2NvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBqKys7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaXNFeGlzdDEgPiAwICYmIGlzRXhpc3QyID4gMCAmJiBpc0V4aXN0MyA+IDAgJiYgaXNFeGlzdDQgPiAwICYmIGlzRXhpc3Q1ID4gMCAmJiBpc0V4aXN0NiA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgaXRlbSA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChwdWtlW2ldKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2gocHVrZVtpc0V4aXN0MV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChwdWtlW2lzRXhpc3QyXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKHB1a2VbaXNFeGlzdDNdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2gocHVrZVtpc0V4aXN0NF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChwdWtlW2lzRXhpc3Q1XSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKHB1a2VbaXNFeGlzdDZdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwdWtlQ29tYmlsZS5wdXNoKGl0ZW0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhc2UgZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuU0hVTlpJXzg6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBpZiAocHVrZS5sZW5ndGggPCA4KSBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBwdWtlLmxlbmd0aCAtIDc7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGZpcnN0VmFsID0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKHB1a2VbaV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGZpcnN0VmFsID49IDEzKSBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBpc0V4aXN0MSA9IDA7dmFyIGlzRXhpc3QyID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBpc0V4aXN0MyA9IDA7dmFyIGlzRXhpc3Q0ID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBpc0V4aXN0NSA9IDA7dmFyIGlzRXhpc3Q2ID0gMDt2YXIgaXNFeGlzdDcgPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGogPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgd2hpbGUgKGogPCBwdWtlLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChmaXJzdFZhbCA9PSB0aGlzLkdldENhcmRDb21tb25WYWwocHVrZVtqXSkgKyAxKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzRXhpc3QxID0gajtqKys7Y29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChmaXJzdFZhbCA9PSB0aGlzLkdldENhcmRDb21tb25WYWwocHVrZVtqXSkgKyAyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzRXhpc3QyID0gajtqKys7Y29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChmaXJzdFZhbCA9PSB0aGlzLkdldENhcmRDb21tb25WYWwocHVrZVtqXSkgKyAzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzRXhpc3QzID0gajtqKys7Y29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChmaXJzdFZhbCA9PSB0aGlzLkdldENhcmRDb21tb25WYWwocHVrZVtqXSkgKyA0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzRXhpc3Q0ID0gajtqKys7Y29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChmaXJzdFZhbCA9PSB0aGlzLkdldENhcmRDb21tb25WYWwocHVrZVtqXSkgKyA1KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzRXhpc3Q1ID0gajtqKys7Y29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChmaXJzdFZhbCA9PSB0aGlzLkdldENhcmRDb21tb25WYWwocHVrZVtqXSkgKyA2KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzRXhpc3Q2ID0gajtqKys7Y29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChmaXJzdFZhbCA9PSB0aGlzLkdldENhcmRDb21tb25WYWwocHVrZVtqXSkgKyA3KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzRXhpc3Q3ID0gajtqKys7Y29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGorKztcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpc0V4aXN0MSA+IDAgJiYgaXNFeGlzdDIgPiAwICYmIGlzRXhpc3QzID4gMCAmJiBpc0V4aXN0NCA+IDAgJiYgaXNFeGlzdDUgPiAwICYmIGlzRXhpc3Q2ID4gMCAmJiBpc0V4aXN0NyA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgaXRlbSA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChwdWtlW2ldKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2gocHVrZVtpc0V4aXN0MV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChwdWtlW2lzRXhpc3QyXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKHB1a2VbaXNFeGlzdDNdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2gocHVrZVtpc0V4aXN0NF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChwdWtlW2lzRXhpc3Q1XSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKHB1a2VbaXNFeGlzdDZdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2gocHVrZVtpc0V4aXN0N10pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHB1a2VDb21iaWxlLnB1c2goaXRlbSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5TSFVOWklfOTpcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChwdWtlLmxlbmd0aCA8IDkpIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHB1a2UubGVuZ3RoIC0gODsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgZmlyc3RWYWwgPSB0aGlzLkdldENhcmRDb21tb25WYWwocHVrZVtpXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmlyc3RWYWwgPj0gMTMpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGlzRXhpc3QxID0gMDt2YXIgaXNFeGlzdDIgPSAwO3ZhciBpc0V4aXN0MyA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgaXNFeGlzdDQgPSAwO3ZhciBpc0V4aXN0NSA9IDA7dmFyIGlzRXhpc3Q2ID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBpc0V4aXN0NyA9IDA7dmFyIGlzRXhpc3Q4ID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBqID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHdoaWxlIChqIDwgcHVrZS5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmlyc3RWYWwgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKHB1a2Vbal0pICsgMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0V4aXN0MSA9IGo7aisrO2NvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmlyc3RWYWwgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKHB1a2Vbal0pICsgMikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0V4aXN0MiA9IGo7aisrO2NvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmlyc3RWYWwgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKHB1a2Vbal0pICsgMykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0V4aXN0MyA9IGo7aisrO2NvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmlyc3RWYWwgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKHB1a2Vbal0pICsgNCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0V4aXN0NCA9IGo7aisrO2NvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmlyc3RWYWwgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKHB1a2Vbal0pICsgNSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0V4aXN0NSA9IGo7aisrO2NvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmlyc3RWYWwgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKHB1a2Vbal0pICsgNikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0V4aXN0NiA9IGo7aisrO2NvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmlyc3RWYWwgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKHB1a2Vbal0pICsgNykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0V4aXN0NyA9IGo7aisrO2NvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmlyc3RWYWwgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKHB1a2Vbal0pICsgOCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0V4aXN0OCA9IGo7aisrO2NvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBqKys7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaXNFeGlzdDEgPiAwICYmIGlzRXhpc3QyID4gMCAmJiBpc0V4aXN0MyA+IDAgJiYgaXNFeGlzdDQgPiAwICYmIGlzRXhpc3Q1ID4gMCAmJiBpc0V4aXN0NiA+IDAgJiYgaXNFeGlzdDcgPiAwICYmIGlzRXhpc3Q4ID4gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBpdGVtID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKHB1a2VbaV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChwdWtlW2lzRXhpc3QxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKHB1a2VbaXNFeGlzdDJdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2gocHVrZVtpc0V4aXN0M10pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChwdWtlW2lzRXhpc3Q0XSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKHB1a2VbaXNFeGlzdDVdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2gocHVrZVtpc0V4aXN0Nl0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChwdWtlW2lzRXhpc3Q3XSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKHB1a2VbaXNFeGlzdDhdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwdWtlQ29tYmlsZS5wdXNoKGl0ZW0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhc2UgZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuU0hVTlpJXzEwOlxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHB1a2UubGVuZ3RoIDwgMTApIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHB1a2UubGVuZ3RoIC0gOTsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgZmlyc3RWYWwgPSB0aGlzLkdldENhcmRDb21tb25WYWwocHVrZVtpXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmlyc3RWYWwgPj0gMTMpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGlzRXhpc3QxID0gMDt2YXIgaXNFeGlzdDIgPSAwO3ZhciBpc0V4aXN0MyA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgaXNFeGlzdDQgPSAwO3ZhciBpc0V4aXN0NSA9IDA7dmFyIGlzRXhpc3Q2ID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBpc0V4aXN0NyA9IDA7dmFyIGlzRXhpc3Q4ID0gMDt2YXIgaXNFeGlzdDkgPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGogPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgd2hpbGUgKGogPCBwdWtlLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChmaXJzdFZhbCA9PSB0aGlzLkdldENhcmRDb21tb25WYWwocHVrZVtqXSkgKyAxKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzRXhpc3QxID0gajtqKys7Y29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChmaXJzdFZhbCA9PSB0aGlzLkdldENhcmRDb21tb25WYWwocHVrZVtqXSkgKyAyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzRXhpc3QyID0gajtqKys7Y29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChmaXJzdFZhbCA9PSB0aGlzLkdldENhcmRDb21tb25WYWwocHVrZVtqXSkgKyAzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzRXhpc3QzID0gajtqKys7Y29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChmaXJzdFZhbCA9PSB0aGlzLkdldENhcmRDb21tb25WYWwocHVrZVtqXSkgKyA0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzRXhpc3Q0ID0gajtqKys7Y29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChmaXJzdFZhbCA9PSB0aGlzLkdldENhcmRDb21tb25WYWwocHVrZVtqXSkgKyA1KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzRXhpc3Q1ID0gajtqKys7Y29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChmaXJzdFZhbCA9PSB0aGlzLkdldENhcmRDb21tb25WYWwocHVrZVtqXSkgKyA2KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzRXhpc3Q2ID0gajtqKys7Y29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChmaXJzdFZhbCA9PSB0aGlzLkdldENhcmRDb21tb25WYWwocHVrZVtqXSkgKyA3KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzRXhpc3Q3ID0gajtqKys7Y29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChmaXJzdFZhbCA9PSB0aGlzLkdldENhcmRDb21tb25WYWwocHVrZVtqXSkgKyA4KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzRXhpc3Q4ID0gajtqKys7Y29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChmaXJzdFZhbCA9PSB0aGlzLkdldENhcmRDb21tb25WYWwocHVrZVtqXSkgKyA5KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzRXhpc3Q5ID0gajtqKys7Y29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGorKztcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpc0V4aXN0MSA+IDAgJiYgaXNFeGlzdDIgPiAwICYmIGlzRXhpc3QzID4gMCAmJiBpc0V4aXN0NCA+IDAgJiYgaXNFeGlzdDUgPiAwICYmIGlzRXhpc3Q2ID4gMCAmJiBpc0V4aXN0NyA+IDAgJiYgaXNFeGlzdDggPiAwICYmIGlzRXhpc3Q5ID4gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBpdGVtID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKHB1a2VbaV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChwdWtlW2lzRXhpc3QxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKHB1a2VbaXNFeGlzdDJdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2gocHVrZVtpc0V4aXN0M10pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChwdWtlW2lzRXhpc3Q0XSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKHB1a2VbaXNFeGlzdDVdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2gocHVrZVtpc0V4aXN0Nl0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChwdWtlW2lzRXhpc3Q3XSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKHB1a2VbaXNFeGlzdDhdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2gocHVrZVtpc0V4aXN0OV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHB1a2VDb21iaWxlLnB1c2goaXRlbSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5TSFVOWklfMTE6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBpZiAocHVrZS5sZW5ndGggPCAxMSkgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgcHVrZS5sZW5ndGggLSAxMDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgZmlyc3RWYWwgPSB0aGlzLkdldENhcmRDb21tb25WYWwocHVrZVtpXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmlyc3RWYWwgPj0gMTMpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGlzRXhpc3QxID0gMDt2YXIgaXNFeGlzdDIgPSAwO3ZhciBpc0V4aXN0MyA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgaXNFeGlzdDQgPSAwO3ZhciBpc0V4aXN0NSA9IDA7dmFyIGlzRXhpc3Q2ID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBpc0V4aXN0NyA9IDA7dmFyIGlzRXhpc3Q4ID0gMDt2YXIgaXNFeGlzdDkgPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGlzRXhpc3QxMCA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgaiA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICB3aGlsZSAoaiA8IHB1a2UubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGZpcnN0VmFsID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChwdWtlW2pdKSArIDEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNFeGlzdDEgPSBqO2orKztjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGZpcnN0VmFsID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChwdWtlW2pdKSArIDIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNFeGlzdDIgPSBqO2orKztjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGZpcnN0VmFsID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChwdWtlW2pdKSArIDMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNFeGlzdDMgPSBqO2orKztjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGZpcnN0VmFsID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChwdWtlW2pdKSArIDQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNFeGlzdDQgPSBqO2orKztjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGZpcnN0VmFsID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChwdWtlW2pdKSArIDUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNFeGlzdDUgPSBqO2orKztjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGZpcnN0VmFsID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChwdWtlW2pdKSArIDYpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNFeGlzdDYgPSBqO2orKztjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGZpcnN0VmFsID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChwdWtlW2pdKSArIDcpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNFeGlzdDcgPSBqO2orKztjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGZpcnN0VmFsID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChwdWtlW2pdKSArIDgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNFeGlzdDggPSBqO2orKztjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGZpcnN0VmFsID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChwdWtlW2pdKSArIDkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNFeGlzdDkgPSBqO2orKztjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGZpcnN0VmFsID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChwdWtlW2pdKSArIDEwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzRXhpc3QxMCA9IGo7aisrO2NvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBqKys7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaXNFeGlzdDEgPiAwICYmIGlzRXhpc3QyID4gMCAmJiBpc0V4aXN0MyA+IDAgJiYgaXNFeGlzdDQgPiAwICYmIGlzRXhpc3Q1ID4gMCAmJiBpc0V4aXN0NiA+IDAgJiYgaXNFeGlzdDcgPiAwICYmIGlzRXhpc3Q4ID4gMCAmJiBpc0V4aXN0OSA+IDAgJiYgaXNFeGlzdDEwID4gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBpdGVtID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKHB1a2VbaV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChwdWtlW2lzRXhpc3QxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKHB1a2VbaXNFeGlzdDJdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2gocHVrZVtpc0V4aXN0M10pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChwdWtlW2lzRXhpc3Q0XSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKHB1a2VbaXNFeGlzdDVdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2gocHVrZVtpc0V4aXN0Nl0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChwdWtlW2lzRXhpc3Q3XSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKHB1a2VbaXNFeGlzdDhdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2gocHVrZVtpc0V4aXN0OV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChwdWtlW2lzRXhpc3QxMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHB1a2VDb21iaWxlLnB1c2goaXRlbSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5TSFVOWklfMTI6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBpZiAocHVrZS5sZW5ndGggPCAxMikgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgcHVrZS5sZW5ndGggLSAxMTsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgZmlyc3RWYWwgPSB0aGlzLkdldENhcmRDb21tb25WYWwocHVrZVtpXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmlyc3RWYWwgPj0gMTMpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGlzRXhpc3QxID0gMDt2YXIgaXNFeGlzdDIgPSAwO3ZhciBpc0V4aXN0MyA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgaXNFeGlzdDQgPSAwO3ZhciBpc0V4aXN0NSA9IDA7dmFyIGlzRXhpc3Q2ID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBpc0V4aXN0NyA9IDA7dmFyIGlzRXhpc3Q4ID0gMDt2YXIgaXNFeGlzdDkgPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGlzRXhpc3QxMCA9IDA7dmFyIGlzRXhpc3QxMSA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgaiA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICB3aGlsZSAoaiA8IHB1a2UubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGZpcnN0VmFsID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChwdWtlW2pdKSArIDEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNFeGlzdDEgPSBqO2orKztjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGZpcnN0VmFsID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChwdWtlW2pdKSArIDIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNFeGlzdDIgPSBqO2orKztjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGZpcnN0VmFsID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChwdWtlW2pdKSArIDMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNFeGlzdDMgPSBqO2orKztjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGZpcnN0VmFsID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChwdWtlW2pdKSArIDQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNFeGlzdDQgPSBqO2orKztjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGZpcnN0VmFsID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChwdWtlW2pdKSArIDUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNFeGlzdDUgPSBqO2orKztjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGZpcnN0VmFsID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChwdWtlW2pdKSArIDYpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNFeGlzdDYgPSBqO2orKztjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGZpcnN0VmFsID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChwdWtlW2pdKSArIDcpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNFeGlzdDcgPSBqO2orKztjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGZpcnN0VmFsID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChwdWtlW2pdKSArIDgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNFeGlzdDggPSBqO2orKztjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGZpcnN0VmFsID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChwdWtlW2pdKSArIDkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNFeGlzdDkgPSBqO2orKztjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGZpcnN0VmFsID09IHRoaXMuR2V0Q2FyZENvbW1vblZhbChwdWtlW2pdKSArIDEwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzRXhpc3QxMCA9IGo7aisrO2NvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmlyc3RWYWwgPT0gdGhpcy5HZXRDYXJkQ29tbW9uVmFsKHB1a2Vbal0pICsgMTEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNFeGlzdDExID0gajtqKys7Y29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGorKztcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpc0V4aXN0MSA+IDAgJiYgaXNFeGlzdDIgPiAwICYmIGlzRXhpc3QzID4gMCAmJiBpc0V4aXN0NCA+IDAgJiYgaXNFeGlzdDUgPiAwICYmIGlzRXhpc3Q2ID4gMCAmJiBpc0V4aXN0NyA+IDAgJiYgaXNFeGlzdDggPiAwICYmIGlzRXhpc3Q5ID4gMCAmJiBpc0V4aXN0MTAgPiAwICYmIGlzRXhpc3QxMSA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgaXRlbSA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChwdWtlW2ldKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2gocHVrZVtpc0V4aXN0MV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChwdWtlW2lzRXhpc3QyXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKHB1a2VbaXNFeGlzdDNdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2gocHVrZVtpc0V4aXN0NF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChwdWtlW2lzRXhpc3Q1XSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKHB1a2VbaXNFeGlzdDZdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2gocHVrZVtpc0V4aXN0N10pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChwdWtlW2lzRXhpc3Q4XSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKHB1a2VbaXNFeGlzdDldKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2gocHVrZVtpc0V4aXN0MTBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2gocHVrZVtpc0V4aXN0MTFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwdWtlQ29tYmlsZS5wdXNoKGl0ZW0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhc2UgZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuU0hJUF9TOlxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHB1a2UubGVuZ3RoIDwgNikgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgcHVrZS5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChwdWtlW2ldKSAhPT0gdGhpcy5HZXRDYXJkVmFsKHB1a2VbaSArIDFdKSB8fCB0aGlzLkdldENhcmRWYWwocHVrZVtpICsgMV0pICE9PSB0aGlzLkdldENhcmRWYWwocHVrZVtpICsgMl0pIHx8IHRoaXMuR2V0Q2FyZFZhbChwdWtlW2kgKyAyXSkgIT09IHRoaXMuR2V0Q2FyZFZhbChwdWtlW2kgKyAzXSkpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaiA9IDA7IGogPCBwdWtlLmxlbmd0aDsgaisrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChwdWtlW2ldKSA9PSB0aGlzLkdldENhcmRWYWwocHVrZVtqXSkpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIF9rOCA9IDA7IF9rOCA8IHB1a2UubGVuZ3RoOyBfazgrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKHB1a2VbaV0pID09IHRoaXMuR2V0Q2FyZFZhbChwdWtlW19rOF0pIHx8IHRoaXMuR2V0Q2FyZFZhbChwdWtlW2pdKSA9PSB0aGlzLkdldENhcmRWYWwocHVrZVtfazhdKSkgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBpdGVtID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0gPSBwdWtlLnNsaWNlKGksIGkgKyA0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKHB1a2Vbal0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2gocHVrZVtfazhdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHVrZUNvbWJpbGUucHVzaChpdGVtKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSBnYW1lQ29uc3REZWYuQ0FSRFNfVFlQRS5TSElQX1M6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBpZiAocHVrZS5sZW5ndGggPCA4KSBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgdmFyIGFsbFhYID0gdGhpcy5HZXRDYXJkc1R5cGVYWChwdWtlKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGFsbFhYLmxlbmd0aCA8IDIpIGJyZWFrO1xuXG4gICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgcHVrZS5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuR2V0Q2FyZFZhbChwdWtlW2ldKSAhPT0gdGhpcy5HZXRDYXJkVmFsKHB1a2VbaSArIDFdKSB8fCB0aGlzLkdldENhcmRWYWwocHVrZVtpICsgMV0pICE9PSB0aGlzLkdldENhcmRWYWwocHVrZVtpICsgMl0pIHx8IHRoaXMuR2V0Q2FyZFZhbChwdWtlW2kgKyAyXSkgIT09IHRoaXMuR2V0Q2FyZFZhbChwdWtlW2kgKyAzXSkpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaiA9IDA7IGogPCBhbGxYWC5sZW5ndGg7IGorKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwoYWxsWFhbal1bMF0pID09IHRoaXMuR2V0Q2FyZFZhbChwdWtlW2ldKSkgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgX2s5ID0gMDsgX2s5IDwgYWxsWFgubGVuZ3RoOyBfazkrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5HZXRDYXJkVmFsKGFsbFhYW19rOV1bMF0pID09IHRoaXMuR2V0Q2FyZFZhbChwdWtlW2ldKSB8fCB0aGlzLkdldENhcmRWYWwoYWxsWFhbX2s5XVswXSkgPT0gdGhpcy5HZXRDYXJkVmFsKGFsbFhYW2pdWzBdKSkgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBpdGVtID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0gPSBwdWtlLnNsaWNlKGksIGkgKyA0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2pdWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW2pdWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5wdXNoKGFsbFhYW19rOV1bMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnB1c2goYWxsWFhbX2s5XVsxXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHB1a2VDb21iaWxlLnB1c2goaXRlbSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhc2UgZ2FtZUNvbnN0RGVmLkNBUkRTX1RZUEUuQk9NQjpcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChwdWtlLmxlbmd0aCA8IDQpIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHB1a2UubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLkdldENhcmRWYWwocHVrZVtpXSkgPT0gdGhpcy5HZXRDYXJkVmFsKHB1a2VbaSArIDFdKSAmJiB0aGlzLkdldENhcmRWYWwocHVrZVtpICsgMV0pID09IHRoaXMuR2V0Q2FyZFZhbChwdWtlW2kgKyAyXSkgJiYgdGhpcy5HZXRDYXJkVmFsKHB1a2VbaSArIDJdKSA9PSB0aGlzLkdldENhcmRWYWwocHVrZVtpICsgM10pKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGl0ZW0gPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtID0gcHVrZS5zbGljZShpLCBpICsgNCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHVrZUNvbWJpbGUucHVzaChpdGVtKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlIGdhbWVDb25zdERlZi5DQVJEU19UWVBFLlJPQ0tFVDpcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChwdWtlLmxlbmd0aCA8IDIpIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICBpZiAocHVrZVswXSA9PSAweDVGICYmIHB1a2VbMV0gPT0gMHg1RSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGl0ZW0gPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChwdWtlWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucHVzaChwdWtlWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHB1a2VDb21iaWxlLnB1c2goaXRlbSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBwdWtlQ29tYmlsZTtcbiAgICB9XG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzk2Nzg5Y3A5b1ZLZDYveVkyVGxPY2VIJywgJ1lpbmdzYW56aGFuZ0dhbWVNZXNzYWdlJyk7XG4vLyByZXNvdXJjZXMvR2FtZXMvWWluZ3NhbnpoYW5nL3NyYy9ZaW5nc2FuemhhbmdHYW1lTWVzc2FnZS5qc1xuXG52YXIgY29uc3REZWYgPSByZXF1aXJlKFwiQ29uc3REZWZcIik7XG52YXIgUHJvdG9jb2xNZXNzYWdlID0gcmVxdWlyZShcIlByb3RvY29sTWVzc2FnZVwiKTtcbnZhciBnYW1lQ29uc3REZWYgPSByZXF1aXJlKFwiWWluZ3NhbnpoYW5nQ29uc3REZWZcIik7XG5cbnZhciBHYW1lTWVzc2FnZSA9IHtcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgaGFuZGxlcl9HRVRfR0FNRV9JTkZPX1NVQ0NFU1M6IGZ1bmN0aW9uIGhhbmRsZXJfR0VUX0dBTUVfSU5GT19TVUNDRVNTKGV2ZW50KSB7XG4gICAgICAgIHZhciBib2R5TXNnID0gZXZlbnQuZGV0YWlsLm1zZ0JvZHk7XG4gICAgICAgIHZhciBpbnN0YW5jZUdsb2JhbCA9IGV2ZW50LmRldGFpbC5pbnN0YW5jZUdsb2JhbDtcbiAgICAgICAgdmFyIGdhbWVEYXRhID0gaW5zdGFuY2VHbG9iYWwuR2V0R2FtZURhdGEoaW5zdGFuY2VHbG9iYWwuc2VsZkRhdGEubkN1ckdhbWVJRCk7XG5cbiAgICAgICAgdmFyIGluZGV4ID0gNTtcbiAgICAgICAgZ2FtZURhdGEubkZkaWFtb25kSCA9IGJvZHlNc2dbaW5kZXgrK10uX2ludF92YWx1ZTtcbiAgICAgICAgZ2FtZURhdGEubkZkaWFtb25kTCA9IGJvZHlNc2dbaW5kZXgrK10uX2ludF92YWx1ZTtcbiAgICAgICAgZ2FtZURhdGEubkZjb2luSCA9IGJvZHlNc2dbaW5kZXgrK10uX2ludF92YWx1ZTtcbiAgICAgICAgZ2FtZURhdGEubkZjb2luTCA9IGJvZHlNc2dbaW5kZXgrK10uX2ludF92YWx1ZTtcblxuICAgICAgICBpZiAoZ2FtZURhdGEubkZiZWdpbm5lcl9mbGFnID4gMCkge1xuICAgICAgICAgICAgdmFyIGN1ckNvbXAgPSBpbnN0YW5jZUdsb2JhbC5sb2FkLmdldENvbXBvbmVudChcIkxvYWRNYW5hZ2VyXCIpO1xuICAgICAgICAgICAgY3VyQ29tcC5PcGVuR2FtZShpbnN0YW5jZUdsb2JhbC5zZWxmRGF0YS5uQ3VyR2FtZUlEKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHZhciBjdXJDb21wID0gaW5zdGFuY2VHbG9iYWwubG9hZC5nZXRDb21wb25lbnQoXCJMb2FkTWFuYWdlclwiKTtcbiAgICAgICAgICAgIGN1ckNvbXAuU2hvdygnemhhamluaHVhX2d1aWRlJyk7XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICBoYW5kbGVyX0dFVF9HQU1FX0lORk9fRkFJTEVEOiBmdW5jdGlvbiBoYW5kbGVyX0dFVF9HQU1FX0lORk9fRkFJTEVEKGV2ZW50KSB7XG4gICAgICAgIGNjLmxvZyhcImhhbmRsZXJfR0VUX0dBTUVfSU5GT19GQUlMRURcIik7XG5cbiAgICAgICAgdmFyIGJvZHlNc2cgPSBldmVudC5kZXRhaWwubXNnQm9keTtcbiAgICAgICAgdmFyIGluc3RhbmNlR2xvYmFsID0gZXZlbnQuZGV0YWlsLmluc3RhbmNlR2xvYmFsO1xuICAgIH0sXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIGhhbmRsZXJfR0VUX1BMQVlFUlNfQkFTRV9JTkZPX1NVQ0NFU1M6IGZ1bmN0aW9uIGhhbmRsZXJfR0VUX1BMQVlFUlNfQkFTRV9JTkZPX1NVQ0NFU1MoZXZlbnQpIHtcbiAgICAgICAgY2MubG9nKFwiaGFuZGxlcl9HRVRfUExBWUVSU19CQVNFX0lORk9fU1VDQ0VTU1wiKTtcbiAgICAgICAgdmFyIGJvZHlNc2cgPSBldmVudC5kZXRhaWwubXNnQm9keTtcbiAgICAgICAgdmFyIGluc3RhbmNlR2xvYmFsID0gZXZlbnQuZGV0YWlsLmluc3RhbmNlR2xvYmFsO1xuICAgICAgICB2YXIgZ2FtZURhdGEgPSBpbnN0YW5jZUdsb2JhbC5HZXRHYW1lRGF0YShpbnN0YW5jZUdsb2JhbC5zZWxmRGF0YS5uQ3VyR2FtZUlEKTtcblxuICAgICAgICB2YXIgaW5kZXggPSAwO1xuICAgICAgICB2YXIgaXRlbSA9IHt9O1xuICAgICAgICB2YXIgbkFjY291bnRJRCA9IGJvZHlNc2dbaW5kZXgrK10uX2ludF92YWx1ZTtcbiAgICAgICAgdmFyIHRlYW1zTGlzdCA9IGdhbWVEYXRhLnZlY3RUZWFtTGlzdDtcbiAgICAgICAgdmFyIHRlYW1zQ291bnQgPSB0ZWFtc0xpc3QubGVuZ3RoO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHRlYW1zQ291bnQ7IGkrKykge1xuICAgICAgICAgICAgaWYgKG5BY2NvdW50SUQgPT09IHRlYW1zTGlzdFtpXS5uQWNjb3VudElEKSB7XG4gICAgICAgICAgICAgICAgdGVhbXNMaXN0W2ldLm5pY2sgPSBib2R5TXNnW2luZGV4KytdLl9zdHJfdmFsdWU7XG4gICAgICAgICAgICAgICAgdGVhbXNMaXN0W2ldLm5TZXggPSBib2R5TXNnW2luZGV4KytdLl9pbnRfdmFsdWU7XG4gICAgICAgICAgICAgICAgdGVhbXNMaXN0W2ldLm5GaGVhZCA9IGJvZHlNc2dbaW5kZXgrK10uX2ludF92YWx1ZTtcbiAgICAgICAgICAgICAgICB0ZWFtc0xpc3RbaV0uc0ZjdXN0b21faGVhZCA9IGJvZHlNc2dbaW5kZXgrK10uX2ludF92YWx1ZTtcbiAgICAgICAgICAgICAgICB2YXIgblZhbEggPSBib2R5TXNnW2luZGV4KytdLl9pbnRfdmFsdWU7XG4gICAgICAgICAgICAgICAgdmFyIG5WYWxMID0gYm9keU1zZ1tpbmRleCsrXS5faW50X3ZhbHVlO1xuICAgICAgICAgICAgICAgIHZhciBudmFsID0gYm9keU1zZ1tpbmRleCsrXS5faW50X3ZhbHVlO1xuICAgICAgICAgICAgICAgIHRlYW1zTGlzdFtpXS5uVG90YWxNb25leSA9IGJvZHlNc2dbaW5kZXgrK10uX2ludF92YWx1ZTtcbiAgICAgICAgICAgICAgICB0ZWFtc0xpc3RbaV0ubkNvaW5IID0gYm9keU1zZ1tpbmRleCsrXS5faW50X3ZhbHVlO1xuICAgICAgICAgICAgICAgIHRlYW1zTGlzdFtpXS5uQ29pbkwgPSBib2R5TXNnW2luZGV4KytdLl9pbnRfdmFsdWU7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZ2FtZURhdGEuUmVmcmVzaFBsYXllckRhdGEoKTtcbiAgICB9LFxuXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIGhhbmRsZXJfR0VUX1BMQVlFUlNfQkFTRV9JTkZPX0ZBSUxFRDogZnVuY3Rpb24gaGFuZGxlcl9HRVRfUExBWUVSU19CQVNFX0lORk9fRkFJTEVEKGV2ZW50KSB7XG4gICAgICAgIHZhciBib2R5TXNnID0gZXZlbnQuZGV0YWlsLm1zZ0JvZHk7XG4gICAgICAgIHZhciBpbnN0YW5jZUdsb2JhbCA9IGV2ZW50LmRldGFpbC5pbnN0YW5jZUdsb2JhbDtcbiAgICB9LFxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICBoYW5kbGVyX0dFVF9URUFNX01FTUJFUlNfU1VDQ0VTUzogZnVuY3Rpb24gaGFuZGxlcl9HRVRfVEVBTV9NRU1CRVJTX1NVQ0NFU1MoZXZlbnQpIHtcbiAgICAgICAgY2MubG9nKFwiaGFuZGxlcl9HRVRfVEVBTV9NRU1CRVJTX1NVQ0NFU1NcIik7XG4gICAgICAgIHZhciBib2R5TXNnID0gZXZlbnQuZGV0YWlsLm1zZ0JvZHk7XG4gICAgICAgIHZhciBpbnN0YW5jZUdsb2JhbCA9IGV2ZW50LmRldGFpbC5pbnN0YW5jZUdsb2JhbDtcbiAgICAgICAgdmFyIGdhbWVEYXRhID0gaW5zdGFuY2VHbG9iYWwuR2V0R2FtZURhdGEoaW5zdGFuY2VHbG9iYWwuc2VsZkRhdGEubkN1ckdhbWVJRCk7XG5cbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBib2R5TXNnLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICB2YXIgdmVjdExpc3QgPSBib2R5TXNnW2ldLl92ZWN0X3ZhbHVlO1xuICAgICAgICAgICAgdmFyIGluZGV4ID0gMDtcbiAgICAgICAgICAgIHZhciBuVGVhbUlEID0gdmVjdExpc3RbaW5kZXgrK10uX2ludF92YWx1ZTtcbiAgICAgICAgICAgIHZhciBuQWNjb3VudElEID0gdmVjdExpc3RbaW5kZXgrK10uX2ludF92YWx1ZTtcbiAgICAgICAgICAgIHZhciB0ZWFtTGlzdCA9IGdhbWVEYXRhLnZlY3RUZWFtTGlzdDtcbiAgICAgICAgICAgIGZvciAodmFyIGogPSAwOyBqIDwgdGVhbUxpc3QubGVuZ3RoOyBqKyspIHtcbiAgICAgICAgICAgICAgICBpZiAoblRlYW1JRCA9PSB0ZWFtTGlzdFtqXS5uVGVhbUlEKSB7XG4gICAgICAgICAgICAgICAgICAgIHRlYW1MaXN0W2pdLm5BY2NvdW50SUQgPSBuQWNjb3VudElEO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaW5zdGFuY2VHbG9iYWwuR2V0R2FtZUNvbnRyb2xsZXIoaW5zdGFuY2VHbG9iYWwuc2VsZkRhdGEubkN1ckdhbWVJRCkuU2VuZE1zZyhjb25zdERlZi5DT05ORUNUX0NBTExCQUNLX1NUQVRVUy5MT0dPTl9HRVRfUExBWUVSU19CQVNFX0lORk8pO1xuICAgIH0sXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICBoYW5kbGVyX0dFVF9URUFNX01FTUJFUlNfRkFJTEVEOiBmdW5jdGlvbiBoYW5kbGVyX0dFVF9URUFNX01FTUJFUlNfRkFJTEVEKGV2ZW50KSB7XG4gICAgICAgIHZhciBib2R5TXNnID0gZXZlbnQuZGV0YWlsLm1zZ0JvZHk7XG4gICAgICAgIHZhciBpbnN0YW5jZUdsb2JhbCA9IGV2ZW50LmRldGFpbC5pbnN0YW5jZUdsb2JhbDtcbiAgICB9LFxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgaGFuZGxlcl9HRVRfTUFUQ0hfREFUQV9OT1RJRlk6IGZ1bmN0aW9uIGhhbmRsZXJfR0VUX01BVENIX0RBVEFfTk9USUZZKGV2ZW50KSB7XG4gICAgICAgIGNjLmxvZyhcImhhbmRsZXJfR0VUX01BVENIX0RBVEFfTk9USUZZXCIpO1xuICAgICAgICB2YXIgYm9keU1zZyA9IGV2ZW50LmRldGFpbC5tc2dCb2R5O1xuICAgICAgICB2YXIgaW5zdGFuY2VHbG9iYWwgPSBldmVudC5kZXRhaWwuaW5zdGFuY2VHbG9iYWw7XG4gICAgICAgIHZhciBnYW1lRGF0YSA9IGluc3RhbmNlR2xvYmFsLkdldEdhbWVEYXRhKGluc3RhbmNlR2xvYmFsLnNlbGZEYXRhLm5DdXJHYW1lSUQpO1xuXG4gICAgICAgIHZhciBpbmRleCA9IDA7XG4gICAgICAgIGlmIChib2R5TXNnLmxlbmd0aCA+IDEpIC8vIOacquaKpeWQjeWPquS8oOS4gOS4quWtl+autSAgIG5NYXRjaFNpZ25UUz0wXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgdmFyIG5NYXRjaFNpZ25UUyA9IGJvZHlNc2dbaW5kZXgrK10uX2ludF92YWx1ZTtcbiAgICAgICAgICAgICAgICB2YXIgbk1hdGNoRmxhZyA9IGJvZHlNc2dbaW5kZXgrK10uX2ludF92YWx1ZTtcbiAgICAgICAgICAgICAgICB2YXIgblRlYW1JRCA9IGJvZHlNc2dbaW5kZXgrK10uX2ludF92YWx1ZTtcbiAgICAgICAgICAgICAgICB2YXIgbk1hdGNoU3RhdHVzID0gYm9keU1zZ1tpbmRleCsrXS5faW50X3ZhbHVlO1xuICAgICAgICAgICAgICAgIHZhciBuTWF0Y2hTdGF0dXNUUyA9IGJvZHlNc2dbaW5kZXgrK10uX2ludF92YWx1ZTtcbiAgICAgICAgICAgICAgICB2YXIgbk1hdGNoUmVtYWluQ291bnQgPSBib2R5TXNnW2luZGV4KytdLl9pbnRfdmFsdWU7XG4gICAgICAgICAgICAgICAgdmFyIG5NYXRjaFJhbmsgPSBib2R5TXNnW2luZGV4KytdLl9pbnRfdmFsdWU7XG5cbiAgICAgICAgICAgICAgICBpZiAobk1hdGNoRmxhZyA9PSBjb25zdERlZi5NQVRDSF9SRVNVTFQuTk9ORSB8fCBuVGVhbUlEID09IGdhbWVEYXRhLm5UZWFtSUQpIHtcbiAgICAgICAgICAgICAgICAgICAgZ2FtZURhdGEubk1hdGNoVFMgPSBuTWF0Y2hTaWduVFM7XG4gICAgICAgICAgICAgICAgICAgIGdhbWVEYXRhLm5NYXRjaEZsYWcgPSBuTWF0Y2hGbGFnO1xuICAgICAgICAgICAgICAgICAgICBnYW1lRGF0YS5uVGVhbUlEID0gblRlYW1JRDtcbiAgICAgICAgICAgICAgICAgICAgZ2FtZURhdGEubk1hdGNoU3RhdHVzID0gbk1hdGNoU3RhdHVzO1xuICAgICAgICAgICAgICAgICAgICBnYW1lRGF0YS5uTWF0Y2hTdGF0dXNUUyA9IG5NYXRjaFN0YXR1c1RTO1xuICAgICAgICAgICAgICAgICAgICBnYW1lRGF0YS5uTWF0Y2hSZW1haW5Db3VudCA9IG5NYXRjaFJlbWFpbkNvdW50O1xuICAgICAgICAgICAgICAgICAgICBnYW1lRGF0YS5uTWF0Y2hSYW5rID0gbk1hdGNoUmFuaztcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBpZiAobk1hdGNoRmxhZyA+PSBjb25zdERlZi5NQVRDSF9SRVNVTFQuT3V0QXRPbmNlX09VVCAmJiBuTWF0Y2hGbGFnIDw9IGNvbnN0RGVmLk1BVENIX1JFU1VMVC5GaXhlZFJvdW5kX1dJTikge1xuICAgICAgICAgICAgICAgICAgICBnYW1lRGF0YS5SZWZyZXNoRGF0YSgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICB9LFxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgaGFuZGxlcl9HRVRfTUFUQ0hfQ1VSX0NPVU5UX1NVQ0NFU1M6IGZ1bmN0aW9uIGhhbmRsZXJfR0VUX01BVENIX0NVUl9DT1VOVF9TVUNDRVNTKGV2ZW50KSB7XG4gICAgICAgIHZhciBib2R5TXNnID0gZXZlbnQuZGV0YWlsLm1zZ0JvZHk7XG4gICAgICAgIHZhciBpbnN0YW5jZUdsb2JhbCA9IGV2ZW50LmRldGFpbC5pbnN0YW5jZUdsb2JhbDtcbiAgICAgICAgdmFyIGdhbWVEYXRhID0gaW5zdGFuY2VHbG9iYWwuR2V0R2FtZURhdGEoaW5zdGFuY2VHbG9iYWwuc2VsZkRhdGEubkN1ckdhbWVJRCk7XG5cbiAgICAgICAgdmFyIGluZGV4ID0gMDtcbiAgICAgICAgdmFyIG5NYXRjaFRTID0gYm9keU1zZ1tpbmRleCsrXS5faW50X3ZhbHVlO1xuICAgICAgICB2YXIgbk1hdGNoQ3VyU2lnbkNvdW50ID0gYm9keU1zZ1tpbmRleCsrXS5faW50X3ZhbHVlO1xuICAgICAgICBnYW1lRGF0YS5uTWF0Y2hDdXJTaWduQ291bnQgPSBuTWF0Y2hDdXJTaWduQ291bnQ7XG4gICAgICAgIGdhbWVEYXRhLlJlZnJlc2hHYW1lV2FpdCgpO1xuICAgIH0sXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICBoYW5kbGVyX0JBTEFOQ0VfTk9USUZZOiBmdW5jdGlvbiBoYW5kbGVyX0JBTEFOQ0VfTk9USUZZKGV2ZW50KSB7XG4gICAgICAgIGNjLmxvZyhcImhhbmRsZXJfQkFMQU5DRV9OT1RJRllcIik7XG4gICAgICAgIHZhciBib2R5TXNnID0gZXZlbnQuZGV0YWlsLm1zZ0JvZHk7XG4gICAgICAgIHZhciBpbnN0YW5jZUdsb2JhbCA9IGV2ZW50LmRldGFpbC5pbnN0YW5jZUdsb2JhbDtcbiAgICAgICAgdmFyIGdhbWVEYXRhID0gaW5zdGFuY2VHbG9iYWwuR2V0R2FtZURhdGEoaW5zdGFuY2VHbG9iYWwuc2VsZkRhdGEubkN1ckdhbWVJRCk7XG5cbiAgICAgICAgaWYgKGJvZHlNc2cubGVuZ3RoID4gMSkge1xuICAgICAgICAgICAgdmFyIGluZGV4ID0gMDtcbiAgICAgICAgICAgIHZhciBuQWNjb3VudElEID0gYm9keU1zZ1tpbmRleCsrXS5faW50X3ZhbHVlO1xuICAgICAgICAgICAgdmFyIG5UeXBlID0gYm9keU1zZ1tpbmRleCsrXS5faW50X3ZhbHVlO1xuICAgICAgICAgICAgaWYgKG5UeXBlID09IGNvbnN0RGVmLkZJR0hUX1JFU1VMVC5NQVRDSF9SRVZPS0UpIC8vIOavlOi1m+ino+aVo1xuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgZ2FtZURhdGEubk1hdGNoVFMgPSAwO1xuICAgICAgICAgICAgICAgICAgICBnYW1lRGF0YS5SZWZyZXNoR2FtZVdhaXQoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9LFxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgaGFuZGxlcl9FTlRFUl9ST09NX1NVQ0NFU1M6IGZ1bmN0aW9uIGhhbmRsZXJfRU5URVJfUk9PTV9TVUNDRVNTKGV2ZW50KSB7XG4gICAgICAgIGNjLmxvZyhcImhhbmRsZXJfRU5URVJfUk9PTV9TVUNDRVNTXCIpO1xuICAgICAgICB2YXIgYm9keU1zZyA9IGV2ZW50LmRldGFpbC5tc2dCb2R5O1xuICAgICAgICB2YXIgaW5zdGFuY2VHbG9iYWwgPSBldmVudC5kZXRhaWwuaW5zdGFuY2VHbG9iYWw7XG4gICAgICAgIHZhciBnYW1lRGF0YSA9IGluc3RhbmNlR2xvYmFsLkdldEdhbWVEYXRhKGluc3RhbmNlR2xvYmFsLnNlbGZEYXRhLm5DdXJHYW1lSUQpO1xuXG4gICAgICAgIGlmIChpbnN0YW5jZUdsb2JhbC5jb25mRGF0YS5iSG9sZFBsYXllcnNJbmZvID09PSB0cnVlKSB7XG4gICAgICAgICAgICB2YXIgbXNnID0gbmV3IFByb3RvY29sTWVzc2FnZShjb25zdERlZi5NRVNTQUdFLkNNRF9NQUlOX1BMQVRGT1JNLCBjb25zdERlZi5NRVNTQUdFLkdFVF9ST09NX1BMQVlFUlNfUkVRLCBmYWxzZSk7XG4gICAgICAgICAgICBpbnN0YW5jZUdsb2JhbC5Tb2NrZXRNYW5hZ2VyLlNlbmRNZXNzYWdlKGNvbnN0RGVmLlNFUlZFUl9VUkwuZ2FtZSwgbXNnKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGdhbWVEYXRhLkNsZWFyQmF0dGxlRGF0YSgpO1xuXG4gICAgICAgIGlmIChib2R5TXNnLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIGdhbWVEYXRhLkluaXRCYXR0bGVEYXRhKGJvZHlNc2cpO1xuICAgICAgICAgICAgdmFyIGN1ckNvbXAgPSBpbnN0YW5jZUdsb2JhbC5sb2FkLmdldENvbXBvbmVudChcIkxvYWRNYW5hZ2VyXCIpO1xuICAgICAgICAgICAgY3VyQ29tcC5TaG93KCdZaW5nc2Fuemhhbmdfd2FyJyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBpZiAoZ2FtZURhdGEubk9wZW5Nb2RlID09IGNvbnN0RGVmLkJBVFRMRV9PUEVOX01PREUuTUFUQ0gpIHtcbiAgICAgICAgICAgICAgICB2YXIgY3VyQ29tcCA9IGluc3RhbmNlR2xvYmFsLmxvYWQuZ2V0Q29tcG9uZW50KFwiTG9hZE1hbmFnZXJcIik7XG4gICAgICAgICAgICAgICAgY3VyQ29tcC5TaG93KCdZaW5nc2FuemhhbmdfZ2FtZVdhaXQnKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdmFyIG1zZzIgPSBuZXcgUHJvdG9jb2xNZXNzYWdlKGNvbnN0RGVmLk1FU1NBR0UuQ01EX01BSU5fR0FNRSwgY29uc3REZWYuTUVTU0FHRS5FTlRFUl9CQVRUTEVfUkVRLCBmYWxzZSk7XG4gICAgICAgICAgICAgICAgUHJvdG9jb2xNZXNzYWdlLkFkZFZlY3RJdGVtSW50KG1zZzIuX2JvZHlfbXNnLCAwKTsgLy8g5b+r6YCf5Yqg5YWl77yM5qGM5a2QSUTkuLowXG4gICAgICAgICAgICAgICAgaW5zdGFuY2VHbG9iYWwuU29ja2V0TWFuYWdlci5TZW5kTWVzc2FnZShjb25zdERlZi5TRVJWRVJfVVJMLmdhbWUsIG1zZzIpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSxcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIGhhbmRsZXJfRU5URVJfUk9PTV9GQUlMRUQ6IGZ1bmN0aW9uIGhhbmRsZXJfRU5URVJfUk9PTV9GQUlMRUQoZXZlbnQpIHtcbiAgICAgICAgdmFyIGJvZHlNc2cgPSBldmVudC5kZXRhaWwubXNnQm9keTtcbiAgICAgICAgdmFyIGluc3RhbmNlR2xvYmFsID0gZXZlbnQuZGV0YWlsLmluc3RhbmNlR2xvYmFsO1xuXG4gICAgICAgIHZhciBoaW50Q29tcCA9IGluc3RhbmNlR2xvYmFsLmhpbnQuZ2V0Q29tcG9uZW50KFwiSGludE1hbmFnZXJcIik7XG4gICAgICAgIGhpbnRDb21wLlNob3dIaW50KFwi6L+b5YWl5pyN5Yqh5Zmo5aSx6LSl77yBXCIpO1xuICAgIH0sXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIGhhbmRsZXJfUExBWUVSX0VOVEVSX1JPT01fTk9USUZZOiBmdW5jdGlvbiBoYW5kbGVyX1BMQVlFUl9FTlRFUl9ST09NX05PVElGWShldmVudCkge1xuICAgICAgICBjYy5sb2coXCJoYW5kbGVyX1BMQVlFUl9FTlRFUl9ST09NX05PVElGWVwiKTtcbiAgICAgICAgdmFyIGJvZHlNc2cgPSBldmVudC5kZXRhaWwubXNnQm9keTtcbiAgICAgICAgdmFyIGluc3RhbmNlR2xvYmFsID0gZXZlbnQuZGV0YWlsLmluc3RhbmNlR2xvYmFsO1xuICAgICAgICB2YXIgZ2FtZURhdGEgPSBpbnN0YW5jZUdsb2JhbC5HZXRHYW1lRGF0YShpbnN0YW5jZUdsb2JhbC5zZWxmRGF0YS5uQ3VyR2FtZUlEKTtcblxuICAgICAgICB2YXIgaW5kZXggPSAwO1xuICAgICAgICB2YXIgbkFjY291bnRJRCA9IGJvZHlNc2dbaW5kZXgrK10uX2ludF92YWx1ZTtcbiAgICAgICAgdmFyIG5UZWFtSUQgPSBib2R5TXNnW2luZGV4KytdLl9pbnRfdmFsdWU7XG5cbiAgICAgICAgdmFyIGl0ZW0gPSB7fTtcbiAgICAgICAgdmFyIHBsYXllcnMgPSBpbnN0YW5jZUdsb2JhbC5zZWxmRGF0YS5wbGF5ZXJzO1xuICAgICAgICB2YXIgcGxheWVyc0NvdW50ID0gcGxheWVycy5sZW5ndGg7XG5cbiAgICAgICAgaWYgKGluc3RhbmNlR2xvYmFsLmNvbmZEYXRhLmJIb2xkUGxheWVyc0luZm8gPT09IHRydWUpIHtcbiAgICAgICAgICAgIHZhciBpc0V4c2l0ID0gZmFsc2U7XG4gICAgICAgICAgICBpdGVtLm5BY2NvdW50SUQgPSBib2R5TXNnW2luZGV4XS5faW50X3ZhbHVlO1xuICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBwbGF5ZXJzQ291bnQ7IGkrKykge1xuICAgICAgICAgICAgICAgIGlmIChpdGVtLm5BY2NvdW50SUQgPT09IHBsYXllcnNbaV0ubkFjY291bnRJRCkge1xuICAgICAgICAgICAgICAgICAgICBpc0V4c2l0ID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIWlzRXhzaXQpIHtcbiAgICAgICAgICAgICAgICBwbGF5ZXJzLnB1c2goaXRlbSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyA9PT09PVxuICAgICAgICBmb3IgKHZhciB0ID0gMDsgdCA8IGdhbWVEYXRhLnZlY3RUZWFtTGlzdC5sZW5ndGg7IHQrKykge1xuICAgICAgICAgICAgdmFyIGl0ZW1GaWdodGVyID0gZ2FtZURhdGEudmVjdFRlYW1MaXN0W3RdO1xuICAgICAgICAgICAgaWYgKGl0ZW1GaWdodGVyLm5UZWFtSUQgPT0gblRlYW1JRCkge1xuICAgICAgICAgICAgICAgIGl0ZW1GaWdodGVyLmlzT2ZmbGluZSA9IDA7XG4gICAgICAgICAgICAgICAgZ2FtZURhdGEuUmVmcmVzaFBsYXllckRhdGEoMSk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9LFxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICBoYW5kbGVyX1BMQVlFUl9MRUFWRV9ST09NX05PVElGWTogZnVuY3Rpb24gaGFuZGxlcl9QTEFZRVJfTEVBVkVfUk9PTV9OT1RJRlkoZXZlbnQpIHtcbiAgICAgICAgY2MubG9nKFwiaGFuZGxlcl9QTEFZRVJfTEVBVkVfUk9PTV9OT1RJRllcIik7XG4gICAgICAgIHZhciBib2R5TXNnID0gZXZlbnQuZGV0YWlsLm1zZ0JvZHk7XG4gICAgICAgIHZhciBpbnN0YW5jZUdsb2JhbCA9IGV2ZW50LmRldGFpbC5pbnN0YW5jZUdsb2JhbDtcbiAgICAgICAgdmFyIGdhbWVEYXRhID0gaW5zdGFuY2VHbG9iYWwuR2V0R2FtZURhdGEoaW5zdGFuY2VHbG9iYWwuc2VsZkRhdGEubkN1ckdhbWVJRCk7XG5cbiAgICAgICAgdmFyIGluZGV4ID0gMDtcbiAgICAgICAgdmFyIG5BY2NvdW50SUQgPSBib2R5TXNnW2luZGV4KytdLl9pbnRfdmFsdWU7XG4gICAgICAgIHZhciBuSXNPZmZsaW5lID0gYm9keU1zZ1tpbmRleCsrXS5faW50X3ZhbHVlOyAvLyAxLeaWree6v++8jOS9huS7jeWcqOaImOaWl+S4rVxuICAgICAgICB2YXIgcGxheWVycyA9IGluc3RhbmNlR2xvYmFsLnNlbGZEYXRhLnBsYXllcnM7XG4gICAgICAgIHZhciBwbGF5ZXJzQ291bnQgPSBwbGF5ZXJzLmxlbmd0aDtcblxuICAgICAgICBpZiAoaW5zdGFuY2VHbG9iYWwuY29uZkRhdGEuYkhvbGRQbGF5ZXJzSW5mbyA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBwbGF5ZXJzQ291bnQ7IGkrKykge1xuICAgICAgICAgICAgICAgIGlmIChuQWNjb3VudElEID09PSBwbGF5ZXJzW2ldLm5BY2NvdW50SUQpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKG5Jc09mZmxpbmUgPT0gMSkge30gLy8g6K6+572u5pat57q/5qCH5b+XIOOAguOAguOAglxuICAgICAgICAgICAgICAgICAgICBlbHNlIHBsYXllcnMuc3BsaWNlKGksIDEpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICB2YXIgdCA9IDA7XG4gICAgICAgIGZvciAodCA9IDA7IHQgPCBnYW1lRGF0YS52ZWN0VGVhbUxpc3QubGVuZ3RoOyB0KyspIHtcbiAgICAgICAgICAgIGlmIChnYW1lRGF0YS52ZWN0VGVhbUxpc3RbdF0ubkFjY291bnRJRCA9PSBuQWNjb3VudElEKSB7XG4gICAgICAgICAgICAgICAgZ2FtZURhdGEudmVjdFRlYW1MaXN0W3RdLmlzT2ZmbGluZSA9IG5Jc09mZmxpbmU7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgLy8gLS0tLeW9k+acieS6uuemu+W8gOaIluaWree6vyDvvIzkuI3lnKjmiJjmlpfkuK3miYDmnInkurrpg73nprvlvIDmiL/pl7RcbiAgICAgICAgaWYgKG5Jc09mZmxpbmUgPT0gMSkge1xuICAgICAgICAgICAgaWYgKGdhbWVEYXRhLm5CYXR0bGVTdGF0dXMgPT0gZ2FtZUNvbnN0RGVmLkZJR0hUX1NUQVRVUy5JTklUKSB7XG4gICAgICAgICAgICAgICAgZ2FtZURhdGEubkxlYXZlUm9vbUZsYWcgPSAxO1xuICAgICAgICAgICAgICAgIGluc3RhbmNlR2xvYmFsLkdldEdhbWVDb250cm9sbGVyKGluc3RhbmNlR2xvYmFsLnNlbGZEYXRhLm5DdXJHYW1lSUQpLlNlbmRNc2coZ2FtZUNvbnN0RGVmLkNPTk5FQ1RfQ0FMTEJBQ0tfU1RBVFVTLkhPTUVfTEVBVkVfVEVBTSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGlmIChnYW1lRGF0YS5uQmF0dGxlU3RhdHVzID09IGdhbWVDb25zdERlZi5GSUdIVF9TVEFUVVMuRU5EKSBnYW1lRGF0YS5uTGVhdmVSb29tRmxhZyA9IDE7XG4gICAgICAgICAgICAgICAgZ2FtZURhdGEuUmVmcmVzaFBsYXllckRhdGEoMSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9LFxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgaGFuZGxlcl9URUFNX0FMTF9SRUFEWV9TVUNDRVNTOiBmdW5jdGlvbiBoYW5kbGVyX1RFQU1fQUxMX1JFQURZX1NVQ0NFU1MoZXZlbnQpIHtcbiAgICAgICAgdmFyIGJvZHlNc2cgPSBldmVudC5kZXRhaWwubXNnQm9keTtcbiAgICAgICAgdmFyIGluc3RhbmNlR2xvYmFsID0gZXZlbnQuZGV0YWlsLmluc3RhbmNlR2xvYmFsO1xuICAgICAgICB2YXIgZ2FtZURhdGEgPSBpbnN0YW5jZUdsb2JhbC5HZXRHYW1lRGF0YShpbnN0YW5jZUdsb2JhbC5zZWxmRGF0YS5uQ3VyR2FtZUlEKTtcblxuICAgICAgICB2YXIgaW5kZXggPSAwO1xuICAgICAgICB2YXIgblRlYW1JRCA9IGJvZHlNc2dbaW5kZXgrK10uX2ludF92YWx1ZTtcbiAgICAgICAgdmFyIG5NYXRjaFRTID0gYm9keU1zZ1tpbmRleCsrXS5faW50X3ZhbHVlO1xuXG4gICAgICAgIGdhbWVEYXRhLm5UZWFtSUQgPSBuVGVhbUlEO1xuICAgICAgICBnYW1lRGF0YS5uTWF0Y2hUUyA9IG5NYXRjaFRTO1xuXG4gICAgICAgIGlmIChuTWF0Y2hUUyA+IDApIHtcbiAgICAgICAgICAgIGdhbWVEYXRhLm5NYXRjaEN1clNpZ25Db3VudCArPSAxO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgZ2FtZURhdGEubk1hdGNoQ3VyU2lnbkNvdW50IC09IDE7XG4gICAgICAgIH1cbiAgICAgICAgZ2FtZURhdGEuUmVmcmVzaEdhbWVXYWl0KCk7XG4gICAgfSxcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIGhhbmRsZXJfVEVBTV9BTExfUkVBRFlfTk9USUZZOiBmdW5jdGlvbiBoYW5kbGVyX1RFQU1fQUxMX1JFQURZX05PVElGWShldmVudCkge1xuICAgICAgICB2YXIgYm9keU1zZyA9IGV2ZW50LmRldGFpbC5tc2dCb2R5O1xuICAgICAgICB2YXIgaW5zdGFuY2VHbG9iYWwgPSBldmVudC5kZXRhaWwuaW5zdGFuY2VHbG9iYWw7XG4gICAgfSxcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIGhhbmRsZXJfVEVBTV9BTExfUkVBRFlfRkFJTEVEOiBmdW5jdGlvbiBoYW5kbGVyX1RFQU1fQUxMX1JFQURZX0ZBSUxFRChldmVudCkge1xuICAgICAgICB2YXIgYm9keU1zZyA9IGV2ZW50LmRldGFpbC5tc2dCb2R5O1xuICAgICAgICB2YXIgaW5zdGFuY2VHbG9iYWwgPSBldmVudC5kZXRhaWwuaW5zdGFuY2VHbG9iYWw7XG4gICAgfSxcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIGhhbmRsZXJfTEVBVkVfVEVBTV9OT1RJRlk6IGZ1bmN0aW9uIGhhbmRsZXJfTEVBVkVfVEVBTV9OT1RJRlkoZXZlbnQpIHtcbiAgICAgICAgY2MubG9nKFwiaGFuZGxlcl9MRUFWRV9URUFNX05PVElGWVwiKTtcbiAgICAgICAgdmFyIGJvZHlNc2cgPSBldmVudC5kZXRhaWwubXNnQm9keTtcbiAgICAgICAgdmFyIGluc3RhbmNlR2xvYmFsID0gZXZlbnQuZGV0YWlsLmluc3RhbmNlR2xvYmFsO1xuICAgICAgICB2YXIgZ2FtZURhdGEgPSBpbnN0YW5jZUdsb2JhbC5HZXRHYW1lRGF0YShpbnN0YW5jZUdsb2JhbC5zZWxmRGF0YS5uQ3VyR2FtZUlEKTtcblxuICAgICAgICB2YXIgaW5kZXggPSAwO1xuICAgICAgICB2YXIgbkFjY291bnRJRCA9IGJvZHlNc2dbaW5kZXgrK10uX2ludF92YWx1ZTtcblxuICAgICAgICBpZiAobkFjY291bnRJRCA9PSBpbnN0YW5jZUdsb2JhbC5zZWxmRGF0YS5uQWNjb3VudElEKSB7XG4gICAgICAgICAgICBpZiAoZ2FtZURhdGEubkxlYXZlUm9vbUZsYWcgPT0gMSAmJiBnYW1lRGF0YS5uQmF0dGxlU3RhdHVzID09IGdhbWVDb25zdERlZi5GSUdIVF9TVEFUVVMuSU5JVCkge1xuICAgICAgICAgICAgICAgIGdhbWVEYXRhLm5MZWF2ZVJvb21GbGFnID0gMDtcbiAgICAgICAgICAgICAgICBpbnN0YW5jZUdsb2JhbC5HZXRHYW1lQ29udHJvbGxlcihpbnN0YW5jZUdsb2JhbC5zZWxmRGF0YS5uQ3VyR2FtZUlEKS5TZW5kTXNnKGdhbWVDb25zdERlZi5DT05ORUNUX0NBTExCQUNLX1NUQVRVUy5IT01FX0VOVEVSX1JPT00pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSxcblxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgaGFuZGxlcl9FTlRFUl9CQVRUTEVfTk9USUZZOiBmdW5jdGlvbiBoYW5kbGVyX0VOVEVSX0JBVFRMRV9OT1RJRlkoZXZlbnQpIHtcbiAgICAgICAgY2MubG9nKFwiaGFuZGxlcl9FTlRFUl9CQVRUTEVfTk9USUZZXCIpO1xuICAgICAgICB2YXIgYm9keU1zZyA9IGV2ZW50LmRldGFpbC5tc2dCb2R5O1xuICAgICAgICB2YXIgaW5zdGFuY2VHbG9iYWwgPSBldmVudC5kZXRhaWwuaW5zdGFuY2VHbG9iYWw7XG4gICAgICAgIHZhciBnYW1lRGF0YSA9IGluc3RhbmNlR2xvYmFsLkdldEdhbWVEYXRhKGluc3RhbmNlR2xvYmFsLnNlbGZEYXRhLm5DdXJHYW1lSUQpO1xuXG4gICAgICAgIHZhciBpbmRleCA9IDA7XG4gICAgICAgIHZhciBuQmF0dGxlSUQgPSBib2R5TXNnW2luZGV4KytdLl9pbnRfdmFsdWU7XG4gICAgICAgIGlmIChnYW1lRGF0YS5uT3Blbk1vZGUgPT0gY29uc3REZWYuQkFUVExFX09QRU5fTU9ERS5NQVRDSCkge1xuICAgICAgICAgICAgdmFyIG5NYXRjaFN0YXR1cyA9IGJvZHlNc2dbaW5kZXgrK10uX2ludF92YWx1ZTtcbiAgICAgICAgfVxuICAgICAgICB2YXIgdmVjdExpc3QgPSBib2R5TXNnW2luZGV4KytdLl92ZWN0X3ZhbHVlO1xuXG4gICAgICAgIGlmIChnYW1lRGF0YS5uT3Blbk1vZGUgPT0gY29uc3REZWYuQkFUVExFX09QRU5fTU9ERS5NQVRDSCkge1xuICAgICAgICAgICAgdmFyIGl0ZW1Db3VudCA9IDQ7XG4gICAgICAgICAgICB2YXIgY291bnQgPSB2ZWN0TGlzdC5sZW5ndGggLyBpdGVtQ291bnQ7XG4gICAgICAgICAgICB2YXIgdGVhbUlkcyA9IFtdO1xuICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBjb3VudDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgdmFyIG5UZWFtSUQgPSB2ZWN0TGlzdFtpICogaXRlbUNvdW50ICsgMF0uX2ludF92YWx1ZTtcbiAgICAgICAgICAgICAgICB2YXIgblNpdCA9IHZlY3RMaXN0W2kgKiBpdGVtQ291bnQgKyAxXS5faW50X3ZhbHVlO1xuICAgICAgICAgICAgICAgIHZhciBuQWNjb3VudElEID0gdmVjdExpc3RbaSAqIGl0ZW1Db3VudCArIDJdLl9pbnRfdmFsdWU7XG4gICAgICAgICAgICAgICAgdmFyIG5TY29yZSA9IHZlY3RMaXN0W2kgKiBpdGVtQ291bnQgKyAzXS5faW50X3ZhbHVlO1xuICAgICAgICAgICAgICAgIGlmIChuQWNjb3VudElEID09IGluc3RhbmNlR2xvYmFsLnNlbGZEYXRhLm5BY2NvdW50SUQpIHtcbiAgICAgICAgICAgICAgICAgICAgZ2FtZURhdGEuQ2xlYXJCYXR0bGVEYXRhKCk7XG4gICAgICAgICAgICAgICAgICAgIGdhbWVEYXRhLm5CYXR0bGVJRCA9IG5CYXR0bGVJRDtcbiAgICAgICAgICAgICAgICAgICAgZ2FtZURhdGEubk1hdGNoU3RhdHVzID0gbk1hdGNoU3RhdHVzO1xuICAgICAgICAgICAgICAgICAgICBnYW1lRGF0YS5uVGVhbUlEID0gblRlYW1JRDtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGdhbWVEYXRhLm5CYXR0bGVJRCA9PSBuQmF0dGxlSUQpIHtcblxuICAgICAgICAgICAgICAgIGZvciAodmFyIGogPSAwOyBqIDwgY291bnQ7IGorKykge1xuICAgICAgICAgICAgICAgICAgICB2YXIgblRlYW1JRCA9IHZlY3RMaXN0W2ogKiBpdGVtQ291bnQgKyAwXS5faW50X3ZhbHVlO1xuICAgICAgICAgICAgICAgICAgICB2YXIgblNpdCA9IHZlY3RMaXN0W2ogKiBpdGVtQ291bnQgKyAxXS5faW50X3ZhbHVlO1xuICAgICAgICAgICAgICAgICAgICB2YXIgblNjb3JlID0gdmVjdExpc3RbaiAqIGl0ZW1Db3VudCArIDNdLl9pbnRfdmFsdWU7XG4gICAgICAgICAgICAgICAgICAgIHZhciB0ZWFtSXRlbSA9IGdhbWVEYXRhLnZlY3RUZWFtTGlzdFtuU2l0IC0gMV07XG4gICAgICAgICAgICAgICAgICAgIHRlYW1JdGVtLm5UZWFtSUQgPSBuVGVhbUlEO1xuICAgICAgICAgICAgICAgICAgICB0ZWFtSXRlbS5uU2NvcmUgPSBuU2NvcmU7XG4gICAgICAgICAgICAgICAgICAgIHRlYW1JZHMucHVzaChuVGVhbUlEKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZ2FtZURhdGEuaW5pdEN1ckdhbWVSZW1haW5Db3VudCgpO1xuICAgICAgICAgICAgICAgIC8v6I635Y+W6Zif5LyN5oiQ5ZGYXG4gICAgICAgICAgICAgICAgdmFyIG1zZyA9IG5ldyBQcm90b2NvbE1lc3NhZ2UoY29uc3REZWYuTUVTU0FHRS5DTURfTUFJTl9HQU1FLCBjb25zdERlZi5NRVNTQUdFLkdFVF9URUFNX01FTUJFUlNfUkVRLCBmYWxzZSk7XG4gICAgICAgICAgICAgICAgdmFyIHZlY3RJbmRleCA9IDA7XG4gICAgICAgICAgICAgICAgUHJvdG9jb2xNZXNzYWdlLkFkZFZlY3RJdGVtVmVjdChtc2cuX2JvZHlfbXNnKTtcbiAgICAgICAgICAgICAgICBmb3IgKHZhciB0ID0gMDsgdCA8IHRlYW1JZHMubGVuZ3RoOyB0KyspIHtcbiAgICAgICAgICAgICAgICAgICAgUHJvdG9jb2xNZXNzYWdlLkFkZFZlY3RJdGVtSW50KG1zZy5fYm9keV9tc2dbdmVjdEluZGV4XS5fdmVjdF92YWx1ZSwgdGVhbUlkc1t0XSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGluc3RhbmNlR2xvYmFsLlNvY2tldE1hbmFnZXIuU2VuZE1lc3NhZ2UoY29uc3REZWYuU0VSVkVSX1VSTC5nYW1lLCBtc2cpO1xuXG4gICAgICAgICAgICAgICAgdmFyIGN1ckNvbXAgPSBpbnN0YW5jZUdsb2JhbC5sb2FkLmdldENvbXBvbmVudChcIkxvYWRNYW5hZ2VyXCIpO1xuICAgICAgICAgICAgICAgIGN1ckNvbXAuU2hvdygnWWluZ3NhbnpoYW5nX3dhcicpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdmFyIGl0ZW1Db3VudCA9IDI7XG4gICAgICAgICAgICB2YXIgY291bnQgPSB2ZWN0TGlzdC5sZW5ndGggLyBpdGVtQ291bnQ7XG4gICAgICAgICAgICBpZiAobkJhdHRsZUlEID09IGdhbWVEYXRhLm5CYXR0bGVJRCkge1xuICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgY291bnQ7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICB2YXIgblRlYW1JRCA9IHZlY3RMaXN0W2kgKiBpdGVtQ291bnQgKyAwXS5faW50X3ZhbHVlO1xuICAgICAgICAgICAgICAgICAgICB2YXIgblNpdCA9IHZlY3RMaXN0W2kgKiBpdGVtQ291bnQgKyAxXS5faW50X3ZhbHVlO1xuICAgICAgICAgICAgICAgICAgICBpZiAoblRlYW1JRCAhPT0gZ2FtZURhdGEublRlYW1JRCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHRlYW1JdGVtID0gZ2FtZURhdGEudmVjdFRlYW1MaXN0W25TaXQgLSAxXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRlYW1JdGVtLm5UZWFtSUQgPSBuVGVhbUlEO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIG1zZyA9IG5ldyBQcm90b2NvbE1lc3NhZ2UoY29uc3REZWYuTUVTU0FHRS5DTURfTUFJTl9HQU1FLCBjb25zdERlZi5NRVNTQUdFLkdFVF9URUFNX01FTUJFUlNfUkVRLCBmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgdmVjdEluZGV4ID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIFByb3RvY29sTWVzc2FnZS5BZGRWZWN0SXRlbVZlY3QobXNnLl9ib2R5X21zZyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBQcm90b2NvbE1lc3NhZ2UuQWRkVmVjdEl0ZW1JbnQobXNnLl9ib2R5X21zZ1t2ZWN0SW5kZXhdLl92ZWN0X3ZhbHVlLCBuVGVhbUlEKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGluc3RhbmNlR2xvYmFsLlNvY2tldE1hbmFnZXIuU2VuZE1lc3NhZ2UoY29uc3REZWYuU0VSVkVSX1VSTC5nYW1lLCBtc2cpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSxcbiAgICBoYW5kbGVyX0VOVEVSX0JBVFRMRV9TVUNDRVNTOiBmdW5jdGlvbiBoYW5kbGVyX0VOVEVSX0JBVFRMRV9TVUNDRVNTKGV2ZW50KSB7XG4gICAgICAgIGNjLmxvZyhcImhhbmRsZXJfRU5URVJfQkFUVExFX1NVQ0NFU1NcIik7XG4gICAgICAgIHZhciBib2R5TXNnID0gZXZlbnQuZGV0YWlsLm1zZ0JvZHk7XG4gICAgICAgIHZhciBpbnN0YW5jZUdsb2JhbCA9IGV2ZW50LmRldGFpbC5pbnN0YW5jZUdsb2JhbDtcbiAgICAgICAgdmFyIGdhbWVEYXRhID0gaW5zdGFuY2VHbG9iYWwuR2V0R2FtZURhdGEoaW5zdGFuY2VHbG9iYWwuc2VsZkRhdGEubkN1ckdhbWVJRCk7XG4gICAgICAgIGdhbWVEYXRhLkNsZWFyQmF0dGxlRGF0YSgpO1xuXG4gICAgICAgIGlmIChib2R5TXNnLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIGdhbWVEYXRhLkluaXRCYXR0bGVEYXRhKGJvZHlNc2cpO1xuICAgICAgICB9XG5cbiAgICAgICAgdmFyIGN1ckNvbXAgPSBpbnN0YW5jZUdsb2JhbC5sb2FkLmdldENvbXBvbmVudChcIkxvYWRNYW5hZ2VyXCIpO1xuICAgICAgICBjdXJDb21wLlNob3coJ1lpbmdzYW56aGFuZ193YXInKTtcbiAgICB9LFxuICAgIGhhbmRsZXJfRU5URVJfQkFUVExFX0ZBSUxFRDogZnVuY3Rpb24gaGFuZGxlcl9FTlRFUl9CQVRUTEVfRkFJTEVEKGV2ZW50KSB7XG4gICAgICAgIHZhciBib2R5TXNnID0gZXZlbnQuZGV0YWlsLm1zZ0JvZHk7XG4gICAgICAgIHZhciBpbnN0YW5jZUdsb2JhbCA9IGV2ZW50LmRldGFpbC5pbnN0YW5jZUdsb2JhbDtcbiAgICB9LFxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG5cbiAgICBoYW5kbGVyX0ZJR0hUX1JFQURZX1NVQ0NFU1M6IGZ1bmN0aW9uIGhhbmRsZXJfRklHSFRfUkVBRFlfU1VDQ0VTUyhldmVudCkge1xuICAgICAgICBjYy5sb2coXCJoYW5kbGVyX0ZJR0hUX1JFQURZX1NVQ0NFU1NcIik7XG4gICAgICAgIHZhciBib2R5TXNnID0gZXZlbnQuZGV0YWlsLm1zZ0JvZHk7XG4gICAgICAgIHZhciBpbnN0YW5jZUdsb2JhbCA9IGV2ZW50LmRldGFpbC5pbnN0YW5jZUdsb2JhbDtcbiAgICB9LFxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgaGFuZGxlcl9GSUdIVF9SRUFEWV9GQUlMRUQ6IGZ1bmN0aW9uIGhhbmRsZXJfRklHSFRfUkVBRFlfRkFJTEVEKGV2ZW50KSB7XG4gICAgICAgIGNjLmxvZyhcImhhbmRsZXJfRklHSFRfUkVBRFlfRkFJTEVEXCIpO1xuICAgICAgICB2YXIgYm9keU1zZyA9IGV2ZW50LmRldGFpbC5tc2dCb2R5O1xuICAgICAgICB2YXIgaW5zdGFuY2VHbG9iYWwgPSBldmVudC5kZXRhaWwuaW5zdGFuY2VHbG9iYWw7XG4gICAgfSxcbiAgICBoYW5kbGVyX0ZJR0hUX1JFQURZX05PVElGWTogZnVuY3Rpb24gaGFuZGxlcl9GSUdIVF9SRUFEWV9OT1RJRlkoZXZlbnQpIHtcbiAgICAgICAgY2MubG9nKFwiaGFuZGxlcl9GSUdIVF9SRUFEWV9OT1RJRllcIik7XG4gICAgICAgIHZhciBib2R5TXNnID0gZXZlbnQuZGV0YWlsLm1zZ0JvZHk7XG4gICAgICAgIHZhciBpbnN0YW5jZUdsb2JhbCA9IGV2ZW50LmRldGFpbC5pbnN0YW5jZUdsb2JhbDtcbiAgICAgICAgdmFyIGdhbWVEYXRhID0gaW5zdGFuY2VHbG9iYWwuR2V0R2FtZURhdGEoaW5zdGFuY2VHbG9iYWwuc2VsZkRhdGEubkN1ckdhbWVJRCk7XG5cbiAgICAgICAgdmFyIGluZGV4ID0gMDtcbiAgICAgICAgdmFyIG5BY2NvdW50SUQgPSBib2R5TXNnW2luZGV4KytdLl9pbnRfdmFsdWU7XG4gICAgICAgIHZhciB0ZWFtTGlzdCA9IGdhbWVEYXRhLnZlY3RUZWFtTGlzdDtcbiAgICAgICAgZm9yICh2YXIgaiA9IDA7IGogPCB0ZWFtTGlzdC5sZW5ndGg7IGorKykge1xuICAgICAgICAgICAgaWYgKG5BY2NvdW50SUQgPT0gdGVhbUxpc3Rbal0ubkFjY291bnRJRCkge1xuICAgICAgICAgICAgICAgIHRlYW1MaXN0W2pdLmlzT25SZWFkeSA9IDE7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBpZiAobkFjY291bnRJRCA9PSBpbnN0YW5jZUdsb2JhbC5zZWxmRGF0YS5uQWNjb3VudElEKSB7XG4gICAgICAgICAgICB2YXIgbXNnID0gbmV3IFByb3RvY29sTWVzc2FnZShjb25zdERlZi5NRVNTQUdFLkNNRF9NQUlOX0dBTUUsIGNvbnN0RGVmLk1FU1NBR0UuU0NFTkVfUkVBRFlfUkVRLCBmYWxzZSk7XG4gICAgICAgICAgICBQcm90b2NvbE1lc3NhZ2UuQWRkVmVjdEl0ZW1CeXRlKG1zZy5fYm9keV9tc2csIDEwMCk7XG4gICAgICAgICAgICBpbnN0YW5jZUdsb2JhbC5Tb2NrZXRNYW5hZ2VyLlNlbmRNZXNzYWdlKGNvbnN0RGVmLlNFUlZFUl9VUkwuZ2FtZSwgbXNnKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGdhbWVEYXRhLlJlZnJlc2hQbGF5ZXJEYXRhKDIpO1xuICAgIH0sXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICBoYW5kbGVyX1NDRU5FX1JFQURZX05PVElGWTogZnVuY3Rpb24gaGFuZGxlcl9TQ0VORV9SRUFEWV9OT1RJRlkoZXZlbnQpIHtcbiAgICAgICAgY2MubG9nKFwiaGFuZGxlcl9TQ0VORV9SRUFEWV9OT1RJRllcIik7XG5cbiAgICAgICAgdmFyIGJvZHlNc2cgPSBldmVudC5kZXRhaWwubXNnQm9keTtcbiAgICAgICAgdmFyIGluc3RhbmNlR2xvYmFsID0gZXZlbnQuZGV0YWlsLmluc3RhbmNlR2xvYmFsO1xuICAgICAgICB2YXIgZ2FtZURhdGEgPSBpbnN0YW5jZUdsb2JhbC5HZXRHYW1lRGF0YShpbnN0YW5jZUdsb2JhbC5zZWxmRGF0YS5uQ3VyR2FtZUlEKTtcblxuICAgICAgICB2YXIgaW5kZXggPSAwO1xuICAgICAgICB2YXIgbkFjY291bnRJRCA9IGJvZHlNc2dbaW5kZXgrK10uX2ludF92YWx1ZTtcbiAgICAgICAgaWYgKG5BY2NvdW50SUQgPT0gaW5zdGFuY2VHbG9iYWwuc2VsZkRhdGEubkFjY291bnRJRCkge1xuICAgICAgICAgICAgZ2FtZURhdGEuUmVmcmVzaERhdGEoKTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIGhhbmRsZXJfU0NFTkVfUkVBRFlfU1VDQ0VTUzogZnVuY3Rpb24gaGFuZGxlcl9TQ0VORV9SRUFEWV9TVUNDRVNTKGV2ZW50KSB7XG4gICAgICAgIHZhciBib2R5TXNnID0gZXZlbnQuZGV0YWlsLm1zZ0JvZHk7XG4gICAgICAgIHZhciBpbnN0YW5jZUdsb2JhbCA9IGV2ZW50LmRldGFpbC5pbnN0YW5jZUdsb2JhbDtcbiAgICB9LFxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICBoYW5kbGVyX1NDRU5FX1JFQURZX0ZBSUxFRDogZnVuY3Rpb24gaGFuZGxlcl9TQ0VORV9SRUFEWV9GQUlMRUQoZXZlbnQpIHtcbiAgICAgICAgdmFyIGJvZHlNc2cgPSBldmVudC5kZXRhaWwubXNnQm9keTtcbiAgICAgICAgdmFyIGluc3RhbmNlR2xvYmFsID0gZXZlbnQuZGV0YWlsLmluc3RhbmNlR2xvYmFsO1xuICAgIH0sXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICBoYW5kbGVyX0ZJR0hUX0JFR0lOX05PVElGWTogZnVuY3Rpb24gaGFuZGxlcl9GSUdIVF9CRUdJTl9OT1RJRlkoZXZlbnQpIHtcbiAgICAgICAgY2MubG9nKFwiaGFuZGxlcl9GSUdIVF9CRUdJTl9OT1RJRllcIik7XG4gICAgICAgIHZhciBib2R5TXNnID0gZXZlbnQuZGV0YWlsLm1zZ0JvZHk7XG4gICAgICAgIHZhciBpbnN0YW5jZUdsb2JhbCA9IGV2ZW50LmRldGFpbC5pbnN0YW5jZUdsb2JhbDtcbiAgICAgICAgdmFyIGdhbWVEYXRhID0gaW5zdGFuY2VHbG9iYWwuR2V0R2FtZURhdGEoaW5zdGFuY2VHbG9iYWwuc2VsZkRhdGEubkN1ckdhbWVJRCk7XG5cbiAgICAgICAgdmFyIGluZGV4ID0gMDtcbiAgICAgICAgZ2FtZURhdGEubkN1clNpdCA9IGJvZHlNc2dbaW5kZXgrK10uX2ludF92YWx1ZTs7XG4gICAgICAgIHZhciB2ZWN0TGlzdCA9IGJvZHlNc2dbaW5kZXgrK10uX3ZlY3RfdmFsdWU7XG4gICAgICAgIHZhciBpdGVtQ291bnQgPSA1O1xuICAgICAgICB2YXIgY291bnQgPSB2ZWN0TGlzdC5sZW5ndGggLyBpdGVtQ291bnQ7XG4gICAgICAgIHZhciBpbmRleDEgPSAwO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGNvdW50OyBpKyspIHtcbiAgICAgICAgICAgIHZhciBpdGVtID0gZ2FtZURhdGEudmVjdFRlYW1MaXN0W2ldO1xuICAgICAgICAgICAgaXRlbS5uVGVhbUlEID0gdmVjdExpc3RbaSAqIGl0ZW1Db3VudCArIGluZGV4MSsrXS5faW50X3ZhbHVlO1xuICAgICAgICAgICAgaXRlbS5uU2l0ID0gdmVjdExpc3RbaSAqIGl0ZW1Db3VudCArIGluZGV4MSsrXS5faW50X3ZhbHVlO1xuICAgICAgICAgICAgaXRlbS5wdWtlWzBdID0gdmVjdExpc3RbaSAqIGl0ZW1Db3VudCArIGluZGV4MSsrXS5faW50X3ZhbHVlO1xuICAgICAgICAgICAgaXRlbS5wdWtlWzFdID0gdmVjdExpc3RbaSAqIGl0ZW1Db3VudCArIGluZGV4MSsrXS5faW50X3ZhbHVlO1xuICAgICAgICAgICAgaXRlbS5wdWtlWzJdID0gdmVjdExpc3RbaSAqIGl0ZW1Db3VudCArIGluZGV4MSsrXS5faW50X3ZhbHVlO1xuICAgICAgICB9XG5cbiAgICAgICAgZ2FtZURhdGEubkJhdHRsZVN0YXR1cyA9IGdhbWVDb25zdERlZi5GSUdIVF9TVEFUVVMuQkVHSU47XG5cbiAgICAgICAgZ2FtZURhdGEubkNsaWVudFN0YXR1cyA9IGdhbWVDb25zdERlZi5GSUdIVF9TVEFUVVMuQ19CRUdJTjtcblxuICAgICAgICBnYW1lRGF0YS5SZWZyZXNoRGF0YSgpO1xuICAgIH0sXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICBoYW5kbGVyX0ZJR0hUX0VORF9OT1RJRlk6IGZ1bmN0aW9uIGhhbmRsZXJfRklHSFRfRU5EX05PVElGWShldmVudCkge1xuICAgICAgICBjYy5sb2coXCJoYW5kbGVyX0ZJR0hUX0VORF9OT1RJRllcIik7XG4gICAgICAgIHZhciBib2R5TXNnID0gZXZlbnQuZGV0YWlsLm1zZ0JvZHk7XG4gICAgICAgIHZhciBpbnN0YW5jZUdsb2JhbCA9IGV2ZW50LmRldGFpbC5pbnN0YW5jZUdsb2JhbDtcbiAgICAgICAgdmFyIGdhbWVEYXRhID0gaW5zdGFuY2VHbG9iYWwuR2V0R2FtZURhdGEoaW5zdGFuY2VHbG9iYWwuc2VsZkRhdGEubkN1ckdhbWVJRCk7XG5cbiAgICAgICAgdmFyIGluZGV4ID0gMDtcbiAgICAgICAgdmFyIHZlY3RMaXN0ID0gYm9keU1zZ1tpbmRleCsrXS5fdmVjdF92YWx1ZTtcbiAgICAgICAgdmFyIGl0ZW1Db3VudCA9IDM7XG4gICAgICAgIHZhciBjb3VudCA9IHZlY3RMaXN0Lmxlbmd0aCAvIGl0ZW1Db3VudDtcbiAgICAgICAgdmFyIGluZGV4MSA9IDA7XG4gICAgICAgIGZvciAodmFyIF9pID0gMDsgX2kgPCBjb3VudDsgX2krKykge1xuICAgICAgICAgICAgdmFyIG5UZWFtSUQgPSB2ZWN0TGlzdFtpbmRleDErK10uX2ludF92YWx1ZTtcbiAgICAgICAgICAgIHZhciBuUmVzdWx0ID0gdmVjdExpc3RbaW5kZXgxKytdLl9pbnRfdmFsdWU7XG4gICAgICAgICAgICB2YXIgbk1vbmV5ID0gdmVjdExpc3RbaW5kZXgxKytdLl9pbnRfdmFsdWU7XG4gICAgICAgICAgICBmb3IgKHZhciB0ID0gMDsgdCA8IGdhbWVEYXRhLnZlY3RUZWFtTGlzdC5sZW5ndGg7IHQrKykge1xuICAgICAgICAgICAgICAgIGlmIChnYW1lRGF0YS52ZWN0VGVhbUxpc3RbdF0ublRlYW1JRCA9PSBuVGVhbUlEKSB7XG4gICAgICAgICAgICAgICAgICAgIGdhbWVEYXRhLnZlY3RUZWFtTGlzdFt0XS5uUmVzdWx0ID0gblJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgZ2FtZURhdGEudmVjdFRlYW1MaXN0W3RdLm5Nb25leSA9IG5Nb25leTsgLy8g5Z+65pWwXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB2YXIgYXJyID0gbnVsbDtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBnYW1lRGF0YS5wdWtlLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBhcnIgPSBnYW1lRGF0YS5wdWtlW2ldLnNwbGljZSgxLCBnYW1lRGF0YS5wdWtlW2ldLmxlbmd0aCAtIDEpO1xuICAgICAgICAgICAgdmFyIHRlbXBfYXJyID0gZ2FtZURhdGEuT3JkZXJQdWtlKGFycik7XG5cbiAgICAgICAgICAgIGZvciAodmFyIG4gPSAwOyBuIDwgdGVtcF9hcnIubGVuZ3RoOyBuKyspIHtcbiAgICAgICAgICAgICAgICBnYW1lRGF0YS5wdWtlW2ldLnB1c2godGVtcF9hcnJbbl0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGdhbWVEYXRhLm5CYXR0bGVTdGF0dXMgPSBnYW1lQ29uc3REZWYuRklHSFRfU1RBVFVTLkVORDtcbiAgICAgICAgZ2FtZURhdGEubkNsaWVudFN0YXR1cyA9IGdhbWVDb25zdERlZi5GSUdIVF9TVEFUVVMuQ19FTkRfU0hPV19MRUZUX0NBUkRTO1xuICAgICAgICBnYW1lRGF0YS5SZWZyZXNoRGF0YSgpO1xuICAgIH0sXG5cbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICBoYW5kbGVyX0JFVF9TVUNDRVNTOiBmdW5jdGlvbiBoYW5kbGVyX0JFVF9TVUNDRVNTKGV2ZW50KSB7XG4gICAgICAgIHZhciBib2R5TXNnID0gZXZlbnQuZGV0YWlsLm1zZ0JvZHk7XG4gICAgICAgIHZhciBpbnN0YW5jZUdsb2JhbCA9IGV2ZW50LmRldGFpbC5pbnN0YW5jZUdsb2JhbDtcbiAgICB9LFxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIGhhbmRsZXJfQkVUX0ZBSUxFRDogZnVuY3Rpb24gaGFuZGxlcl9CRVRfRkFJTEVEKGV2ZW50KSB7XG4gICAgICAgIHZhciBib2R5TXNnID0gZXZlbnQuZGV0YWlsLm1zZ0JvZHk7XG4gICAgICAgIHZhciBpbnN0YW5jZUdsb2JhbCA9IGV2ZW50LmRldGFpbC5pbnN0YW5jZUdsb2JhbDtcbiAgICB9LFxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIGhhbmRsZXJfQkVUX05PVElGWTogZnVuY3Rpb24gaGFuZGxlcl9CRVRfTk9USUZZKGV2ZW50KSB7XG4gICAgICAgIC8qXG4gICAgICAgIHZhciBib2R5TXNnID0gZXZlbnQuZGV0YWlsLm1zZ0JvZHk7XG4gICAgICAgIHZhciBpbnN0YW5jZUdsb2JhbCA9IGV2ZW50LmRldGFpbC5pbnN0YW5jZUdsb2JhbDsgXG4gICAgICAgIHZhciBnYW1lRGF0YSA9IGluc3RhbmNlR2xvYmFsLkdldEdhbWVEYXRhKGluc3RhbmNlR2xvYmFsLnNlbGZEYXRhLm5DdXJHYW1lSUQpO1xuICAgICAgICAgdmFyIGluZGV4ID0gMDtcbiAgICAgICAgdmFyIG5UZWFtSUQgPSBib2R5TXNnW2luZGV4KytdLl9pbnRfdmFsdWU7XG4gICAgICAgIHZhciBuQ3VyR3JhYkJhbmtlclZhbCA9IGJvZHlNc2dbaW5kZXhdLl9pbnRfdmFsdWU7XG4gICAgICAgICAgICAgICAgZ2FtZURhdGEubkN1clN0YXR1c1RTID0gaW5zdGFuY2VHbG9iYWwuR2V0UmlnaHRUaW1lKCk7ICAgICAgIC8vXG4gICAgICAgICB2YXIgbkN1ckdyYWJCYW5rZXJTZXEgPSAwO1xuICAgICAgICB2YXIgdGVhbUxpc3QgPSBnYW1lRGF0YS52ZWN0VGVhbUxpc3Q7XG4gICAgICAgIGZvcihsZXQgaT0wO2k8dGVhbUxpc3QubGVuZ3RoO2krKylcbiAgICAgICAge1xuICAgICAgICAgICAgaWYodGVhbUxpc3RbaV0ublRlYW1JRCA9PSBuVGVhbUlEKVxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGdhbWVEYXRhLm5DbGllbnRTdGF0dXMgPSBnYW1lQ29uc3REZWYuRklHSFRfU1RBVFVTLkNfQkVHSU5fR1JBQl9CQU5LRVIgKyBpO1xuICAgICAgICAgICAgICAgIG5DdXJHcmFiQmFua2VyU2VxID0gaSArIDE7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgICAgICBpZihuQ3VyR3JhYkJhbmtlclZhbCA+IGdhbWVEYXRhLm5DdXJCYW5rZXJWYWwpXG4gICAgICAgIHtcbiAgICAgICAgICAgIGdhbWVEYXRhLm5DdXJCYW5rZXJTZXEgPSBuQ3VyR3JhYkJhbmtlclNlcTsgICAgICAgICAgICAgIFxuICAgICAgICAgICAgZ2FtZURhdGEubkN1ckJhbmtlclZhbCA9IG5DdXJHcmFiQmFua2VyVmFsOyAgXG4gICAgICAgIH1cbiAgICAgICAgIFxuICAgICAgICBpZiggbkN1ckdyYWJCYW5rZXJTZXEgPT0gMyB8fCBnYW1lRGF0YS5uQ3VyQmFua2VyVmFsID09IDMpXG4gICAgICAgIHtcbiAgICAgICAgICAgIGlmKG5DdXJHcmFiQmFua2VyU2VxID09IDMgJiYgZ2FtZURhdGEubkN1ckJhbmtlclZhbCA9PSAwKVxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIC8v5rKh5Lq65Y+r5YiG77yM6buY6K6k56ys5LiA5Liq5Lq6XG4gICAgICAgICAgICAgICAgZ2FtZURhdGEubkN1ckJhbmtlclNlcSA9IDE7XG4gICAgICAgICAgICAgICAgZ2FtZURhdGEubkN1ckJhbmtlclZhbCA9IDE7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBnYW1lRGF0YS5wdWtlW2dhbWVEYXRhLm5DdXJCYW5rZXJTZXEtMV1bMF0gPSAyMDtcbiAgICAgICAgICAgIGZvcihsZXQgaj0wO2o8MztqKyspXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZ2FtZURhdGEucHVrZVtnYW1lRGF0YS5uQ3VyQmFua2VyU2VxLTFdLnB1c2goIGdhbWVEYXRhLmFyckxhbmRDYXJkc1tqXSk7ICAgIFxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgIGdhbWVEYXRhLm5DbGllbnRTdGF0dXMgPSBnYW1lQ29uc3REZWYuRklHSFRfU1RBVFVTLkNfQkFOS0VSX0ZJTklTSDtcbiAgICAgICAgICAgIGdhbWVEYXRhLlJlZnJlc2hEYXRhKCk7XG4gICAgICAgICAgICAgICAgaWYoZ2FtZURhdGEubkNsaWVudFN0YXR1cz09Z2FtZUNvbnN0RGVmLkZJR0hUX1NUQVRVUy5DX0JBTktFUl9GSU5JU0gpXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZ2FtZURhdGEubkN1clR1cm5TZXEgPSBnYW1lRGF0YS5uQ3VyQmFua2VyU2VxO1xuICAgICAgICAgICAgICAgIGdhbWVEYXRhLm5CYXR0bGVTdGF0dXM9Z2FtZUNvbnN0RGVmLkZJR0hUX1NUQVRVUy5GSUdIVElORztcbiAgICAgICAgICAgICAgICBnYW1lRGF0YS5uQ2xpZW50U3RhdHVzPWdhbWVDb25zdERlZi5GSUdIVF9TVEFUVVMuQ19GSUdIVElORztcbiAgICAgICAgICAgICAgICBnYW1lRGF0YS5SZWZyZXNoRGF0YSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2UgXG4gICAgICAgIHtcbiAgICAgICAgICAgIGdhbWVEYXRhLlJlZnJlc2hEYXRhKCk7XG4gICAgICAgIH0qL1xuICAgIH0sXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgaGFuZGxlcl9GT0xMT1dfQkVUX05PVElGWTogZnVuY3Rpb24gaGFuZGxlcl9GT0xMT1dfQkVUX05PVElGWShldmVudCkge1xuXG4gICAgICAgIC8qXG4gICAgICAgIHZhciBib2R5TXNnID0gZXZlbnQuZGV0YWlsLm1zZ0JvZHk7XG4gICAgICAgIHZhciBpbnN0YW5jZUdsb2JhbCA9IGV2ZW50LmRldGFpbC5pbnN0YW5jZUdsb2JhbDsgXG4gICAgICAgIHZhciBnYW1lRGF0YSA9IGluc3RhbmNlR2xvYmFsLkdldEdhbWVEYXRhKGluc3RhbmNlR2xvYmFsLnNlbGZEYXRhLm5DdXJHYW1lSUQpO1xuICAgICAgICAgdmFyIGluZGV4ID0gMDtcbiAgICAgICAgdmFyIHRvdGFsQ291bnQgPSBib2R5TXNnLmxlbmd0aDtcbiAgICAgICAgdmFyIG5UZWFtSUQgPSBib2R5TXNnW2luZGV4XS5faW50X3ZhbHVlO1xuICAgICAgICAgdmFyIHRlYW1MaXN0ID0gZ2FtZURhdGEudmVjdFRlYW1MaXN0O1xuICAgICAgICB2YXIgbkN1ck91dFB1a2VTZXEgPSAwO1xuICAgICAgICBnYW1lRGF0YS5uQ3VyU3RhdHVzVFMgPSBpbnN0YW5jZUdsb2JhbC5HZXRSaWdodFRpbWUoKTtcbiAgICAgICAgZm9yKGxldCBpPTA7aTx0ZWFtTGlzdC5sZW5ndGg7aSsrKVxuICAgICAgICB7XG4gICAgICAgICAgICBpZih0ZWFtTGlzdFtpXS5uVGVhbUlEID09IG5UZWFtSUQpXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgbkN1ck91dFB1a2VTZXEgPSBpICsgMTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgLy8g5piv5ZCm5Ye654mMXG4gICAgICAgIGlmKHRvdGFsQ291bnQgPiAyKSAgICAvLyDmtojmga/oh7PlsJHlkKvmnIluVGVhbUlEIOOAgWJhdHRsZUlkXG4gICAgICAgIHtcbiAgICAgICAgICAgIGdhbWVEYXRhLmFyckN1ck91dFB1a2UubGVuZ3RoID0gMDtcbiAgICAgICAgICAgIGdhbWVEYXRhLmFyckN1ck91dFB1a2UucHVzaCh0b3RhbENvdW50LTIpO1xuICAgICAgICAgICAgZm9yKGxldCBpPTE7aTx0b3RhbENvdW50LTE7aSsrKVxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHZhciBjYXJkVmFsdWUgPSBib2R5TXNnW2ldLl9pbnRfdmFsdWU7XG4gICAgICAgICAgICAgICAgZ2FtZURhdGEuYXJyQ3VyT3V0UHVrZS5wdXNoKGNhcmRWYWx1ZSk7ICAgIFxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZ2FtZURhdGEubkN1ck91dFB1a2VTZXEgPSBuQ3VyT3V0UHVrZVNlcTtcbiAgICAgICAgICAgICAgZ2FtZURhdGEucHVrZVtuQ3VyT3V0UHVrZVNlcS0xXVswXSAtPSBnYW1lRGF0YS5hcnJDdXJPdXRQdWtlWzBdO1xuICAgICAgICAgICAgZm9yKGxldCBtPTE7bTxnYW1lRGF0YS5hcnJDdXJPdXRQdWtlLmxlbmd0aDttKyspXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZm9yKGxldCB6PWdhbWVEYXRhLnB1a2VbbkN1ck91dFB1a2VTZXEtMV0ubGVuZ3RoLTE7ej4wO3otLSlcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGlmKGdhbWVEYXRhLnB1a2VbbkN1ck91dFB1a2VTZXEtMV1bel0gPT0gZ2FtZURhdGEuYXJyQ3VyT3V0UHVrZVttXSlcbiAgICAgICAgICAgICAgICAgICAgeyBcbiAgICAgICAgICAgICAgICAgICAgICAgIGdhbWVEYXRhLnB1a2VbbkN1ck91dFB1a2VTZXEtMV0uc3BsaWNlKHosMSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0gICAgIFxuICAgICAgICAgICAgfVxuICAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgZ2FtZURhdGEubkN1clR1cm5TZXEgPSAobkN1ck91dFB1a2VTZXE+PTMpPzE6KG5DdXJPdXRQdWtlU2VxKzEpO1xuICAgICAgICAgZ2FtZURhdGEuUmVmcmVzaERhdGEoKTsqL1xuICAgIH0sXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgaGFuZGxlcl9GT0xMT1dfQkVUX1NVQ0NFU1M6IGZ1bmN0aW9uIGhhbmRsZXJfRk9MTE9XX0JFVF9TVUNDRVNTKGV2ZW50KSB7XG4gICAgICAgIHZhciBib2R5TXNnID0gZXZlbnQuZGV0YWlsLm1zZ0JvZHk7XG4gICAgICAgIHZhciBpbnN0YW5jZUdsb2JhbCA9IGV2ZW50LmRldGFpbC5pbnN0YW5jZUdsb2JhbDtcbiAgICB9LFxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIGhhbmRsZXJfRk9MTE9XX0JFVF9GQUlMRUQ6IGZ1bmN0aW9uIGhhbmRsZXJfRk9MTE9XX0JFVF9GQUlMRUQoZXZlbnQpIHtcbiAgICAgICAgdmFyIGJvZHlNc2cgPSBldmVudC5kZXRhaWwubXNnQm9keTtcbiAgICAgICAgdmFyIGluc3RhbmNlR2xvYmFsID0gZXZlbnQuZGV0YWlsLmluc3RhbmNlR2xvYmFsO1xuICAgIH0sXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgaGFuZGxlcl9BRERfQkVUX1NVQ0NFU1M6IGZ1bmN0aW9uIGhhbmRsZXJfQUREX0JFVF9TVUNDRVNTKGV2ZW50KSB7XG4gICAgICAgIHZhciBib2R5TXNnID0gZXZlbnQuZGV0YWlsLm1zZ0JvZHk7XG4gICAgICAgIHZhciBpbnN0YW5jZUdsb2JhbCA9IGV2ZW50LmRldGFpbC5pbnN0YW5jZUdsb2JhbDtcbiAgICB9LFxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIGhhbmRsZXJfQUREX0JFVF9GQUlMRUQ6IGZ1bmN0aW9uIGhhbmRsZXJfQUREX0JFVF9GQUlMRUQoZXZlbnQpIHtcbiAgICAgICAgdmFyIGJvZHlNc2cgPSBldmVudC5kZXRhaWwubXNnQm9keTtcbiAgICAgICAgdmFyIGluc3RhbmNlR2xvYmFsID0gZXZlbnQuZGV0YWlsLmluc3RhbmNlR2xvYmFsO1xuICAgIH0sXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgaGFuZGxlcl9BRERfQkVUX05PVElGWTogZnVuY3Rpb24gaGFuZGxlcl9BRERfQkVUX05PVElGWShldmVudCkge1xuICAgICAgICAvLyB2YXIgYm9keU1zZyA9IGV2ZW50LmRldGFpbC5tc2dCb2R5O1xuICAgICAgICAvLyB2YXIgaW5zdGFuY2VHbG9iYWwgPSBldmVudC5kZXRhaWwuaW5zdGFuY2VHbG9iYWw7XG4gICAgICAgIC8vIHZhciBnYW1lRGF0YSA9IGluc3RhbmNlR2xvYmFsLkdldEdhbWVEYXRhKGluc3RhbmNlR2xvYmFsLnNlbGZEYXRhLm5DdXJHYW1lSUQpO1xuXG4gICAgICAgIC8vIHZhciBpbmRleCA9IDA7XG4gICAgICAgIC8vIHZhciBuVGVhbUlEID0gYm9keU1zZ1tpbmRleCsrXS5faW50X3ZhbHVlO1xuICAgICAgICAvLyB2YXIgbkZsYWcgICA9IGJvZHlNc2dbaW5kZXgrK10uX2ludF92YWx1ZTtcblxuICAgICAgICAvLyB2YXIgdGVhbUxpc3QgPSBnYW1lRGF0YS52ZWN0VGVhbUxpc3Q7XG4gICAgICAgIC8vIGZvcihsZXQgaT0wO2k8dGVhbUxpc3QubGVuZ3RoO2krKylcbiAgICAgICAgLy8ge1xuICAgICAgICAvLyAgICAgaWYodGVhbUxpc3RbaV0ublRlYW1JRCA9PSBuVGVhbUlEKVxuICAgICAgICAvLyAgICAge1xuICAgICAgICAvLyAgICAgICAgIHRlYW1MaXN0W2ldLmlzRGVwb3NpdCA9IG5GbGFnO1xuICAgICAgICAvLyAgICAgICAgIGJyZWFrO1xuICAgICAgICAvLyAgICAgfVxuICAgICAgICAvLyB9XG4gICAgICAgIC8vIGdhbWVEYXRhLlJlZnJlc2hQbGF5ZXJEYXRhKDIpO1xuICAgIH0sXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgaGFuZGxlcl9MT09LX0NBUkRfU1VDQ0VTUzogZnVuY3Rpb24gaGFuZGxlcl9MT09LX0NBUkRfU1VDQ0VTUyhldmVudCkge1xuICAgICAgICB2YXIgYm9keU1zZyA9IGV2ZW50LmRldGFpbC5tc2dCb2R5O1xuICAgICAgICB2YXIgaW5zdGFuY2VHbG9iYWwgPSBldmVudC5kZXRhaWwuaW5zdGFuY2VHbG9iYWw7XG4gICAgfSxcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICBoYW5kbGVyX0xPT0tfQ0FSRF9GQUlMRUQ6IGZ1bmN0aW9uIGhhbmRsZXJfTE9PS19DQVJEX0ZBSUxFRChldmVudCkge1xuICAgICAgICB2YXIgYm9keU1zZyA9IGV2ZW50LmRldGFpbC5tc2dCb2R5O1xuICAgICAgICB2YXIgaW5zdGFuY2VHbG9iYWwgPSBldmVudC5kZXRhaWwuaW5zdGFuY2VHbG9iYWw7XG4gICAgfSxcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICBoYW5kbGVyX0xPT0tfQ0FSRF9OT1RJRlk6IGZ1bmN0aW9uIGhhbmRsZXJfTE9PS19DQVJEX05PVElGWShldmVudCkge1xuICAgICAgICB2YXIgYm9keU1zZyA9IGV2ZW50LmRldGFpbC5tc2dCb2R5O1xuICAgICAgICB2YXIgaW5zdGFuY2VHbG9iYWwgPSBldmVudC5kZXRhaWwuaW5zdGFuY2VHbG9iYWw7XG4gICAgfSxcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICBoYW5kbGVyX0RJU0NBUkRfU1VDQ0VTUzogZnVuY3Rpb24gaGFuZGxlcl9ESVNDQVJEX1NVQ0NFU1MoZXZlbnQpIHtcbiAgICAgICAgdmFyIGJvZHlNc2cgPSBldmVudC5kZXRhaWwubXNnQm9keTtcbiAgICAgICAgdmFyIGluc3RhbmNlR2xvYmFsID0gZXZlbnQuZGV0YWlsLmluc3RhbmNlR2xvYmFsO1xuICAgIH0sXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgaGFuZGxlcl9ESVNDQVJEX0ZBSUxFRDogZnVuY3Rpb24gaGFuZGxlcl9ESVNDQVJEX0ZBSUxFRChldmVudCkge1xuICAgICAgICB2YXIgYm9keU1zZyA9IGV2ZW50LmRldGFpbC5tc2dCb2R5O1xuICAgICAgICB2YXIgaW5zdGFuY2VHbG9iYWwgPSBldmVudC5kZXRhaWwuaW5zdGFuY2VHbG9iYWw7XG4gICAgfSxcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICBoYW5kbGVyX0RJU0NBUkRfTk9USUZZOiBmdW5jdGlvbiBoYW5kbGVyX0RJU0NBUkRfTk9USUZZKGV2ZW50KSB7XG4gICAgICAgIHZhciBib2R5TXNnID0gZXZlbnQuZGV0YWlsLm1zZ0JvZHk7XG4gICAgICAgIHZhciBpbnN0YW5jZUdsb2JhbCA9IGV2ZW50LmRldGFpbC5pbnN0YW5jZUdsb2JhbDtcbiAgICB9LFxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICAgIGhhbmRsZXJfQ09NUEFSRV9DQVJEX1NVQ0NFU1M6IGZ1bmN0aW9uIGhhbmRsZXJfQ09NUEFSRV9DQVJEX1NVQ0NFU1MoZXZlbnQpIHtcbiAgICAgICAgdmFyIGJvZHlNc2cgPSBldmVudC5kZXRhaWwubXNnQm9keTtcbiAgICAgICAgdmFyIGluc3RhbmNlR2xvYmFsID0gZXZlbnQuZGV0YWlsLmluc3RhbmNlR2xvYmFsO1xuICAgIH0sXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgaGFuZGxlcl9DT01QQVJFX0NBUkRfRkFJTEVEOiBmdW5jdGlvbiBoYW5kbGVyX0NPTVBBUkVfQ0FSRF9GQUlMRUQoZXZlbnQpIHtcbiAgICAgICAgdmFyIGJvZHlNc2cgPSBldmVudC5kZXRhaWwubXNnQm9keTtcbiAgICAgICAgdmFyIGluc3RhbmNlR2xvYmFsID0gZXZlbnQuZGV0YWlsLmluc3RhbmNlR2xvYmFsO1xuICAgIH0sXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gICAgaGFuZGxlcl9DT01QQVJFX0NBUkRfTk9USUZZOiBmdW5jdGlvbiBoYW5kbGVyX0NPTVBBUkVfQ0FSRF9OT1RJRlkoZXZlbnQpIHtcbiAgICAgICAgdmFyIGJvZHlNc2cgPSBldmVudC5kZXRhaWwubXNnQm9keTtcbiAgICAgICAgdmFyIGluc3RhbmNlR2xvYmFsID0gZXZlbnQuZGV0YWlsLmluc3RhbmNlR2xvYmFsO1xuICAgIH1cblxufTtcbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxubW9kdWxlLmV4cG9ydHMgPSBHYW1lTWVzc2FnZTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzAxYjRkWm5RSmhCeUkyNDhHNFNUbVdGJywgJ1lpbmdzYW56aGFuZ19BbmltVUknKTtcbi8vIHJlc291cmNlcy9HYW1lcy9ZaW5nc2Fuemhhbmcvc2NlbmUvc2NlbmVXYXIvWWluZ3NhbnpoYW5nX0FuaW1VSS5qc1xuXG5jYy5DbGFzcyh7XG4gICAgXCJleHRlbmRzXCI6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyAuLi5cbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7fVxuXG59KTtcbi8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4vLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4vLyB9LFxuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnMWNlMDZPZXJ4Uk1INzV6dE1WNlRWUlEnLCAnWWluZ3NhbnpoYW5nX0JldCcpO1xuLy8gcmVzb3VyY2VzL0dhbWVzL1lpbmdzYW56aGFuZy9yZXMvcHJlZmFiL0JldC9ZaW5nc2FuemhhbmdfQmV0LmpzXG5cbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge30sXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7fSxcbiAgICBzZXRWYWx1ZUFuZFR5cGU6IGZ1bmN0aW9uIHNldFZhbHVlQW5kVHlwZSh0eXBlLCB2YWwpIHtcbiAgICAgICAgY2MubG9nKFwic2V0VmFsdWVBbmRUeXBlOiBmdW5jdGlvbih0eXBlLHZhbClcIik7XG4gICAgICAgIHZhciBpbWdfdXJsO1xuICAgICAgICBzd2l0Y2ggKHR5cGUpIHtcbiAgICAgICAgICAgIGNhc2UgMTpcbiAgICAgICAgICAgICAgICBpbWdfdXJsID0gXCJHYW1lcy9ZaW5nc2FuemhhbmcvcmVzL3ByZWZhYi9CZXQvaW1hZ2UvYmV0X3JlZFwiO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAyOlxuICAgICAgICAgICAgICAgIGltZ191cmwgPSBcIkdhbWVzL1lpbmdzYW56aGFuZy9yZXMvcHJlZmFiL0JldC9pbWFnZS9iZXRfZ3JlZW5cIjtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgMzpcbiAgICAgICAgICAgICAgICBpbWdfdXJsID0gXCJHYW1lcy9ZaW5nc2FuemhhbmcvcmVzL3ByZWZhYi9CZXQvaW1hZ2UvYmV0X29yZ1wiO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIHZhciBzcHJpdGUgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSk7XG4gICAgICAgIGNjLmxvYWRlci5sb2FkUmVzKGltZ191cmwsIGNjLlNwcml0ZUZyYW1lLCBmdW5jdGlvbiAoZXJyb3IsIHNwcml0ZUZyYW1lKSB7XG4gICAgICAgICAgICBpZiAoIWVycm9yKSB7XG4gICAgICAgICAgICAgICAgc3ByaXRlLnNwcml0ZUZyYW1lID0gc3ByaXRlRnJhbWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuXG4gICAgICAgIHZhciBsYWJlbCA9IHRoaXMubm9kZS5nZXRDaGlsZEJ5TmFtZShcImxhYmVsXCIpLmdldENvbXBvbmVudChjYy5MYWJlbCk7XG5cbiAgICAgICAgbGFiZWwuc3RyaW5nID0gdmFsLnRvU3RyaW5nKCk7XG4gICAgfVxuXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4gICAgLy8gfSxcbn0pO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnZTNkZDhCeEtyMUNvWU43QmsvemJNcGgnLCAnWWluZ3NhbnpoYW5nX0NhcmQnKTtcbi8vIHJlc291cmNlcy9HYW1lcy9ZaW5nc2FuemhhbmcvcmVzL3ByZWZhYi9DYXJkL1lpbmdzYW56aGFuZ19DYXJkLmpzXG5cbnZhciBDYXJkQ29udHJvbGxlciA9IGNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICAvL+ato+mdoueZveW6leaIluiAheiDjOmdouWbvuahiFxuICAgICAgICBmYWNlX0ltZzoge1xuICAgICAgICAgICAgXCJkZWZhdWx0XCI6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBjYy5TcHJpdGVcbiAgICAgICAgfSxcbiAgICAgICAgLy9BLTEwLEotSyzlpKflsI/njotcbiAgICAgICAgY2FyZElEX0ltZzoge1xuICAgICAgICAgICAgXCJkZWZhdWx0XCI6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBjYy5TcHJpdGVcbiAgICAgICAgfSxcbiAgICAgICAgLy/lsI/lnovniYznp43nsbvlm77moYhcbiAgICAgICAgc21hbGxfdHlwZV9JbWc6IHtcbiAgICAgICAgICAgIFwiZGVmYXVsdFwiOiBudWxsLFxuICAgICAgICAgICAgdHlwZTogY2MuU3ByaXRlXG4gICAgICAgIH0sXG4gICAgICAgIC8v5aSn5Z6L54mM56eN57G75Zu+5qGIXG4gICAgICAgIGJpZ190eXBlX0ltZzoge1xuICAgICAgICAgICAgXCJkZWZhdWx0XCI6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBjYy5TcHJpdGVcbiAgICAgICAgfSxcbiAgICAgICAgY2FyZFZhbHVlOiAwXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge30sXG4gICAgU2V0RGlzQ2FyZDogZnVuY3Rpb24gU2V0RGlzQ2FyZCgpIHtcblxuICAgICAgICB2YXIgZmFjZV91cmwgPSBcIkdhbWVzL1lpbmdzYW56aGFuZy9yZXMvcHJlZmFiL0NhcmQvaW1hZ2UvXCIgKyBcImJhY2tHcmF5XCI7XG4gICAgICAgIGNjLmxvZyhcIlNldERpc0NhcmRcIiwgZmFjZV91cmwpO1xuICAgICAgICB2YXIgZmFjZV9pbWFnZSA9IHRoaXMuZmFjZV9JbWc7XG4gICAgICAgIGNjLmxvYWRlci5sb2FkUmVzKGZhY2VfdXJsLCBjYy5TcHJpdGVGcmFtZSwgZnVuY3Rpb24gKGVycm9yLCBzcHJpdGVGcmFtZSkge1xuICAgICAgICAgICAgaWYgKCFlcnJvcikge1xuICAgICAgICAgICAgICAgIGZhY2VfaW1hZ2Uuc3ByaXRlRnJhbWUgPSBzcHJpdGVGcmFtZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfSxcbiAgICBTZXRDYXJkSW5mbzogZnVuY3Rpb24gU2V0Q2FyZEluZm8odmFsKSB7XG4gICAgICAgIHRoaXMuY2FyZFZhbHVlID0gdmFsO1xuICAgICAgICB2YXIgZmFjZV9pbWFnZSA9IHRoaXMuZmFjZV9JbWc7XG4gICAgICAgIHZhciBjYXJkSURfaW1hZ2UgPSB0aGlzLmNhcmRJRF9JbWc7XG4gICAgICAgIHZhciBzbWFsbF90eXBlX2ltYWdlID0gdGhpcy5zbWFsbF90eXBlX0ltZztcbiAgICAgICAgdmFyIGJpZ190eXBlX2ltYWdlID0gdGhpcy5iaWdfdHlwZV9JbWc7XG5cbiAgICAgICAgaWYgKHZhbCA9PT0gMCB8fCB2YWwgPj0gMHg1MCkge1xuICAgICAgICAgICAgY2FyZElEX2ltYWdlLm5vZGUub3BhY2l0eSA9IDA7XG4gICAgICAgICAgICBzbWFsbF90eXBlX2ltYWdlLm5vZGUub3BhY2l0eSA9IDA7XG4gICAgICAgICAgICBiaWdfdHlwZV9pbWFnZS5ub2RlLm9wYWNpdHkgPSAwO1xuXG4gICAgICAgICAgICB2YXIgZmFjZV91cmwgPSBcIkdhbWVzL1lpbmdzYW56aGFuZy9yZXMvcHJlZmFiL0NhcmQvaW1hZ2UvXCIgKyBcImJhY2tcIjtcbiAgICAgICAgICAgIGlmICh2YWwgPT0gMHg1RSkgZmFjZV91cmwgPSBcIkdhbWVzL1lpbmdzYW56aGFuZy9yZXMvcHJlZmFiL0NhcmQvaW1hZ2UvXCIgKyBcInNtYWxsX2pva2VyXCI7ZWxzZSBpZiAodmFsID09IDB4NUYpIGZhY2VfdXJsID0gXCJHYW1lcy9ZaW5nc2FuemhhbmcvcmVzL3ByZWZhYi9DYXJkL2ltYWdlL1wiICsgXCJiaWdfam9rZXJcIjtcblxuICAgICAgICAgICAgY2MubG9hZGVyLmxvYWRSZXMoZmFjZV91cmwsIGNjLlNwcml0ZUZyYW1lLCBmdW5jdGlvbiAoZXJyb3IsIHNwcml0ZUZyYW1lKSB7XG4gICAgICAgICAgICAgICAgaWYgKCFlcnJvcikge1xuICAgICAgICAgICAgICAgICAgICBmYWNlX2ltYWdlLnNwcml0ZUZyYW1lID0gc3ByaXRlRnJhbWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB2YXIgZmFjZV91cmwgPSBcIkdhbWVzL1lpbmdzYW56aGFuZy9yZXMvcHJlZmFiL0NhcmQvaW1hZ2UvXCIgKyBcImZhY2VcIjtcbiAgICAgICAgICAgIGNjLmxvYWRlci5sb2FkUmVzKGZhY2VfdXJsLCBjYy5TcHJpdGVGcmFtZSwgZnVuY3Rpb24gKGVycm9yLCBzcHJpdGVGcmFtZSkge1xuICAgICAgICAgICAgICAgIGlmICghZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgZmFjZV9pbWFnZS5zcHJpdGVGcmFtZSA9IHNwcml0ZUZyYW1lO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICBjYXJkSURfaW1hZ2Uubm9kZS5vcGFjaXR5ID0gMjU1O1xuICAgICAgICAgICAgc21hbGxfdHlwZV9pbWFnZS5ub2RlLm9wYWNpdHkgPSAyNTU7XG4gICAgICAgICAgICBiaWdfdHlwZV9pbWFnZS5ub2RlLm9wYWNpdHkgPSAyNTU7XG5cbiAgICAgICAgICAgIHZhciBwdWtlS2luZCA9IHZhbCA+PiA0O1xuICAgICAgICAgICAgdmFyIHB1a2VWYWwgPSB2YWwgJiAweEY7XG5cbiAgICAgICAgICAgIHZhciBzbWFsbF9UeXBlX3VybCA9IFwiR2FtZXMvWWluZ3NhbnpoYW5nL3Jlcy9wcmVmYWIvQ2FyZC9pbWFnZS9zbWFsbF9wdWtlX2tpbmRfXCIgKyBwdWtlS2luZC50b1N0cmluZygpO1xuICAgICAgICAgICAgdmFyIGJpZ19UeXBlX3VybCA9IFwiR2FtZXMvWWluZ3NhbnpoYW5nL3Jlcy9wcmVmYWIvQ2FyZC9pbWFnZS9iaWdfcHVrZV9raW5kX1wiICsgcHVrZUtpbmQudG9TdHJpbmcoKTtcbiAgICAgICAgICAgIHZhciBjYXJkSURfbmFtZV91cmwgPSBcIkdhbWVzL1lpbmdzYW56aGFuZy9yZXMvcHJlZmFiL0NhcmQvaW1hZ2UvYmxhY2tfZmxhZy9oXCIgKyBwdWtlVmFsLnRvU3RyaW5nKCk7XG4gICAgICAgICAgICBpZiAocHVrZUtpbmQgJSAyID09PSAxKSBjYXJkSURfbmFtZV91cmwgPSBcIkdhbWVzL1lpbmdzYW56aGFuZy9yZXMvcHJlZmFiL0NhcmQvaW1hZ2UvcmVkX2ZsYWcvaFwiICsgcHVrZVZhbC50b1N0cmluZygpO1xuXG4gICAgICAgICAgICBjYy5sb2FkZXIubG9hZFJlcyhjYXJkSURfbmFtZV91cmwsIGNjLlNwcml0ZUZyYW1lLCBmdW5jdGlvbiAoZXJyb3IsIHNwcml0ZUZyYW1lKSB7XG4gICAgICAgICAgICAgICAgaWYgKCFlcnJvcikge1xuICAgICAgICAgICAgICAgICAgICBjYXJkSURfaW1hZ2Uuc3ByaXRlRnJhbWUgPSBzcHJpdGVGcmFtZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgY2MubG9hZGVyLmxvYWRSZXMoc21hbGxfVHlwZV91cmwsIGNjLlNwcml0ZUZyYW1lLCBmdW5jdGlvbiAoZXJyb3IsIHNwcml0ZUZyYW1lKSB7XG4gICAgICAgICAgICAgICAgaWYgKCFlcnJvcikge1xuICAgICAgICAgICAgICAgICAgICBzbWFsbF90eXBlX2ltYWdlLnNwcml0ZUZyYW1lID0gc3ByaXRlRnJhbWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIGNjLmxvYWRlci5sb2FkUmVzKGJpZ19UeXBlX3VybCwgY2MuU3ByaXRlRnJhbWUsIGZ1bmN0aW9uIChlcnJvciwgc3ByaXRlRnJhbWUpIHtcbiAgICAgICAgICAgICAgICBpZiAoIWVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIGJpZ190eXBlX2ltYWdlLnNwcml0ZUZyYW1lID0gc3ByaXRlRnJhbWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9XG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzEzZDM5SEFZUkZBQW9Pb1doc1ZqZDl5JywgJ1lpbmdzYW56aGFuZ19FbmRVSScpO1xuLy8gcmVzb3VyY2VzL0dhbWVzL1lpbmdzYW56aGFuZy9zY2VuZS9zY2VuZVdhci9ZaW5nc2FuemhhbmdfRW5kVUkuanNcblxuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIC8vIGZvbzoge1xuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXG4gICAgICAgIC8vICAgIHVybDogY2MuVGV4dHVyZTJELCAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIHZpc2libGU6IHRydWUsICAgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICBkaXNwbGF5TmFtZTogJ0ZvbycsIC8vIG9wdGlvbmFsXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcbiAgICAgICAgLy8gfSxcbiAgICAgICAgLy8gLi4uXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge31cblxufSk7XG4vLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xuLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcblxuLy8gfSxcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzYzMDlmaFJMMTlPOHJiUkdMYW5qcUduJywgJ1lpbmdzYW56aGFuZ19Ib21lVUknKTtcbi8vIHJlc291cmNlcy9HYW1lcy9ZaW5nc2Fuemhhbmcvc2NlbmUvc2NlbmVIb21lL1lpbmdzYW56aGFuZ19Ib21lVUkuanNcblxudmFyIEdsb2JhbE1hbmFnZXIgPSByZXF1aXJlKFwiR2xvYmFsTWFuYWdlclwiKTtcbnZhciBQcm90b2NvbE1lc3NhZ2UgPSByZXF1aXJlKFwiUHJvdG9jb2xNZXNzYWdlXCIpO1xudmFyIGNvbnN0RGVmID0gcmVxdWlyZShcIkNvbnN0RGVmXCIpO1xudmFyIGdhbWVDb25zdERlZiA9IHJlcXVpcmUoXCJZaW5nc2FuemhhbmdDb25zdERlZlwiKTtcblxuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIC8vIGZvbzoge1xuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXG4gICAgICAgIC8vICAgIHVybDogY2MuVGV4dHVyZTJELCAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIHZpc2libGU6IHRydWUsICAgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICBkaXNwbGF5TmFtZTogJ0ZvbycsIC8vIG9wdGlvbmFsXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcbiAgICAgICAgLy8gfSxcbiAgICAgICAgLy8gLi4uXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge30sXG4gICAgZW50ZXJfcm9vbTogZnVuY3Rpb24gZW50ZXJfcm9vbSgpIHtcbiAgICAgICAgY2MubG9nKFwiZW50ZXJfcm9vbVwiKTtcbiAgICAgICAgdmFyIGdhbWVEYXRhID0gR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5HZXRHYW1lRGF0YShHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLnNlbGZEYXRhLm5DdXJHYW1lSUQpO1xuICAgICAgICAvLyB2YXIgY2xhc3NpY3NJdGVtQ29tcCA9IGV2ZW50LnRhcmdldC5nZXRDb21wb25lbnQoXCJkb3VkaXpodUpEX2NsYXNzaWNzSXRlbVwiKTsgXG4gICAgICAgIC8vIGNvbnN0RGVmLlNFUlZFUl9VUkwuZ2FtZSA9IGNsYXNzaWNzSXRlbUNvbXAuc2VydmVyVXJsO1xuICAgICAgICAvLyBnYW1lRGF0YS5uT3Blbk1vZGUgPSBjb25zdERlZi5CQVRUTEVfT1BFTl9NT0RFLlRBQkxFO1xuICAgICAgICAvLyBnYW1lRGF0YS5uUm9vbUlEID0gY2xhc3NpY3NJdGVtQ29tcC5yb29tSUQ7XG4gICAgICAgIHZhciBhcmVhQmFzZUluZm8gPSBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLmNvbmZEYXRhLmdldFJvb21BcmVhKEdsb2JhbE1hbmFnZXIuaW5zdGFuY2Uuc2VsZkRhdGEubkN1ckdhbWVJRCwgMSk7XG5cbiAgICAgICAgdmFyIG5vZGVCYXNlSW5mbyA9IEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuY29uZkRhdGEuZ2V0R2FtZU5vZGUoYXJlYUJhc2VJbmZvLkZhcmVhX2lkKTtcblxuICAgICAgICB2YXIgcm9vbUJhc2VJbmZvID0gR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5jb25mRGF0YS5nZXRHYW1lUm9vbShub2RlQmFzZUluZm9bMF0uRm5vZGVfaWQpO1xuXG4gICAgICAgIHZhciBzZXJ2ZXJCYXNlSW5mbyA9IEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuY29uZkRhdGEuZ2V0U2VydmVySW5mbyhyb29tQmFzZUluZm8uRnNlcnZlcl9pZCk7XG5cbiAgICAgICAgZ2FtZURhdGEubk9wZW5Nb2RlID0gY29uc3REZWYuQkFUVExFX09QRU5fTU9ERS5UQUJMRTtcbiAgICAgICAgZ2FtZURhdGEublJvb21JRCA9IHJvb21CYXNlSW5mby5Gcm9vbV9pZDtcblxuICAgICAgICBjb25zdERlZi5TRVJWRVJfVVJMLmdhbWUgPSBcIndzOi8vXCIgKyBzZXJ2ZXJCYXNlSW5mby5Gc2VydmVyX2lwICsgXCI6XCIgKyBzZXJ2ZXJCYXNlSW5mby5Gc2VydmVyX3BvcnQgKyBcIi9cIjtcblxuICAgICAgICBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLkdldEdhbWVDb250cm9sbGVyKEdsb2JhbE1hbmFnZXIuaW5zdGFuY2Uuc2VsZkRhdGEubkN1ckdhbWVJRCkuU2VuZE1zZyhnYW1lQ29uc3REZWYuQ09OTkVDVF9DQUxMQkFDS19TVEFUVVMuSE9NRV9FTlRFUl9ST09NKTtcbiAgICB9XG59KTtcbi8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4vLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4vLyB9LFxuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnOWQwZDBMS1hpOUUrN3cybjNqZ3RmYm4nLCAnWWluZ3NhbnpoYW5nX015Q29udHJvbGxlcicpO1xuLy8gcmVzb3VyY2VzL0dhbWVzL1lpbmdzYW56aGFuZy9zY2VuZS9zY2VuZVdhci9ZaW5nc2FuemhhbmdfTXlDb250cm9sbGVyLmpzXG5cbnZhciBHbG9iYWxNYW5hZ2VyID0gcmVxdWlyZShcIkdsb2JhbE1hbmFnZXJcIik7XG52YXIgUHJvdG9jb2xNZXNzYWdlID0gcmVxdWlyZShcIlByb3RvY29sTWVzc2FnZVwiKTtcbnZhciBjb25zdERlZiA9IHJlcXVpcmUoXCJDb25zdERlZlwiKTtcbnZhciBnYW1lQ29uc3REZWYgPSByZXF1aXJlKFwiWWluZ3NhbnpoYW5nQ29uc3REZWZcIik7XG5cbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuXG4gICAgICAgIG9wZXJhdGlvbl9ub2RlOiB7XG4gICAgICAgICAgICBcImRlZmF1bHRcIjogbnVsbCxcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGVcbiAgICAgICAgfVxuXG4gICAgfSxcblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge1xuICAgICAgICB0aGlzLnJlZnJlc2hVSSgpO1xuICAgIH0sXG4gICAgZm9sbG93X2JldF9yZXE6IGZ1bmN0aW9uIGZvbGxvd19iZXRfcmVxKCkge1xuXG4gICAgICAgIHZhciBzY29yZSA9IEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuR2V0R2FtZURhdGEoR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5zZWxmRGF0YS5uVGVhbUlEKS5uQ3VyQmV0VmFsO1xuICAgICAgICB2YXIgbXNnID0gbmV3IFByb3RvY29sTWVzc2FnZShnYW1lQ29uc3REZWYuTUVTU0FHRS5DTURfTUFJTl9ZaW5nU2FuWmhhbmcsIGdhbWVDb25zdERlZi5NRVNTQUdFLkZPTExPV19CRVRfUkVRLCBmYWxzZSk7XG4gICAgICAgIFByb3RvY29sTWVzc2FnZS5BZGRWZWN0SXRlbUJ5dGUobXNnLl9ib2R5X21zZywgc2NvcmUpO1xuICAgICAgICBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLlNvY2tldE1hbmFnZXIuU2VuZE1lc3NhZ2UoY29uc3REZWYuU0VSVkVSX1VSTC5nYW1lLCBtc2cpO1xuICAgIH0sXG4gICAgYWRkX2JldF9yZXE6IGZ1bmN0aW9uIGFkZF9iZXRfcmVxKCkge1xuXG4gICAgICAgIHZhciBzY29yZSA9IEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuR2V0R2FtZURhdGEoR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5zZWxmRGF0YS5uVGVhbUlEKS5uQ3VyQmV0VmFsO1xuICAgICAgICB2YXIgbXNnID0gbmV3IFByb3RvY29sTWVzc2FnZShnYW1lQ29uc3REZWYuTUVTU0FHRS5DTURfTUFJTl9ZaW5nU2FuWmhhbmcsIGdhbWVDb25zdERlZi5NRVNTQUdFLkFERF9CRVRfUkVRLCBmYWxzZSk7XG4gICAgICAgIFByb3RvY29sTWVzc2FnZS5BZGRWZWN0SXRlbUJ5dGUobXNnLl9ib2R5X21zZywgc2NvcmUpO1xuICAgICAgICBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLlNvY2tldE1hbmFnZXIuU2VuZE1lc3NhZ2UoY29uc3REZWYuU0VSVkVSX1VSTC5nYW1lLCBtc2cpO1xuICAgIH0sXG4gICAgbG9va19jYXJkX3JlcTogZnVuY3Rpb24gbG9va19jYXJkX3JlcSgpIHtcblxuICAgICAgICB2YXIgc2NvcmUgPSBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLkdldEdhbWVEYXRhKEdsb2JhbE1hbmFnZXIuaW5zdGFuY2Uuc2VsZkRhdGEublRlYW1JRCkubkN1ckJldFZhbDtcbiAgICAgICAgdmFyIG1zZyA9IG5ldyBQcm90b2NvbE1lc3NhZ2UoZ2FtZUNvbnN0RGVmLk1FU1NBR0UuQ01EX01BSU5fWWluZ1NhblpoYW5nLCBnYW1lQ29uc3REZWYuTUVTU0FHRS5MT09LX0NBUkRfUkVRLCBmYWxzZSk7XG4gICAgICAgIFByb3RvY29sTWVzc2FnZS5BZGRWZWN0SXRlbUJ5dGUobXNnLl9ib2R5X21zZywgMSk7XG4gICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuU29ja2V0TWFuYWdlci5TZW5kTWVzc2FnZShjb25zdERlZi5TRVJWRVJfVVJMLmdhbWUsIG1zZyk7XG4gICAgfSxcbiAgICBjb21wYXJlX2NhcmRfcmVxOiBmdW5jdGlvbiBjb21wYXJlX2NhcmRfcmVxKCkge1xuXG4gICAgICAgIHZhciBzY29yZSA9IEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuR2V0R2FtZURhdGEoR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5zZWxmRGF0YS5uVGVhbUlEKS5uQ3VyQmV0VmFsO1xuICAgICAgICB2YXIgbXNnID0gbmV3IFByb3RvY29sTWVzc2FnZShnYW1lQ29uc3REZWYuTUVTU0FHRS5DTURfTUFJTl9ZaW5nU2FuWmhhbmcsIGdhbWVDb25zdERlZi5NRVNTQUdFLkNPTVBBUkVfQ0FSRF9SRVEsIGZhbHNlKTtcbiAgICAgICAgUHJvdG9jb2xNZXNzYWdlLkFkZFZlY3RJdGVtQnl0ZShtc2cuX2JvZHlfbXNnLCBzY29yZSk7XG4gICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuU29ja2V0TWFuYWdlci5TZW5kTWVzc2FnZShjb25zdERlZi5TRVJWRVJfVVJMLmdhbWUsIG1zZyk7XG4gICAgfSxcbiAgICBkaXNjYXJkX3JlcTogZnVuY3Rpb24gZGlzY2FyZF9yZXEoKSB7XG5cbiAgICAgICAgdmFyIHNjb3JlID0gR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5HZXRHYW1lRGF0YShHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLnNlbGZEYXRhLm5UZWFtSUQpLm5DdXJCZXRWYWw7XG4gICAgICAgIHZhciBtc2cgPSBuZXcgUHJvdG9jb2xNZXNzYWdlKGdhbWVDb25zdERlZi5NRVNTQUdFLkNNRF9NQUlOX1lpbmdTYW5aaGFuZywgZ2FtZUNvbnN0RGVmLk1FU1NBR0UuRElTQ0FSRF9SRVEsIGZhbHNlKTtcbiAgICAgICAgUHJvdG9jb2xNZXNzYWdlLkFkZFZlY3RJdGVtQnl0ZShtc2cuX2JvZHlfbXNnLCAxKTtcbiAgICAgICAgR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5Tb2NrZXRNYW5hZ2VyLlNlbmRNZXNzYWdlKGNvbnN0RGVmLlNFUlZFUl9VUkwuZ2FtZSwgbXNnKTtcbiAgICB9LFxuICAgIHJlZnJlc2hVSTogZnVuY3Rpb24gcmVmcmVzaFVJKCkge1xuXG4gICAgICAgIHZhciBmb2xsb3dfbm9kZSA9IHRoaXMub3BlcmF0aW9uX25vZGUuZ2V0Q2hpbGRCeU5hbWUoXCJmb2xsb3dfYmV0XCIpO1xuICAgICAgICB2YXIgYWRkX25vZGUgPSB0aGlzLm9wZXJhdGlvbl9ub2RlLmdldENoaWxkQnlOYW1lKFwiYWRkX2JldFwiKTtcbiAgICAgICAgdmFyIGxvb2tfbm9kZSA9IHRoaXMub3BlcmF0aW9uX25vZGUuZ2V0Q2hpbGRCeU5hbWUoXCJsb29rX2NhcmRcIik7XG4gICAgICAgIHZhciBjb21wYXJlX25vZGUgPSB0aGlzLm9wZXJhdGlvbl9ub2RlLmdldENoaWxkQnlOYW1lKFwiY29tcGFyZV9jYXJkXCIpO1xuICAgICAgICB2YXIgZGlzY2FyZF9ub2RlID0gdGhpcy5vcGVyYXRpb25fbm9kZS5nZXRDaGlsZEJ5TmFtZShcImRpc2NhcmRcIik7XG5cbiAgICAgICAgdmFyIG5vcm1hbF91cmwgPSBcIkdhbWVzL1lpbmdzYW56aGFuZy9yZXMvaW1hZ2Uvc2NlbmVXYXIvYnV0dG9uX25vcm1hbFwiO1xuICAgICAgICB2YXIgZGlzYWJsZV91cmwgPSBcIkdhbWVzL1lpbmdzYW56aGFuZy9yZXMvaW1hZ2Uvc2NlbmVXYXIvYnV0dG9uX2Rpc2FibGVcIjtcbiAgICAgICAgdmFyIGZvbGxvd191cmwgPSBcIkdhbWVzL1lpbmdzYW56aGFuZy9yZXMvaW1hZ2Uvc2NlbmVXYXIvYnV0dG9uX2hsXCI7XG4gICAgICAgIHZhciB0YWcgPSAxO1xuXG4gICAgICAgIGlmICh0YWcgPiAwLjUpIHtcbiAgICAgICAgICAgIHRoaXMubG9hZFNwcml0ZUZyYW1lV2l0aFVybEFuZE5vZGUoZm9sbG93X25vZGUsIGZvbGxvd191cmwpO1xuICAgICAgICAgICAgdGhpcy5sb2FkU3ByaXRlRnJhbWVXaXRoVXJsQW5kTm9kZShhZGRfbm9kZSwgbm9ybWFsX3VybCk7XG4gICAgICAgICAgICB0aGlzLmxvYWRTcHJpdGVGcmFtZVdpdGhVcmxBbmROb2RlKGxvb2tfbm9kZSwgbm9ybWFsX3VybCk7XG4gICAgICAgICAgICB0aGlzLmxvYWRTcHJpdGVGcmFtZVdpdGhVcmxBbmROb2RlKGNvbXBhcmVfbm9kZSwgbm9ybWFsX3VybCk7XG4gICAgICAgICAgICB0aGlzLmxvYWRTcHJpdGVGcmFtZVdpdGhVcmxBbmROb2RlKGRpc2NhcmRfbm9kZSwgbm9ybWFsX3VybCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmxvYWRTcHJpdGVGcmFtZVdpdGhVcmxBbmROb2RlKGZvbGxvd19ub2RlLCBkaXNhYmxlX3VybCk7XG4gICAgICAgICAgICB0aGlzLmxvYWRTcHJpdGVGcmFtZVdpdGhVcmxBbmROb2RlKGFkZF9ub2RlLCBkaXNhYmxlX3VybCk7XG4gICAgICAgICAgICB0aGlzLmxvYWRTcHJpdGVGcmFtZVdpdGhVcmxBbmROb2RlKGxvb2tfbm9kZSwgZGlzYWJsZV91cmwpO1xuICAgICAgICAgICAgdGhpcy5sb2FkU3ByaXRlRnJhbWVXaXRoVXJsQW5kTm9kZShjb21wYXJlX25vZGUsIGRpc2FibGVfdXJsKTtcbiAgICAgICAgICAgIHRoaXMubG9hZFNwcml0ZUZyYW1lV2l0aFVybEFuZE5vZGUoZGlzY2FyZF9ub2RlLCBkaXNhYmxlX3VybCk7XG4gICAgICAgIH1cbiAgICB9LFxuICAgIGxvYWRTcHJpdGVGcmFtZVdpdGhVcmxBbmROb2RlOiBmdW5jdGlvbiBsb2FkU3ByaXRlRnJhbWVXaXRoVXJsQW5kTm9kZShub2RlLCB1cmwpIHtcbiAgICAgICAgY2MubG9hZGVyLmxvYWRSZXModXJsLCBjYy5TcHJpdGVGcmFtZSwgZnVuY3Rpb24gKGVycm9yLCBzcHJpdGVGcmFtZSkge1xuICAgICAgICAgICAgaWYgKCFlcnJvcikge1xuICAgICAgICAgICAgICAgIG5vZGUuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSkuc3ByaXRlRnJhbWUgPSBzcHJpdGVGcmFtZTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgY2MubG9nKFwibG9hZGVyX3VybDpcIiwgdXJsLCBcImVycm9yOlwiLCBlcnJvcik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xuICAgIC8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XG5cbiAgICAvLyB9LFxufSk7XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICcwMTk5MXNhTWpkR0E0OWpKaEhFR0p4KycsICdZaW5nc2FuemhhbmdfUGxheWVyc1VJJyk7XG4vLyByZXNvdXJjZXMvR2FtZXMvWWluZ3NhbnpoYW5nL3NjZW5lL3NjZW5lV2FyL1lpbmdzYW56aGFuZ19QbGF5ZXJzVUkuanNcblxudmFyIGdhbWVDb25zdERlZiA9IHJlcXVpcmUoXCJZaW5nc2FuemhhbmdDb25zdERlZlwiKTtcbnZhciBHbG9iYWxNYW5hZ2VyID0gcmVxdWlyZShcIkdsb2JhbE1hbmFnZXJcIik7XG5cbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuXG4gICAgICAgIHByZWZhYl9wbGF5ZXI6IHtcbiAgICAgICAgICAgIFwiZGVmYXVsdFwiOiBudWxsLFxuICAgICAgICAgICAgdHlwZTogY2MuUHJlZmFiXG4gICAgICAgIH0sXG4gICAgICAgIHByZWZhYl9iZXQ6IHtcbiAgICAgICAgICAgIFwiZGVmYXVsdFwiOiBudWxsLFxuICAgICAgICAgICAgdHlwZTogY2MuUHJlZmFiXG4gICAgICAgIH0sXG4gICAgICAgIGJldF90YWJsZToge1xuICAgICAgICAgICAgXCJkZWZhdWx0XCI6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlXG4gICAgICAgIH0sXG4gICAgICAgIHBsYXllcnNBcnJheTogW11cblxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHtcblxuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IDU7IGkrKykge1xuICAgICAgICAgICAgdmFyIHBsYXllciA9IGNjLmluc3RhbnRpYXRlKHRoaXMucHJlZmFiX3BsYXllcik7XG4gICAgICAgICAgICB2YXIgY29tcG9uID0gcGxheWVyLmdldENvbXBvbmVudChcIllpbmdzYW56aGFuZ19QbGF5ZXJcIik7XG4gICAgICAgICAgICBjb21wb24uSW5pdEluZm8oaSArIDEpO1xuICAgICAgICAgICAgdGhpcy5ub2RlLmFkZENoaWxkKHBsYXllcik7XG4gICAgICAgICAgICB0aGlzLnBsYXllcnNBcnJheS5wdXNoKHBsYXllcik7XG4gICAgICAgIH1cbiAgICB9LFxuICAgIGluaXRQbGF5ZXJzOiBmdW5jdGlvbiBpbml0UGxheWVycygpIHtcbiAgICAgICAgLy8gdmFyIGdhbWVEYXRhID0gR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5HZXRHYW1lRGF0YShHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLnNlbGZEYXRhLm5DdXJHYW1lSUQpO1xuICAgICAgICAvLyB2YXIgbXlUZWFtSUQgPSBnYW1lRGF0YS5uVGVhbUlEO1xuICAgICAgICAvLyBsZXQgblNlbGZJbmRleCA9IDA7XG4gICAgICAgIC8vIGZvciAoblNlbGZJbmRleD0wOyBuU2VsZkluZGV4PGdhbWVEYXRhLnZlY3RUZWFtTGlzdC5sZW5ndGg7IG5TZWxmSW5kZXgrKylcbiAgICAgICAgLy8ge1xuICAgICAgICAvLyAgICAgaWYgKGdhbWVEYXRhLnZlY3RUZWFtTGlzdFtuU2VsZkluZGV4XS5uVGVhbUlEID09IG15VGVhbUlEKSBicmVhaztcbiAgICAgICAgLy8gfVxuICAgICAgICAvLyBpZiAoblNlbGZJbmRleCA9PSBnYW1lRGF0YS52ZWN0VGVhbUxpc3QubGVuZ3RoKSByZXR1cm47XG5cbiAgICAgICAgLy8gbGV0IG5DdXJJbmRleCA9IG5TZWxmSW5kZXg7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdGhpcy5wbGF5ZXJzQXJyYXkubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIHZhciBwbGF5ZXJDb21wID0gdGhpcy5wbGF5ZXJzQXJyYXlbaV0uZ2V0Q29tcG9uZW50KFwiWWluZ3NhbnpoYW5nX1BsYXllclwiKTtcbiAgICAgICAgICAgIC8vIHBsYXllckNvbXAuVXBEYXRlVmlldyhuQ3VySW5kZXgrMSk7ICBcbiAgICAgICAgICAgIHBsYXllckNvbXAuVXBEYXRlVmlldyhpKTtcbiAgICAgICAgICAgIC8vIG5DdXJJbmRleCA9IChuQ3VySW5kZXg+PTIpPzA6KG5DdXJJbmRleCsxKTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgc2VuZENhcmQ6IGZ1bmN0aW9uIHNlbmRDYXJkKCkge1xuICAgICAgICB2YXIgZ2FtZURhdGEgPSBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLkdldEdhbWVEYXRhKEdsb2JhbE1hbmFnZXIuaW5zdGFuY2Uuc2VsZkRhdGEubkN1ckdhbWVJRCk7XG5cbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB0aGlzLnBsYXllcnNBcnJheS5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgdmFyIHBsYXllckNvbXAgPSB0aGlzLnBsYXllcnNBcnJheVtpXS5nZXRDb21wb25lbnQoXCJZaW5nc2FuemhhbmdfUGxheWVyXCIpO1xuICAgICAgICAgICAgcGxheWVyQ29tcC5zZW5kQ2FyZHMoKTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgc2VsZkZvbGxvd0JldDogZnVuY3Rpb24gc2VsZkZvbGxvd0JldCgpIHtcbiAgICAgICAgdGhpcy5hZGRCZXRGcm9tUG9zKDAsIDEwMDAsIDEpO1xuICAgIH0sXG4gICAgc2VsZkFkZEJldDogZnVuY3Rpb24gc2VsZkFkZEJldCgpIHtcbiAgICAgICAgdGhpcy5hZGRCZXRGcm9tUG9zKDAsIDIwMDAsIDIpO1xuICAgIH0sXG4gICAgLy8gcG9zICDlh6Dlj7fkvY3kuIvms6ggIHZhbCDkuIvms6jlpJrlsJEgIHR5cGUg56Cd56CB57G75Z6LIDHjgIEy44CBM1xuICAgIGFkZEJldEZyb21Qb3M6IGZ1bmN0aW9uIGFkZEJldEZyb21Qb3MocG9zLCB2YWwsIHR5cGUpIHtcblxuICAgICAgICB2YXIgcGxheWVyX2FsbGJldF9ub2RlID0gdGhpcy5wbGF5ZXJzQXJyYXlbcG9zXS5nZXRDaGlsZEJ5TmFtZShcInNpZGVOb2RlXCIpLmdldENoaWxkQnlOYW1lKFwiYmV0XCIpO1xuICAgICAgICB2YXIgcG9zaXRpb24gPSBwbGF5ZXJfYWxsYmV0X25vZGUuY29udmVydFRvV29ybGRTcGFjZSh0aGlzLmJldF90YWJsZS5nZXRQb3NpdGlvbigpKTtcbiAgICAgICAgdmFyIGZyb21Qb3NpdGlvbiA9IGNjLnYyKHBvc2l0aW9uLnggLSA0NzAsIHBvc2l0aW9uLnkgKyAxNzApO1xuICAgICAgICB2YXIgdG9Qb3NpdGlvbiA9IHRoaXMucmFuZG9tUG9zaXRpb24oKTtcbiAgICAgICAgdmFyIGJldCA9IGNjLmluc3RhbnRpYXRlKHRoaXMucHJlZmFiX2JldCk7XG4gICAgICAgIHZhciBsZXRfanMgPSBiZXQuZ2V0Q29tcG9uZW50KFwiWWluZ3NhbnpoYW5nX0JldFwiKTtcbiAgICAgICAgYmV0LnNldFBvc2l0aW9uKGZyb21Qb3NpdGlvbik7XG4gICAgICAgIGxldF9qcy5zZXRWYWx1ZUFuZFR5cGUodHlwZSwgdmFsKTtcbiAgICAgICAgdGhpcy5iZXRfdGFibGUuYWRkQ2hpbGQoYmV0KTtcbiAgICAgICAgdmFyIGFjdGlvbkJ5ID0gY2MubW92ZVRvKDAuNSwgdG9Qb3NpdGlvbik7XG4gICAgICAgIGJldC5ydW5BY3Rpb24oYWN0aW9uQnkpO1xuICAgIH0sXG4gICAgcmFuZG9tUG9zaXRpb246IGZ1bmN0aW9uIHJhbmRvbVBvc2l0aW9uKCkge1xuICAgICAgICB2YXIgd2lkdGggPSB0aGlzLmJldF90YWJsZS53aWR0aDtcbiAgICAgICAgdmFyIGhlaWdodCA9IHRoaXMuYmV0X3RhYmxlLmhlaWdodDtcbiAgICAgICAgdmFyIHJhbmRvbVcgPSBNYXRoLnJhbmRvbSgpICogd2lkdGggLyAyO1xuICAgICAgICB2YXIgcmFuZG9tSCA9IE1hdGgucmFuZG9tKCkgKiBoZWlnaHQ7XG4gICAgICAgIHJldHVybiBjYy52MihyYW5kb21XICsgd2lkdGggLyA0LCByYW5kb21IKTtcbiAgICB9XG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4gICAgLy8gfSxcbn0pO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnNTQ5OWVoV1ZrQkorYVRua0hBYi90RE0nLCAnWWluZ3NhbnpoYW5nX1BsYXllcicpO1xuLy8gcmVzb3VyY2VzL0dhbWVzL1lpbmdzYW56aGFuZy9yZXMvcHJlZmFiL1BsYXllci9ZaW5nc2FuemhhbmdfUGxheWVyLmpzXG5cbnZhciBHbG9iYWxNYW5hZ2VyID0gcmVxdWlyZShcIkdsb2JhbE1hbmFnZXJcIik7XG52YXIgUHJvdG9jb2xNZXNzYWdlID0gcmVxdWlyZShcIlByb3RvY29sTWVzc2FnZVwiKTtcbnZhciBnYW1lQ29uc3REZWYgPSByZXF1aXJlKFwiWWluZ3NhbnpoYW5nQ29uc3REZWZcIik7XG5jYy5DbGFzcyh7XG4gICAgXCJleHRlbmRzXCI6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcblxuICAgICAgICBiYWNrR3JvdW5kOiB7XG4gICAgICAgICAgICBcImRlZmF1bHRcIjogbnVsbCxcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGVcbiAgICAgICAgfSxcbiAgICAgICAgY2FyZHNfbm9kZToge1xuICAgICAgICAgICAgXCJkZWZhdWx0XCI6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlXG4gICAgICAgIH0sXG4gICAgICAgIHByb2dyZXNzQmFyOiB7XG4gICAgICAgICAgICBcImRlZmF1bHRcIjogbnVsbCxcbiAgICAgICAgICAgIHR5cGU6IGNjLlByb2dyZXNzQmFyXG4gICAgICAgIH0sXG4gICAgICAgIGhlYWRJbWc6IHtcbiAgICAgICAgICAgIFwiZGVmYXVsdFwiOiBudWxsLFxuICAgICAgICAgICAgdHlwZTogY2MuU3ByaXRlXG4gICAgICAgIH0sXG4gICAgICAgIG5hbWVMYWJlbDoge1xuICAgICAgICAgICAgXCJkZWZhdWx0XCI6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBjYy5MYWJlbFxuICAgICAgICB9LFxuICAgICAgICBhbGxtb25leToge1xuICAgICAgICAgICAgXCJkZWZhdWx0XCI6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBjYy5MYWJlbFxuICAgICAgICB9LFxuICAgICAgICBtYWluTm9kZToge1xuICAgICAgICAgICAgXCJkZWZhdWx0XCI6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlXG4gICAgICAgIH0sXG4gICAgICAgIHNpZGVfbm9kZToge1xuICAgICAgICAgICAgXCJkZWZhdWx0XCI6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlXG4gICAgICAgIH0sXG4gICAgICAgIGxvb2tDYXJkX25vZGU6IHtcbiAgICAgICAgICAgIFwiZGVmYXVsdFwiOiBudWxsLFxuICAgICAgICAgICAgdHlwZTogY2MuU3ByaXRlXG4gICAgICAgIH0sXG4gICAgICAgIGNhcmRUeXBlX25vZGU6IHtcbiAgICAgICAgICAgIFwiZGVmYXVsdFwiOiBudWxsLFxuICAgICAgICAgICAgdHlwZTogY2MuU3ByaXRlXG4gICAgICAgIH0sXG4gICAgICAgIGJldDoge1xuICAgICAgICAgICAgXCJkZWZhdWx0XCI6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBjYy5MYWJlbFxuICAgICAgICB9LFxuICAgICAgICBwcmVmYWJfY2FyZDoge1xuICAgICAgICAgICAgXCJkZWZhdWx0XCI6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBjYy5QcmVmYWJcbiAgICAgICAgfSxcbiAgICAgICAgbGlld2VuOiB7XG4gICAgICAgICAgICBcImRlZmF1bHRcIjogbnVsbCxcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGVcbiAgICAgICAgfSxcbiAgICAgICAgY2FyZHNfYXJyYXk6IFtdLFxuICAgICAgICBpc0xvb2s6IGZhbHNlXG5cbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7fSxcblxuICAgIEluaXRJbmZvOiBmdW5jdGlvbiBJbml0SW5mbyhzaXRTZXEpIHtcbiAgICAgICAgdGhpcy5uU2VsZlBvcyA9IHNpdFNlcTtcbiAgICAgICAgdGhpcy5uU2VsZkluZGV4ID0gc2l0U2VxO1xuXG4gICAgICAgIHRoaXMubWFpbk5vZGUub3BhY2l0eSA9IDA7XG4gICAgICAgIHRoaXMuc2lkZV9ub2RlLm9wYWNpdHkgPSAwO1xuXG4gICAgICAgIHN3aXRjaCAoc2l0U2VxKSB7XG4gICAgICAgICAgICBjYXNlIDE6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLm5vZGUuc2V0UG9zaXRpb24oY2MudjIoODIwLCAtNzc1KSk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2lkZV9ub2RlLnNldFBvc2l0aW9uKGNjLnYyKDI1MCwgMCkpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgMjpcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMubm9kZS5zZXRQb3NpdGlvbihjYy52MigyMDAsIC03MDApKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zaWRlX25vZGUuc2V0UG9zaXRpb24oY2MudjIoMjUwLCAwKSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAzOlxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5ub2RlLnNldFBvc2l0aW9uKGNjLnYyKDIwMCwgLTMzMCkpO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnNpZGVfbm9kZS5zZXRQb3NpdGlvbihjYy52MigyNTAsIDApKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIDQ6XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLm5vZGUuc2V0UG9zaXRpb24oY2MudjIoMTcxMCwgLTMzMCkpO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnNpZGVfbm9kZS5zZXRQb3NpdGlvbihjYy52MigtMjUwLCAwKSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSA1OlxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5ub2RlLnNldFBvc2l0aW9uKGNjLnYyKDE3MTAsIC03MDApKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zaWRlX25vZGUuc2V0UG9zaXRpb24oY2MudjIoLTI1MCwgMCkpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICBVcERhdGVWaWV3OiBmdW5jdGlvbiBVcERhdGVWaWV3KG5DdXJJbmRleCkge1xuICAgICAgICAvLyB0aGlzLm5TZWxmSW5kZXggPSBuQ3VySW5kZXg7XG4gICAgICAgIHRoaXMuUmVmcmVzaFZpZXcobkN1ckluZGV4KTtcbiAgICB9LFxuICAgIFJlZnJlc2hTaWRlVmlldzogZnVuY3Rpb24gUmVmcmVzaFNpZGVWaWV3KG5DdXJJbmRleCkge1xuICAgICAgICB2YXIgZ2FtZURhdGEgPSBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLkdldEdhbWVEYXRhKEdsb2JhbE1hbmFnZXIuaW5zdGFuY2Uuc2VsZkRhdGEubkN1ckdhbWVJRCk7XG4gICAgICAgIHZhciBwbGF5ZXJJbmZvID0gZ2FtZURhdGEudmVjdFRlYW1MaXN0W25DdXJJbmRleF07XG4gICAgICAgIGlmIChwbGF5ZXJJbmZvLm5BY2NvdW50SUQgPT09IDApIHtcbiAgICAgICAgICAgIHRoaXMubm9kZS5vcGFjaXR5ID0gMDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMubm9kZS5vcGFjaXR5ID0gMjU1O1xuICAgICAgICAgICAgdGhpcy5zaWRlX25vZGUub3BhY2l0eSA9IDI1NTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgUmVmcmVzaFZpZXc6IGZ1bmN0aW9uIFJlZnJlc2hWaWV3KCkge1xuICAgICAgICB2YXIgZ2FtZURhdGEgPSBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLkdldEdhbWVEYXRhKEdsb2JhbE1hbmFnZXIuaW5zdGFuY2Uuc2VsZkRhdGEubkN1ckdhbWVJRCk7XG4gICAgICAgIHZhciBwbGF5ZXJJbmZvID0gZ2FtZURhdGEudmVjdFRlYW1MaXN0W3RoaXMublNlbGZJbmRleCAtIDFdO1xuXG4gICAgICAgIGlmIChwbGF5ZXJJbmZvLm5BY2NvdW50SUQgPT09IDApIHtcbiAgICAgICAgICAgIHRoaXMubm9kZS5vcGFjaXR5ID0gMDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMubm9kZS5vcGFjaXR5ID0gMjU1O1xuICAgICAgICAgICAgdGhpcy5tYWluTm9kZS5vcGFjaXR5ID0gMjU1O1xuXG4gICAgICAgICAgICBpZiAocGxheWVySW5mby5uaWNrICE9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5uYW1lTGFiZWwuc3RyaW5nID0gcGxheWVySW5mby5uaWNrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHBsYXllckluZm8ubkNvaW5MICE9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5hbGxtb25leS5zdHJpbmcgPSBwbGF5ZXJJbmZvLm5Db2luTDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIGNjLmxvYWRlci5sb2FkUmVzKFwiR2FtZXMvWWluZ3NhbnpoYW5nL3Jlcy9wcmVmYWIvUGxheWVyL2ltYWdlL2hlYWQvaGVhZF9cIitwbGF5ZXJJbmZvLm5GaGVhZCxjYy5TcHJpdGVGcmFtZSxmdW5jdGlvbihlcnJvcixzcHJpdGVGcmFtZSl7XG4gICAgICAgICAgICAvLyAgICAgaWYoIWVycm9yKVxuICAgICAgICAgICAgLy8gICAgIHtcbiAgICAgICAgICAgIC8vICAgICAgICAgdGhpcy5oZWFkSW1nLnNwcml0ZUZyYW1lID0gc3ByaXRlRnJhbWU7XG4gICAgICAgICAgICAvLyAgICAgfVxuICAgICAgICAgICAgLy8gfSk7XG4gICAgICAgIH1cbiAgICB9LFxuICAgIC8vICDmmL7npLrnu5PmnpwgIDEg5byD54mMIDIg55yL54mMIDMg6L6TXG4gICAgc2hvd0xvb2tOb2RlOiBmdW5jdGlvbiBzaG93TG9va05vZGUodHlwZSkge1xuICAgICAgICB0aGlzLmxvb2tDYXJkX25vZGUuc3ByaXRlRnJhbWUgPSBudWxsO1xuICAgICAgICB2YXIgYmFzZV91cmwgPSBcIkdhbWVzL1lpbmdzYW56aGFuZy9yZXMvcHJlZmFiL1BsYXllci9pbWFnZS9cIjtcbiAgICAgICAgdmFyIHR5cGVfdXJsO1xuICAgICAgICBzd2l0Y2ggKHR5cGUpIHtcbiAgICAgICAgICAgIGNhc2UgZ2FtZUNvbnN0RGVmLlBMQVlFUl9PUEVSQVRJT05fVFlQRS5PUEVSQVRJT05fRElTQ0FSRDpcbiAgICAgICAgICAgICAgICB0eXBlX3VybCA9IFwiZGlzY2FyZFwiO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBnYW1lQ29uc3REZWYuUExBWUVSX09QRVJBVElPTl9UWVBFLk9QRVJBVElPTl9MT09LQ0FSRDpcbiAgICAgICAgICAgICAgICB0eXBlX3VybCA9IFwibG9va1wiO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBnYW1lQ29uc3REZWYuUExBWUVSX09QRVJBVElPTl9UWVBFLk9QRVJBVElPTl9MT1NFOlxuICAgICAgICAgICAgICAgIHR5cGVfdXJsID0gXCJsb3NlXCI7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIHZhciBpbWdfdXJsID0gYmFzZV91cmwgKyB0eXBlX3VybDtcbiAgICAgICAgdmFyIGxvb2tOb2RlID0gdGhpcy5sb29rQ2FyZF9ub2RlO1xuICAgICAgICBjYy5sb2FkZXIubG9hZFJlcyhpbWdfdXJsLCBjYy5TcHJpdGVGcmFtZSwgZnVuY3Rpb24gKGVycm9yLCBzcHJpdGVGcmFtZSkge1xuICAgICAgICAgICAgaWYgKCFlcnJvcikge1xuICAgICAgICAgICAgICAgIGxvb2tOb2RlLnNwcml0ZUZyYW1lID0gc3ByaXRlRnJhbWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH0sXG4gICAgLy8g5pi+56S6IOeBsOS9jiDniYxcbiAgICBzaG93RGlzQ2FyZDogZnVuY3Rpb24gc2hvd0Rpc0NhcmQoKSB7XG4gICAgICAgIHRoaXMuc2hvd1Byb2dyZXNzQmFyKDEwKTtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB0aGlzLmNhcmRzX2FycmF5Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICB2YXIgbm9kZSA9IHRoaXMuY2FyZHNfYXJyYXlbaV07XG4gICAgICAgICAgICB2YXIgY29tcG9uZW50ID0gbm9kZS5nZXRDb21wb25lbnQoXCJZaW5nc2FuemhhbmdfQ2FyZFwiKTtcbiAgICAgICAgICAgIGNvbXBvbmVudC5TZXREaXNDYXJkKCk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5saWV3ZW4uYWN0aXZlID0gdHJ1ZTtcbiAgICB9LFxuICAgIC8v5pi+56S66L+b5bqm5p2hXG4gICAgc2hvd1Byb2dyZXNzQmFyOiBmdW5jdGlvbiBzaG93UHJvZ3Jlc3NCYXIodGltZSkge1xuICAgICAgICB0aGlzLnByb2dyZXNzQmFyLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIHRoaXMucHJvZ3Jlc3NCYXIucHJvZ3Jlc3MgPSAxO1xuICAgICAgICAvLyDku6Xnp5LkuLrljZXkvY3nmoTml7bpl7Tpl7TpmpRcbiAgICAgICAgdmFyIGludGVydmFsID0gMC4xO1xuICAgICAgICAvLyDph43lpI3mrKHmlbBcbiAgICAgICAgdmFyIHJlcGVhdCA9IHRpbWUgLyBpbnRlcnZhbDtcbiAgICAgICAgLy8gIOmAn+W6plxuICAgICAgICB2YXIgc3BlZWQgPSAxIC8gcmVwZWF0O1xuICAgICAgICAvLyDlvIDlp4vlu7bml7ZcbiAgICAgICAgdmFyIGRlbGF5ID0gMDtcbiAgICAgICAgdGhpcy5zY2hlZHVsZShmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB0aGlzLl91cGRhdGVQcm9ncmVzc0Jhcih0aGlzLnByb2dyZXNzQmFyLCBzcGVlZCk7XG4gICAgICAgIH0sIGludGVydmFsLCByZXBlYXQsIGRlbGF5KTtcbiAgICB9LFxuICAgIHRpbWVPdmVyOiBmdW5jdGlvbiB0aW1lT3ZlcigpIHtcbiAgICAgICAgdGhpcy5wcm9ncmVzc0Jhci5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5wcm9ncmVzc0Jhci5wcm9ncmVzcyA9IDA7XG4gICAgfSxcbiAgICBfdXBkYXRlUHJvZ3Jlc3NCYXI6IGZ1bmN0aW9uIF91cGRhdGVQcm9ncmVzc0Jhcihwcm9ncmVzc0Jhciwgc3BlZWQpIHtcblxuICAgICAgICB2YXIgcHJvZ3Jlc3MgPSBwcm9ncmVzc0Jhci5wcm9ncmVzcztcbiAgICAgICAgY2MubG9nKFwicHJvZ3Jlc3M6XCIsIHByb2dyZXNzKTtcbiAgICAgICAgaWYgKHByb2dyZXNzID4gMCkge1xuICAgICAgICAgICAgcHJvZ3Jlc3MgLT0gc3BlZWQ7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLnRpbWVPdmVyKCk7XG4gICAgICAgIH1cbiAgICAgICAgcHJvZ3Jlc3NCYXIucHJvZ3Jlc3MgPSBwcm9ncmVzcztcbiAgICB9LFxuICAgIHNlbmRDYXJkczogZnVuY3Rpb24gc2VuZENhcmRzKCkge1xuICAgICAgICB2YXIgZ2FtZURhdGEgPSBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLkdldEdhbWVEYXRhKEdsb2JhbE1hbmFnZXIuaW5zdGFuY2Uuc2VsZkRhdGEubkN1ckdhbWVJRCk7XG4gICAgICAgIHZhciBwbGF5ZXJJbmZvID0gZ2FtZURhdGEudmVjdFRlYW1MaXN0W3RoaXMublNlbGZJbmRleCAtIDFdO1xuXG4gICAgICAgIGlmIChwbGF5ZXJJbmZvLm5BY2NvdW50SUQgPT09IDApIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB2YXIgY2FyZHMgPSBbXTtcbiAgICAgICAgY2FyZHMucHVzaFtwbGF5ZXJJbmZvLnB1a2VbMF1dO1xuICAgICAgICBjYXJkcy5wdXNoW3BsYXllckluZm8ucHVrZVsxXV07XG4gICAgICAgIGNhcmRzLnB1c2hbcGxheWVySW5mby5wdWtlWzJdXTtcblxuICAgICAgICB0aGlzLmNhcmRzX25vZGUuYWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5jYXJkc19hcnJheSA9IFtdO1xuICAgICAgICB0aGlzLmNhcmRzX25vZGUucmVtb3ZlQWxsQ2hpbGRyZW4oKTtcbiAgICAgICAgLy8g5Lul56eS5Li65Y2V5L2N55qE5pe26Ze06Ze06ZqUXG4gICAgICAgIHZhciBpbnRlcnZhbCA9IDAuMztcbiAgICAgICAgLy8g6YeN5aSN5qyh5pWwXG4gICAgICAgIHZhciByZXBlYXQgPSAyO1xuICAgICAgICAvLyDlvIDlp4vlu7bml7ZcbiAgICAgICAgdmFyIGRlbGF5ID0gMDtcbiAgICAgICAgdmFyIGluZGV4ID0gMDtcbiAgICAgICAgdGhpcy5zY2hlZHVsZShmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB0aGlzLnNlbmRDYXJkKGNhcmRzW2luZGV4KytdKTtcbiAgICAgICAgICAgIGlmIChpbmRleCA+PSAzKSB0aGlzLnNob3dEaXNDYXJkKCk7XG4gICAgICAgIH0sIGludGVydmFsLCByZXBlYXQsIGRlbGF5KTtcbiAgICB9LFxuXG4gICAgc2VuZENhcmQ6IGZ1bmN0aW9uIHNlbmRDYXJkKHZhbHVlKSB7XG4gICAgICAgIGNjLmxvZyhcInZhbHVlOlwiLCB2YWx1ZSk7XG4gICAgICAgIHZhciBwcmVmYWJfY2FyZCA9IGNjLmluc3RhbnRpYXRlKHRoaXMucHJlZmFiX2NhcmQpO1xuICAgICAgICBwcmVmYWJfY2FyZC5zZXRQb3NpdGlvbihjYy52MigwLCAwKSk7XG4gICAgICAgIHByZWZhYl9jYXJkLnNjYWxlID0gMC42O1xuICAgICAgICB2YXIgY29tcG9uZW50ID0gcHJlZmFiX2NhcmQuZ2V0Q29tcG9uZW50KFwiWWluZ3NhbnpoYW5nX0NhcmRcIik7XG4gICAgICAgIGNvbXBvbmVudC5TZXRDYXJkSW5mbyh2YWx1ZSk7XG4gICAgICAgIHRoaXMuY2FyZHNfbm9kZS5hZGRDaGlsZChwcmVmYWJfY2FyZCk7XG4gICAgICAgIHRoaXMuY2FyZHNfYXJyYXkucHVzaChwcmVmYWJfY2FyZCk7XG4gICAgfVxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcblxuICAgIC8vIH0sXG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJ2NkZDU2aHRjZFpLdW84eWI2VWxUbzRGJywgJ1lpbmdzYW56aGFuZ19XYXJVSScpO1xuLy8gcmVzb3VyY2VzL0dhbWVzL1lpbmdzYW56aGFuZy9zY2VuZS9zY2VuZVdhci9ZaW5nc2FuemhhbmdfV2FyVUkuanNcblxudmFyIEdsb2JhbE1hbmFnZXIgPSByZXF1aXJlKFwiR2xvYmFsTWFuYWdlclwiKTtcbnZhciBIaW50TWFuYWdlciA9IHJlcXVpcmUoXCJIaW50TWFuYWdlclwiKTtcbnZhciBQcm90b2NvbE1lc3NhZ2UgPSByZXF1aXJlKFwiUHJvdG9jb2xNZXNzYWdlXCIpO1xudmFyIGNvbnN0RGVmID0gcmVxdWlyZShcIkNvbnN0RGVmXCIpO1xudmFyIFV0aWxzID0gcmVxdWlyZShcIlV0aWxzXCIpO1xudmFyIGdhbWVDb25zdERlZiA9IHJlcXVpcmUoXCJZaW5nc2FuemhhbmdDb25zdERlZlwiKTtcblxuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG5cbiAgICAgICAgTm9kZVBsYXllcnNVSTogY2MuTm9kZSxcbiAgICAgICAgTm9kZU15Q29udHJvbGxlclVJOiBjYy5Ob2RlXG4gICAgfSxcblxuICAgIC8vIGZvbzoge1xuICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxuICAgIC8vICAgIHVybDogY2MuVGV4dHVyZTJELCAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcbiAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAvLyAgICBkaXNwbGF5TmFtZTogJ0ZvbycsIC8vIG9wdGlvbmFsXG4gICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgIC8vIH0sXG4gICAgLy8gLi4uXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7XG5cbiAgICAgICAgLy8gbGV0IG1zZyA9IG5ldyBQcm90b2NvbE1lc3NhZ2UoY29uc3REZWYuTUVTU0FHRS5DTURfTUFJTl9HQU1FLGNvbnN0RGVmLk1FU1NBR0UuRklHSFRfUkVBRFlfUkVRLGZhbHNlKTtcbiAgICAgICAgLy8gUHJvdG9jb2xNZXNzYWdlLkFkZFZlY3RJdGVtQnl0ZShtc2cuX2JvZHlfbXNnLCAxKTtcbiAgICAgICAgLy8gR2xvYmFsTWFuYWdlci5pbnN0YW5jZS5Tb2NrZXRNYW5hZ2VyLlNlbmRNZXNzYWdlKGNvbnN0RGVmLlNFUlZFUl9VUkwuZ2FtZSwgbXNnKTtcblxuICAgIH0sXG4gICAgUmVmcmVzaFVJOiBmdW5jdGlvbiBSZWZyZXNoVUkoKSB7XG4gICAgICAgIGNjLmxvZyhcIlJlZnJlc2hVSVwiKTtcbiAgICAgICAgdGhpcy5Ob2RlUGxheWVyc1VJLmdldENvbXBvbmVudChcIllpbmdzYW56aGFuZ19QbGF5ZXJzVUlcIikuaW5pdFBsYXllcnMoKTtcblxuICAgICAgICB2YXIgZ2FtZURhdGEgPSBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLkdldEdhbWVEYXRhKEdsb2JhbE1hbmFnZXIuaW5zdGFuY2Uuc2VsZkRhdGEubkN1ckdhbWVJRCk7XG5cbiAgICAgICAgaWYgKGdhbWVEYXRhLm5CYXR0bGVTdGF0dXMgPT0gZ2FtZUNvbnN0RGVmLkZJR0hUX1NUQVRVUy5CRUdJTikge1xuICAgICAgICAgICAgaWYgKGdhbWVEYXRhLm5DbGllbnRTdGF0dXMgPT0gZ2FtZUNvbnN0RGVmLkZJR0hUX1NUQVRVUy5DX0JFR0lOKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5Ob2RlTXlDb250cm9sbGVyVUkuZ2V0Q29tcG9uZW50KFwiWWluZ3NhbnpoYW5nX1BsYXllcnNVSVwiKS5zZW5kQ2FyZCgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSxcblxuICAgIFJlZnJlc2hQbGF5ZXJEYXRhOiBmdW5jdGlvbiBSZWZyZXNoUGxheWVyRGF0YSgpIHtcbiAgICAgICAgdGhpcy5Ob2RlUGxheWVyc1VJLmdldENvbXBvbmVudChcIllpbmdzYW56aGFuZ19QbGF5ZXJzVUlcIikuaW5pdFBsYXllcnMoKTtcbiAgICAgICAgY2MubG9nKFwiV2FyX1JlZnJlc2hQbGF5ZXJEYXRhXCIpO1xuICAgIH0sXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbiAgICB1cGRhdGU6IGZ1bmN0aW9uIHVwZGF0ZShkdCkge31cbn0pO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnMjBmODBZZG5KcEszTHdFZC9TWEJxOVQnLCAnWWluZ3NhbnpoYW5nX2NsYXNzaWNzSXRlbScpO1xuLy8gcmVzb3VyY2VzL0dhbWVzL1lpbmdzYW56aGFuZy9yZXMvcHJlZmFiL2NsYXNzaWNzSXRlbS9ZaW5nc2FuemhhbmdfY2xhc3NpY3NJdGVtLmpzXG5cbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICAvLyBmb286IHtcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXG4gICAgICAgIC8vIH0sXG4gICAgICAgIC8vIC4uLlxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHt9XG5cbn0pO1xuLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbi8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XG5cbi8vIH0sXG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICdmNjBiZXEyeTlWTXk0TThtbHA5YWQxSycsICdZaW5nc2FuemhhbmdfZ2FtZVdhaXQnKTtcbi8vIHJlc291cmNlcy9HYW1lcy9ZaW5nc2Fuemhhbmcvc2NlbmUvc2NlbmVXYWl0TWF0Y2gvWWluZ3NhbnpoYW5nX2dhbWVXYWl0LmpzXG5cbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICAvLyBmb286IHtcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXG4gICAgICAgIC8vIH0sXG4gICAgICAgIC8vIC4uLlxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHt9XG5cbn0pO1xuLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbi8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XG5cbi8vIH0sXG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICdlMTU5YkdIQUQ5RHA2dmtZd3IxNVFCNycsICdiYWNrR29vZHMnKTtcbi8vIHJlc291cmNlcy9jb21tb24vcHJlZmFiL2JhY2tHb29kcy9iYWNrR29vZHMuanNcblxuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIExhYmVsTmFtZTogY2MuTGFiZWxcbiAgICB9LFxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge30sXG4gICAgaW5pdEluZm86IGZ1bmN0aW9uIGluaXRJbmZvKGRhdGEpIHtcbiAgICAgICAgdGhpcy5MYWJlbE5hbWUuc3RyaW5nID0gZGF0YS5uYW1lO1xuICAgIH1cbn0pO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnYmM5ZTh6OUhPdEdHb3pvdFRuRS8zelYnLCAnY2NTaGFkZXJfQXZnX0JsYWNrX1doaXRlX0ZyYWcnKTtcbi8vIEdsb2JhbC9xaXN1TGliL1Nob3cvU2hhZGVycy9jY1NoYWRlcl9BdmdfQmxhY2tfV2hpdGVfRnJhZy5qc1xuXG4vKiDlubPlnYflgLzpu5Hnmb0gKi9cblxubW9kdWxlLmV4cG9ydHMgPSBcInByZWNpc2lvbiBtZWRpdW1wIGZsb2F0O1xcblwiICsgXCJ2YXJ5aW5nIHZlYzIgdl90ZXhDb29yZDtcXG5cIiArIFwidm9pZCBtYWluKClcXG5cIiArIFwie1xcblwiICsgXCIgICAgdmVjMyB2ID0gdGV4dHVyZTJEKENDX1RleHR1cmUwLCB2X3RleENvb3JkKS5yZ2I7XFxuXCIgKyBcIiAgICBmbG9hdCBmID0gKHYuciArIHYuZyArIHYuYikgLyAzLjA7XFxuXCIgKyBcIiAgICBnbF9GcmFnQ29sb3IgPSB2ZWM0KGYsIGYsIGYsIDEuMCk7XFxuXCIgKyBcIn1cXG5cIjtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJ2M3M2RlQzc2ZkZEaXFIdFJyNE9qZHowJywgJ2NjU2hhZGVyX0RlZmF1bHRfVmVydF9ub01WUCcpO1xuLy8gR2xvYmFsL3Fpc3VMaWIvU2hvdy9TaGFkZXJzL2NjU2hhZGVyX0RlZmF1bHRfVmVydF9ub01WUC5qc1xuXG5tb2R1bGUuZXhwb3J0cyA9IFwiXFxuYXR0cmlidXRlIHZlYzQgYV9wb3NpdGlvbjtcXG4gYXR0cmlidXRlIHZlYzIgYV90ZXhDb29yZDtcXG4gYXR0cmlidXRlIHZlYzQgYV9jb2xvcjtcXG4gdmFyeWluZyB2ZWMyIHZfdGV4Q29vcmQ7XFxuIHZhcnlpbmcgdmVjNCB2X2ZyYWdtZW50Q29sb3I7XFxuIHZvaWQgbWFpbigpXFxuIHtcXG4gICAgIGdsX1Bvc2l0aW9uID0gQ0NfUE1hdHJpeCAgKiBhX3Bvc2l0aW9uO1xcbiAgICAgdl9mcmFnbWVudENvbG9yID0gYV9jb2xvcjtcXG4gICAgIHZfdGV4Q29vcmQgPSBhX3RleENvb3JkO1xcbiB9XFxuXCI7XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICc2ZGE2MmRLamIxSnRZM0swVTNZYU5DNicsICdjY1NoYWRlcl9EZWZhdWx0X1ZlcnQnKTtcbi8vIEdsb2JhbC9xaXN1TGliL1Nob3cvU2hhZGVycy9jY1NoYWRlcl9EZWZhdWx0X1ZlcnQuanNcblxubW9kdWxlLmV4cG9ydHMgPSBcImF0dHJpYnV0ZSB2ZWM0IGFfcG9zaXRpb247XFxuXCIgKyBcIiBhdHRyaWJ1dGUgdmVjMiBhX3RleENvb3JkO1xcblwiICsgXCIgYXR0cmlidXRlIHZlYzQgYV9jb2xvcjtcXG5cIiArIFwiIHZhcnlpbmcgdmVjMiB2X3RleENvb3JkO1xcblwiICsgXCIgdmFyeWluZyB2ZWM0IHZfZnJhZ21lbnRDb2xvcjtcXG5cIiArIFwiIHZvaWQgbWFpbigpXFxuXCIgKyBcIiB7XFxuXCIgKyBcIiAgICAgZ2xfUG9zaXRpb24gPSAoIENDX1BNYXRyaXggKiBDQ19NVk1hdHJpeCApICogYV9wb3NpdGlvbjtcXG5cIiArIFwiICAgICB2X2ZyYWdtZW50Q29sb3IgPSBhX2NvbG9yO1xcblwiICsgXCIgICAgIHZfdGV4Q29vcmQgPSBhX3RleENvb3JkO1xcblwiICsgXCIgfSBcXG5cIjtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzQ3ZTYyMkJQMlpDUkxsV0wyOTZER3UwJywgJ2NoYXQnKTtcbi8vIHJlc291cmNlcy9jb21tb24vcHJlZmFiL2NoYXRJdGVtL2NoYXQuanNcblxudmFyIEdsb2JhbE1hbmFnZXIgPSByZXF1aXJlKFwiR2xvYmFsTWFuYWdlclwiKTtcblxuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIE5vZGVIZWFkUGljOiBjYy5Ob2RlLFxuICAgICAgICBOb2RlTGVmdDogY2MuTm9kZSxcbiAgICAgICAgTm9kZVJpZ2h0OiBjYy5Ob2RlLFxuICAgICAgICBjb250ZW50TWF4V2lkdGg6IDBcbiAgICB9LFxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge30sXG4gICAgaW5pdEluZm86IGZ1bmN0aW9uIGluaXRJbmZvKGFjY291bnRJZCwgY29udGVudCkge1xuICAgICAgICB2YXIgY3VyQ29udGVudExhYmVsID0gbnVsbDtcbiAgICAgICAgaWYgKGFjY291bnRJZCA9PSBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLnNlbGZEYXRhLm5BY2NvdW50SUQpIHtcbiAgICAgICAgICAgIHRoaXMubm9kZS54ID0gOTAwO1xuICAgICAgICAgICAgY3VyQ29udGVudExhYmVsID0gdGhpcy5Ob2RlTGVmdC5nZXRDaGlsZEJ5TmFtZShcImxhYmVsXCIpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5ub2RlLnggPSAwO1xuICAgICAgICAgICAgY3VyQ29udGVudExhYmVsID0gdGhpcy5Ob2RlUmlnaHQuZ2V0Q2hpbGRCeU5hbWUoXCJsYWJlbFwiKTtcbiAgICAgICAgfVxuICAgICAgICBjdXJDb250ZW50TGFiZWwuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5vdmVyZmxvdyA9IGNjLkxhYmVsLk92ZXJmbG93Lk5PTkU7XG4gICAgICAgIGN1ckNvbnRlbnRMYWJlbC5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZyA9IGNvbnRlbnQ7XG4gICAgICAgIGlmIChjdXJDb250ZW50TGFiZWwud2lkdGggPj0gdGhpcy5jb250ZW50TWF4V2lkdGgpIHtcbiAgICAgICAgICAgIGN1ckNvbnRlbnRMYWJlbC5nZXRDb21wb25lbnQoY2MuTGFiZWwpLm92ZXJmbG93ID0gY2MuTGFiZWwuT3ZlcmZsb3cuUkVTSVpFX0hFSUdIVDtcbiAgICAgICAgICAgIGN1ckNvbnRlbnRMYWJlbC53aWR0aCA9IHRoaXMuY29udGVudE1heFdpZHRoO1xuICAgICAgICB9XG4gICAgICAgIGN1ckNvbnRlbnRMYWJlbC5wYXJlbnQud2lkdGggPSBjdXJDb250ZW50TGFiZWwud2lkdGggKyA2MDtcbiAgICB9XG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzkxZWZhYjRmYkZLN0pZcmJ6YmpPRDc1JywgJ2dhbWVIb3RVcGRhdGUnKTtcbi8vIEdsb2JhbC9xaXN1TGliL3Fpc3VGcmFtZS9Ib3RVcGRhdGUvZ2FtZUhvdFVwZGF0ZS5qc1xuXG5jYy5DbGFzcyh7XG4gICAgXCJleHRlbmRzXCI6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgdXBkYXRlUGFuZWw6IHtcbiAgICAgICAgICAgIFwiZGVmYXVsdFwiOiBudWxsLFxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZVxuICAgICAgICB9LFxuICAgICAgICBtYW5pZmVzdFVybDoge1xuICAgICAgICAgICAgXCJkZWZhdWx0XCI6IG51bGwsXG4gICAgICAgICAgICB1cmw6IGNjLlJhd0Fzc2V0XG4gICAgICAgIH0sXG4gICAgICAgIHBlcmNlbnQ6IHtcbiAgICAgICAgICAgIFwiZGVmYXVsdFwiOiBudWxsLFxuICAgICAgICAgICAgdHlwZTogY2MuTGFiZWxcbiAgICAgICAgfSxcbiAgICAgICAgc3RvcmFnZURpcjogXCJibGFja2phY2stcmVtb3RlLWFzc2V0XCJcbiAgICB9LFxuXG4gICAgY2hlY2tDYjogZnVuY3Rpb24gY2hlY2tDYihldmVudCkge1xuICAgICAgICBjYy5sb2coJ0NvZGU6ICcgKyBldmVudC5nZXRFdmVudENvZGUoKSk7XG4gICAgICAgIHN3aXRjaCAoZXZlbnQuZ2V0RXZlbnRDb2RlKCkpIHtcbiAgICAgICAgICAgIGNhc2UganNiLkV2ZW50QXNzZXRzTWFuYWdlci5FUlJPUl9OT19MT0NBTF9NQU5JRkVTVDpcbiAgICAgICAgICAgICAgICBjYy5sb2coXCJObyBsb2NhbCBtYW5pZmVzdCBmaWxlIGZvdW5kLCBob3QgdXBkYXRlIHNraXBwZWQuXCIpO1xuICAgICAgICAgICAgICAgIGNjLmV2ZW50TWFuYWdlci5yZW1vdmVMaXN0ZW5lcih0aGlzLl9jaGVja0xpc3RlbmVyKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UganNiLkV2ZW50QXNzZXRzTWFuYWdlci5FUlJPUl9ET1dOTE9BRF9NQU5JRkVTVDpcbiAgICAgICAgICAgIGNhc2UganNiLkV2ZW50QXNzZXRzTWFuYWdlci5FUlJPUl9QQVJTRV9NQU5JRkVTVDpcbiAgICAgICAgICAgICAgICBjYy5sb2coXCJGYWlsIHRvIGRvd25sb2FkIG1hbmlmZXN0IGZpbGUsIGhvdCB1cGRhdGUgc2tpcHBlZC5cIik7XG4gICAgICAgICAgICAgICAgY2MuZXZlbnRNYW5hZ2VyLnJlbW92ZUxpc3RlbmVyKHRoaXMuX2NoZWNrTGlzdGVuZXIpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBqc2IuRXZlbnRBc3NldHNNYW5hZ2VyLkFMUkVBRFlfVVBfVE9fREFURTpcbiAgICAgICAgICAgICAgICBjYy5sb2coXCJBbHJlYWR5IHVwIHRvIGRhdGUgd2l0aCB0aGUgbGF0ZXN0IHJlbW90ZSB2ZXJzaW9uLlwiKTtcbiAgICAgICAgICAgICAgICBjYy5ldmVudE1hbmFnZXIucmVtb3ZlTGlzdGVuZXIodGhpcy5fY2hlY2tMaXN0ZW5lcik7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIGpzYi5FdmVudEFzc2V0c01hbmFnZXIuTkVXX1ZFUlNJT05fRk9VTkQ6XG4gICAgICAgICAgICAgICAgdGhpcy5fbmVlZFVwZGF0ZSA9IHRydWU7XG5cbiAgICAgICAgICAgICAgICB0aGlzLnVwZGF0ZVBhbmVsLmFjdGl2ZSA9IHRydWU7XG5cbiAgICAgICAgICAgICAgICB2YXIgY3VyU2NlbmUgPSBjYy5kaXJlY3Rvci5nZXRTY2VuZSgpO1xuICAgICAgICAgICAgICAgIHZhciBjdXJOb2RlID0gY2MuZmluZChcIkNhbnZhc1wiLCBjdXJTY2VuZSk7XG4gICAgICAgICAgICAgICAgdGhpcy51cGRhdGVQYW5lbC5wYXJlbnQgPSBjdXJOb2RlO1xuICAgICAgICAgICAgICAgIHRoaXMudXBkYXRlUGFuZWwueCA9IDA7XG4gICAgICAgICAgICAgICAgdGhpcy51cGRhdGVQYW5lbC55ID0gMDtcblxuICAgICAgICAgICAgICAgIHRoaXMucGVyY2VudC5zdHJpbmcgPSAnMDAuMDAlJztcbiAgICAgICAgICAgICAgICBjYy5ldmVudE1hbmFnZXIucmVtb3ZlTGlzdGVuZXIodGhpcy5fY2hlY2tMaXN0ZW5lcik7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgfSxcblxuICAgIHVwZGF0ZUNiOiBmdW5jdGlvbiB1cGRhdGVDYihldmVudCkge1xuICAgICAgICB2YXIgbmVlZFJlc3RhcnQgPSBmYWxzZTtcbiAgICAgICAgdmFyIGZhaWxlZCA9IGZhbHNlO1xuICAgICAgICBzd2l0Y2ggKGV2ZW50LmdldEV2ZW50Q29kZSgpKSB7XG4gICAgICAgICAgICBjYXNlIGpzYi5FdmVudEFzc2V0c01hbmFnZXIuRVJST1JfTk9fTE9DQUxfTUFOSUZFU1Q6XG4gICAgICAgICAgICAgICAgY2MubG9nKCdObyBsb2NhbCBtYW5pZmVzdCBmaWxlIGZvdW5kLCBob3QgdXBkYXRlIHNraXBwZWQuJyk7XG4gICAgICAgICAgICAgICAgZmFpbGVkID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UganNiLkV2ZW50QXNzZXRzTWFuYWdlci5VUERBVEVfUFJPR1JFU1NJT046XG4gICAgICAgICAgICAgICAgdmFyIHBlcmNlbnQgPSBldmVudC5nZXRQZXJjZW50KCk7XG4gICAgICAgICAgICAgICAgdmFyIHBlcmNlbnRCeUZpbGUgPSBldmVudC5nZXRQZXJjZW50QnlGaWxlKCk7XG5cbiAgICAgICAgICAgICAgICB2YXIgbXNnID0gZXZlbnQuZ2V0TWVzc2FnZSgpO1xuICAgICAgICAgICAgICAgIGlmIChtc2cpIHtcbiAgICAgICAgICAgICAgICAgICAgY2MubG9nKG1zZyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNjLmxvZyhwZXJjZW50LnRvRml4ZWQoMikgKyAnJScpO1xuICAgICAgICAgICAgICAgIHRoaXMucGVyY2VudC5zdHJpbmcgPSBwZXJjZW50ICsgJyUnO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBqc2IuRXZlbnRBc3NldHNNYW5hZ2VyLkVSUk9SX0RPV05MT0FEX01BTklGRVNUOlxuICAgICAgICAgICAgY2FzZSBqc2IuRXZlbnRBc3NldHNNYW5hZ2VyLkVSUk9SX1BBUlNFX01BTklGRVNUOlxuICAgICAgICAgICAgICAgIGNjLmxvZygnRmFpbCB0byBkb3dubG9hZCBtYW5pZmVzdCBmaWxlLCBob3QgdXBkYXRlIHNraXBwZWQuJyk7XG4gICAgICAgICAgICAgICAgZmFpbGVkID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UganNiLkV2ZW50QXNzZXRzTWFuYWdlci5BTFJFQURZX1VQX1RPX0RBVEU6XG4gICAgICAgICAgICAgICAgY2MubG9nKCdBbHJlYWR5IHVwIHRvIGRhdGUgd2l0aCB0aGUgbGF0ZXN0IHJlbW90ZSB2ZXJzaW9uLicpO1xuICAgICAgICAgICAgICAgIGZhaWxlZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIGpzYi5FdmVudEFzc2V0c01hbmFnZXIuVVBEQVRFX0ZJTklTSEVEOlxuICAgICAgICAgICAgICAgIGNjLmxvZygnVXBkYXRlIGZpbmlzaGVkLiAnICsgZXZlbnQuZ2V0TWVzc2FnZSgpKTtcblxuICAgICAgICAgICAgICAgIG5lZWRSZXN0YXJ0ID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UganNiLkV2ZW50QXNzZXRzTWFuYWdlci5VUERBVEVfRkFJTEVEOlxuICAgICAgICAgICAgICAgIGNjLmxvZygnVXBkYXRlIGZhaWxlZC4gJyArIGV2ZW50LmdldE1lc3NhZ2UoKSk7XG5cbiAgICAgICAgICAgICAgICB0aGlzLl9mYWlsQ291bnQrKztcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fZmFpbENvdW50IDwgNSkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLl9hbS5kb3dubG9hZEZhaWxlZEFzc2V0cygpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGNjLmxvZygnUmVhY2ggbWF4aW11bSBmYWlsIGNvdW50LCBleGl0IHVwZGF0ZSBwcm9jZXNzJyk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2ZhaWxDb3VudCA9IDA7XG4gICAgICAgICAgICAgICAgICAgIGZhaWxlZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBqc2IuRXZlbnRBc3NldHNNYW5hZ2VyLkVSUk9SX1VQREFUSU5HOlxuICAgICAgICAgICAgICAgIGNjLmxvZygnQXNzZXQgdXBkYXRlIGVycm9yOiAnICsgZXZlbnQuZ2V0QXNzZXRJZCgpICsgJywgJyArIGV2ZW50LmdldE1lc3NhZ2UoKSk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIGpzYi5FdmVudEFzc2V0c01hbmFnZXIuRVJST1JfREVDT01QUkVTUzpcbiAgICAgICAgICAgICAgICBjYy5sb2coZXZlbnQuZ2V0TWVzc2FnZSgpKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoZmFpbGVkKSB7XG4gICAgICAgICAgICBjYy5ldmVudE1hbmFnZXIucmVtb3ZlTGlzdGVuZXIodGhpcy5fdXBkYXRlTGlzdGVuZXIpO1xuICAgICAgICAgICAgdGhpcy51cGRhdGVQYW5lbC5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChuZWVkUmVzdGFydCkge1xuICAgICAgICAgICAgY2MuZXZlbnRNYW5hZ2VyLnJlbW92ZUxpc3RlbmVyKHRoaXMuX3VwZGF0ZUxpc3RlbmVyKTtcbiAgICAgICAgICAgIC8vIFByZXBlbmQgdGhlIG1hbmlmZXN0J3Mgc2VhcmNoIHBhdGhcbiAgICAgICAgICAgIHZhciBzZWFyY2hQYXRocyA9IGpzYi5maWxlVXRpbHMuZ2V0U2VhcmNoUGF0aHMoKTtcbiAgICAgICAgICAgIHZhciBuZXdQYXRocyA9IHRoaXMuX2FtLmdldExvY2FsTWFuaWZlc3QoKS5nZXRTZWFyY2hQYXRocygpO1xuICAgICAgICAgICAgQXJyYXkucHJvdG90eXBlLnVuc2hpZnQoc2VhcmNoUGF0aHMsIG5ld1BhdGhzKTtcbiAgICAgICAgICAgIC8vIFRoaXMgdmFsdWUgd2lsbCBiZSByZXRyaWV2ZWQgYW5kIGFwcGVuZGVkIHRvIHRoZSBkZWZhdWx0IHNlYXJjaCBwYXRoIGR1cmluZyBnYW1lIHN0YXJ0dXAsXG4gICAgICAgICAgICAvLyBwbGVhc2UgcmVmZXIgdG8gc2FtcGxlcy9qcy10ZXN0cy9tYWluLmpzIGZvciBkZXRhaWxlZCB1c2FnZS5cbiAgICAgICAgICAgIC8vICEhISBSZS1hZGQgdGhlIHNlYXJjaCBwYXRocyBpbiBtYWluLmpzIGlzIHZlcnkgaW1wb3J0YW50LCBvdGhlcndpc2UsIG5ldyBzY3JpcHRzIHdvbid0IHRha2UgZWZmZWN0LlxuICAgICAgICAgICAgY2Muc3lzLmxvY2FsU3RvcmFnZS5zZXRJdGVtKCdIb3RVcGRhdGVTZWFyY2hQYXRocycsIEpTT04uc3RyaW5naWZ5KHNlYXJjaFBhdGhzKSk7XG5cbiAgICAgICAgICAgIGpzYi5maWxlVXRpbHMuc2V0U2VhcmNoUGF0aHMoc2VhcmNoUGF0aHMpO1xuICAgICAgICAgICAgY2MuZ2FtZS5yZXN0YXJ0KCk7XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgaG90VXBkYXRlOiBmdW5jdGlvbiBob3RVcGRhdGUoKSB7XG4gICAgICAgIGlmICh0aGlzLl9hbSAmJiB0aGlzLl9uZWVkVXBkYXRlKSB7XG4gICAgICAgICAgICB0aGlzLl91cGRhdGVMaXN0ZW5lciA9IG5ldyBqc2IuRXZlbnRMaXN0ZW5lckFzc2V0c01hbmFnZXIodGhpcy5fYW0sIHRoaXMudXBkYXRlQ2IuYmluZCh0aGlzKSk7XG4gICAgICAgICAgICBjYy5ldmVudE1hbmFnZXIuYWRkTGlzdGVuZXIodGhpcy5fdXBkYXRlTGlzdGVuZXIsIDEpO1xuXG4gICAgICAgICAgICB0aGlzLl9mYWlsQ291bnQgPSAwO1xuICAgICAgICAgICAgdGhpcy5fYW0udXBkYXRlKCk7XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgY2hlY2tVcGRhdGU6IGZ1bmN0aW9uIGNoZWNrVXBkYXRlKCkge1xuICAgICAgICBpZiAoIWNjLnN5cy5pc05hdGl2ZSkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHZhciBzdG9yYWdlUGF0aCA9IChqc2IuZmlsZVV0aWxzID8ganNiLmZpbGVVdGlscy5nZXRXcml0YWJsZVBhdGgoKSA6ICcvJykgKyB0aGlzLnN0b3JhZ2VEaXI7XG5cbiAgICAgICAgdGhpcy5fYW0gPSBuZXcganNiLkFzc2V0c01hbmFnZXIodGhpcy5tYW5pZmVzdFVybCwgc3RvcmFnZVBhdGgpO1xuICAgICAgICB0aGlzLl9hbS5yZXRhaW4oKTtcblxuICAgICAgICB0aGlzLl9uZWVkVXBkYXRlID0gZmFsc2U7XG4gICAgICAgIGlmICh0aGlzLl9hbS5nZXRMb2NhbE1hbmlmZXN0KCkuaXNMb2FkZWQoKSkge1xuICAgICAgICAgICAgdGhpcy5fY2hlY2tMaXN0ZW5lciA9IG5ldyBqc2IuRXZlbnRMaXN0ZW5lckFzc2V0c01hbmFnZXIodGhpcy5fYW0sIHRoaXMuY2hlY2tDYi5iaW5kKHRoaXMpKTtcbiAgICAgICAgICAgIGNjLmV2ZW50TWFuYWdlci5hZGRMaXN0ZW5lcih0aGlzLl9jaGVja0xpc3RlbmVyLCAxKTtcblxuICAgICAgICAgICAgdGhpcy5fYW0uY2hlY2tVcGRhdGUoKTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgLy8gb25Mb2FkOiBmdW5jdGlvbiAoKSB7XG4gICAgLy8gICAgIC8vIEhvdCB1cGRhdGUgaXMgb25seSBhdmFpbGFibGUgaW4gTmF0aXZlIGJ1aWxkXG4gICAgLy8gICAgIGlmICghY2Muc3lzLmlzTmF0aXZlKSB7XG4gICAgLy8gICAgICAgICByZXR1cm47XG4gICAgLy8gICAgIH1cbiAgICAvLyAgICAgdmFyIHN0b3JhZ2VQYXRoID0gKChqc2IuZmlsZVV0aWxzID8ganNiLmZpbGVVdGlscy5nZXRXcml0YWJsZVBhdGgoKSA6ICcvJykgKyB0aGlzLnN0b3JhZ2VEaXIpO1xuICAgIC8vICAgICBjYy5sb2coJ1N0b3JhZ2UgcGF0aCBmb3IgcmVtb3RlIGFzc2V0IDogJyArIHN0b3JhZ2VQYXRoKTtcblxuICAgIC8vICAgICAvLyBjYy5sb2coJ0xvY2FsIG1hbmlmZXN0IFVSTCA6ICcgKyB0aGlzLm1hbmlmZXN0VXJsKTtcbiAgICAvLyAgICAgdGhpcy5fYW0gPSBuZXcganNiLkFzc2V0c01hbmFnZXIodGhpcy5tYW5pZmVzdFVybCwgc3RvcmFnZVBhdGgpO1xuICAgIC8vICAgICB0aGlzLl9hbS5yZXRhaW4oKTtcblxuICAgIC8vICAgICB0aGlzLl9uZWVkVXBkYXRlID0gZmFsc2U7XG4gICAgLy8gICAgIGlmICh0aGlzLl9hbS5nZXRMb2NhbE1hbmlmZXN0KCkuaXNMb2FkZWQoKSlcbiAgICAvLyAgICAge1xuICAgIC8vICAgICAgICAgdGhpcy5fY2hlY2tMaXN0ZW5lciA9IG5ldyBqc2IuRXZlbnRMaXN0ZW5lckFzc2V0c01hbmFnZXIodGhpcy5fYW0sIHRoaXMuY2hlY2tDYi5iaW5kKHRoaXMpKTtcbiAgICAvLyAgICAgICAgIGNjLmV2ZW50TWFuYWdlci5hZGRMaXN0ZW5lcih0aGlzLl9jaGVja0xpc3RlbmVyLCAxKTtcblxuICAgIC8vICAgICAgICAgdGhpcy5fYW0uY2hlY2tVcGRhdGUoKTtcbiAgICAvLyAgICAgfVxuICAgIC8vIH0sXG5cbiAgICBvbkRlc3Ryb3k6IGZ1bmN0aW9uIG9uRGVzdHJveSgpIHtcbiAgICAgICAgdGhpcy5fYW0gJiYgdGhpcy5fYW0ucmVsZWFzZSgpO1xuICAgIH1cbn0pO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnNjVkZjNnTFBwMUZjNmlrZm1CZ0xsYlUnLCAnZ2FtZScpO1xuLy8gcmVzb3VyY2VzL2NvbW1vbi9wcmVmYWIvZ2FtZS9nYW1lLmpzXG5cbnZhciBjb25zdERlZiA9IHJlcXVpcmUoXCJDb25zdERlZlwiKTtcbnZhciBHbG9iYWxNYW5hZ2VyID0gcmVxdWlyZShcIkdsb2JhbE1hbmFnZXJcIik7XG5cbmNjLkNsYXNzKHtcbiAgICBcImV4dGVuZHNcIjogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICBOb2RlQnV0dG9uOiBjYy5Ob2RlLFxuICAgICAgICBOb2RlR3JpZDogY2MuTm9kZSxcbiAgICAgICAgTm9kZUJ1dHRvbkJveDogY2MuTm9kZSxcbiAgICAgICAgU3ByaXRlSWNvbjogY2MuU3ByaXRlLFxuICAgICAgICBMYWJlbE51bWJlcjogY2MuTGFiZWwsXG4gICAgICAgIExhYmVsUGxheWVyTnVtOiBjYy5MYWJlbCxcbiAgICAgICAgTGFiZWxHYW1lTmFtZTogY2MuTGFiZWwsXG4gICAgICAgIExhYmVsRGVzYzogY2MuTGFiZWwsXG4gICAgICAgIHNlbGZJbmRleDogMCxcbiAgICAgICAgZ2FtZUlkOiAwXG4gICAgfSxcblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge1xuICAgICAgICB2YXIgY3R4ID0gdGhpcy5Ob2RlR3JpZC5nZXRDb21wb25lbnQoY2MuR3JhcGhpY3MpO1xuICAgICAgICBjdHgubW92ZVRvKC01NDAsIC0xMjUpO1xuICAgICAgICBjdHgubGluZVRvKDEwODAsIC0xMjUpO1xuICAgICAgICBjdHguc3Ryb2tlKCk7XG5cbiAgICAgICAgdmFyIGcgPSB0aGlzLk5vZGVCdXR0b25Cb3guZ2V0Q29tcG9uZW50KGNjLkdyYXBoaWNzKTtcbiAgICAgICAgZy5yb3VuZFJlY3QoLTc1LCAtMzUsIDE1MCwgNzAsIDEwKTtcbiAgICAgICAgZy5zdHJva2UoKTtcblxuICAgICAgICB0aGlzLk5vZGVCdXR0b24ub24oXCJ0b3VjaGVuZFwiLCB0aGlzLm9uQ2xpY2tJbnN0YWxsLCB0aGlzKTtcbiAgICB9LFxuICAgIGluaXRJbmZvOiBmdW5jdGlvbiBpbml0SW5mbyhkYXRhKSB7XG4gICAgICAgIHRoaXMuc2VsZkluZGV4ID0gZGF0YS5pbmRleDtcbiAgICAgICAgdGhpcy5nYW1lSWQgPSBkYXRhLmdhbWVJZDtcbiAgICAgICAgdGhpcy5MYWJlbE51bWJlci5zdHJpbmcgPSBkYXRhLmluZGV4O1xuICAgICAgICB0aGlzLkxhYmVsR2FtZU5hbWUuc3RyaW5nID0gZGF0YS5uYW1lO1xuICAgICAgICBpZiAodHlwZW9mIGRhdGEub25MaW5lQ291bnQgPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgICAgIGRhdGEub25MaW5lQ291bnQgPSAwO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuTGFiZWxQbGF5ZXJOdW0uc3RyaW5nID0gZGF0YS5vbkxpbmVDb3VudCArIFwi5Lq6XCI7XG4gICAgICAgIHRoaXMuTGFiZWxEZXNjLnN0cmluZyA9IGRhdGEuZGVzYztcblxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgICAgIGNjLmxvYWRlci5sb2FkKGRhdGEuaW1nVXJsLCBmdW5jdGlvbiAoZXJyLCB0ZXh0dXJlKSB7XG4gICAgICAgICAgICB2YXIgZnJhbWUgPSBuZXcgY2MuU3ByaXRlRnJhbWUodGV4dHVyZSk7XG4gICAgICAgICAgICBzZWxmLlNwcml0ZUljb24uc3ByaXRlRnJhbWUgPSBmcmFtZTtcbiAgICAgICAgfSk7XG4gICAgfSxcbiAgICB1cGRhdGVPbmxpbmVDb3VudDogZnVuY3Rpb24gdXBkYXRlT25saW5lQ291bnQoKSB7XG4gICAgICAgIHRoaXMuTGFiZWxQbGF5ZXJOdW0uc3RyaW5nID0gZGF0YS5wbGF5ZXJzTnVtICsgXCLkurpcIjtcbiAgICB9LFxuICAgIG9uQ2xpY2tJbnN0YWxsOiBmdW5jdGlvbiBvbkNsaWNrSW5zdGFsbChldmVudCkge1xuICAgICAgICB2YXIgZ2FtZUlkID0gdGhpcy5nYW1lSWQ7XG4gICAgICAgIEdsb2JhbE1hbmFnZXIuaW5zdGFuY2UuR2FtZU5vZGVBZGRDb21wb25lbnQoZ2FtZUlkLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLnNlbGZEYXRhLm5DdXJHYW1lSUQgPSBnYW1lSWQ7XG4gICAgICAgICAgICBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLkdldEdhbWVDb250cm9sbGVyKGdhbWVJZCkuU2VuZE1zZyhjb25zdERlZi5DT05ORUNUX0NBTExCQUNLX1NUQVRVUy5MT0dPTl9HRVRfR0FNRV9JTkZPKTtcbiAgICAgICAgfSk7XG4gICAgfVxufSk7XG5cbmNjLl9SRnBvcCgpOyIsIlwidXNlIHN0cmljdFwiO1xuY2MuX1JGcHVzaChtb2R1bGUsICc5MDc0YkVjNGlKSjBvVHNJNzU2Ri9jRScsICdtYWluJyk7XG4vLyBHbG9iYWwvc2VydmljZS9jb250cm9sbGVyL21haW4uanNcblxudmFyIEdsb2JhbE1hbmFnZXIgPSByZXF1aXJlKFwiR2xvYmFsTWFuYWdlclwiKTtcbnZhciBjb25zdERlZiA9IHJlcXVpcmUoXCJDb25zdERlZlwiKTtcblxuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7fSxcblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge1xuICAgICAgICBHbG9iYWxNYW5hZ2VyLmluc3RhbmNlLmNvbmZEYXRhLmxvYWRDb25mSnNvbigpO1xuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJsb2dvblwiKTtcbiAgICB9XG5cbn0pO1xuXG5jYy5fUkZwb3AoKTsiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnODUxNzh1TlBUdExuN1pJQjFFaHF4U0EnLCAnbWQ1Jyk7XG4vLyBHbG9iYWwvcWlzdUxpYi9iYXNlL21kNS5qc1xuXG52YXIgbWQ1ID0ge1xuICAgICAgICBtZDU6IGZ1bmN0aW9uIG1kNShzdHJpbmcpIHtcbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBtZDVfUm90YXRlTGVmdChsVmFsdWUsIGlTaGlmdEJpdHMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBsVmFsdWUgPDwgaVNoaWZ0Qml0cyB8IGxWYWx1ZSA+Pj4gMzIgLSBpU2hpZnRCaXRzO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBtZDVfQWRkVW5zaWduZWQobFgsIGxZKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgbFg0LCBsWTQsIGxYOCwgbFk4LCBsUmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICAgICAgbFg4ID0gbFggJiAweDgwMDAwMDAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgbFk4ID0gbFkgJiAweDgwMDAwMDAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgbFg0ID0gbFggJiAweDQwMDAwMDAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgbFk0ID0gbFkgJiAweDQwMDAwMDAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgbFJlc3VsdCA9IChsWCAmIDB4M0ZGRkZGRkYpICsgKGxZICYgMHgzRkZGRkZGRik7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAobFg0ICYgbFk0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBsUmVzdWx0IF4gMHg4MDAwMDAwMCBeIGxYOCBeIGxZODtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChsWDQgfCBsWTQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGxSZXN1bHQgJiAweDQwMDAwMDAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGxSZXN1bHQgXiAweEMwMDAwMDAwIF4gbFg4IF4gbFk4O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBsUmVzdWx0IF4gMHg0MDAwMDAwMCBeIGxYOCBeIGxZODtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGxSZXN1bHQgXiBsWDggXiBsWTg7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGZ1bmN0aW9uIG1kNV9GKHgsIHksIHopIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB4ICYgeSB8IH54ICYgejtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZnVuY3Rpb24gbWQ1X0coeCwgeSwgeikge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHggJiB6IHwgeSAmIH56O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBtZDVfSCh4LCB5LCB6KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4geCBeIHkgXiB6O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBtZDVfSSh4LCB5LCB6KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4geSBeICh4IHwgfnopO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBtZDVfRkYoYSwgYiwgYywgZCwgeCwgcywgYWMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGEgPSBtZDVfQWRkVW5zaWduZWQoYSwgbWQ1X0FkZFVuc2lnbmVkKG1kNV9BZGRVbnNpZ25lZChtZDVfRihiLCBjLCBkKSwgeCksIGFjKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbWQ1X0FkZFVuc2lnbmVkKG1kNV9Sb3RhdGVMZWZ0KGEsIHMpLCBiKTtcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIGZ1bmN0aW9uIG1kNV9HRyhhLCBiLCBjLCBkLCB4LCBzLCBhYykge1xuICAgICAgICAgICAgICAgICAgICAgICAgYSA9IG1kNV9BZGRVbnNpZ25lZChhLCBtZDVfQWRkVW5zaWduZWQobWQ1X0FkZFVuc2lnbmVkKG1kNV9HKGIsIGMsIGQpLCB4KSwgYWMpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBtZDVfQWRkVW5zaWduZWQobWQ1X1JvdGF0ZUxlZnQoYSwgcyksIGIpO1xuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgZnVuY3Rpb24gbWQ1X0hIKGEsIGIsIGMsIGQsIHgsIHMsIGFjKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBhID0gbWQ1X0FkZFVuc2lnbmVkKGEsIG1kNV9BZGRVbnNpZ25lZChtZDVfQWRkVW5zaWduZWQobWQ1X0goYiwgYywgZCksIHgpLCBhYykpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG1kNV9BZGRVbnNpZ25lZChtZDVfUm90YXRlTGVmdChhLCBzKSwgYik7XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBtZDVfSUkoYSwgYiwgYywgZCwgeCwgcywgYWMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGEgPSBtZDVfQWRkVW5zaWduZWQoYSwgbWQ1X0FkZFVuc2lnbmVkKG1kNV9BZGRVbnNpZ25lZChtZDVfSShiLCBjLCBkKSwgeCksIGFjKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbWQ1X0FkZFVuc2lnbmVkKG1kNV9Sb3RhdGVMZWZ0KGEsIHMpLCBiKTtcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIGZ1bmN0aW9uIG1kNV9Db252ZXJ0VG9Xb3JkQXJyYXkoc3RyaW5nKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgbFdvcmRDb3VudDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBsTWVzc2FnZUxlbmd0aCA9IHN0cmluZy5sZW5ndGg7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgbE51bWJlck9mV29yZHNfdGVtcDEgPSBsTWVzc2FnZUxlbmd0aCArIDg7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgbE51bWJlck9mV29yZHNfdGVtcDIgPSAobE51bWJlck9mV29yZHNfdGVtcDEgLSBsTnVtYmVyT2ZXb3Jkc190ZW1wMSAlIDY0KSAvIDY0O1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGxOdW1iZXJPZldvcmRzID0gKGxOdW1iZXJPZldvcmRzX3RlbXAyICsgMSkgKiAxNjtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBsV29yZEFycmF5ID0gQXJyYXkobE51bWJlck9mV29yZHMgLSAxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBsQnl0ZVBvc2l0aW9uID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBsQnl0ZUNvdW50ID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHdoaWxlIChsQnl0ZUNvdW50IDwgbE1lc3NhZ2VMZW5ndGgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbFdvcmRDb3VudCA9IChsQnl0ZUNvdW50IC0gbEJ5dGVDb3VudCAlIDQpIC8gNDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbEJ5dGVQb3NpdGlvbiA9IGxCeXRlQ291bnQgJSA0ICogODtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbFdvcmRBcnJheVtsV29yZENvdW50XSA9IGxXb3JkQXJyYXlbbFdvcmRDb3VudF0gfCBzdHJpbmcuY2hhckNvZGVBdChsQnl0ZUNvdW50KSA8PCBsQnl0ZVBvc2l0aW9uO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsQnl0ZUNvdW50Kys7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBsV29yZENvdW50ID0gKGxCeXRlQ291bnQgLSBsQnl0ZUNvdW50ICUgNCkgLyA0O1xuICAgICAgICAgICAgICAgICAgICAgICAgbEJ5dGVQb3NpdGlvbiA9IGxCeXRlQ291bnQgJSA0ICogODtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxXb3JkQXJyYXlbbFdvcmRDb3VudF0gPSBsV29yZEFycmF5W2xXb3JkQ291bnRdIHwgMHg4MCA8PCBsQnl0ZVBvc2l0aW9uO1xuICAgICAgICAgICAgICAgICAgICAgICAgbFdvcmRBcnJheVtsTnVtYmVyT2ZXb3JkcyAtIDJdID0gbE1lc3NhZ2VMZW5ndGggPDwgMztcbiAgICAgICAgICAgICAgICAgICAgICAgIGxXb3JkQXJyYXlbbE51bWJlck9mV29yZHMgLSAxXSA9IGxNZXNzYWdlTGVuZ3RoID4+PiAyOTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBsV29yZEFycmF5O1xuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgZnVuY3Rpb24gbWQ1X1dvcmRUb0hleChsVmFsdWUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBXb3JkVG9IZXhWYWx1ZSA9IFwiXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgV29yZFRvSGV4VmFsdWVfdGVtcCA9IFwiXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbEJ5dGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbENvdW50O1xuICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChsQ291bnQgPSAwOyBsQ291bnQgPD0gMzsgbENvdW50KyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbEJ5dGUgPSBsVmFsdWUgPj4+IGxDb3VudCAqIDggJiAyNTU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFdvcmRUb0hleFZhbHVlX3RlbXAgPSBcIjBcIiArIGxCeXRlLnRvU3RyaW5nKDE2KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgV29yZFRvSGV4VmFsdWUgPSBXb3JkVG9IZXhWYWx1ZSArIFdvcmRUb0hleFZhbHVlX3RlbXAuc3Vic3RyKFdvcmRUb0hleFZhbHVlX3RlbXAubGVuZ3RoIC0gMiwgMik7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gV29yZFRvSGV4VmFsdWU7XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBtZDVfVXRmOEVuY29kZShzdHJpbmcpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0cmluZyA9IHN0cmluZy5yZXBsYWNlKC9cXHJcXG4vZywgXCJcXG5cIik7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgdXRmdGV4dCA9IFwiXCI7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBuID0gMDsgbiA8IHN0cmluZy5sZW5ndGg7IG4rKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgYyA9IHN0cmluZy5jaGFyQ29kZUF0KG4pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoYyA8IDEyOCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHV0ZnRleHQgKz0gU3RyaW5nLmZyb21DaGFyQ29kZShjKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChjID4gMTI3ICYmIGMgPCAyMDQ4KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXRmdGV4dCArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKGMgPj4gNiB8IDE5Mik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXRmdGV4dCArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKGMgJiA2MyB8IDEyOCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXRmdGV4dCArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKGMgPj4gMTIgfCAyMjQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHV0ZnRleHQgKz0gU3RyaW5nLmZyb21DaGFyQ29kZShjID4+IDYgJiA2MyB8IDEyOCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXRmdGV4dCArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKGMgJiA2MyB8IDEyOCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB1dGZ0ZXh0O1xuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgdmFyIHggPSBBcnJheSgpO1xuICAgICAgICAgICAgICAgIHZhciBrLCBBQSwgQkIsIENDLCBERCwgYSwgYiwgYywgZDtcbiAgICAgICAgICAgICAgICB2YXIgUzExID0gNyxcbiAgICAgICAgICAgICAgICAgICAgUzEyID0gMTIsXG4gICAgICAgICAgICAgICAgICAgIFMxMyA9IDE3LFxuICAgICAgICAgICAgICAgICAgICBTMTQgPSAyMjtcbiAgICAgICAgICAgICAgICB2YXIgUzIxID0gNSxcbiAgICAgICAgICAgICAgICAgICAgUzIyID0gOSxcbiAgICAgICAgICAgICAgICAgICAgUzIzID0gMTQsXG4gICAgICAgICAgICAgICAgICAgIFMyNCA9IDIwO1xuICAgICAgICAgICAgICAgIHZhciBTMzEgPSA0LFxuICAgICAgICAgICAgICAgICAgICBTMzIgPSAxMSxcbiAgICAgICAgICAgICAgICAgICAgUzMzID0gMTYsXG4gICAgICAgICAgICAgICAgICAgIFMzNCA9IDIzO1xuICAgICAgICAgICAgICAgIHZhciBTNDEgPSA2LFxuICAgICAgICAgICAgICAgICAgICBTNDIgPSAxMCxcbiAgICAgICAgICAgICAgICAgICAgUzQzID0gMTUsXG4gICAgICAgICAgICAgICAgICAgIFM0NCA9IDIxO1xuICAgICAgICAgICAgICAgIHN0cmluZyA9IG1kNV9VdGY4RW5jb2RlKHN0cmluZyk7XG4gICAgICAgICAgICAgICAgeCA9IG1kNV9Db252ZXJ0VG9Xb3JkQXJyYXkoc3RyaW5nKTtcbiAgICAgICAgICAgICAgICBhID0gMHg2NzQ1MjMwMTtiID0gMHhFRkNEQUI4OTtjID0gMHg5OEJBRENGRTtkID0gMHgxMDMyNTQ3NjtcbiAgICAgICAgICAgICAgICBmb3IgKGsgPSAwOyBrIDwgeC5sZW5ndGg7IGsgKz0gMTYpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIEFBID0gYTtCQiA9IGI7Q0MgPSBjO0REID0gZDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGEgPSBtZDVfRkYoYSwgYiwgYywgZCwgeFtrICsgMF0sIFMxMSwgMHhENzZBQTQ3OCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBkID0gbWQ1X0ZGKGQsIGEsIGIsIGMsIHhbayArIDFdLCBTMTIsIDB4RThDN0I3NTYpO1xuICAgICAgICAgICAgICAgICAgICAgICAgYyA9IG1kNV9GRihjLCBkLCBhLCBiLCB4W2sgKyAyXSwgUzEzLCAweDI0MjA3MERCKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGIgPSBtZDVfRkYoYiwgYywgZCwgYSwgeFtrICsgM10sIFMxNCwgMHhDMUJEQ0VFRSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBhID0gbWQ1X0ZGKGEsIGIsIGMsIGQsIHhbayArIDRdLCBTMTEsIDB4RjU3QzBGQUYpO1xuICAgICAgICAgICAgICAgICAgICAgICAgZCA9IG1kNV9GRihkLCBhLCBiLCBjLCB4W2sgKyA1XSwgUzEyLCAweDQ3ODdDNjJBKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGMgPSBtZDVfRkYoYywgZCwgYSwgYiwgeFtrICsgNl0sIFMxMywgMHhBODMwNDYxMyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBiID0gbWQ1X0ZGKGIsIGMsIGQsIGEsIHhbayArIDddLCBTMTQsIDB4RkQ0Njk1MDEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgYSA9IG1kNV9GRihhLCBiLCBjLCBkLCB4W2sgKyA4XSwgUzExLCAweDY5ODA5OEQ4KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGQgPSBtZDVfRkYoZCwgYSwgYiwgYywgeFtrICsgOV0sIFMxMiwgMHg4QjQ0RjdBRik7XG4gICAgICAgICAgICAgICAgICAgICAgICBjID0gbWQ1X0ZGKGMsIGQsIGEsIGIsIHhbayArIDEwXSwgUzEzLCAweEZGRkY1QkIxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGIgPSBtZDVfRkYoYiwgYywgZCwgYSwgeFtrICsgMTFdLCBTMTQsIDB4ODk1Q0Q3QkUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgYSA9IG1kNV9GRihhLCBiLCBjLCBkLCB4W2sgKyAxMl0sIFMxMSwgMHg2QjkwMTEyMik7XG4gICAgICAgICAgICAgICAgICAgICAgICBkID0gbWQ1X0ZGKGQsIGEsIGIsIGMsIHhbayArIDEzXSwgUzEyLCAweEZEOTg3MTkzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGMgPSBtZDVfRkYoYywgZCwgYSwgYiwgeFtrICsgMTRdLCBTMTMsIDB4QTY3OTQzOEUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgYiA9IG1kNV9GRihiLCBjLCBkLCBhLCB4W2sgKyAxNV0sIFMxNCwgMHg0OUI0MDgyMSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBhID0gbWQ1X0dHKGEsIGIsIGMsIGQsIHhbayArIDFdLCBTMjEsIDB4RjYxRTI1NjIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgZCA9IG1kNV9HRyhkLCBhLCBiLCBjLCB4W2sgKyA2XSwgUzIyLCAweEMwNDBCMzQwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGMgPSBtZDVfR0coYywgZCwgYSwgYiwgeFtrICsgMTFdLCBTMjMsIDB4MjY1RTVBNTEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgYiA9IG1kNV9HRyhiLCBjLCBkLCBhLCB4W2sgKyAwXSwgUzI0LCAweEU5QjZDN0FBKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGEgPSBtZDVfR0coYSwgYiwgYywgZCwgeFtrICsgNV0sIFMyMSwgMHhENjJGMTA1RCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBkID0gbWQ1X0dHKGQsIGEsIGIsIGMsIHhbayArIDEwXSwgUzIyLCAweDI0NDE0NTMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgYyA9IG1kNV9HRyhjLCBkLCBhLCBiLCB4W2sgKyAxNV0sIFMyMywgMHhEOEExRTY4MSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBiID0gbWQ1X0dHKGIsIGMsIGQsIGEsIHhbayArIDRdLCBTMjQsIDB4RTdEM0ZCQzgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgYSA9IG1kNV9HRyhhLCBiLCBjLCBkLCB4W2sgKyA5XSwgUzIxLCAweDIxRTFDREU2KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGQgPSBtZDVfR0coZCwgYSwgYiwgYywgeFtrICsgMTRdLCBTMjIsIDB4QzMzNzA3RDYpO1xuICAgICAgICAgICAgICAgICAgICAgICAgYyA9IG1kNV9HRyhjLCBkLCBhLCBiLCB4W2sgKyAzXSwgUzIzLCAweEY0RDUwRDg3KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGIgPSBtZDVfR0coYiwgYywgZCwgYSwgeFtrICsgOF0sIFMyNCwgMHg0NTVBMTRFRCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBhID0gbWQ1X0dHKGEsIGIsIGMsIGQsIHhbayArIDEzXSwgUzIxLCAweEE5RTNFOTA1KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGQgPSBtZDVfR0coZCwgYSwgYiwgYywgeFtrICsgMl0sIFMyMiwgMHhGQ0VGQTNGOCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjID0gbWQ1X0dHKGMsIGQsIGEsIGIsIHhbayArIDddLCBTMjMsIDB4Njc2RjAyRDkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgYiA9IG1kNV9HRyhiLCBjLCBkLCBhLCB4W2sgKyAxMl0sIFMyNCwgMHg4RDJBNEM4QSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBhID0gbWQ1X0hIKGEsIGIsIGMsIGQsIHhbayArIDVdLCBTMzEsIDB4RkZGQTM5NDIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgZCA9IG1kNV9ISChkLCBhLCBiLCBjLCB4W2sgKyA4XSwgUzMyLCAweDg3NzFGNjgxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGMgPSBtZDVfSEgoYywgZCwgYSwgYiwgeFtrICsgMTFdLCBTMzMsIDB4NkQ5RDYxMjIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgYiA9IG1kNV9ISChiLCBjLCBkLCBhLCB4W2sgKyAxNF0sIFMzNCwgMHhGREU1MzgwQyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBhID0gbWQ1X0hIKGEsIGIsIGMsIGQsIHhbayArIDFdLCBTMzEsIDB4QTRCRUVBNDQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgZCA9IG1kNV9ISChkLCBhLCBiLCBjLCB4W2sgKyA0XSwgUzMyLCAweDRCREVDRkE5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGMgPSBtZDVfSEgoYywgZCwgYSwgYiwgeFtrICsgN10sIFMzMywgMHhGNkJCNEI2MCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBiID0gbWQ1X0hIKGIsIGMsIGQsIGEsIHhbayArIDEwXSwgUzM0LCAweEJFQkZCQzcwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGEgPSBtZDVfSEgoYSwgYiwgYywgZCwgeFtrICsgMTNdLCBTMzEsIDB4Mjg5QjdFQzYpO1xuICAgICAgICAgICAgICAgICAgICAgICAgZCA9IG1kNV9ISChkLCBhLCBiLCBjLCB4W2sgKyAwXSwgUzMyLCAweEVBQTEyN0ZBKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGMgPSBtZDVfSEgoYywgZCwgYSwgYiwgeFtrICsgM10sIFMzMywgMHhENEVGMzA4NSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBiID0gbWQ1X0hIKGIsIGMsIGQsIGEsIHhbayArIDZdLCBTMzQsIDB4NDg4MUQwNSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBhID0gbWQ1X0hIKGEsIGIsIGMsIGQsIHhbayArIDldLCBTMzEsIDB4RDlENEQwMzkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgZCA9IG1kNV9ISChkLCBhLCBiLCBjLCB4W2sgKyAxMl0sIFMzMiwgMHhFNkRCOTlFNSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjID0gbWQ1X0hIKGMsIGQsIGEsIGIsIHhbayArIDE1XSwgUzMzLCAweDFGQTI3Q0Y4KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGIgPSBtZDVfSEgoYiwgYywgZCwgYSwgeFtrICsgMl0sIFMzNCwgMHhDNEFDNTY2NSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBhID0gbWQ1X0lJKGEsIGIsIGMsIGQsIHhbayArIDBdLCBTNDEsIDB4RjQyOTIyNDQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgZCA9IG1kNV9JSShkLCBhLCBiLCBjLCB4W2sgKyA3XSwgUzQyLCAweDQzMkFGRjk3KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGMgPSBtZDVfSUkoYywgZCwgYSwgYiwgeFtrICsgMTRdLCBTNDMsIDB4QUI5NDIzQTcpO1xuICAgICAgICAgICAgICAgICAgICAgICAgYiA9IG1kNV9JSShiLCBjLCBkLCBhLCB4W2sgKyA1XSwgUzQ0LCAweEZDOTNBMDM5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGEgPSBtZDVfSUkoYSwgYiwgYywgZCwgeFtrICsgMTJdLCBTNDEsIDB4NjU1QjU5QzMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgZCA9IG1kNV9JSShkLCBhLCBiLCBjLCB4W2sgKyAzXSwgUzQyLCAweDhGMENDQzkyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGMgPSBtZDVfSUkoYywgZCwgYSwgYiwgeFtrICsgMTBdLCBTNDMsIDB4RkZFRkY0N0QpO1xuICAgICAgICAgICAgICAgICAgICAgICAgYiA9IG1kNV9JSShiLCBjLCBkLCBhLCB4W2sgKyAxXSwgUzQ0LCAweDg1ODQ1REQxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGEgPSBtZDVfSUkoYSwgYiwgYywgZCwgeFtrICsgOF0sIFM0MSwgMHg2RkE4N0U0Rik7XG4gICAgICAgICAgICAgICAgICAgICAgICBkID0gbWQ1X0lJKGQsIGEsIGIsIGMsIHhbayArIDE1XSwgUzQyLCAweEZFMkNFNkUwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGMgPSBtZDVfSUkoYywgZCwgYSwgYiwgeFtrICsgNl0sIFM0MywgMHhBMzAxNDMxNCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBiID0gbWQ1X0lJKGIsIGMsIGQsIGEsIHhbayArIDEzXSwgUzQ0LCAweDRFMDgxMUExKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGEgPSBtZDVfSUkoYSwgYiwgYywgZCwgeFtrICsgNF0sIFM0MSwgMHhGNzUzN0U4Mik7XG4gICAgICAgICAgICAgICAgICAgICAgICBkID0gbWQ1X0lJKGQsIGEsIGIsIGMsIHhbayArIDExXSwgUzQyLCAweEJEM0FGMjM1KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGMgPSBtZDVfSUkoYywgZCwgYSwgYiwgeFtrICsgMl0sIFM0MywgMHgyQUQ3RDJCQik7XG4gICAgICAgICAgICAgICAgICAgICAgICBiID0gbWQ1X0lJKGIsIGMsIGQsIGEsIHhbayArIDldLCBTNDQsIDB4RUI4NkQzOTEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgYSA9IG1kNV9BZGRVbnNpZ25lZChhLCBBQSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBiID0gbWQ1X0FkZFVuc2lnbmVkKGIsIEJCKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGMgPSBtZDVfQWRkVW5zaWduZWQoYywgQ0MpO1xuICAgICAgICAgICAgICAgICAgICAgICAgZCA9IG1kNV9BZGRVbnNpZ25lZChkLCBERCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiAobWQ1X1dvcmRUb0hleChhKSArIG1kNV9Xb3JkVG9IZXgoYikgKyBtZDVfV29yZFRvSGV4KGMpICsgbWQ1X1dvcmRUb0hleChkKSkudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgfVxuXG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IG1kNTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJ2JiNDg2c2tDREZBODVHV3NkSkNCQmp3JywgJ21lc3NhZ2UnKTtcbi8vIHJlc291cmNlcy9jb21tb24vcHJlZmFiL21lc3NhZ2UvbWVzc2FnZS5qc1xuXG5jYy5DbGFzcyh7XG4gICAgXCJleHRlbmRzXCI6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHt9LFxuXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7XG4gICAgICAgIHZhciBjdHggPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLkdyYXBoaWNzKTtcbiAgICAgICAgY3R4Lm1vdmVUbygwLCAwKTtcbiAgICAgICAgY3R4LmxpbmVUbygxMDgwLCAwKTtcblxuICAgICAgICBjdHguc3Ryb2tlKCk7XG4gICAgfSxcbiAgICBpbml0SW5mbzogZnVuY3Rpb24gaW5pdEluZm8oZGF0YSkge31cbn0pO1xuXG5jYy5fUkZwb3AoKTsiXX0=
